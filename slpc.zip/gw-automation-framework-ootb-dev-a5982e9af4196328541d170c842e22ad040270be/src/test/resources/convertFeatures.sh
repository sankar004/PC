cd features
find . -type f -name "*.feature" | xargs sed --in-place=old/* -f ../sedConverter.txt
cd ..
