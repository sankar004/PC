package eu.sollers;

import static java.util.Arrays.asList;
import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.embedder.StoryControls;
import org.jbehave.core.embedder.StoryTimeouts.TimeoutParser;
import org.jbehave.core.failures.FailingUponPendingStep;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.UnderscoredToCapitalized;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.model.TableTransformers;
import org.jbehave.core.parsers.RegexStoryParser;
import org.jbehave.core.reporters.FilePrintStreamFactory;
import org.jbehave.core.reporters.FreemarkerViewGenerator;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.MarkUnmatchedStepsAsPending;
import org.jbehave.core.steps.ParameterConverters;
import org.openqa.selenium.remote.service.DriverService;

import eu.sollers.automation.glue.BATSAllureReporter;
import eu.sollers.automation.glue.BATSExamplesTableConverter;
import eu.sollers.automation.glue.BATSStoryReporterBuilder;
import eu.sollers.automation.glue.BATSXMLOutput;
import eu.sollers.automation.glue.InliningExamplesFileParser;
import eu.sollers.automation.glue.LineNumberParser;
import eu.sollers.automation.glue.LocalWebDriverHtmlOutput;
import eu.sollers.automation.glue.TranslatingGherkinStoryParser;
import eu.sollers.automation.helpers.CustomTimeoutParser;
import eu.sollers.automation.impl.misc.GwStringConverter;
import eu.sollers.automation.jbehave.GACStepsFactory;
import eu.sollers.automation.jbehave.core.io.BATSRegexCompositeParser;
import eu.sollers.automation.jbehave.core.io.BATSStoryLoader;
import eu.sollers.automation.performance.PerformanceRecorderStepMonitor;
import eu.sollers.automation.performance.PerformanceRecorderStoryReporter;
import eu.sollers.configuration.AutomationOptions;
import eu.sollers.core.io.BATSUnderscoredToCapitalized;


public class ThreadGherkinIT {
    DriverService driverService;
    String compositePath;
    String featurePath;
    Set<String> listOfComposites;
    String featureFilter;
    String tagFilter;
    List<String> storyPaths;
    Locale locale;
    Keywords keywords;
    GherkinIT gherkinITInstance;
    String lineNumbers;
    StoryReporterBuilder storyReporterBuilder;
    ExamplesTableFactory tableFactory;
    InjectableStepsFactory injectableStepsFactory;
    int threadsNumber;
    private Map<Integer, Map<Integer, List<String>>> prioritizedStoryPaths;

    public ThreadGherkinIT() {
    }

    public void initializateObject(DriverService driverService, String compositePath, String featurePath,
            Set<String> listOfComposites, String featureFilter, String tagFilter, List<String> storyPaths,
            Locale locale, Keywords keywords, GherkinIT gherkinITInstance, int threadsNumber) {
        this.driverService = driverService;
        this.compositePath = compositePath;
        this.featurePath = featurePath;
        this.listOfComposites = listOfComposites;
        this.featureFilter = featureFilter;
        this.keywords = keywords;
        this.locale = locale;
        this.storyPaths = storyPaths;
        this.tagFilter = tagFilter;
        this.gherkinITInstance = gherkinITInstance;
        this.threadsNumber = threadsNumber;
        preConfigure();
    }

    public ThreadGherkinIT getInstance() {
        return this;
    }

    public void runInstance() {

        setThreadsNumber(this.threadsNumber);
        this.gherkinITInstance.injectedEmbedder().useStepsFactory(getInstanceOfInjectableStepsFactory());
        setMetaFilters(getTagsListWithPlusSignes());
        this.gherkinITInstance.injectedEmbedder().mapStoriesAsPaths(storyPaths);
        setMetaFilters(tagFilter);
        this.gherkinITInstance.injectedEmbedder().runStoriesAsPaths(storyPaths);
    }

    private String getTagsListWithPlusSignes() {
        return "+" + AutomationOptions.getConfiguration().tagsList.trim().replaceAll("\\s([^\\s])", " +$1");
    }

    private void setMetaFilters(String tagsList) {
        this.gherkinITInstance.injectedEmbedder().useMetaFilters(asList(tagsList.split(" ")));
    }

    public void runInstance(Map<Integer, Map<Integer, List<String>>> prioritizedStoryPaths) {
        setMetaFilters(getTagsListWithPlusSignes());
        this.gherkinITInstance.injectedEmbedder().mapStoriesAsPaths(storyPaths);
        setMetaFilters(tagFilter);
        prioritizedStoryPaths.forEach((priority, map) -> {
            map.forEach((threads, paths) -> {
                setThreadsNumber(threads);
                this.gherkinITInstance.injectedEmbedder().useStepsFactory(getInstanceOfInjectableStepsFactory());
                this.gherkinITInstance.injectedEmbedder().runStoriesAsPaths(paths);
            });
        });
    }

    private void preConfigure() {
        this.gherkinITInstance.injectedEmbedder()
                .embedderControls()
                .doGenerateViewAfterStories(true)
                .doIgnoreFailureInStories(true)
                .doIgnoreFailureInView(true)
                .doVerboseFiltering(true);
        this.gherkinITInstance.injectedEmbedder().useTimeoutParsers(new CustomTimeoutParser());
        setLineNumbers();
        setTableFactory();
        setStoryReporterBuilder();
        configureEmbedder();
    }

    private InjectableStepsFactory getInstanceOfInjectableStepsFactory() {
        if (this.injectableStepsFactory == null) {
            this.injectableStepsFactory = GACStepsFactory.buildStepsFactory(
                    this.gherkinITInstance.injectedEmbedder().configuration(), this.gherkinITInstance.getClass());
        }
        return this.injectableStepsFactory;
    }

    private void setLineNumbers() {
        this.lineNumbers = LineNumberParser.getLineNumbers(
                Optional.ofNullable(System.getProperty("lineNumbers")).orElse(null));
    }

    private void setTableFactory() {
        this.tableFactory = new ExamplesTableFactory(keywords, new LoadFromClasspath(this.gherkinITInstance.getClass()),
                new TableTransformers());
    }

    private void setStoryReporterBuilder() {
        this.storyReporterBuilder = new BATSStoryReporterBuilder().withCodeLocation(
                CodeLocations.codeLocationFromClass(this.gherkinITInstance.getClass()))
                .withDefaultFormats()
                .withPathResolver(new FilePrintStreamFactory.ResolveToPackagedName())
                .withKeywords(keywords)
                .withFormats(CONSOLE, LocalWebDriverHtmlOutput.WEB_DRIVER_HTML, BATSXMLOutput.XML_OUTPUT);
    }

    private void configureEmbedder() {
        this.gherkinITInstance.injectedEmbedder()
                .configuration()
                .useStoryLoader(new BATSStoryLoader(new LocalizedKeywords(locale)))
                .useStoryParser(new InliningExamplesFileParser(
                        new TranslatingGherkinStoryParser(new RegexStoryParser(keywords, tableFactory), keywords),
                        keywords, lineNumbers))
                .useStoryReporterBuilder(storyReporterBuilder.withReporters(new BATSAllureReporter(),
                        PerformanceRecorderStoryReporter.createPerformanceRecorderStoryReporter(
                                this.gherkinITInstance.injectedEmbedder()))
                        .withCodeLocation(CodeLocations.codeLocationFromClass(this.gherkinITInstance.getClass()))
                        .withDefaultFormats()
                        .withFormats(CONSOLE, HTML)
                        .withFailureTrace(true)
                        .withFailureTraceCompression(true))
                .useCompositePaths(listOfComposites)
                .useCompositeParser(new BATSRegexCompositeParser(keywords))
                .useKeywords(keywords)
                .useStepCollector(new MarkUnmatchedStepsAsPending(keywords))
                .useParameterConverters(
                        new ParameterConverters().addConverters(new BATSExamplesTableConverter(tableFactory),
                                new GwStringConverter()))
                .useStoryControls(new StoryControls().doResetStateBeforeStory(true))
                .useStepMonitor(PerformanceRecorderStepMonitor.createPerformanceRecorderStepMonitor())
                .useViewGenerator(
                        new FreemarkerViewGenerator(new BATSUnderscoredToCapitalized(), FreemarkerViewGenerator.class))
                .usePendingStepStrategy(new FailingUponPendingStep());
    }

    private void setThreadsNumber(int threadsNumber) {
        this.gherkinITInstance.injectedEmbedder()
                .embedderControls()
                .useThreads(threadsNumber)
                .useStoryTimeouts("0secs")
                .doFailOnStoryTimeout(false);
    }
}
