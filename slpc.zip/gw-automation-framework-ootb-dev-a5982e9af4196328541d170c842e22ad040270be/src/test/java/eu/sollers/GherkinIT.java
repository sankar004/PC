package eu.sollers;

import static org.jbehave.core.io.CodeLocations.codeLocationFromClass;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import eu.sollers.steps.ADJCustomSteps;
import org.jbehave.core.InjectableEmbedder;
import org.jbehave.core.annotations.UsingEmbedder;
import org.jbehave.core.annotations.UsingSteps;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.io.StoryFinder;
import org.jbehave.core.junit.AnnotatedEmbedderRunner;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.remote.service.DriverService;

import eu.sollers.steps.ADJCustomSteps;
import eu.sollers.automation.core.StoryPrioritizer;
import eu.sollers.automation.core.driver.WebDriverManager;
import eu.sollers.automation.glue.AssertionSteps;
import eu.sollers.automation.glue.CEAM_V7SpecificSteps;
import eu.sollers.automation.glue.CenterPanelSteps;
import eu.sollers.automation.glue.CentersLogSteps;
import eu.sollers.automation.glue.CombinedLocalizedKeywords;
import eu.sollers.automation.glue.CommonSteps;
import eu.sollers.automation.glue.DateSteps;
import eu.sollers.automation.glue.FailOnScreenshot;
import eu.sollers.automation.glue.FullScreenSteps;
import eu.sollers.automation.glue.Hooks;
import eu.sollers.automation.glue.IntegrationSteps;
import eu.sollers.automation.glue.LogicSteps;
import eu.sollers.automation.glue.NorthPanelSteps;
import eu.sollers.automation.glue.PortalFullScreenSteps;
import eu.sollers.automation.glue.PortalLogSteps;
import eu.sollers.automation.glue.QnBV7SpecificSteps;
import eu.sollers.automation.glue.ScreenCaptureSteps;
import eu.sollers.automation.glue.SideBarSteps;
import eu.sollers.automation.glue.SouthPanelSteps;
import eu.sollers.automation.glue.TableAssertionSteps;
import eu.sollers.automation.glue.TableSteps;
import eu.sollers.automation.glue.WebServicesSteps;
import eu.sollers.automation.glue.WestPanelSteps;
import eu.sollers.automation.jbehave.GACEmbedder;
import eu.sollers.configuration.AutomationOptions;
import eu.sollers.webdav.WebDavIntegration;

/**
 * Class used to invoke Gherkin Scenarios as JUnit tests using the cucumber libraries.
 * <p>
 * IT stands for "integration test" and the IT suffix is important, so that the class will be picked up by the
 * <code>maven-failsafe-plugin</code>.
 * </p>
 */
@RunWith(AnnotatedEmbedderRunner.class)
@UsingEmbedder(embedder = GACEmbedder.class)
@UsingSteps(instances = { FailOnScreenshot.class, AssertionSteps.class, NorthPanelSteps.class, SouthPanelSteps.class,
        WestPanelSteps.class, CenterPanelSteps.class, FullScreenSteps.class, LogicSteps.class, CentersLogSteps.class,
        Hooks.class, TableSteps.class, TableAssertionSteps.class, DateSteps.class,
        IntegrationSteps.class, PortalLogSteps.class, PortalFullScreenSteps.class,
        Hooks.class, TableSteps.class, TableAssertionSteps.class, DateSteps.class,
        IntegrationSteps.class, PortalLogSteps.class, PortalFullScreenSteps.class,
        SideBarSteps.class, QnBV7SpecificSteps.class, CEAM_V7SpecificSteps.class, ScreenCaptureSteps.class,
        WebDavIntegration.class, WebServicesSteps.class, CommonSteps.class, ADJCustomSteps.class
})

public class GherkinIT extends InjectableEmbedder {
    private static DriverService driverService;
    private String compositePath = AutomationOptions.getConfiguration().compositesPreprocessedDirectory.toString()
            .concat("/");
    private String featurePath = AutomationOptions.getConfiguration().featuresPreprocessedDirectory.toString()
            .concat("/");
    private Map<Integer, Map<Integer, List<String>>> prioritizedStoryPaths; //Contains information about threads numbers on story as well
    private final Set<String> listOfComposites = new HashSet<>(
            Arrays.asList(compositePath.concat("ADJ_PC_composite.steps"),
                    compositePath.concat("ADJ_BC_composite.steps"),
                    compositePath.concat("ADJ_All_Centers_composite.steps"),
                    compositePath.concat("Universal_Composites.steps")));

    @Override
    @Test
    public void run() {
        String featureFilter = featurePath.concat(Optional.ofNullable(System.getProperty("featureFilter"))
                .orElse("/**/*.feature"));
        String tagFilter = Optional.ofNullable(System.getProperty("tagFilter"))
                .orElse("-obsolete -bcTest");
        List<String> storyPaths = new StoryFinder().findPaths(codeLocationFromClass(this.getClass()),
                featureFilter,"");
        final Locale locale = Locale.forLanguageTag(AutomationOptions.getConfiguration().featureLanguage);
        Keywords keywords = new CombinedLocalizedKeywords(locale);
        StoryPrioritizer storyPrioritizer = new StoryPrioritizer(storyPaths);
        this.prioritizedStoryPaths = storyPrioritizer.getPrioritizedStoryPaths();

        ThreadGherkinIT threadGherkinIT = new ThreadGherkinIT();
        threadGherkinIT.initializateObject(driverService, compositePath, featurePath,
                listOfComposites, featureFilter, tagFilter, storyPaths, locale, keywords, this, storyPrioritizer.getThreadsNumber());
        threadGherkinIT.runInstance(this.prioritizedStoryPaths);

    }
    @BeforeClass
    public static void startDriver() {
        Hooks.validateAutomationOptions();
        driverService = WebDriverManager.init(AutomationOptions.getConfiguration());
    }

    @AfterClass
    public static void tearDownDriver() {
        if (driverService != null) {
            driverService.stop();
        }
    }
}
