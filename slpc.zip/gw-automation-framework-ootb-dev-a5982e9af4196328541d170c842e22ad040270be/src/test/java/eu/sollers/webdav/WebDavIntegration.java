package eu.sollers.webdav;

import com.github.sardine.SardineFactory;
import com.github.sardine.Sardine;

import org.apache.commons.io.FileUtils;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.io.*;
import java.nio.file.NoSuchFileException;

public class WebDavIntegration {

    @When("Simulating external integration, I save file from path '$path' as '$fileName' on server")
    public void sendFileToExternal(@Named("path") String filepath, @Named("fileName") String fileName) throws IOException {
        Sardine sardine = SardineFactory.begin("admin", "Haslo123");
        try (InputStream fis = new FileInputStream((new File(filepath)))) {
            sardine.put("http://gwdocs:8889/" + fileName, fis);
            if (sardine.exists("http://gwdocs:8889/" + fileName)) {
                System.out.println("File named " + fileName + " successfully delivered to the server");
            } else {
                System.out.println("File named " + fileName + " cannot be found on server");
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @When("Simulating external integration, I delete server file named '$fileName'")
    public void deleteFileFromExternal(@Named("fileName") String fileName) throws IOException {
        try {
            Sardine sardine = SardineFactory.begin("admin", "Haslo123");
            sardine.delete("http://gwdocs:8889/" + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Then("Simulating external integration, I check if file named '$fileName' exists on server")
    public void checkIfFileExist(@Named("fileName") String fileName) throws IOException {
        Sardine sardine = SardineFactory.begin("admin", "Haslo123");
        try {
            if (!sardine.exists("http://gwdocs:8889/" + fileName)) {
                throw new NoSuchFileException("Cannot find '" + fileName + "' on server");
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @When("Simulating external integration, I save file named '$fileName' from server at '$filepath'")
    public void saveFileFromServerOnPath(@Named("filepath") String filepath, @Named("fileName") String fileName) throws IOException {
        Sardine sardine = SardineFactory.begin("admin", "Haslo123");
        try (InputStream fis = sardine.get("http://gwdocs:8889/" + fileName)) {
            File file2 = new File(filepath + fileName);
            FileUtils.copyInputStreamToFile(fis, file2);
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Then("Simulating external integration, I check if file at '$filepath' is equal to file named '$fileName' on server")
    public void checkIfFileEqualsFileOnServer(@Named("filepath") String filepath, @Named("fileName") String fileName) throws IOException {
        Sardine sardine = SardineFactory.begin("admin", "Haslo123");
        try (InputStream fis = sardine.get("http://gwdocs:8889/" + fileName)) {
            File file1 = new File(filepath);
            File file2 = new File("src/main/resources/targetFile.tmp");
            FileUtils.copyInputStreamToFile(fis, file2);
            if (!FileUtils.contentEquals(file1, file2)) {
                throw new NoSuchFileException("Files used in assertion are not equal");
            }
            file2.deleteOnExit();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }
}

