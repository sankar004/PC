package eu.sollers.steps;

import eu.sollers.automation.aspect.ExclusionFlag;
import eu.sollers.automation.glue.FullScreenSteps;
import eu.sollers.automation.glue.Utils;
import eu.sollers.automation.helpers.SearchHelper;
import eu.sollers.automation.impl.controls.SelectedDropDown;
import eu.sollers.automation.impl.misc.DateUtil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ADJCustomSteps extends FullScreenSteps {

    private static final Logger LOGGER = LogManager.getLogger(ADJCustomSteps.class);

    @When("I set current server date attribute to '$currentDate'")
    public void setCurrentServerDateAttribute(String currentDate) {
        DateUtil.setCurrentServerDate(currentDate);
    }

    @When("If it is enabled I set dropdown in '$groupLabel' with label '$label' to '$value'")
    public void clickIfExists(@Named("groupLabel") String groupLabel, @Named("comboLabel") String comboLabel,
                              @Named("value") String value) {
        SearchHelper.SkipWait(() -> {
            WebElement dropdown = app.findElement(
                    By.xpath(String.format(app.getPattern("DROP_DOWN_BY_LABEL_IN_GROUP"), groupLabel, comboLabel)));
            if (dropdown.isEnabled()) {
                SelectedDropDown.create(dropdown).selectComboOptionByText(value);
            }
            app.waitForPageRefresh();
        });
    }

    @When("on Coverages screen, in group '$groupLabel' I set dropdown with label '$comboLabel' to '$value'")
    public void coveragesComboBoxSelectInGroup(@Named("grouplabel") String groupLabel,
                                               @Named("comboLabel") String comboLabel,
                                               @Named("value") String value) {
        SearchHelper.SkipWait(() -> {
            WebElement dropdown = app.findElement(
                    By.xpath(String.format(
                            app.getPattern("DROP_DOWN_BY_LABEL_IN_GROUP_ON_COVERAGES_SCREEN"), groupLabel, comboLabel)));
            SelectedDropDown.create(dropdown).selectComboOptionByText(value);
            app.waitForPageRefresh();
        });
    }

    @When("if there is text '$text' on the screen then exclude '$module'")
    public void setInclusionIfTextOnScreen(String text, String module) {
        boolean toExclude = false;
        try {
            SearchHelper.SkipWait(() -> app.findElement(By.xpath(String.format(app.getPattern("TEXT_ON_SCREEN"), text))));
            ExclusionFlag.FLAG_VALUE.set(module);
            toExclude = true;
            app.saveStepsAttributeValue(module, "true");
        } catch (NoSuchElementException e) {
            app.removeStepsAttributeWithName(module);
        }
        Utils.logConditionResult(toExclude, module, LOGGER);
    }

    @Then("I check if element with '$label' is disabled")
    public void isElementDisabled(String label) {
        WebElement element = SearchHelper.SkipWait(() -> {
            return app.findElement(By.xpath(String.format(app.getPattern("ELEMENT_BY_LABEL"), label)));
        });
        Assertions.assertThat(isElementDisabled(element)).isTrue();
    }
}
