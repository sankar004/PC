package eu.sollers.automation.aspect;

import eu.sollers.automation.glue.StepsBase;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class ConditionalIgnore {

    @Around("@annotation(org.jbehave.core.annotations.Given) || @annotation(org.jbehave.core.annotations.When) || @annotation(org.jbehave.core.annotations.Then)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        args = StepsBase.getSavedValues(args);
        return ExclusionFlag.FLAG_VALUE.get() == null ? joinPoint.proceed(args) : null;
    }
}
