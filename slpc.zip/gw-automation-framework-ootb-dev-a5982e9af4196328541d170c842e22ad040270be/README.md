# About the project

The project consists of two modules  `gw-automation-core` and  `gw-automation-ootb`. The core module contains page objects and step definitions of out of the box version of Guidewire.
In customer module you can add client-specific test scenarios, step definitions and required classes. To create customer module, simply copy gw-framework-ootb and rename it as needed.
# Using `gw-automation-core` and `gw-automation-customer` in your GW project

For the examplary project see:
  1. `gw-automation-core`  <a href="http://gitlab/guidewire/gw-automation-framework-core/">core</a>.
  2. `gw-automation-ootb`  <a href="http://gitlab/guidewire/gw-automation-framework-ootb">ootb </a>.

# Development prerequisities

In order to build the project you need maven 3.5.0 or newer.

The project is meant to be worked on from **IntelliJ IDEA 2018.1.2** with `Cucumber for java` plugin installed. Older versions of IntelliJ IDEA contain incompatible version of the plugin and will cause make running feature files from IDE fail. 

# Architecture

Modules `gw-automation-core` consists of three main packages:
1. `eu.sollers.automation.core`  
Contains implementation of core classes for the rest of the project, such as `WebDriverManager`.
2. `eu.sollers.automation.glue`  
Step definitions.
3. `eu.sollers.automation.impl`  
Contains implementation of steps using the WebDriver interface.

Modules `gw-automation-ootb` consists of an important folder:
- features, folder where the written scenarios are stored.


## Step development

Steps are developed mainly in the impl package where they are divided in a manageble way via the PCF control or PCF region they automate. Each step represents a basic action that a tester may consider as atomic operation.
Once impl part is written, step has to be made visible to cucumber by means of one of the glue tags (When, Then, And) and it's regural expression. This is done in the glue package.

## Downloading WebDrivers

In order to run the automation tests you will need to have some webdriver server. These are downloadable from the internet and are not committed to this repository. Instead you should download and use the drivers using the maven goal:

`mvn com.lazerycode.selenium:driver-binary-downloader-maven-plugin:1.0.17:selenium`

You can execute it either directly from command line (from the project root) or from IntelliJ idea in `view > tool windows > maven projects` and then by selecting `gw-automation-core > Plugins > driver-binary-downloader > driver-binary-downloader:selenium` in the Maven Projects panel.  

This command will download the drivers into `src/test/resources/selenium_standalone_binaries`.

## Running Gherkin tests in IDE

You can right-click the feature file or a scenario and press run. This will create a new run configuration using your defaults for Cucumber-java.

You have to make sure that your default java-cucumber run configuration provides necessary `AutomationOptions`. You can this in IntelliJ by opening `Run > Edit Configuraitons... > VM options:` and putting `-ea -Dautomation.config=src/test/resources/configs/maven-automation.properties`
 aslo in ` Working directory:` select a folder ` gw-automation-framework-ootb`. Tests should execute successfully.  

# Building the project

The project should be fully using `mvn verify` which will execute all unit tests as well as integration tests (i.e. GherkinIT) for the implemented steps.

# Maven properties

The file maven-automation.properties contains parameters which are required for continuous integration tests. For local parameters as a browser, urls for XCenters and display test on screen use environment variables.  

# Using environment variables

There are following environment variables which should be set prior to tests proceeding:
 - AUTOMATION_BROWSER = browser name ie. chrome, firefox etc.
 - AUTOMATION_BROWSER_HEADLESS = false/true - determined if test is displayed
 - AUTOMATION_AB_URL = urls for test centers
 - AUTOMATION_BC_URL
 - AUTOMATION_CC_URL
 - AUTOMATION_PC_URL
                        
They should be set either as system or user variables.                        
