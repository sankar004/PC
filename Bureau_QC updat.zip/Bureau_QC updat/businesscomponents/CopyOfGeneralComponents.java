package businesscomponents;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
//import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Status;
import com.cognizant.framework.TestParameters;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class CopyOfGeneralComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	//static final String THAW_DATA = "THAWData";
	
	//static final String NOTIFICATION_DATA = "Notification_Data";
	static final String ICON_DATA = "General_Data";
	static final String Bureau = "Bureau";
	String TCID=dataTable.getData(Bureau, "TC_ID");
	
	public String textMessage;
	
	public CopyOfGeneralComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
public void testcreate()  {
		
		try{
			
			Date date = new Date(System.currentTimeMillis());
			String dateString = date.toString();
			int lineNumber = 0;
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"dd-MMM-yyyy HH_mm_ss");
			int flg = 0;
			int count = 0;

			/* destination file, where the content to be pasted */
			String destTextFilexls = "H:\\Bureau\\compare\\Test\\Actual";
			String destTextFile = destTextFilexls + "\\" + TCID + "_"
					+ dateFormat.format(date) + ".xml";
			File destFile = new File(destTextFile);

			BufferedWriter wr = new BufferedWriter(new FileWriter(destFile,
					true));
			String pol_num = dataTable.getData(Bureau, "Policy_Num"); /*
																	 * Policy
																	 * number to
																	 * be
																	 * identified
																	 */
			/* Source file, from which content will be copied */

			String fileName = "";
			String trans_number = "";
			File folder = new File("H:\\Bureau\\compare\\Test\\ActualDump");
			File[] listOfFiles = folder.listFiles();
			if (listOfFiles.length < 1) {
				try {
					report.updateTestLog("Source file path: " + folder,
							"File not found", Status.FAIL);
				} finally {

				}
			}

			/* if file not exist then create one */
			if (!destFile.exists()) {
				try {
					destFile.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			for (int i = 0; i < listOfFiles.length; i++) {
				String srcTextFile = "";
				if (listOfFiles[i].isFile()) {
					fileName = listOfFiles[i].getName();
					String srcTextFolder = folder + "\\" + fileName;
					srcTextFile = srcTextFolder;
				}
				File sourceFile = new File(srcTextFile);
				BufferedReader rd = new BufferedReader(new FileReader(
						sourceFile));

				block1: {
					if (count < 1) {
						/* for loop to read to source file content line by line */
						for (String line1; (line1 = rd.readLine()) != null;) {
							 if(line1.contains("RatingStatus")){
							//if (line1.contains("RatabaseXML")) {
								rd.mark(lineNumber);
								/*wr.write(line1);
								wr.newLine();*/
							}
							lineNumber = lineNumber + 1;
							String Str = new String(line1);
							String pol_number = "";
							// String end_string = Str.substring(0, 3);
							String end_str = "/Inputs";
							// if(count<1){
							//if (Str.length() > 47) {
							if (line1.contains("CorrelationServiceId")){
								// pol_number = Str.substring(13, 19);
								
								pol_number = StringUtils.substringBetween(line1, "<CorrelationServiceId>", "</CorrelationServiceId>");
								
								//pol_number = Str.substring(28, 47);
							}
							if (pol_number.compareTo(pol_num) == 0) {
								count++;
								flg = 1;
								// flg1=true;
								/*
								 * wr.write(line1); wr.newLine();
								 */
								rd.reset();
								//wr.write(line1);
								wr.write("<RatingStatus>");
								wr.newLine();
								for (String line; (line = rd.readLine()) != null;) {
									wr.write(line);
									wr.newLine();
									// if(line.contains("</Inputs>")){
									if (line.contains(end_str)) {
										// continue loop1;
										break block1;
									} else {
										continue;
									}
								}
							}

						}

					}

				}

				// if(flg5==0)
				// {
				if (flg == 0) {
					System.out.println("Policy number not found");
					report.updateTestLog("Policy number",
							"Not found in source file", Status.FAIL);
				} else {
					System.out.println("File saved Successfully");
					report.updateTestLog("Destination File",
							"Saved Successfully...", Status.PASS);
					break; // temprorary , saves the first encountered file with
							// specified policy number
				}
				// }
				rd.close();
			}

			wr.close();
		}
		catch (Exception i) {
			System.out.println(i);
		}
		
		
		    
	}
	
	
	public void testExcel_Cmp()  throws IOException {
		
		String fileName="";
		//String TCID=dataTable.getData(NPPS, "TC_ID");
		String actualPath="H:\\Compass\\compare\\Regression\\Actual";
		File folder = new File(actualPath);
	    FileFilter fileFilter = new WildcardFileFilter("*.xls");
		File[] listOfFiles = folder.listFiles(fileFilter);
		
		  if (listOfFiles == null || listOfFiles.length == 0) {
	       // return null;
			  report.updateTestLog("Empty Folder","No files present in Actual folder", Status.FAIL);
	    }

	    File lastModifiedFile = listOfFiles[0];
	    for (int i = 1; i < listOfFiles.length; i++) {
	    	 if(listOfFiles.length<2)
	    		   fileName = listOfFiles[i].getName();
	    	 else{
	    		 if (lastModifiedFile.lastModified() < listOfFiles[i].lastModified()) {
	    			 lastModifiedFile = listOfFiles[i];
	    			 fileName = listOfFiles[i].getName();
	    		 }
	    	 }
	       
	    }
	    
	    String actual=actualPath+"\\"+fileName;
	    String baselinexls=dataTable.getData(Bureau, "Baseline");
		String baseline=baselinexls+"\\"+TCID+".xls";
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileInputStream inputStream1 = new FileInputStream(baseline); 
		FileInputStream inputStream2 = new FileInputStream(actual); 
	    HSSFWorkbook Baseline_wrk=new HSSFWorkbook(inputStream1); 	     
	    HSSFWorkbook Actual_wrk=new HSSFWorkbook(inputStream2); 	 
	    for (int i=0;i<4;i++){
	    	HSSFSheet  Sheet1 = Baseline_wrk.getSheetAt(i);
	    	HSSFSheet  Sheet2 = Actual_wrk.getSheetAt(i);
	    	String Sht_Name=Sheet1.getSheetName();
	    	int col_cnt = (int) Sheet1.getRow(1).getCell(64).getNumericCellValue();
	    	int row_cnt = (int) Sheet1.getRow(0).getCell(64).getNumericCellValue()+3;
	    	int line_flg=0;
	    	for (int j=3;row_cnt>j;j++){
	    		String line_no=Integer.toString(j-2);
 	    		line_flg=0;
	    		for (int k=1;col_cnt>k;k++){
	    			String Basline_val=Sheet1.getRow(j).getCell(k).getStringCellValue();
	    			String Actual_val=Sheet2.getRow(j).getCell(k).getStringCellValue();
	    			if (Basline_val.compareTo(Actual_val)!=0) {
	    				line_flg=1;
	    				String col_name=Sheet2.getRow(0).getCell(k).getStringCellValue();
	    				report.updateTestLog(Sht_Name+" Line "+line_no,Sheet2.getRow(0).getCell(k).getStringCellValue()+"- Mismatched - Baseline Value "+Basline_val+ " Actual Value "+Actual_val, Status.FAIL);
	    				//System.out.println(Sheet1.getRow(j).getCell(k).getStringCellValue());
	    				//System.out.println("matched");
	    			}
	    			//else
	    				//report.updateTestLog(Sht_Name+" Line "+line_no,Sheet2.getRow(0).getCell(k).getStringCellValue()+"- Matched - Baseline Value "+Basline_val+ " Actual Value "+Actual_val, Status.PASS);
	    			
	    		}
	    		
	    		if (line_flg==0) {
	    			//report.updateTestLog("line: "+line_no+" - "+Sht_Name,"Mismatched", Status.PASS);
	    			report.updateTestLog(Sht_Name+" Line "+line_no," All Values are Matched", Status.PASS);
	    		}
	    	
	    	}
	    			    	
	    }
	    
	    
	}
		
	
	public void testcompare() throws IOException {
		
		report.updateTestLog("Flat file comparison - Function","Execution Started...", Status.DONE);
		
		/* Baseline_File to be compared with */
		String baselinexls=dataTable.getData(Bureau, "Baseline");
		String baseline=baselinexls+"\\"+TCID+".txt";
		//File Baseline_filepath = new File("H:/Compass/compare/Baseline.txt");
		File Baseline_filepath = new File(baseline);
		
		if (!Baseline_filepath.exists()) {
			try {
				report.updateTestLog("Baseline file path "+Baseline_filepath,"File not found", Status.FAIL);
			} finally {
				
			}
		}
		
		/* Actual_file to be compared */
		String actualxls=dataTable.getData(Bureau, "Actual");
		String actual=baselinexls+"\\"+TCID+".txt";
		File Actual_filepath = new File(actual);
		//File Actual_filepath = new File("H:/Compass/compare/Actual.txt");
		
		if (!Actual_filepath.exists()) {
			try {
				report.updateTestLog("Baseline file path "+Actual_filepath,"File not found", Status.FAIL);
			} finally {
				
			}
		}
		
		
		/* Result file */
		File Result_filepath = new File("H:/Compass/compare/Result/"+TCID+".txt");
		
		if (!Result_filepath.exists()) {
			try {
				Result_filepath.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		BufferedReader Baseline_file = new BufferedReader(new FileReader(Baseline_filepath));
		BufferedReader Actual_file = new BufferedReader(new FileReader(Actual_filepath));
		BufferedWriter Result_file = new BufferedWriter(new FileWriter(Result_filepath));
		
		//long Baseline_file_lncnt = Baseline_file.lines().count();
		//long Actual_file_lncnt = Actual_file.lines().count();
		long Baseline_file_lncnt = Baseline_file.lines().count();
		long Actual_file_lncnt = Actual_file.lines().count();
		
		Actual_file.close();
		Baseline_file.close();
		
		int ln=0;
		Actual_file = new BufferedReader(new FileReader(Actual_filepath));
		Baseline_file = new BufferedReader(new FileReader(Baseline_filepath));
		
		if (Baseline_file_lncnt == Actual_file_lncnt){
			
			report.updateTestLog("Total Lines count ",""+Actual_file_lncnt, Status.PASS);
			Result_file.write("Total Lines count: "+Actual_file_lncnt);			
			Result_file.newLine();
			System.out.println("Total Lines count: "+Actual_file_lncnt);
			
		    for(String bs_ln; (bs_ln = Baseline_file.readLine()) != null; ) {
		    	//System.out.println(bs_ln); 
		  	String Ac_ln = Actual_file.readLine();
		     String baseline_fileln = new String(bs_ln);
		     String Actual_fileln = new String(Ac_ln);
		     ln=ln+1;
		     if(baseline_fileln.compareTo(Actual_fileln)==0){
		    	 report.updateTestLog("Line "+ln,"Matched", Status.PASS); 
		    	 System.out.println("Line "+ln +": Matched");
		    	 Result_file.write("Line "+ln +": Matched");			
		     }
		     else{
		    	 report.updateTestLog("Line "+ln," Mismatched", Status.FAIL);
		    	 System.out.println("Line "+ln +": Mismatched");
		    	 Result_file.write("Line "+ln +": Mismatched");
		     }
		     Result_file.newLine();
		    }
		    
	}
		else{
			 System.out.println("Total lines count mismatched between two files");
			 System.out.println("Baseline file Total lines count : " +Baseline_file_lncnt);
			 System.out.println("Actual file Total lines count : " +Actual_file_lncnt);
			 Result_file.write("Total lines count mismatched between two files");
			 Result_file.newLine();
			 Result_file.write("Baseline file Total lines count : " +Baseline_file_lncnt);
			 Result_file.newLine();
			 Result_file.write("Actual file Total lines count : " +Actual_file_lncnt);
		}

		Baseline_file.close();
	    Actual_file.close();
	    Result_file.close();
	}
	
}