package businesscomponents;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
//import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Status;
import com.cognizant.framework.TestParameters;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class GeneralComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	//static final String THAW_DATA = "THAWData";
	static final String ICON_DATA = "General_Data";
	static final String Bureau = "Bureau";
	//static final String NOTIFICATION_DATA = "Notification_Data";
	
	public String textMessage;
	
	public GeneralComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	public void loginNBV()
	{
		//driver.get(properties.getProperty("ApplicationUrl"));
		driver.get(dataTable.getData(ICON_DATA, "Url"));
		String userId = dataTable.getData(ICON_DATA, "EDI_USER");
		String password = dataTable.getData(ICON_DATA, "EDI_PASSWORD");
		report.updateTestLog("Enter user credentials", "Specify username = "+userId, Status.PASS);
		if(dataTable.getData(ICON_DATA, "Url").contains("qa01")||dataTable.getData(ICON_DATA, "Url").contains("ti01")){
			driver.findElement(By.name("USERText")).sendKeys(userId);
		}
		else{
			driver.findElement(By.name("USER")).sendKeys(userId);
		}
		
		for (int s = 0; s < password.length(); s++){
	   	        char c = password.charAt(s);
	   	        String S = new StringBuilder().append(c).toString();
	   	     driver.findElement(By.name("PASSWORD")).sendKeys(S);
	   	    }
		
		driver.findElement(By.name("PASSWORD")).sendKeys(Keys.TAB);
		//driver.findElement(By.name("PASSWORD")).sendKeys(password);
		report.updateTestLog("Login", "Click the sign-in button", Status.SCREENSHOT);
		if(dataTable.getData(ICON_DATA, "Url").contains("qa01")||dataTable.getData(ICON_DATA, "Url").contains("ti01")){
			driver.findElement(By.id("login-submit")).click();
		}
		else{
			driver.findElement(By.id("login")).click();
		}
		
		if(driver.getTitle().equalsIgnoreCase("Login | The Hartford EBC eBusiness Center for P&C Agents")){
			report.updateTestLog("Verify Login ", "Login failed for valid user",  Status.FAIL);
			
		}
		
		else if(driver.getTitle().equalsIgnoreCase("Commercial Insurance: Home | The Hartford EBC eBusiness Center for P&C Agents")){
		report.updateTestLog("Login successful", "Login successful", Status.PASS);
		driver.findElement(By.xpath("//*[contains(text(),'Quote Small Commercial (ICON)')]")).click();
		
		waitToBeDisplayed(5);
		ArrayList<String> allwindows1=new ArrayList<String>(driver.getWindowHandles());
		//System.out.println(driver.getWindowHandles().size());
		for (String winHandle : allwindows1) {
			//System.out.println(driver.getTitle());
			  driver.switchTo().window(winHandle); 
			if(driver.getTitle().contains("ICON | Small Commercial Quoting | Customer Home")) {			
				    //driver.switchTo().window(winHandle); 
				   // System.out.println(driver.getTitle());
				break;
				}
			}
		}
		else if(driver.getTitle().equalsIgnoreCase("ICON | Small Commercial Quoting | Customer Home")){
			report.updateTestLog("Login successful", "Login successful", Status.PASS);
		}
		else{
			System.out.println("issue in login");
		}
			
	}
	public void invokeApplication() {
		System.out.println("invoke application");
		report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								properties.getProperty("ApplicationUrl"), Status.DONE);
		
		driver.get(properties.getProperty("ApplicationUrl"));
	}
	public void newCustomer_ProducerCode()
	{
		String ProducerCode=ReusableCommonComponents.Total_objectvalue;
		String  Entityid=driver.findElement(By.xpath("//*[contains(@name,'CustomerInfoForm:pc')]")).getAttribute("id");
		
		//System.out.println(Entityid);
		if(Entityid.contains("pc_input")){
		driver.findElement(By.id("CustomerInfoForm:pc_input")).sendKeys(ProducerCode);
		driver.findElement(By.id("CustomerInfoForm:pc_input")).sendKeys(Keys.TAB);
		waitToBeDisplayed(3);
		report.updateTestLog("Entered Producer Code", "Specified Producer Code = "+ProducerCode, Status.PASS);
		}
		else if(Entityid.equals("CustomerInfoForm:pc_list")){
			Select newdropdown= new Select(driver.findElement(By.id("CustomerInfoForm:pc_list")));
         	newdropdown.selectByVisibleText(ProducerCode);
         	report.updateTestLog("Entered Producer Code", "Specified Producer Code = "+ProducerCode, Status.PASS);
		}
			
	}
	public void verifyPageTitle(){
		waitToBeDisplayed(2);
		if(textMessage == null){
			textMessage = dataTable.getData(ICON_DATA, "PageTitle");
			String arrPage[] = textMessage.split(";");
			try{
				if(Arrays.asList(arrPage).contains(driver.getTitle().trim())){
					report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.SCREENSHOT);
				}else{
					report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.SCREENSHOT);
				}
			}catch(Exception e){
				report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.FAIL);
			}
		}
	}
	
	
	
	public void genInfoPage(){
		try{
			waitToBeDisplayed(3);
			
			 ArrayList<String> allwindows=new ArrayList<String>(driver.getWindowHandles());
			//System.out.println("first trial "+driver.getWindowHandles().size());
			 if(allwindows.size()<4){
	        		for(int sec=0;(sec<=60 && !(allwindows.size()>=4));sec=sec+5){
	        			waitToBeDisplayed(5);
	        			allwindows=new ArrayList<String>(driver.getWindowHandles());
	        		}
	        		
	        	}
			for (String winHandle : allwindows) {
				//System.out.println(driver.getTitle());
				driver.switchTo().window(winHandle); 
				if(driver.getTitle().contains("ICON - "+ ReusableCommonComponents.LegalName)) {			
					   // System.out.println(driver.getTitle());
					break;    
					}
				}
			
			waitToBeDisplayed(3);
			//System.out.println("just checking");
		}catch(Exception e){
			report.updateTestLog("Verify Login ", "Login failed for valid user", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("Verify Login", "Login failed for valid user");
			
		}
	}
	public void eligibility_Ques(){
		try {
			String eligibilityMessage="There are no questions to answer.";
			boolean eligibilityques=false;
			
			try{
				WebElement EM=driver.findElement(By.xpath("//*[contains(text(),'"+ eligibilityMessage +"')]"));
				System.out.println("No eligibility questions are Present");
			}
			catch (Exception e){
				eligibilityques=true;
			}
			if(eligibilityques){
				waitToBeDisplayed(2);
				WebElement fieldset=null;
				String Lob = dataTable.getData("Selectlob", "Object");
				if((Lob.toLowerCase().contains("spectrum")) || (Lob.toLowerCase().contains("auto"))){
					fieldset = driver.findElement(By.id("eligibilityQuestions"));
				}
				else if(Lob.toLowerCase().contains("wc")){
					fieldset = driver.findElement(By.id("policyInformation"));	
				}
				
				try{
				List<WebElement> ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
				String [] labelids=new String[ElementsLable.size()];
				int RadioCounter = 0;
				//for(int Counter = 0; Counter < ElementsLable.size(); Counter++){
					while(RadioCounter < ElementsLable.size()){
					labelids[RadioCounter]=ElementsLable.get(RadioCounter).getAttribute("id");
					String labelid=labelids[RadioCounter].substring(0,labelids[RadioCounter].indexOf('_'));
					List<WebElement> Elementvalues=fieldset.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
					
					for(int ValCount=Elementvalues.size()-1;ValCount>=0 ;ValCount--){
						Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
						
							try{
								WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
								if(hardstop.isDisplayed())
									Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
							}
							catch(Exception ex){
								//System.out.println("check box 'none of the above' selected");
								break;
							}
						
					}
					RadioCounter++;
					ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));				
					}
				
				}
				catch(Exception RB){
					//System.out.println("No radio buttons present");
				}
				List<WebElement> Chckboxes =fieldset.findElements(By.xpath("//*[@type='checkbox']"));
				if(Chckboxes!=null){
				try{
				int totalCheckboxes=fieldset.findElements(By.xpath("//*[@type='checkbox']/ancestor::div/preceding::div[contains(@class,'required')]")).size();	
				int checked=0;
				List<WebElement> ElementNoneofabove =fieldset.findElements(By.xpath("//*[@type='checkbox']/../following-sibling::label/span[contains(@id,'labelText') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
				if(ElementNoneofabove.size()>0){
					for(int x=0;x<ElementNoneofabove.size();x++){
						ElementNoneofabove.get(x).click();
						
						try{
							WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop1.isDisplayed())
								ElementNoneofabove.get(x).click();
							checked--;
						}
						catch(Exception e){
							//System.out.println("check box 'none of the above' selected");
							checked++;
						}
						}	
					}
				if(totalCheckboxes>checked){
					for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
						
						Chckboxes.get(Counter).click();
							//System.out.println("checking");
							try{
								WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
								if(hardstop.isDisplayed())
								Chckboxes.get(Counter).click();
							}
							catch(Exception ex){
								//System.out.println("check box selected");
							}
						}
				}
				}
				catch(Exception e){
					for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
						
						Chckboxes.get(Counter).click();
						//	System.out.println("checking");
							try{
								WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
								if(hardstop.isDisplayed())
								Chckboxes.get(Counter).click();
							}
							catch(Exception ex){
								//System.out.println("check box 'none of the above' selected");
							}
						}	
				}
				}
				else System.out.println("no checkboxes eligibility questions");
			}
			
		}
		catch(Exception e){
			System.out.println(e);
			report.updateTestLog("Eligibity Questions ", "Eligibity Questions failed", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("Eligibity Questions", "Eligibity Questions failed");
			
		}
	}
	public void underWriting_Ques(){
		try {
			waitToBeDisplayed(1);
			WebElement PolicyQuestions=driver.findElement(By.xpath("//*[@id='UnderwritingQuestions']"));
			try{
				List<WebElement> ElementsLable = PolicyQuestions.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
				String [] labelids=new String[ElementsLable.size()];
			//int Counter=0;
				for (int Counter=0;Counter < ElementsLable.size();Counter++){
				
					labelids[Counter]=ElementsLable.get(Counter).getAttribute("id");
					//System.out.println(labelids[Counter]);
					String labelid=labelids[Counter].substring(0,labelids[Counter].indexOf('_'));
					//System.out.println(labelid);
					List<WebElement> Elementvalues=PolicyQuestions.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
					//System.out.println("//input[contains(@id,'"+labelid+"')]");
					for(int ValCount=Elementvalues.size()-1; ValCount>=0 ;ValCount--){
						Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							
						}
						catch(Exception ex){
							//Counter++;						
							break;
							
						}
						
					}
					waitToBeDisplayed(1);
					ElementsLable = PolicyQuestions.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));				
					if(ElementsLable.size()!=labelids.length){
						labelids = Arrays.copyOf(labelids, ElementsLable.size());
					}
				}
			}
		catch(Exception r){
				System.out.println(r);
				System.out.println("No Radio buttons");
			}
			
			try{
				
			List<WebElement> TotalCheckboxQuestions=PolicyQuestions.findElements(By.xpath("//*[@type='checkbox']/ancestor::div[1]/ancestor::fieldset"));	
			String[] checkboxIds=new String[TotalCheckboxQuestions.size()];
			String checkboxlabel="";
			
			for(int checkboxQ = 0; checkboxQ < TotalCheckboxQuestions.size(); checkboxQ++){
				checkboxlabel=TotalCheckboxQuestions.get(checkboxQ).getAttribute("id");
				checkboxIds[checkboxQ]=checkboxlabel.substring(checkboxlabel.indexOf("_")+2,checkboxlabel.length());
				
				List<WebElement> ElementCheckboxvals=PolicyQuestions.findElements(By.xpath("//fieldset//input[@type='checkbox' and contains(@id,'"+checkboxIds[checkboxQ]+"')]"));
				try{
				WebElement ElementNoneofabove =PolicyQuestions.findElement(By.xpath("//fieldset//label/span[contains(@id,'labelText') and contains(@id,'"+checkboxIds[checkboxQ]+"') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
				if(ElementNoneofabove != null){
					ElementNoneofabove.click();
					try{
						WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
						if(hardstop1.isDisplayed())
							ElementNoneofabove.click();
						
					}
					catch(Exception e){
						//System.out.println("check box 'none of the above' selected");
						break;
					}
					}
				}
				catch( Exception N){
					
				
				for(int s=0;s<ElementCheckboxvals.size();s++ ){
					ElementCheckboxvals.get(s).click();
					
					try{
						WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
						if(hardstop1.isDisplayed())
							ElementCheckboxvals.get(s).click();
						
					}
					catch(Exception e){
						//System.out.println("check box 'none of the above' selected");
						break;
					}
				}
					
				} 
				waitToBeDisplayed(1);
				TotalCheckboxQuestions=PolicyQuestions.findElements(By.xpath("//*[@type='checkbox']/ancestor::div[1]/ancestor::fieldset"));
				if(TotalCheckboxQuestions.size()!=checkboxIds.length){
					checkboxIds = Arrays.copyOf(checkboxIds, TotalCheckboxQuestions.size());
				}
			}
			
			}
			catch(Exception c){
				//System.out.println("No Check boxes");
				
			}
			
			try{
				List<WebElement> Totallistboxes=PolicyQuestions.findElements(By.xpath("//select[not (contains(@id,'secondary'))]"));	
				for(int listboxQ = 0; listboxQ < Totallistboxes.size(); listboxQ++){
					 Select newdropdown= new Select(Totallistboxes.get(listboxQ));
					 int optionCount=newdropdown.getOptions().size();
					 for(int selectOption=1;selectOption<optionCount;selectOption++){
						 newdropdown.selectByIndex(selectOption);
							
							try{
								WebElement hardstop2=driver.findElement(By.xpath("//p[@class='hardStop']"));
								
								}
							catch(Exception e){
								break;
							} 
					 }
					 
			         
				}
				
			}catch(Exception LB){
				//System.out.println(LB);
			}
			try{
				List<WebElement> TotalTextareas=PolicyQuestions.findElements(By.xpath("//textarea"));	
				for(int T=0;T<TotalTextareas.size();T++ ){
					TotalTextareas.get(T).sendKeys("Checking");;
					}
				
			}
			catch(Exception TE){
				//System.out.println(TE);
			}
			
			WebElement continuebutton=driver.findElement(By.id("continueButton"));
			 waitToBeDisplayed(2);
 	    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
 	    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
 	    	 element.click();	
		}
			
		catch(Exception e){
			report.updateTestLog("UnderWriting Questions ", "UnderWritin Questions failed", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("UnderWritin Questions", "UnderWritin Questions failed");
			
		}
	}
	public void premium_Summary(){
		try {
			waitToBeDisplayed(3);
			try{
				WebElement bindable=driver.findElement(By.id("bindNoteGreenDiv"));
				if(bindable.isDisplayed())
				report.updateTestLog("Quote is Bindable", "Quote is Bindable", Status.PASS);
				
			}catch(Exception e){
				System.out.println("Yet to be updated code for non bindable condition");
			}
			
			
		}
		catch(Exception e){
			report.updateTestLog("Premium Summary ", "Premium Summary failed", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("Premium Summary", "Premium Summary failed");
			
		}
	}
	
	public void Flatfile() throws IOException {
System.out.println("hi");
		/* Source file, from which content will be copied */
		File sourceFile = new File("H:/Compass/SRC.txt");

		/* destination file, where the content to be pasted */
		File destFile = new File("H:/Compass/Dest.txt");
		
		/* if file not exist then create one */
		if (!destFile.exists()) {
			try {
				destFile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		BufferedReader rd = new BufferedReader(new FileReader(sourceFile));
		BufferedWriter wr = new BufferedWriter(new FileWriter(destFile));
		/*for loop to read to source file content line by line*/
		    for(String line; (line = rd.readLine()) != null; ) {
		     String Str = new String(line);
		     String pol_number = Str.substring(13, 19);
		     String pol_num="AA8BN5"; /* Policy number to be identified */
		     /*if condition to identify the starting line of the policy number */
		     if(pol_number.compareTo(pol_num)==0){
		    	 wr.write(line);				/* Write the contents in the destination file */
		    	 wr.newLine();
		    	 for(String lin; (lin = rd.readLine()) != null;) {
		    		 String Str1 = new String(lin);
				     String end_string = Str1.substring(0, 3);
				     String end_str = "411"; 	/* End of policy identifier keyword */
				/* Write the contents in the destination file */
				     wr.write(lin);
				     /*if condition to identify the ending line of the policy */
				     if(end_string.compareTo(end_str)==0){
		                break;
				     }
				     wr.newLine();
		             }
		    	 break;
		     }
		    }
		    rd.close();
		    wr.close();
		    
	}
	
	public void testcreate()  {
		
		try{
			 String TCID=dataTable.getData(Bureau, "TC_ID");
			int col_Count=0;
			//int col_Count=0;
			//testExcel_Cmp(); /*to compare*/
				//FileInputStream fis = new FileInputStream("C://NPPS Workspace//Bureau//Datatables//Bureau.xls");
	        //XSSFWorkbook workbook = new XSSFWorkbook(fis);
	        //XSSFSheet sheet = workbook.getSheet("Bureau");
				//HSSFWorkbook workbook = new HSSFWorkbook(fis);

		    	//HSSFSheet sheet = workbook.getSheetAt(0);

		    	//HSSFRow row = sheet.getRow(0);
	 
	        	//int col_num = -1;
	 
				//for(int i=0; i < row.getLastCellNum(); i++)
	        	//{
	            	//if(row.getCell(i).getStringCellValue().trim().equals(TCID))
	            		//col_Count++;
	        	//}
			
			
			FileInputStream inputStream = new FileInputStream("H://Bureau//Bureau_Template.xls"); 
		    HSSFWorkbook wrk=new HSSFWorkbook(inputStream); 	     
		    FormulaEvaluator evaluator = wrk.getCreationHelper().createFormulaEvaluator();
		    HSSFSheet  Sheet1 = wrk.getSheet("Record1");
			HSSFSheet  Sheet2 = wrk.getSheet("Record2");
			HSSFSheet  Sheet3 = wrk.getSheet("Record3");
			HSSFSheet  Sheet4 = wrk.getSheet("Record4");
			HSSFSheet  Sheet5 = wrk.getSheet("Record5");
			HSSFSheet  Sheet6 = wrk.getSheet("Record6");
			HSSFSheet  Sheet7 = wrk.getSheet("Record7");
			HSSFSheet  Sheet8 = wrk.getSheet("Record8");
			Date date = new Date(System.currentTimeMillis());
	        String dateString = date.toString();
	        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH_mm_ss") ;
			int flg=0;
			int flgForWritingOnce=0;
			int flg1=3;
		    int flg2=3;
		    int flg3=3;
		    int flg4=3;
		    int flg5=3;
		    int flg6=3;
		    int flg7=3;
		    int flg8=3;
		    int flg9=1;
		    /* destination file, where the content to be pasted */
		   // String destTextFilexls=dataTable.getData(NPPS, "Actual");
		   
			String destTextFile="H:\\Bureau\\compare\\Actual"+"\\"+TCID+"_"+dateFormat.format(date)+".txt";
		    File destFile = new File(destTextFile);
		    
		    BufferedWriter wr = new BufferedWriter(new FileWriter(destFile,true));		
			
			/* Source file, from which content will be copied */
					    
		    String fileName="";
		    String trans_number="";
		    String state_code="";
		    int count=0;
		    int lineNumber=0;
		    int stateCount=0;
		    int no_Of_Files=0;
		    File folder = new File("H:\\Bureau\\compare\\ActualDump");
			File[] listOfFiles = folder.listFiles();
			if(listOfFiles.length<1){
				try {
					report.updateTestLog("Source file path: "+folder,"File not found", Status.FAIL);
				} finally {
					
				}
			}
		
			/* if file not exist then create one */
			if (!destFile.exists()) {
				try {
					destFile.createNewFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		   for (int i = 0; i < listOfFiles.length; i++) 
		    {
		    	String srcTextFile="";
		      	if (listOfFiles[i].isFile())
		      	{
		      		 no_Of_Files++;
		    		 fileName = listOfFiles[i].getName();
				     String srcTextFolder=folder+"\\"+fileName;
				     srcTextFile=srcTextFolder;
		      	}
				     File sourceFile = new File(srcTextFile);
				     BufferedReader rd = new BufferedReader(new FileReader(sourceFile));
				    	
				     	/*for loop to read to source file content line by line*/
				   loop:for(String line; (line = rd.readLine()) != null; )
				     	{
				    		if(count<1)
				    		{
				    		rd.mark(lineNumber);
				    		}
				     		String Str = new String(line);
				     		String rec_number=Str.substring(45,47);
 				     		String pol_number=Str.substring(10, 30).trim();
 				     		trans_number = Str.substring(41, 43);
 				     		String pol_num=dataTable.getData(Bureau, "Policy_Num"); /* Policy number to be identified */
 				     		String trans_num=dataTable.getData(Bureau, "Trans_Num"); /* Transaction Number to be identified */
 				     		String state_cd=dataTable.getData(Bureau, "State_Code"); /* Transaction Number to be identified */
 				     		//System.out.println(state_cd);
				     			/*if condition to identify the starting line of the policy number */
				     			if(pol_number.compareTo(pol_num)==0)
				     			{
				     				if(trans_number.compareTo(trans_num)==0)
					     			{
				     					
				     					if(count<1)
				     					{
				     					for(String line1; (line1 = rd.readLine()) != null; )
		 				     			{
		 				     				
		 				     				String Str1 = new String(line1);	
		 				     				String rec_number1=Str1.substring(45,47);
		 				     				if(rec_number1.compareTo("04")==0)
				     						{
		 				     				state_code = Str1.substring(43, 45);
		 				     				
		 				     				if(state_code.compareTo(state_cd)==0)
		 				     				{
		 				     					count=count+1;
		 				     					report.updateTestLog("State","Entry for the state "+state_cd+" is found", Status.DONE);
		 				     					
		 				     					//if(count<1)
		 				     					//{
		 				     					rd.reset();
		 				       					break;
		 				     					//}
		 				     					
		 				     				}
		 				     					
				     						}
		 				     				}
		 				     				//break;
		 				     			}
				     					
				     					
				     					//if(flgForWritingOnce==0)
				     					//{
				     							if(rec_number.compareTo("01")==0)
				     							{
				     								Sheet1.getRow(flg1).createCell(0).setCellValue(line);
				     								flg1=flg1+1;
				     							}
				     							if(rec_number.compareTo("02")==0)
				     							{
				     								Sheet2.getRow(flg2).createCell(0).setCellValue(line);
				     								flg2=flg2+1;
				     							}
					     
				     							if(rec_number.compareTo("03")==0)
				     							{
				     								Sheet3.getRow(flg3).createCell(0).setCellValue(line);
				     								flg3=flg3+1;
				     							}
					     
					     						if(rec_number.compareTo("04")==0)
					     						{
					     							Sheet4.getRow(flg4).createCell(0).setCellValue(line);
					     							flg4=flg4+1;
					     						}
					     						if(rec_number.compareTo("05")==0)
					     						{
					     							Sheet5.getRow(flg5).createCell(0).setCellValue(line);
					     							flg5=flg5+1;
					     						}
					     						if(rec_number.compareTo("06")==0)
					     						{
					     							Sheet6.getRow(flg6).createCell(0).setCellValue(line);
					     							flg6=flg6+1;
					     						}
					     						if(rec_number.compareTo("07")==0)
					     						{
					     							Sheet7.getRow(flg7).createCell(0).setCellValue(line);
					     							flg7=flg7+1;
					     						}
					     						if(rec_number.compareTo("08")==0)
					     						{
					     							Sheet8.getRow(flg8).createCell(0).setCellValue(line);
					     							flg8=flg8+1;
					     						}
					     
					     					/* Write the contents in the destination file */
					     					wr.write(line);
					     						/*if condition to identify the ending line of the policy */
					     							
					     					wr.newLine();
					     					flg=1;
				     					//}
				     				}	
				     			  
				     			}
				     			lineNumber++;
				     			//count=count+1;
				     		 }
				//   if(no_Of_Files==listOfFiles.length)
				 //  {
				     if (flg==0)
					{
						System.out.println("Policy number not found");
						report.updateTestLog("Policy number", "Not found in source file", Status.FAIL);
					}
					else 
					{
						if(flgForWritingOnce==0){
						System.out.println("File saved Successfully");
						flgForWritingOnce=1;
						report.updateTestLog("Destination File","Saved Successfully...", Status.PASS);
						break; //temprorary , saves the first encountered file with specified policy number
						}
				//	}
				   }
				
				rd.close();
		    }
			    
			    wr.close();
			    evaluator.evaluateAll();
			  //  if(flgForWritingOnce==0){
			    String actual ="H:\\Bureau\\compare\\Actual"+"\\"+TCID+"_"+dateFormat.format(date)+ ".xls";
		        FileOutputStream outFile = new FileOutputStream(new File(actual));
			    wrk.write(outFile);
			    wrk.close();
		        outFile.close();
			  // }
		        inputStream.close();
		        testExcel_Cmp();
			  //  }
		    
		  
		} 
		catch (Exception i){
			System.out.println(i);
		}
		
		
		    
	}
	
	
	public void testExcel_Cmp()  throws IOException {
		
		String fileName="";
		String TCID=dataTable.getData(Bureau, "TC_ID");
		String actualPath="H:\\Bureau\\compare\\Actual";
		File folder = new File(actualPath);
	    FileFilter fileFilter = new WildcardFileFilter("*.xls");
		File[] listOfFiles = folder.listFiles(fileFilter);
		
		  if (listOfFiles == null || listOfFiles.length == 0) {
	       // return null;
			  report.updateTestLog("Empty Folder","No files present in Actual folder", Status.FAIL);
	    }

	    File lastModifiedFile = listOfFiles[0];
	    for (int i = 1; i < listOfFiles.length; i++) {
	    	 if(listOfFiles.length<2)
	    		   fileName = listOfFiles[i].getName();
	    	 else{
	    		 if (lastModifiedFile.lastModified() < listOfFiles[i].lastModified()) {
	    			 lastModifiedFile = listOfFiles[i];
	    			 fileName = listOfFiles[i].getName();
	    		 }
	    	 }
	       
	    }
	    
	    String actual=actualPath+"\\"+fileName;
	   	String baseline="H:\\Bureau\\compare\\Baseline"+"\\"+TCID+".xls";
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileInputStream inputStream1 = new FileInputStream(baseline); 
		FileInputStream inputStream2 = new FileInputStream(actual); 
	    HSSFWorkbook Baseline_wrk=new HSSFWorkbook(inputStream1); 	     
	    HSSFWorkbook Actual_wrk=new HSSFWorkbook(inputStream2); 	 
	    for (int i=0;i<7;i++){
	    	HSSFSheet  Sheet1 = Baseline_wrk.getSheetAt(i);
	    	HSSFSheet  Sheet2 = Actual_wrk.getSheetAt(i);
	    	String Sht_Name=Sheet1.getSheetName();
	    	int col_cnt = (int) Sheet1.getRow(1).getCell(41).getNumericCellValue();
	    	int row_cnt = (int) Sheet1.getRow(0).getCell(41).getNumericCellValue()+3;
	    	int line_flg=0;
	    	for (int j=3;row_cnt>j;j++){
	    		String line_no=Integer.toString(j-2);
 	    		line_flg=0;
	    		for (int k=1;col_cnt>k;k++){
	    			String Basline_val=Sheet1.getRow(j).getCell(k).getStringCellValue();
	    			String Actual_val=Sheet2.getRow(j).getCell(k).getStringCellValue();
	    			if (Basline_val.compareTo(Actual_val)!=0) {
	    				line_flg=1;
	    				String col_name=Sheet2.getRow(0).getCell(k).getStringCellValue();
	    				int fieldValueAffected=checkPriorityFields(i,col_name);
	    				if(fieldValueAffected==1)
	    				{
	    				report.updateTestLog(Sht_Name+" Line "+line_no,Sheet2.getRow(0).getCell(k).getStringCellValue()+"- Mismatched - Baseline Value "+Basline_val+ " Actual Value "+Actual_val, Status.FAIL);
	    				}
	    				else
	    				{
	    				report.updateTestLog(Sht_Name+" Line "+line_no,Sheet2.getRow(0).getCell(k).getStringCellValue()+"- Mismatched - Baseline Value "+Basline_val+ " Actual Value "+Actual_val, Status.FAIL);
	    				}
	    				String fieldnm=Sheet2.getRow(0).getCell(k).getStringCellValue();
	    				getField(fieldnm);
	    				//System.out.println(Sheet1.getRow(j).getCell(k).getStringCellValue());
	    				//System.out.println("matched");
	    			}
	    			
	    		}
	    		
	    		if (line_flg==0) {
	    			//report.updateTestLog("line: "+line_no+" - "+Sht_Name,"Mismatched", Status.PASS);
	    			report.updateTestLog(Sht_Name+" Line "+line_no," All Values are Matched", Status.PASS);
	    		}
	    	
	    	}
	    			    	
	    }
	    
	    
	}
	
	public int checkPriorityFields(int i,String col_name)
	{
		String field;
		int fieldValueAffected=0;
		String FilePath = "H:\\Compass\\Fields to be validated.xls";
		try{
		FileInputStream inputStream1 = new FileInputStream(FilePath);
		//FileInputStream fs = new FileInputStream(FilePath);
		XSSFWorkbook priorityFields=new XSSFWorkbook(inputStream1);
		XSSFSheet  Sheet1 = priorityFields.getSheetAt(i);
		//Workbook wb = Workbook.getWorkbook(fs);

		// TO get the access to the sheet
		//Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		//int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
//		int totalNoOfCols = Sheet1.getColumns();
		int totalNoOfRows = Sheet1.getLastRowNum();
		int col=0;
		//for (int row = 0; row < totalNoOfRows; row++) {

			for (int row = 0; row < totalNoOfRows; row++) {
				field=Sheet1.getRow(row).getCell(col).getStringCellValue();
					if(col_name.equalsIgnoreCase(field))
					{
						fieldValueAffected=1;
						break;
					}
					
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
			
		}
		return fieldValueAffected;
		}
	
	
	public void testcompare() throws IOException {
		
		report.updateTestLog("Flat file comparison - Function","Execution Started...", Status.DONE);
		
		/* Baseline_File to be compared with */
		File Baseline_filepath = new File("H:/Compass/compare/Baseline.txt");
		
		if (!Baseline_filepath.exists()) {
			try {
				report.updateTestLog("Baseline file path "+Baseline_filepath,"File not found", Status.FAIL);
			} finally {
				
			}
		}
		
		/* Actual_file to be compared */
		File Actual_filepath = new File("H:/Compass/compare/Actual.txt");
		
		if (!Actual_filepath.exists()) {
			try {
				report.updateTestLog("Baseline file path "+Actual_filepath,"File not found", Status.FAIL);
			} finally {
				
			}
		}
		
		
		/* Result file */
		File Result_filepath = new File("H:/Compass/compare/Result.txt");
		
		if (!Result_filepath.exists()) {
			try {
				Result_filepath.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		BufferedReader Baseline_file = new BufferedReader(new FileReader(Baseline_filepath));
		BufferedReader Actual_file = new BufferedReader(new FileReader(Actual_filepath));
		BufferedWriter Result_file = new BufferedWriter(new FileWriter(Result_filepath));
		
		//long Baseline_file_lncnt = Baseline_file.lines().count();
		//long Actual_file_lncnt = Actual_file.lines().count();
		long Baseline_file_lncnt = Baseline_file.lines().count();
		long Actual_file_lncnt = Actual_file.lines().count();
		
		Actual_file.close();
		Baseline_file.close();
		
		int ln=0;
		Actual_file = new BufferedReader(new FileReader(Actual_filepath));
		Baseline_file = new BufferedReader(new FileReader(Baseline_filepath));
		
		if (Baseline_file_lncnt == Actual_file_lncnt){
			
			report.updateTestLog("Total Lines count ",""+Actual_file_lncnt, Status.PASS);
			Result_file.write("Total Lines count: "+Actual_file_lncnt);			
			Result_file.newLine();
			System.out.println("Total Lines count: "+Actual_file_lncnt);
			
		    for(String bs_ln; (bs_ln = Baseline_file.readLine()) != null; ) {
		    	//System.out.println(bs_ln); 
		  	String Ac_ln = Actual_file.readLine();
		     String baseline_fileln = new String(bs_ln);
		     String Actual_fileln = new String(Ac_ln);
		     ln=ln+1;
		     if(baseline_fileln.compareTo(Actual_fileln)==0){
		    	 report.updateTestLog("Line "+ln,"Matched", Status.PASS); 
		    	 System.out.println("Line "+ln +": Matched");
		    	 Result_file.write("Line "+ln +": Matched");			
		     }
		     else{
		    	 report.updateTestLog("Line "+ln," Mismatched", Status.FAIL);
		    	 System.out.println("Line "+ln +": Mismatched");
		    	 Result_file.write("Line "+ln +": Mismatched");
		     }
		     Result_file.newLine();
		    }
		    
	}
		else{
			 System.out.println("Total lines count mismatched between two files");
			 System.out.println("Baseline file Total lines count : " +Baseline_file_lncnt);
			 System.out.println("Actual file Total lines count : " +Actual_file_lncnt);
			 Result_file.write("Total lines count mismatched between two files");
			 Result_file.newLine();
			 Result_file.write("Baseline file Total lines count : " +Baseline_file_lncnt);
			 Result_file.newLine();
			 Result_file.write("Actual file Total lines count : " +Actual_file_lncnt);
		}

		Baseline_file.close();
	    Actual_file.close();
	    Result_file.close();
	}
	
	public static void waitToBeDisplayed(int sec) {
			try {
				int requiredtime=sec*1000;
				Thread.sleep(requiredtime);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	public void sample()
	{
	
		 String fileName="";
		    File folder = new File("H:\\compass\\compare\\Actual");
		    FileFilter fileFilter = new WildcardFileFilter("*." + "xls");
			File[] listOfFiles = folder.listFiles(fileFilter);
			
			  if (listOfFiles == null || listOfFiles.length == 0) {
		       // return null;
				  System.out.println("Fail");
		    }

		    File lastModifiedFile = listOfFiles[0];
		    for (int i = 1; i < listOfFiles.length; i++) {
		       if (lastModifiedFile.lastModified() < listOfFiles[i].lastModified()) {
		           lastModifiedFile = listOfFiles[i];
		           fileName = listOfFiles[i].getName();
		       }
		    }
		   // return lastModifiedFile;
		
	}
	
   public void getField(String fieldnm) throws IOException{
       
XSSFWorkbook srcBook = new XSSFWorkbook("H:\\Compass");
XSSFSheet sourceSheet = srcBook.getSheetAt(0);
// int rownum = 2;
for (int rownum=1;rownum<9;rownum++)
{
XSSFRow sourceRow = sourceSheet.getRow(rownum);
int lastcellNum = sourceRow.getLastCellNum() - 1;
int lastrowNum = sourceSheet.getLastRowNum() - 1;

ArrayList<String> rowValues = new ArrayList<String>();

for (int i = 0; i <= lastcellNum; i++) {
String val = (sourceRow.getCell(i+1)).getRichStringCellValue().getString();
if(val.equalsIgnoreCase(fieldnm))
{
	
}
	


break;

}
break;
}
}

	
	
}