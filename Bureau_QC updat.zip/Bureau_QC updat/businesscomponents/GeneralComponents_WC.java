package businesscomponents;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
//import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Status;
//import com.cognizant.framework.TestParameters;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class GeneralComponents_WC extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	//static final String THAW_DATA = "THAWData";
	static final String THAW_DATA = "General_Data";
	//static final String NOTIFICATION_DATA = "Notification_Data";
	
	public String textMessage;
	
	public GeneralComponents_WC(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	public void ccDeleteEdit() {
		System.out.println("ccDeleteEdit");
		/*report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								properties.getProperty("ApplicationUrl"), Status.DONE);
		
		driver.get(properties.getProperty("ApplicationUrl"));*/
	}
	
	public static void waitToBeDisplayed(int sec) {
			try {
				int requiredtime=sec*1000;
				Thread.sleep(requiredtime);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
}