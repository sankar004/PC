package businesscomponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
import com.cognizant.framework.Status;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.Util;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class ReusableCommonComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public static WebElement LegalEntity=null;
	static By ORType = null;
	static String Curr_obj = null;
	static String obj_Name=null;
	static String[] arrobj_name=null;
	static String[] arrdata=null;
	static String obj_type,Total_objectvalue=null;
	static String[] obj_value=null;
	static String[] type=null;
	static String LegalName=null;
	static boolean Obj_Existence,status=true;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public ReusableCommonComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	public void reusablecomponent(){
		try{
			ObjectRepository ORTable = new ObjectRepository(null);
			ORTable.getInputData();
			
			String Data=DriverScript.totaldata;
			arrdata=Data.split("\\<==>");
			String object=arrdata[1];
			String objectValue=arrdata[0];
			
			arrobj_name= object.split("\\;");
		 	
			arrdata=objectValue.split("\\;");
		 	Obj_Existence=false;
		 	int objcheckval=0;
	        for(int i=0;i<arrobj_name.length;i++)
	        {
	        	type=arrobj_name[i].split("\\_");
	        	obj_type=type[0];
	        	
	        	if(objcheckval==0){
	        		if(obj_type.contains("RDO")||obj_type.contains("GRP")||obj_type.contains("CAL")){
	        			Obj_Existence=true;
	        		}
	        	else
	        	{
	        			Obj_Existence=false;
	        			String objType="By."+ ORTable.getType(arrobj_name[i]);
	    	        	String objelement=ORTable.getElement(arrobj_name[i]);
	    	        	//System.out.println(arrobj_name[i]);
	    	        	waitToBeDisplayed(2);
	    	        	WebElement PageFirstObj=GetwebElement(objType,objelement);
	    	        	Obj_Existence=PageFirstObj.isDisplayed();
	    	        	if(!Obj_Existence){
	    	        		for(int sec=0;(sec<=60 && !Obj_Existence);sec=sec+5){
	    	        			waitToBeDisplayed(5);
	    	        			Obj_Existence=PageFirstObj.isDisplayed();
	    	        		}
	    	        		
	    	        	}
	    	        	if(Obj_Existence)
    	        			objcheckval=1;
	        		}
	        		
	        	}
	        	
	        	if(Obj_Existence==true)
	        	{
	        		Total_objectvalue=arrdata[i].toString();
	        		String value;
	        		int rangeVal=Total_objectvalue.indexOf("##");
	        		if(rangeVal<=0){
	        			value=Total_objectvalue;
	        		}
	        		else{
	        			value=Total_objectvalue.substring(0,Total_objectvalue.indexOf("##"));
	        			
	        		}
	        		
	        		if(!obj_type.contains("RDO")&&!obj_type.contains("GRP")&&!obj_type.contains("CAL")){
	        			
	        			String Type1;
	        			if(ORTable.getType(arrobj_name[i])!=null){
	        				Type1="By."+ ORTable.getType(arrobj_name[i]);
	    	        		Curr_obj=ORTable.getElement(arrobj_name[i]);
	    	        		//System.out.println(arrobj_name[i]);
	    	        		LegalEntity=GetwebElement(Type1,Curr_obj);
	        			}
	        		}
	        	switch(obj_type){
	        	
	 	        case "LST":
	 	        Select newdropdown= new Select(LegalEntity);
	         	newdropdown.selectByVisibleText(value);
	         	break;
		         		         	
	 	        case "EDI":
	 	        	if(value.contains("Automation_Unique")){
	 	        		SecureRandom r = new SecureRandom();
						StringBuilder sb = new StringBuilder( 12 );
						   for( int E = 0; E < 12; E++ ) 
						      sb.append( AB.charAt( r.nextInt(AB.length()) ) );
						  
						//System.out.println("Account Name is "+sb.toString());	
						   value=sb.toString();
						   
						   }
	 	        	LegalEntity.click();
	 	   		
	 	   		for (int s = 0; s < value.length(); s++){
	 	   	        char c = value.charAt(s);
	 	   	        String S = new StringBuilder().append(c).toString();
	 	   	        LegalEntity.sendKeys(S);
	 	   	    }
	 	   			LegalEntity.sendKeys(Keys.TAB);
	 	   			if(arrobj_name[i].equalsIgnoreCase("EDI_LegalName") || arrobj_name[i].equalsIgnoreCase("EDI_CustomerName")){
	 	   				LegalName=value;
	 	   			}

	 	        	break;
	 	       
	 	        case "RDO":	
	 	        	waitToBeDisplayed(2);
	 	        	String[] radio=null;
	 	        		//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'no')]/input[@type='radio']
		 	        	//*[contains(text(),'Is this building sprinklered?')]/ancestor::div//*[contains(text(),'No') ]/input[@type='radio']
		 	        radio=value.split("\\:");
	 	        	radio[0]=radio[0].toLowerCase().trim();
		 	        	if(radio.length>1){
		 	        		
		 	        		radio[1]=radio[1].toLowerCase().trim();
		 	        		//LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[@class='radioSet']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input"));
		 	        		LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/input "
		 	        						+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
		 	        	}
		 	        	else
		 	        	{
		 	        		LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] +"')]/input[@type='radio']"));
			 	        }
		 	        	Boolean EntityEnabled=LegalEntity.isEnabled();
		 	        	 if(EntityEnabled){
		 	        		//LegalEntity.click();
		 	        		//LegalEntity.sendKeys(Keys.ENTER);
		 	        		LegalEntity.sendKeys(Keys.SPACE);
		 	        		waitToBeDisplayed(2);
		 	        	}
		 	        	
		 	        	 /*if(!LegalEntity.isSelected()){
		 	        		LegalEntity.click(); 
		 	        	 }*/
		 	        
		 	       break;
	 	        	
	 	        case "ELE":	
	 	        	waitToBeDisplayed(2);
	 	        				if(!LegalEntity.isEnabled()){
	 	       	 	        			System.out.println("Obj is not enabled");
	 	        					}
	 	        					LegalEntity.click();
	 	        	break;
	 	        case "CHK":
	 	        	
	 	        		while(!LegalEntity.isSelected()){
	 	        				LegalEntity.click();
	 	        				waitToBeDisplayed(2);
							}
	 	        	
	 	        	break;
	 	        case "LNK":	
	 	        	 waitToBeDisplayed(5);
		 	    	 WebDriverWait wait1 = new WebDriverWait(driver, 100); 
		 	    	wait1.until(ExpectedConditions.elementToBeClickable(LegalEntity));
		 	    	 
		 	    	LegalEntity.click();
	 	        	
	 	        	break;
	 	       case "BTN":
	 	    	  waitToBeDisplayed(5);
	 	    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
	 	    	wait.until(ExpectedConditions.elementToBeClickable(LegalEntity));
	 	    	 
	 	    	LegalEntity.click();
	 	    		
	 	        	break;
	 	        case "CAL":	
	 	        	invokeFunction(arrobj_name[i].substring(4,arrobj_name[i].length()));
	 	        	
	 	        	break;
	 	       case "GRP":
	 	    	   String elementtype=type[1].toLowerCase();
	 	    	  switch(elementtype){
	 	    	  		case "checkbox":
	 	    	  			String[] checkboxgroup=null,individualcheckbox=null;
	 	    	  			checkboxgroup=value.split("\\~");
	 			 	        for(int chkgrp=0;chkgrp<checkboxgroup.length;chkgrp++){
	 			 	        	try{
	 			 	        		individualcheckbox=checkboxgroup[chkgrp].split("\\:");
	 			 	        		LegalEntity=driver.findElement(By.id(individualcheckbox[0]));
	 			 	        	Boolean LegalEntityStatus=LegalEntity.isSelected();
	 			 	        		if((individualcheckbox[1].toUpperCase().equals("ON") && !LegalEntityStatus )||(individualcheckbox[1].toUpperCase().equals("OFF") && LegalEntityStatus))
	 			 	  			{
	 			 	        			while(!LegalEntity.isSelected()){
		 		 	        				LegalEntity.click();
		 		 	        				waitToBeDisplayed(2);
		 								}
	 			 	  			}
	 			 	        		
	 			 	        	}
	 			 	        	catch(Exception chk){
	 			 	        		System.out.println(chk + " issue with checkbox" + checkboxgroup[chkgrp] +" is not available" );
	 			 	        	}
	 			 	        	waitToBeDisplayed(1);
	 			 	           }
	 	    	  			break;
	 	    	  		case "radiobutton":
	 	    	  			String[] radiogroup=null,individualradio=null;
	 			 	        radiogroup=value.split("\\~");
	 			 	        for(int radgrp=0;radgrp<radiogroup.length;radgrp++){
	 			 	        		
	 			 	        	individualradio=radiogroup[radgrp].split("\\:");
	 			 	        	individualradio[0]=individualradio[0].toLowerCase().trim();
	 			 	        	if(individualradio.length>1){
	 			 	        		
	 			 	        		individualradio[1]=individualradio[1].toLowerCase().trim();
	 			 	        		LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input[@type='radio']"
	 			 	        						+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
	 			 	        	}
	 			 	        	else
	 			 	        	{
	 			 	        		LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] +"')]/input[@type='radio']"));
	 				 	        }
	 			 	        	Boolean Entityselectedval=LegalEntity.isSelected();
	 			 	        	if(!Entityselectedval){
	 			 	        		
	 			 	        		LegalEntity.sendKeys(Keys.SPACE);
	 			 	        	}
	 			 	        	waitToBeDisplayed(1);
	 			 	        }
	 	    	  			break;
	 	    	  		case "editbox":
	 	    	  			String[] editboxgroup=null,individualeditbox=null;
	 	    	  			editboxgroup=value.split("\\~");
	 			 	        for(int edtgrp=0;edtgrp<editboxgroup.length;edtgrp++){
	 			 	        	individualeditbox=editboxgroup[edtgrp].split("\\:");
	 			 	        	try{
	 			 	        		LegalEntity=driver.findElement(By.id(individualeditbox[0]));
		 			 	        	for (int a = 0; a < individualeditbox[1].length(); a++){
		 				 	   	        char n = individualeditbox[1].charAt(a);
		 				 	   	        String S = new StringBuilder().append(n).toString();
		 				 	   	        LegalEntity.sendKeys(S);
		 				 	   	    }
		 				 	   			LegalEntity.sendKeys(Keys.TAB);
	 			 	        	}catch(Exception ed){
	 			 	        		System.out.println(ed + " issue in editbox" + individualeditbox[0] +" is not available" );
	 			 	        	}
	 			 	        	waitToBeDisplayed(1);
	 			 	           }
	 	    	  			break;
	 	    	  			
	 	    	  		case "listbox":
	 	    	  			String[] listboxgroup=null,individuallistbox=null;
	 	    	  			listboxgroup=value.split("\\~");
	 			 	        for(int lstgrp=0;lstgrp<listboxgroup.length;lstgrp++){
	 			 	        	individuallistbox=listboxgroup[lstgrp].split("\\:");
	 			 	        	try{
	 			 	        		LegalEntity=driver.findElement(By.id(individuallistbox[0]));
		 			 	        	 Select individualLST= new Select(LegalEntity);
		 			 	        	individualLST.selectByVisibleText(individuallistbox[1]);
	 			 	        	}catch(Exception lst){
	 			 	        		System.out.println(lst + " issue in listbox" + individuallistbox[0] +" is not available or "+individuallistbox[1]+" is not available" );
	 			 	        	}
	 			 	        	waitToBeDisplayed(1);
	 			 	        }
	 	    	  			break;
	 	    	  		}
	 	    	   
	 	        	break;
	 	       		default:
	 	        
	 	        	break;
	 	        
	        	}
	        	
	        	if(Total_objectvalue.contains("##")){
	        		waitToBeDisplayed(3);
	        		String VerificationData=Total_objectvalue.substring(Total_objectvalue.indexOf("##")+2);
	        		String VerificationContent[]=VerificationData.split("\\~");
	        		for(int sc=0;sc<VerificationContent.length;sc++){
	        			
	        			String Switchval=VerificationContent[sc].substring(0,3);
	        			WebElement VerifyLegalEntity=null;
	        			String VerifyData[]=null,VerifyType="",Curr_verification_obj="";
	        			if(!Switchval.contains("RDO")&&!Switchval.contains("CAL")&&!Switchval.contains("WAI")){
	        			 VerifyData=VerificationContent[sc].split(":");
	        			 VerifyType="By."+ ORTable.getType(VerifyData[0]);
	        			 Curr_verification_obj=ORTable.getElement(VerifyData[0]);
	        			 VerifyLegalEntity=GetwebElement(VerifyType,Curr_verification_obj);
	        			}
	        			switch(Switchval){
	        				case "LST":
	        					if(VerifyData.length>1){
	        					 Select Verifydropdown= new Select(VerifyLegalEntity);
	        					 String SelectedOption=Verifydropdown.getFirstSelectedOption().getText();
	        					 if(SelectedOption.equalsIgnoreCase(VerifyData[1])){
	        						 report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	        			    	        		VerifyData[0]+" Passed", Status.DONE); 
	        					 }else
	        						 throw new Exception("Given selected value "+VerifyData[1]+" does not match with"+ SelectedOption +"==> list verification failed ");
	        					}
	        					else{
	        						boolean ListObjectExistence=false;
	    	    	        		for(int sec=0;(sec<=60 && !ListObjectExistence);sec=sec+5){
	    	    	        			waitToBeDisplayed(5);
	    	    	        			ListObjectExistence=VerifyLegalEntity.isDisplayed();
	    	    	        		}
	    	    	        		if(!ListObjectExistence){
	    	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	    	        		}else{
	    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    	    		    	        		VerifyData[0]+" Passed", Status.DONE);
	    	    	        		}
	        					}
	        					break;
	        		         		         	
	        	 	        case "EDI":
	        	 	        	if(VerifyData.length>1){
	    	    	        		
	    	    	        		if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getAttribute("value"))){
	    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    	    	        		VerifyData[0]+" Passed", Status.DONE);
	    	    	        		}else if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getText())){
	    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    		    	    	        		VerifyData[0]+" Passed", Status.DONE);
	    	    	        		}else{
	    	    	        			throw new Exception(VerifyData[1] +" verification is failed due to the content mismatch");
	    	    	        		}	        	
	    	    	        	}
	    	    	        	else{
	    	    	        		boolean EditobjectExistence=false;
	    	    	        		for(int sec=0;(sec<=60 && !EditobjectExistence);sec=sec+5){
	    	    	        			waitToBeDisplayed(5);
	    	    	        			EditobjectExistence=VerifyLegalEntity.isEnabled();
	    	    	        		}
	    	    	        		if(!EditobjectExistence){
	    	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	    	        		}else{
	    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    	    		    	        		VerifyData[0]+" Passed", Status.DONE);
	    	    	        		}
	    	    	        		
	    	    	        	}
	    	        		break;
	        	 	        	
	        	 	        case "RDO":	
	        	 	        		System.out.println("yet to be confirmed");
	        	 	        	break;
	        	 	        	
	        	 	        case "ELE":	
	        	 	        	boolean EleobjectExistence=false;
    	    	        		for(int sec=0;(sec<=60 && !EleobjectExistence);sec=sec+5){
    	    	        			waitToBeDisplayed(5);
    	    	        			EleobjectExistence=VerifyLegalEntity.isDisplayed();
    	    	        		}
    	    	        		if(!EleobjectExistence){
    	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
    	    	        		}else{
    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
    	    		    	        		VerifyData[0]+" Passed", Status.DONE);
    	    	        		}
	        	 	        	break;
	        	 	        	
	        	 	        case "LNK":	
	        	 	        	boolean lnkobjectExistence=false;
    	    	        		for(int sec=0;(sec<=60 && !lnkobjectExistence);sec=sec+5){
    	    	        			waitToBeDisplayed(5);
    	    	        			lnkobjectExistence=VerifyLegalEntity.isDisplayed();
    	    	        		}
    	    	        		if(!lnkobjectExistence){
    	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
    	    	        		}else{
    	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
    	    		    	        		VerifyData[0]+" Passed", Status.DONE);
    	    	        		}
	        	 	        	
	        	 	        	break;
	        	 	       case "BTN":	
	        	 	    	  boolean BTNobjectExistence=false;
	        	 	    	  for(int sec=0;(sec<=60 && !BTNobjectExistence);sec=sec+5){
	        	 	    		  waitToBeDisplayed(5);
	        	 	    		 //BTNobjectExistence=VerifyLegalEntity.isDisplayed();
	        	 	    		 BTNobjectExistence=VerifyLegalEntity.isEnabled();
	        	 	    	  }
	        	 	    	  if(!BTNobjectExistence){
	        	 	    		  throw new Exception(VerifyData[0] +" Object not loaded");
	        	 	    	  }else{
	        	 	    		  report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
  	    		    	        		VerifyData[0]+" Passed", Status.DONE);
	        	 	    	  }
	        	 	        	
	        	 	        	break;
	        	 	       case "WAI":	
	        	 	    	   		VerifyData=VerificationContent[sc].split(":");
	        	 	    	   		int waittime= Integer.parseInt(VerifyData[1]);
	        	 	    	   		waitToBeDisplayed(waittime);
	        	 	        	
	        	 	        	break;
	        	 	        case "CAL":	
	        	 	        		invokeFunction(arrobj_name[i].substring(4,arrobj_name[i].length()));
	        	 	        	
	        	 	        	break;
	        			}
	        			
	        		}
	        	}
	        	}
	        	else
	        	{
	        		throw new Exception(arrobj_name[i] +" page is not loaded");
	        	}
	                	
	        }
		}catch(Exception e)
		{
			System.out.println("reusable component "+e);
			report.updateTestLog("issue in reusable component", "Page execution failed", Status.FAIL);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("issue in reusable component", "Page Execution failed");
			
		}
	}
	
	private WebElement GetwebElement(String Type,String Obj) {
		try{
		WebElement localWeb=null;
		if(Type.contains("id")){
			localWeb=driver.findElement(By.id(Obj));
		}else if(Type.contains("name")){
			localWeb=driver.findElement(By.name(Obj));
		}
		else if(Type.contains("xpath")){
			localWeb=driver.findElement(By.xpath(Obj));
		}
		return localWeb;
		} 
		catch (Exception e){
			System.out.println("issue in webelement  "+e);
			return null;
		}
	}
	
	
	public static void waitToBeDisplayed(int sec) {
		try {
			int requiredtime=sec*1000;
			Thread.sleep(requiredtime);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void invokeFunction(String Functionname)
			throws IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException {
		Boolean isMethodFound = false;
		final String CLASS_FILE_EXTENSION = ".class";
		File[] packageDirectories = {
				new File(frameworkParameters.getRelativePath()
						+ Util.getFileSeparator() + "businesscomponents")};

		for (File packageDirectory : packageDirectories) {
			File[] packageFiles = packageDirectory.listFiles();
			String packageName = packageDirectory.getName();

			for (int i = 0; i < packageFiles.length; i++) {
				File packageFile = packageFiles[i];
				String fileName = packageFile.getName();

				// We only want the .class files
				if (fileName.endsWith(CLASS_FILE_EXTENSION)) {
					// Remove the .class extension to get the class name
					String className = fileName.substring(0, fileName.length()
							- CLASS_FILE_EXTENSION.length());

					Class<?> reusableMethods = Class.forName(packageName+ "." + className);
					Method executeMethod;
					try {
						// Convert the first letter of the method to lowercase
						// (in line with java naming conventions)
						Functionname = Functionname.substring(0, 1)
								.toLowerCase() + Functionname.substring(1);
						executeMethod = reusableMethods.getMethod(
								Functionname, (Class<?>[]) null);
					} catch (NoSuchMethodException ex) {
						// If the method is not found in this class, search the
						// next class
						continue;
					}

					isMethodFound = true;

					Constructor<?> ctor = reusableMethods
							.getDeclaredConstructors()[0];
					Object businessComponent = ctor.newInstance(scriptHelper);

					executeMethod.invoke(businessComponent, (Object[]) null);
					
					break;
				}
			} 
		}

		if (!isMethodFound) {
			throw new FrameworkException("Keyword " + Functionname
					+ " not found within any class "
					+ "inside the businesscomponents package");
		}
	}
	
}