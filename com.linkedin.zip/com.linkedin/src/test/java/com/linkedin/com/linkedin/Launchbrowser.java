package com.linkedin.com.linkedin;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Launchbrowser {
	static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		driver.get("https://www.linkedin.com/");
		
		//WebElement SignIn = driver.findElement(By.xpath("//*[@title = 'Sign In']"));
		WebElement SignIn = driver.findElement(By.xpath("//*[text() = 'Sign in' or text() = 'Sign In']"));
		
		SignIn.click();
		waittillpageload();
		WebElement UserName = driver.findElement(By.id("username"));
		WebElement Password = driver.findElement(By.id("password"));
		waittillpageload();
		WebElement SignInbtn = driver.findElement(By.xpath("//*[@aria-label= 'Sign in']"));
		
		UserName.sendKeys("navaniithan@gmail.com");
		Password.sendKeys("Qwerty@123");
		waittillpageload();
		SignInbtn.click();
		waittillpageload();
		//WebElement ProfileIcon = driver.findElement(By.xpath("//button[@id='nav-settings__dropdown-trigger']//li-icon"));
		//WebElement SignOut = driver.findElement(By.xpath("//*[text() = 'Sign out']"));
		//Thread.sleep(5000);
		
/*		ProfileIcon.click();
		waittillpageload();
		SignOut.click();
		waittillpageload();	*/	
		
		
		WebElement searchbox = driver.findElement(By.className("search-global-typeahead__input"));
		//searchbox.click();
		searchbox.sendKeys("Software Engineer");
		searchbox.sendKeys(Keys.RETURN);
		//Thread.sleep(50000);
		waittillpageload();
		WebElement People = driver.findElement(By.xpath("//*[@aria-label= 'View only People results']"));
		People.click();
		waittillpageload();
		
		for(int j = 1; j <= 3; j++) {
		List<WebElement> connect = driver.findElements(By.xpath("//button[text()= 'Connect']"));
		/*	while(connect.size()<10) {
			connect = driver.findElements(By.xpath("//button[text()= 'Connect']"));
			}*/
			
		for(int i = 0; i < connect.size();i++) {
		waittillpageload();
		Thread.sleep(1000);
		waittillpageload();
		connect.get(i).click();				
		WebElement AddNote = driver.findElement(By.xpath("//span[text()='Add a note']"));
		AddNote.click();
		WebElement message = driver.findElement(By.name("message"));
		message.sendKeys("Hi\r\n" + 
				"I would like to connect with great people to mutually share the opportunities and knowledge to grow together.\r\n" + 
				"Thank you.   ");
		
		WebElement DoneBtn = driver.findElement(By.xpath("//span[text()='Done']"));
		DoneBtn.click();
		waittillpageload();
		} 
		WebElement Next = driver.findElement(By.xpath("//span[text()='Next']"));
		Next.click();

		}
		
	}
	
	public static void waittillpageload() throws InterruptedException{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	for (int i = 1; i <= 60; i++) {		
		System.out.println(js.executeScript("return document.readyState").toString());
		//Boolean isAjaxRunning = Boolean.valueOf(js.executeScript("return document.readyState").toString());

		//System.out.println(isAjaxRunning);
			if(js.executeScript("return document.readyState").toString().equals("complete")) {
				break;
			}else {
				System.out.println("Wait 1000");
				Thread.sleep(1000);							
			}          
		}

	}
}

