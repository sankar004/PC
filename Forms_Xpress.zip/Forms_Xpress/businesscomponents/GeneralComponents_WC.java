package businesscomponents;



import java.sql.*;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.DriverScript;
import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;








//import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Status;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.selenium.CraftDriver;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class GeneralComponents_WC extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
		
	public GeneralComponents_WC(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	public void ccDeleteEdit() {
		try{
			WebElement table=driver.findElement(By.xpath("//table[@class='roster']"));
			
			List<WebElement> ElementsLable=table.findElements(By.xpath("//table[@class='roster']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'delete')]"));
			while(ElementsLable.size()!=0){
			ElementsLable.get(0).click();
				waitToBeDisplayed(1);
				driver.findElement(By.xpath("//table[@class='foreground']//a[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'yes')]")).click();
				
				table=driver.findElement(By.xpath("//table[@class='roster']"));
				 ElementsLable=table.findElements(By.xpath("//table[@class='roster']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'delete')]"));
			}
		}catch(Exception e){
			System.out.println("Issue in ccDeleteEdit  "+e);
		}
	
	}
	public void eligibility_Ques(){
		try {
			String eligibilityMessage="There are no questions to answer.";
			boolean eligibilityques=false;
			
			try{
				WebElement EM=driver.findElement(By.xpath("//*[contains(text(),'"+ eligibilityMessage +"')]"));
				System.out.println("No eligibility questions are Present");
			}
			catch (Exception e){
				eligibilityques=true;
			}
			if(eligibilityques){
				waitToBeDisplayed(2);
				WebElement fieldset=null;
				String Lob="";
				try{
					Lob = dataTable.getData("Selectlob", "Object");
				}catch(Exception e){
					Lob="wc";//should be updated
				}
				if((Lob.toLowerCase().contains("spectrum")) || (Lob.toLowerCase().contains("auto"))){
					fieldset = driver.findElement(By.id("eligibilityQuestions"));
				}
				else if(Lob.toLowerCase().contains("wc")){
					fieldset = driver.findElement(By.id("policyInformation"));	
				}
				commonElegibilityQuestions(fieldset);
				
			}
			
		}
		catch(Exception e){
			System.out.println("Eligibility Questions "+e);
			report.updateTestLog("Eligibility Questions ", "Eligibity Questions failed", Status.SCREENSHOT);
			//frameworkParameters.setStopExecution(true);
			//throw new FrameworkException("Eligibity Questions", "Eligibity Questions failed");
			
		}
	}
	public void additionalEligQues() {
		try{
			String xpath="//form[contains(@id,'EligibilityQuestions')]";
			WebElement Fieldset=driver.findElement(By.xpath("//form[contains(@id,'EligibilityQuestions')]"));
			commonElegibilityQuestions(Fieldset);
			WebElement continuebutton=driver.findElement(By.id("continueButton"));
			 waitToBeDisplayed(2);
	    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
	    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
	    	 element.click();
	        	
			
		}catch(Exception e){
			System.out.println("Issue in additionalEligQues  "+e);
		}
	
	}
	public void commonElegibilityQuestions(WebElement fieldset){
		try{
			List<WebElement> ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
			String [] labelids=new String[ElementsLable.size()];
			int RadioCounter = 0;
			//for(int Counter = 0; Counter < ElementsLable.size(); Counter++){
				while(RadioCounter < ElementsLable.size()){
				labelids[RadioCounter]=ElementsLable.get(RadioCounter).getAttribute("id");
				String labelid=labelids[RadioCounter].substring(0,labelids[RadioCounter].indexOf('_'));
				List<WebElement> Elementvalues=fieldset.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
				
				for(int ValCount=Elementvalues.size()-1;ValCount>=0 ;ValCount--){
					Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
					
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
								Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
						}
						catch(Exception ex){
							//System.out.println("check box 'none of the above' selected");
							break;
						}
					
				}
				RadioCounter++;
				ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));				
				}
			
			}
			catch(Exception RB){
				//System.out.println("No radio buttons present");
			}
			List<WebElement> Chckboxes =fieldset.findElements(By.xpath("//*[@type='checkbox']"));
			if(Chckboxes!=null){
			try{
			int totalCheckboxes=fieldset.findElements(By.xpath("//*[@type='checkbox']/ancestor::div/preceding::div[contains(@class,'required')]")).size();	
			int checked=0;
			List<WebElement> ElementNoneofabove =fieldset.findElements(By.xpath("//*[@type='checkbox']/../following-sibling::label/span[contains(@id,'labelText') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
			if(ElementNoneofabove.size()>0){
				for(int x=0;x<ElementNoneofabove.size();x++){
					ElementNoneofabove.get(x).click();
					
					try{
						WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
						if(hardstop1.isDisplayed())
							ElementNoneofabove.get(x).click();
						checked--;
					}
					catch(Exception e){
						//System.out.println("check box 'none of the above' selected");
						checked++;
					}
					}	
				}
			if(totalCheckboxes>checked){
				for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
					
					Chckboxes.get(Counter).click();
						//System.out.println("checking");
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
							Chckboxes.get(Counter).click();
						}
						catch(Exception ex){
							//System.out.println("check box selected");
						}
					}
			}
			}
			catch(Exception e){
				for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
					
					Chckboxes.get(Counter).click();
					//	System.out.println("checking");
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
							Chckboxes.get(Counter).click();
						}
						catch(Exception ex){
							//System.out.println("check box 'none of the above' selected");
						}
					}	
			}
			}
			
	}
	public void pricingAdjustment() {
		try{
			//driver.findElement(By.id("REQUEST_PRICING_LINK")).click();
			waitToBeDisplayed(2);
			WebElement Fieldset=driver.findElement(By.xpath("//form[@id='requestPricing']"));
			waitToBeDisplayed(2);
			try{
				List<WebElement> DropdownLST=Fieldset.findElements(By.xpath("//form[@id='requestPricing']//select[translate(@id, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')!='secondaryactions']"));
				float[][] optinvalues=null;
				float condition=0;
				optinvalues = new float[DropdownLST.size()][];
				for(int i=0;i<DropdownLST.size();i++){
					
					Select newdropdown= new Select(DropdownLST.get(i));
	 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
	 	        	optinvalues[i] = new float[dropdownlist.size()];
	 	        	int k;
	 	        	String first_val=dropdownlist.get(0).getAttribute("value");
	 	        	
	 	        	
	 	        	for(int j=0;j<dropdownlist.size();j++){
	 	        		String optionval=dropdownlist.get(j).getAttribute("value").toString();
	 	        		
	 	        		if(!optionval.contains(".")){
	 	        			optionval=optionval+".00";
	 	        		}
	 	        		
	 	        		if(first_val.startsWith("-"))
		 	        	{
		 	        		k=dropdownlist.size()-(j+1);
		 	        	}
		 	        	else
		 	        	{
		 	        		k=j;
		 	        	}
	 	        		
	 	        		
	 	        		optinvalues[i][k]=Float.parseFloat(optionval);
	 	        	}
	 	        	if(optinvalues[i][dropdownlist.size()-1]>0)
	 	        	{
	 	        		
	 	        		condition=optinvalues[i][dropdownlist.size()-1]+condition;
	 	        	}
	 	        	else
	 	        	{
	 	        		condition=optinvalues[i][0]+condition;
	 	        	}
 	        		
	 	        	
	 	        	
				}
				System.out.println("pricingAdjustment condition count" + condition);
				if(condition<=25.00){
					for(int k=0;k<DropdownLST.size();k++){
						Select newdropdown= new Select(DropdownLST.get(k));
		 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
		 	        	newdropdown.selectByIndex(dropdownlist.size()-1);
					}	
				}
				else if(condition>=25.00) {
					double target=25.00;
				float val[]=randomCount(optinvalues,target);
				String dropdownval;
				for(int i=0;i<DropdownLST.size();i++){
					Select newdropdown= new Select(DropdownLST.get(i));
					String list_values=DropdownLST.get(i).getText();
					String arr_listvalues[]=list_values.split("\n");
					int arrlist_len=arr_listvalues.length;
					for(int j=0;i<arr_listvalues.length;j++)
					{
						String currarr_value=arr_listvalues[j];
						System.out.println(currarr_value);
					dropdownval=String.valueOf(val[i]);
					System.out.println(dropdownval);
					dropdownval=dropdownval.substring(0,dropdownval.indexOf("."));
					if(arr_listvalues[j].contains(dropdownval))
					{
					//newdropdown.selectByValue(currarr_value);
					//newdropdown.selectByIndex(j);
					newdropdown.selectByVisibleText(currarr_value);
					break;
					}
				}
					/*while (24.00>=condition && condition<=27.00){
						condition=0;
						float localcondition=0;
						for(int k=0;k<DropdownLST.size();k++){
							Select newdropdown= new Select(DropdownLST.get(k));
			 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
			 	        	int indexToSelect = (int)(Math.random()*(dropdownlist.size()-1)+1);
			 	        	newdropdown.selectByIndex(indexToSelect);
			 	        	localcondition=localcondition+Float.parseFloat(dropdownlist.get(indexToSelect).toString());
						}
						condition=localcondition;
					}*/
				}
				WebElement continuebutton=driver.findElement(By.id("continueButton"));
				 waitToBeDisplayed(2);
		    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
		    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
		    	 element.click();
		    	 //continueButton
				
			}
			}catch(Exception le){
				System.out.println("Issue with the list of elements in request pricing --> " +le);
			}
		}catch(Exception e){
			System.out.println("Issue in pricingAdjustment  "+e);
		}
	
	}
	public float[] randomCount(float[][] optinvalues,double target){
		try{
		  int n = 1;
	      for (int j = 0; j < optinvalues.length; j++) {
	         n *= optinvalues[j].length;
	      }
	      int i[] = new int[optinvalues.length];
	      float val[]=new float[optinvalues.length];
	      double sum=0;
	      while(sum!=target){
	      for (int k = 0; k < n; k++) {
	    	  
	         for (int rr = 0; rr < optinvalues.length; rr++) {
	        	 sum=sum+optinvalues[rr][i[rr]];
	        	 val[rr]=optinvalues[rr][i[rr]];
	           // System.out.print(optinvalues[rr][i[rr]] + " ");
	         }
	        // System.out.println(sum+" sum");
	         if(sum==target){
	        	 break;
	        	
	         }
	         
	         else if(sum>=target-1||sum<=target+1)
	         {
	        	 break;
	         }
	         
	         
	         else{
	         i[optinvalues.length-1]++;
	         for (int j = optinvalues.length-1; j > 0; j--) {
	            if (i[j] >= optinvalues[j].length) {
	               i[j] = 0;
	               i[j - 1]++;
	            } else{
	            	sum=0;
	            	
	               break;
	         }
	            
	         }
	      }
	      }
	    
	      }
	      return val ;
		}
		catch(Exception e)
		{
		System.out.println("Exception"+e);
		return null;
		}
	      
	}
	public void pricingJustification() {
		try{
			WebElement heading=driver.findElement(By.xpath("//*[@id='pageTitle' and contains(text(),'Pricing Justification')]"));
			while(heading.isDisplayed()){
			WebElement fieldset=driver.findElement(By.xpath("//fieldset[contains(@id,'PricingJustificationSection')]"));
			try{
			List<WebElement> DropdownLST=fieldset.findElements(By.xpath("//fieldset[contains(@id,'PricingJustificationSection')]//select[not (contains(@id,'Percentage'))]"));
			
			for(int i=0;i<DropdownLST.size();i++){
				Select newdropdown= new Select(DropdownLST.get(i));
 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
 	        	int n = (int)(Math.random()*(dropdownlist.size()-1) +1);
	        		newdropdown.selectByIndex(n);
	        		waitToBeDisplayed(1);
 	        	}
 	        	
			}catch (Exception Ls){
				System.out.println("No List boxes in pricing justifications "+Ls);
			}
			try{
				List<WebElement> DropdownLST_Percentage=fieldset.findElements(By.xpath("//fieldset[contains(@id,'PricingJustificationSection')]//select[contains(@id,'Percentage')]"));
				float[][] optinvalues=null;
				String condition=driver.findElement(By.xpath("//label[@id='PricingDebitBottonMsg2_label']/ancestor::div[1]/span/span")).getText();
				int condition_val=Integer.parseInt(condition.substring(0,condition.indexOf("%")));
				optinvalues = new float[DropdownLST_Percentage.size()][];
				for(int i=0;i<DropdownLST_Percentage.size();i++){
					Select newdropdown= new Select(DropdownLST_Percentage.get(i));
	 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
	 	        	optinvalues[i] = new float[dropdownlist.size()];
	 	        	int j;
	 	        	String firstText=dropdownlist.get(0).getText().toString();
	 	        	int firstval=Integer.parseInt(firstText.substring(0,firstText.indexOf("%")));
	 	        	int k;
	 	        	
	 	        		for(j=0;j<=dropdownlist.size()-1;j++){
		 	        		String optiontext=dropdownlist.get(j).getText().toString();
		 	        		int optionval=Integer.parseInt(optiontext.substring(0,optiontext.indexOf("%")));
		 	        		if(firstval<0){
		 	        			k=dropdownlist.size()-(j+1);
		 	        		}else{
		 	        			k=j;
		 	        		}
		 	        		optinvalues[i][k]=optionval;
		 	        }
	 	        	
	 	        }

				float aval[]=randomCount(optinvalues,condition_val);
				String dropdownval;
				for(int i=0;i<DropdownLST_Percentage.size();i++){
					Select newdropdown= new Select(DropdownLST_Percentage.get(i));
					dropdownval=String.valueOf(aval[i]);
					dropdownval=dropdownval.substring(0,dropdownval.indexOf("."))+"%";
					newdropdown.selectByVisibleText(dropdownval);
				}
				
				}
				catch (Exception Ls){
					System.out.println("No List boxes in pricing justifications "+Ls);
				}
			try{
				List<WebElement> CheckboxLST=fieldset.findElements(By.xpath("//fieldset[contains(@id,'PricingJustificationSection')]//input[@type='checkbox']"));
				for(int j=0;j<CheckboxLST.size();j++){
					if(!CheckboxLST.get(j).isSelected()){
					CheckboxLST.get(j).click();
	 				waitToBeDisplayed(2);
					}
				}				
			}
			catch (Exception CB){
				System.out.println("No Check boxes in pricing justifications "+CB);
			}
			WebElement continuebutton=driver.findElement(By.id("continueButton"));
			 waitToBeDisplayed(2);
	    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
	    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
	    	 element.click();
	    	 waitToBeDisplayed(2);
	    	 heading=driver.findElement(By.xpath("//*[@id='pageTitle' and contains(text(),'Pricing Justification')]"));
			 }
		}
		catch(Exception e){
			System.out.println("Issue in pricing Justification: "+e);
		}
	
	}
	

    

	public static void waitToBeDisplayed(int sec) {
			try {
				int requiredtime=sec*1000;
				Thread.sleep(requiredtime);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	
	
	
	
	
public static String SelectQuery(String TargetColumnName, String TableNmae, String SourceColumnName, String SourceValue ) throws SQLException{
		
		Statement statement = null;		 
		ResultSet resultSet = null;
		String result = null;
		statement = Getconnection();		 
		
		String Query = "SELECT " + TargetColumnName + " FROM " + TableNmae + " WHERE " + SourceColumnName + " ='" + SourceValue + "'";	 		 
		 
		resultSet = statement.executeQuery(Query);		 
		while(resultSet.next()) {
        	 result = resultSet.getString(1);
        	 }         
         return result;
     }	
	
	public static String SelectQuery(String TargetColumnName, String TableNmae, String SourceColumnName_1, String SourceValue_1, String SourceColumnName_2, String SourceValue_2, String SourceColumnName_3, int SourceValue_3 ) throws SQLException{
		
		Statement statement = null;		 
		ResultSet resultSet = null;
		String result = null;
		statement = Getconnection();
		String Query = "SELECT " + TargetColumnName + " FROM " + TableNmae + " WHERE " + SourceColumnName_1 + " ='" + SourceValue_1 + "' AND " + SourceColumnName_2 + " ='" + SourceValue_2 + "' AND " + SourceColumnName_3 + " ='" + SourceValue_3 + "'";
		resultSet = statement.executeQuery(Query);		 

		while(resultSet.next()) {
        	 result = resultSet.getString(1);
        } 

         return result;
     }	
	
	
	public static int getversionumber(String TableNmae, String SourceColumnName_1, String SourceValue_1, String SourceColumnName_2, String SourceValue_2) throws SQLException{
		Statement statement = null;		
		ResultSet resultSet = null;
		int result = 0;
		int result1 = 0;		
		statement = Getconnection();		
		String Query = "SELECT  Version FROM " + TableNmae + " WHERE " + SourceColumnName_1 + " ='" + SourceValue_1 + "' AND " + SourceColumnName_2 + " ='" + SourceValue_2 + "'";
		resultSet = statement.executeQuery(Query);		 
		while(resultSet.next()) {
			String tempres = resultSet.getString(1);
			if (!tempres.isEmpty())			
			{
			result1 = Integer.parseInt(tempres);
			}
        	 if (result < result1)
        	 {
        	 result = result1;    		 
        	 }	 
        }  
		return result;
	}
		
public static void updatequery(String value1, String value2, String value3, int value4 ) throws SQLException{		
		 Statement statement = null;		 
		 statement = Getconnection();		 
		 String Query = "INSERT INTO E2E_Testdata (E2E_Scenario_Name, Field_Name, Field_Value, Version) VALUES ('"+ value1 +"', '"+ value2 +"', '"+ value3 +"', '"+ value4 +"')";	 
		 statement.execute(Query);		 
     }		

	public static Statement Getconnection(){		
		
	  // variables
     Connection connection = null;
     Statement statement = null;
     //Loading or registering Oracle JDBC driver class
     try {

         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
     }
     catch(ClassNotFoundException cnfex) {

         System.out.println("Problem in loading or "
                 + "registering MS Access JDBC driver");
         cnfex.printStackTrace();
     }
     //Opening database connection
     try {
         String msAccDB = "C:/Selenium/WorkSpace/NewIconFrame/NewIconFrame/Uploadresults/E2E_TestData.accdb";
         String dbURL = "jdbc:ucanaccess://" + msAccDB; 
         //Create and get connection using DriverManager class
         connection = DriverManager.getConnection(dbURL); 
         //Creating JDBC Statement 
         statement = connection.createStatement();		
     	}
     catch(SQLException sqlex){
         sqlex.printStackTrace();
     	}	
     // Returning statement object
		return statement;		
	}
	
	
	
	
	
	
}