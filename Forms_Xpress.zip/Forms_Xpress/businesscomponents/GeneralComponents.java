package businesscomponents;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Scanner; 

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
//import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Status;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.selenium.CraftDriver;


/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class GeneralComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	//static final String THAW_DATA = "THAWData";
	static final String ICON_DATA = "General_Data";
	//static final String NOTIFICATION_DATA = "Notification_Data";
	 boolean DEBUG_MODE = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp")>0; 
	 
	public String textMessage;
	
	public GeneralComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	public void loginNBV()
	{
		//driver.get(properties.getProperty("ApplicationUrl"));
		driver.get(dataTable.getData(ICON_DATA, "Url"));
		String userId = dataTable.getData(ICON_DATA, "EDI_USER");
		String password = dataTable.getData(ICON_DATA, "EDI_PASSWORD");
		report.updateTestLog("Enter user credentials", "Specify username = "+userId, Status.PASS);
		if(dataTable.getData(ICON_DATA, "Url").contains("qa01")||dataTable.getData(ICON_DATA, "Url").contains("ti01ebc")){
			driver.findElement(By.name("USERText")).sendKeys(userId);
		}
		else{
			driver.findElement(By.name("USER")).sendKeys(userId);
		}
		
		for (int s = 0; s < password.length(); s++){
	   	        char c = password.charAt(s);
	   	        String S = new StringBuilder().append(c).toString();
	   	     driver.findElement(By.name("PASSWORD")).sendKeys(S);
	   	    }
		
		driver.findElement(By.name("PASSWORD")).sendKeys(Keys.TAB);
		//driver.findElement(By.name("PASSWORD")).sendKeys(password);
		report.updateTestLog("Login", "Click the sign-in button", Status.SCREENSHOT);
		if(dataTable.getData(ICON_DATA, "Url").contains("qa01")||dataTable.getData(ICON_DATA, "Url").contains("ti01ebc")){
			driver.findElement(By.id("login-submit")).click();
		}
		else{
			driver.findElement(By.id("login")).click();
		}
		
		if(driver.getTitle().equalsIgnoreCase("Login | The Hartford EBC eBusiness Center for P&C Agents")){
			report.updateTestLog("Verify Login ", "Login failed for valid user",  Status.FAIL);
			
		}
		
		else if(driver.getTitle().equalsIgnoreCase("Commercial Insurance: Home | The Hartford EBC eBusiness Center for P&C Agents")){
		report.updateTestLog("Login successful", "Login successful", Status.PASS);
		driver.findElement(By.xpath("//*[contains(text(),'Quote Small Commercial (ICON)')]")).click();
		
		waitToBeDisplayed(5);
		ArrayList<String> allwindows1=new ArrayList<String>(driver.getWindowHandles());
		//System.out.println(driver.getWindowHandles().size());
		for (String winHandle : allwindows1) {
			//System.out.println(driver.getTitle());
			  driver.switchTo().window(winHandle); 
			if(driver.getTitle().contains("ICON | Small Commercial Quoting | Customer Home")) {			
				    //driver.switchTo().window(winHandle); 
				   // System.out.println(driver.getTitle());
				break;
				}
			}
		}
		else if(driver.getTitle().equalsIgnoreCase("ICON | Small Commercial Quoting | Customer Home")){
			report.updateTestLog("Login successful", "Login successful", Status.PASS);
		}
		else{
			System.out.println("issue in login");
		}
			
	}
	
	
	public void login_NBV()
	{
	       //driver.get(properties.getProperty("ApplicationUrl"));
	       driver.get(dataTable.getData(ICON_DATA, "Url"));
	       String userId = dataTable.getData(ICON_DATA, "EDI_USER");
	       String password = dataTable.getData(ICON_DATA, "EDI_PASSWORD");
	       report.updateTestLog("Enter user credentials", "Specify username = "+userId, Status.PASS);
	       waitToBeDisplayed(2);
	       if(dataTable.getData(ICON_DATA, "Url").contains("qa04")||dataTable.getData(ICON_DATA, "Url").contains("qa01"))
	       {
	              driver.findElement(By.name("USER")).sendKeys(userId);
	       }
	       else{
	              driver.findElement(By.name("USERText")).sendKeys(userId);
	       }
	       
	       for (int s = 0; s < password.length(); s++)
	       {
	               char c = password.charAt(s);
	               String S = new StringBuilder().append(c).toString();
	            driver.findElement(By.name("PASSWORD")).sendKeys(S);
	           }
	       
	       driver.findElement(By.name("PASSWORD")).sendKeys(Keys.TAB);
	       //driver.findElement(By.name("PASSWORD")).sendKeys(password);
	       report.updateTestLog("Login", "Click the sign-in button", Status.SCREENSHOT);
	       if(dataTable.getData(ICON_DATA, "Url").contains("qa04")||dataTable.getData(ICON_DATA, "Url").contains("qa01"))
	       {
	              driver.findElement(By.id("login")).click();
	       }
	       else{
	              driver.findElement(By.id("login-submit")).click();
	       }
	       report.updateTestLog("Login successful", "Login successful", Status.PASS);
	      /* WebDriverWait wait=new WebDriverWait(driver, 5);
	       //WebElement LinkAddNew;
	       //LinkAddNew = 
	       wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("AddCustomerForm:icon4_Home_Addnew_Customer")));
	       
	       //Best//waitToBeDisplayed(100);
	       ArrayList<String> allwindows1=new ArrayList<String>(driver.getWindowHandles());
	       //System.out.println(driver.getWindowHandles().size());
	       for (String winHandle : allwindows1) 
	       {
	              //System.out.println(driver.getTitle());
	                driver.switchTo().window(winHandle); 
	              if(driver.getTitle().contains("ICON | Small Commercial Quoting | Customer Home"))
	              {                    
	                         //driver.switchTo().window(winHandle); 
	                        // System.out.println(driver.getTitle());
	                     report.updateTestLog("Login successful", "Login successful", Status.PASS);
	                     break;
	                     }
	              
	       else{
	              System.out.println("issue in login");
	       }
	              
	}*/
	}
	
	
	public void invokeApplication() {
		System.out.println("invoke application");
		report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								properties.getProperty("ApplicationUrl"), Status.DONE);
		
		driver.get(properties.getProperty("ApplicationUrl"));
	}
	public void newCustomer_ProducerCode()
	{	
		String ProducerCode=dataTable.getData("NewCustomer", "CAL_NewCustomer_ProducerCode");
	System.out.println("ProducerCode"+ProducerCode);
		String  Entityid=driver.findElement(By.xpath("//*[contains(@name,'CustomerInfoForm:pc')]")).getAttribute("id");
		
		if(Entityid.contains("pc_input")){
		driver.findElement(By.id("CustomerInfoForm:pc_input")).sendKeys(ProducerCode);
		driver.findElement(By.id("CustomerInfoForm:pc_input")).sendKeys(Keys.TAB);
		waitToBeDisplayed(3);
		report.updateTestLog("Entered Producer Code", "Specified Producer Code = "+ProducerCode, Status.PASS);
		}
		else if(Entityid.equals("CustomerInfoForm:pc_list")){
			Select newdropdown= new Select(driver.findElement(By.id("CustomerInfoForm:pc_list")));
         	newdropdown.selectByVisibleText(ProducerCode);
         	report.updateTestLog("Entered Producer Code", "Specified Producer Code = "+ProducerCode, Status.PASS);
		}
			
	}
	public void verifyPageTitle(){
		waitToBeDisplayed(2);
		if(textMessage == null){
			textMessage = dataTable.getData(ICON_DATA, "PageTitle");
			String arrPage[] = textMessage.split(";");
			try{
				if(Arrays.asList(arrPage).contains(driver.getTitle().trim())){
					report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.SCREENSHOT);
				}else{
					report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.SCREENSHOT);
				}
			}catch(Exception e){
				report.updateTestLog("Page Title", ""+driver.getTitle().toUpperCase()+"- Page title displayed", Status.FAIL);
			}
		}
	}
	
	
	
	/*public void genInfoPage(){
		try{
			waitToBeDisplayed(3);
			
			 ArrayList<String> allwindows=new ArrayList<String>(driver.getWindowHandles());
			//System.out.println("first trial "+driver.getWindowHandles().size());
			 if(allwindows.size()<4){
	        		for(int sec=0;(sec<=60 && !(allwindows.size()>=4));sec=sec+5){
	        			waitToBeDisplayed(5);
	        			allwindows=new ArrayList<String>(driver.getWindowHandles());
	        		}
	        		
	        	}
			for (String winHandle : allwindows) {
				//System.out.println(driver.getTitle());
				driver.switchTo().window(winHandle); 
				if(driver.getTitle().contains("ICON - "+ ReusableCommonComponents.LegalName)) {			
					   // System.out.println(driver.getTitle());
					break;    
					}
				}
			
			waitToBeDisplayed(3);
			//System.out.println("just checking");
		}catch(Exception e){
			report.updateTestLog("Verify Login ", "Login failed for valid user", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("Verify Login", "Login failed for valid user");
			
		}
	}
	*/
	
	public void genInfoPage(){
        try{
               waitToBeDisplayed(3);
               
               ArrayList<String> allwindows=new ArrayList<String>(driver.getWindowHandles());
               //System.out.println("first trial "+driver.getWindowHandles().size());
               int wincount;
               if(dataTable.getData(ICON_DATA, "Url").contains("esubmissions")){
                     wincount=3;
                     }
                     else{
                            wincount=4;
                     }
               if(allwindows.size()<wincount){
                      for(int sec=0;(sec<=60 && !(allwindows.size()>=wincount));sec=sec+3){
                            waitToBeDisplayed(3);
                            allwindows=new ArrayList<String>(driver.getWindowHandles());
                      }
                      
               }
               for (String winHandle : allwindows) {
            	  
                     //System.out.println(driver.getTitle());
                     driver.switchTo().window(winHandle); 
                     System.out.println(driver.getTitle().replaceAll(" ", ""));
                    // if(driver.getTitle().contains("ICON - "+ ReusableCommonComponents.LegalName)) { 
                    	 if(driver.getTitle().replaceAll(" ", "").contains("ICON-")) { 
                               // System.out.println(driver.getTitle());
                            break;    
                            }
                     }
               
               waitToBeDisplayed(3);
               //System.out.println("just checking");
        }catch(Exception e){
               report.updateTestLog("Verify Login ", "Login failed for valid user", Status.SCREENSHOT);
               frameworkParameters.setStopExecution(true);
               throw new FrameworkException("Verify Login", "Login failed for valid user");
               
        }
 }
	
	
	public void underWriting_Ques(){
		
        try {
            waitToBeDisplayed(1);
            WebElement PolicyQuestions=driver.findElement(By.xpath("//*[@id='work_item_menu']|//*[@id='UnderwritingQuestions']"));
            try{
                  List<WebElement> ElementsLable = PolicyQuestions.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
                  String [] labelids=new String[ElementsLable.size()];
            //int Counter=0;
                  for (int Counter=0;Counter < ElementsLable.size();Counter++){
                  
                         labelids[Counter]=ElementsLable.get(Counter).getAttribute("id");
                         //System.out.println(labelids[Counter]);
                         String labelid=labelids[Counter].substring(0,labelids[Counter].indexOf('_'));
                         //System.out.println(labelid);
                         List<WebElement> Elementvalues=PolicyQuestions.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
                         //System.out.println("//input[contains(@id,'"+labelid+"')]");
                         for(int ValCount=Elementvalues.size()-1; ValCount>=0 ;ValCount--){
                                Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
                                try{
                                       WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                       
                                }
                                catch(Exception ex){
                                       //Counter++;                                    
                                       break;
                                       
                                }
                         }
                         waitToBeDisplayed(1);
                         ElementsLable = PolicyQuestions.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));                        
                         if(ElementsLable.size()!=labelids.length){
                                labelids = Arrays.copyOf(labelids, ElementsLable.size());
                         }
                  }
            }
            
     catch(Exception r){
                  System.out.println(r);
                  System.out.println("No Radio buttons");
            }
            try{
                  
            List<WebElement> TotalCheckboxQuestions=PolicyQuestions.findElements(By.xpath("//*[@type='checkbox']/ancestor::div[1]/ancestor::fieldset"));       
            String[] checkboxIds=new String[TotalCheckboxQuestions.size()];
            String checkboxlabel="";
            
            for(int checkboxQ = 0; checkboxQ < TotalCheckboxQuestions.size(); checkboxQ++){
                  checkboxlabel=TotalCheckboxQuestions.get(checkboxQ).getAttribute("id");
                   checkboxIds[checkboxQ]=checkboxlabel.substring(checkboxlabel.indexOf("_")+2,checkboxlabel.length());
                  
                  List<WebElement> ElementCheckboxvals=PolicyQuestions.findElements(By.xpath("//fieldset//input[@type='checkbox' and contains(@id,'"+checkboxIds[checkboxQ]+"')]"));
                  try{
                  WebElement ElementNoneofabove =PolicyQuestions.findElement(By.xpath("//fieldset//label/span[contains(@id,'labelText') and contains(@id,'"+checkboxIds[checkboxQ]+"') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
                  if(ElementNoneofabove != null){
                                              ElementNoneofabove.click();
                         try{
                                WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                if(hardstop1.isDisplayed())
                                       ElementNoneofabove.click();
                                
                         }
                  
                         catch(Exception e){
                                //System.out.println("check box 'none of the above' selected");
                                break;
                         }
                 

                  }
                  
                  }
                  catch( Exception N){
                         
                  
                  for(int s=0;s<ElementCheckboxvals.size();s++ ){
                  try
                      {
                         ElementCheckboxvals.get(s).click();}
                  catch(Exception e)
                      {
                           ElementCheckboxvals.get(s).sendKeys(Keys.RETURN);
                          ElementCheckboxvals.get(s).click();
                      }
                         
                         try{
                                WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                if(hardstop1.isDisplayed())
                                  
                                       ElementCheckboxvals.get(s).click();
                                
                                
                         }
                         catch(Exception e){
                                //System.out.println("check box 'none of the above' selected");
                                break;
                        }
                  }
                  } 
                  waitToBeDisplayed(1);
                   TotalCheckboxQuestions=PolicyQuestions.findElements(By.xpath("//*[@type='checkbox']/ancestor::div[1]/ancestor::fieldset"));
                  if(TotalCheckboxQuestions.size()!=checkboxIds.length){
                         checkboxIds = Arrays.copyOf(checkboxIds, TotalCheckboxQuestions.size());
                  }
            }
            
            }
            catch(Exception c){
                  //System.out.println("No Check boxes");
                  
            }
            
            try{
                  List<WebElement> Totallistboxes=PolicyQuestions.findElements(By.xpath("//select[not (contains(@id,'secondary'))]"));    
                  for(int listboxQ = 0; listboxQ < Totallistboxes.size(); listboxQ++){
                         Select newdropdown= new Select(Totallistboxes.get(listboxQ));
                         int optionCount=newdropdown.getOptions().size();
                         for(int selectOption=1;selectOption<optionCount;selectOption++){
                                newdropdown.selectByIndex(selectOption);
                                       
                                       try{
                                              WebElement hardstop2=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                              
                                              }
                                       catch(Exception e){
                                              break;
                                       } 
                          }
                  }
                  
            }catch(Exception LB){
                  //System.out.println(LB);
            }
            if(driver.findElement(By.xpath("//*[@id='work_item_menu']"))!=null){
            try{
       String value="checking";
       WebElement UWtext = driver.findElement(By.xpath("//*[@id='work_item_menu']"));
       //List<WebElement> TotalTextareas=PolicyQuestions.findElements(By.xpath("//textarea | //input"));    
       List<WebElement> TotalTextareas=UWtext.findElements(By.xpath("//textarea"));      
       for(int T=0;T<TotalTextareas.size();T++ ){
              for (int s = 0; s < value.length(); s++){
               char c = value.charAt(s);
               String S = new StringBuilder().append(c).toString();
           TotalTextareas.get(T).sendKeys(S);
           }
              TotalTextareas.get(T).sendKeys(Keys.TAB);
              waitToBeDisplayed(3);
              UWtext = driver.findElement(By.xpath("//*[@id='work_item_menu']"));
              TotalTextareas=UWtext.findElements(By.xpath("//textarea")); 
       }
            }
            catch(Exception TE){
                  //System.out.println(TE);
            }
            }
            if(driver.findElement(By.xpath("//*[@id='work_item_menu']"))!=null){
            try{
                  
                  String smallvalue ="2";
                  WebElement UWtext = driver.findElement(By.xpath("//*[@id='work_item_menu']"));
       //List<WebElement> TotalTextareas=PolicyQuestions.findElements(By.xpath("//textarea | //input"));    
       List<WebElement> TotalSmallTextareas=UWtext.findElements(By.xpath("//div[contains(@class,'formRow dynamicUWQuestion')]//input[contains(@type,'text')]"));      
       for(int T=0;T<TotalSmallTextareas.size();T++ ){
              for (int s = 0; s < smallvalue.length(); s++){
               char c = smallvalue.charAt(s);
               String S = new StringBuilder().append(c).toString();
               TotalSmallTextareas.get(T).sendKeys(S);
           }
              TotalSmallTextareas.get(T).sendKeys(Keys.TAB);
              waitToBeDisplayed(3);
              UWtext = driver.findElement(By.xpath("//*[@id='work_item_menu']"));
              TotalSmallTextareas=UWtext.findElements(By.xpath("//div[contains(@class,'formRow dynamicUWQuestion')]//input[contains(@type,'text')]")); 
       }
            
            }
            
            catch(Exception TE){
                  //System.out.println(TE);
            }
            }
            
            WebElement continuebutton=driver.findElement(By.id("continueButton"));
              boolean BTNobjectExistence=false;
      for(int sec=0;(sec<=60 && !BTNobjectExistence);sec=sec+5){
             waitToBeDisplayed(5);
            //BTNobjectExistence=VerifyLegalEntity.isDisplayed();
            BTNobjectExistence=continuebutton.isEnabled();
           report.updateTestLog("UnderWriting Questions ", "UnderWritin Questions Passed", Status.SCREENSHOT);
           try
           {
           continuebutton.click();
           }
           catch(Exception e)
           {
             continuebutton.sendKeys(Keys.RETURN);
           }
      }
     
             waitToBeDisplayed(2);
    /* WebDriverWait wait = new WebDriverWait(driver, 100); 
      WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
     element.click();
     waitToBeDisplayed(10);*/
     }
            
     catch(Exception e){
            System.out.println(e);
            report.updateTestLog("UnderWriting Questions ", "UnderWritin Questions failed", Status.SCREENSHOT);
            frameworkParameters.setStopExecution(true);
            throw new FrameworkException("UnderWritin Questions", "UnderWritin Questions failed");
            
     }
	}
	
	
	
	public void referUnderwriter() {
	       
	    WebElement ReferUW = driver.findElement(By.xpath("//*[@id='premiumSummary']/h3"));
	    if(ReferUW !=null){
	           try{
	         waitToBeDisplayed(3);
	         if(ReferUW.findElement(By.xpath("//*[@id='REFER_BUTTON']"))!=null){
	           ReferUW.findElement(By.xpath("//*[@id='REFER_BUTTON']")).click();
	           waitToBeDisplayed(2); 
	           WebElement referto=driver.findElement(By.xpath("//*[@id='referButton']"));
	           try
	           {
	                      referto.click();
	           }
	           catch(Exception e)
	           {
	               referto.sendKeys(Keys.RETURN);
	           }
	              
	         }}
	           catch(Exception e)
	           {
	                  System.out.println("No Value present");
	                  }
	           }
	     
	        
	          }
	
	
	
	public static void highlightobject(CraftDriver driver, Properties properties, WebElement element) {
        String highlightobject = properties.getProperty("highlightobject");
               if (highlightobject.equals("Y")){
                     try{   
                            String attributevalue="border:5px solid Green;";//change border width and colour values if required
                            JavascriptExecutor executor = (JavascriptExecutor)driver.getWebDriver();
                       //JavascriptExecutor executor= (JavascriptExecutor) Driver;
                       String getattrib=element.getAttribute("style");
                       executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, attributevalue);
                       Thread.sleep(100);
                       executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattrib);
                            }
                     catch (Exception e){
                            e.printStackTrace();              
                     }
               }
 }
	
	
	
	
	
	
	
	public void premium_Summary(){
		try {
			waitToBeDisplayed(3);
			try{
				WebElement bindable=driver.findElement(By.id("bindNoteGreenDiv"));
				if(bindable.isDisplayed())
				report.updateTestLog("Quote is Bindable", "Quote is Bindable", Status.PASS);
				
			}catch(Exception e){
				System.out.println("Yet to be updated code for non bindable condition");
			}
			
			
		}
		catch(Exception e){
			report.updateTestLog("Premium Summary ", "Premium Summary failed", Status.SCREENSHOT);
			frameworkParameters.setStopExecution(true);
			throw new FrameworkException("Premium Summary", "Premium Summary failed");
			
		}
	}
	
	
	
	
	public void ccDeleteEdit() {
		try{
			WebElement table=driver.findElement(By.xpath("//table[@class='roster']"));
			
			List<WebElement> ElementsLable=table.findElements(By.xpath("//table[@class='roster']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'delete')]"));
			while(ElementsLable.size()!=0){
			ElementsLable.get(0).click();
				waitToBeDisplayed(1);
				driver.findElement(By.xpath("//table[@class='foreground']//a[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'yes')]")).click();
				
				table=driver.findElement(By.xpath("//table[@class='roster']"));
				 ElementsLable=table.findElements(By.xpath("//table[@class='roster']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'delete')]"));
			}
		}catch(Exception e){
			System.out.println("Issue in ccDeleteEdit  "+e);
		}
	
	}
	
	
	public void eligibility_Ques(){
        try {
               String eligibilityMessage="There are no questions to answer.";
               boolean eligibilityques=false;
               
               try{
                     WebElement EM=driver.findElement(By.xpath("//*[contains(text(),'"+ eligibilityMessage +"')]"));
                     System.out.println("No eligibility questions are Present");
               }
               catch (Exception e){
                     eligibilityques=true;
               }
               if(eligibilityques){
                     waitToBeDisplayed(2);
                     WebElement fieldset=null;
               try{
                     fieldset = driver.findElement(By.id("eligibilityQuestions"));
                     }
                     catch(Exception elemen){
                     fieldset = driver.findElement(By.id("policyInformation"));    }
                     try{
                     List<WebElement> ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
                     String [] labelids=new String[ElementsLable.size()];
                     int RadioCounter = 0;
                     //for(int Counter = 0; Counter < ElementsLable.size(); Counter++){
                            while(RadioCounter < ElementsLable.size()){
                            labelids[RadioCounter]=ElementsLable.get(RadioCounter).getAttribute("id");
                            String labelid=labelids[RadioCounter].substring(0,labelids[RadioCounter].indexOf('_'));
                            List<WebElement> Elementvalues=fieldset.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
                            
                            for(int ValCount=Elementvalues.size()-1;ValCount>=0 ;ValCount--){
                                   Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
                                   
                                          try{
                                                 WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                                 if(hardstop.isDisplayed())
                                                        Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
                                          }
                                          catch(Exception ex){
                                                 //System.out.println("check box 'none of the above' selected");
                                                 break;
                                          }
                                   
                            }
                            RadioCounter++;
                            ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));   
                            
                            }
                                          }
                     catch(Exception RB){
                            //System.out.println("No radio buttons present");
                     }
                     List<WebElement> Chckboxes =fieldset.findElements(By.xpath("//*[@type='checkbox']"));
                     if(Chckboxes!=null){
                     try{
                     int totalCheckboxes=fieldset.findElements(By.xpath("//*[@type='checkbox']/ancestor::div/preceding::div[contains(@class,'required')]")).size();       
                     int checked=0;
                     List<WebElement> ElementNoneofabove =fieldset.findElements(By.xpath("//*[@type='checkbox']/../following-sibling::label/span[contains(@id,'labelText') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
                     if(ElementNoneofabove.size()>0){
                            for(int x=0;x<ElementNoneofabove.size();x++){
                                   ElementNoneofabove.get(x).click();
                                   
                                   try{
                                          WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                          if(hardstop1.isDisplayed())
                                                 ElementNoneofabove.get(x).click();
                                          checked--;
                                   }
                                   catch(Exception e){
                                          //System.out.println("check box 'none of the above' selected");
                                          checked++;
                                   }
                                   }      
                            }
                     if(totalCheckboxes>checked){
                            for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
                                   
                                   Chckboxes.get(Counter).click();
                                          //System.out.println("checking");
                                          try{
                                                 WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                                 if(hardstop.isDisplayed())
                                                 Chckboxes.get(Counter).click();
                                          }
                                          catch(Exception ex){
                                                 //System.out.println("check box selected");
                                          }
                                   }
                     }
                     }
                     catch(Exception e){
                            for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
                                   
                                   Chckboxes.get(Counter).click();
                                   //     System.out.println("checking");
                                          try{
                                                 WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
                                                 if(hardstop.isDisplayed())
                                                 Chckboxes.get(Counter).click();
                                          }
                                          catch(Exception ex){
                                                 //System.out.println("check box 'none of the above' selected");
                                          }
                                   }      
                     }
                     }
                     else System.out.println("no checkboxes eligibility questions");
               }
               
        }
        catch(Exception e){
               System.out.println(e);
               report.updateTestLog("Eligibity Questions ", "Eligibity Questions failed", Status.SCREENSHOT);
               frameworkParameters.setStopExecution(true);
               throw new FrameworkException("Eligibity Questions", "Eligibity Questions failed");
               
        }
 }

	
	
	
	
	
	
	/*public void eligibility_Ques(){
		try {
			String eligibilityMessage="There are no questions to answer.";
			boolean eligibilityques=false;
			
			try{
				WebElement EM=driver.findElement(By.xpath("//*[contains(text(),'"+ eligibilityMessage +"')]"));
				System.out.println("No eligibility questions are Present");
			}
			catch (Exception e){
				eligibilityques=true;
			}
			if(eligibilityques){
				waitToBeDisplayed(2);
				WebElement fieldset=null;
				String Lob="";
				try{
					Lob = dataTable.getData("Selectlob", "Object");
				}catch(Exception e){
					Lob="wc";//should be updated
				}
				if((Lob.toLowerCase().contains("spectrum")) || (Lob.toLowerCase().contains("auto"))){
					fieldset = driver.findElement(By.id("eligibilityQuestions"));
				}
				else if(Lob.toLowerCase().contains("wc")){
					fieldset = driver.findElement(By.id("policyInformation"));	
				}
				commonElegibilityQuestions(fieldset);
				
			}
			
		}
		catch(Exception e){
			System.out.println("Eligibility Questions "+e);
			report.updateTestLog("Eligibility Questions ", "Eligibity Questions failed", Status.SCREENSHOT);
			//frameworkParameters.setStopExecution(true);
			//throw new FrameworkException("Eligibity Questions", "Eligibity Questions failed");
			
		}
	}*/
	public void additionalEligQues() {
		try{
			String xpath="//form[contains(@id,'EligibilityQuestions')]";
			WebElement Fieldset=driver.findElement(By.xpath("//form[contains(@id,'EligibilityQuestions')]"));
			commonElegibilityQuestions(Fieldset);
			WebElement continuebutton=driver.findElement(By.id("continueButton"));
			 waitToBeDisplayed(2);
	    	 WebDriverWait wait = new WebDriverWait(driver, 100); 
	    	 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(continuebutton));
	    	 element.click();
	        	
			
		}catch(Exception e){
			System.out.println("Issue in additionalEligQues  "+e);
		}
	
	}
	public void commonElegibilityQuestions(WebElement fieldset){
		try{
			List<WebElement> ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));
			String [] labelids=new String[ElementsLable.size()];
			int RadioCounter = 0;
			//for(int Counter = 0; Counter < ElementsLable.size(); Counter++){
				while(RadioCounter < ElementsLable.size()){
				labelids[RadioCounter]=ElementsLable.get(RadioCounter).getAttribute("id");
				String labelid=labelids[RadioCounter].substring(0,labelids[RadioCounter].indexOf('_'));
				List<WebElement> Elementvalues=fieldset.findElements(By.xpath("//input[contains(@id,'"+labelid+"')]"));
				
				for(int ValCount=Elementvalues.size()-1;ValCount>=0 ;ValCount--){
					Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
					
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
								Elementvalues.get(ValCount).sendKeys(Keys.SPACE);
						}
						catch(Exception ex){
							//System.out.println("check box 'none of the above' selected");
							break;
						}
					
				}
				RadioCounter++;
				ElementsLable = fieldset.findElements(By.xpath("//*[@class='radioSet']/span[@class='label']"));				
				}
			
			}
			catch(Exception RB){
				//System.out.println("No radio buttons present");
			}
			List<WebElement> Chckboxes =fieldset.findElements(By.xpath("//*[@type='checkbox']"));
			if(Chckboxes!=null){
			try{
			int totalCheckboxes=fieldset.findElements(By.xpath("//*[@type='checkbox']/ancestor::div/preceding::div[contains(@class,'required')]")).size();	
			int checked=0;
			List<WebElement> ElementNoneofabove =fieldset.findElements(By.xpath("//*[@type='checkbox']/../following-sibling::label/span[contains(@id,'labelText') and contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'none of the above')]/../preceding-sibling::span/input"));
			if(ElementNoneofabove.size()>0){
				for(int x=0;x<ElementNoneofabove.size();x++){
					ElementNoneofabove.get(x).click();
					
					try{
						WebElement hardstop1=driver.findElement(By.xpath("//p[@class='hardStop']"));
						if(hardstop1.isDisplayed())
							ElementNoneofabove.get(x).click();
						checked--;
					}
					catch(Exception e){
						//System.out.println("check box 'none of the above' selected");
						checked++;
					}
					}	
				}
			if(totalCheckboxes>checked){
				for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
					
					Chckboxes.get(Counter).click();
						//System.out.println("checking");
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
							Chckboxes.get(Counter).click();
						}
						catch(Exception ex){
							//System.out.println("check box selected");
						}
					}
			}
			}
			catch(Exception e){
				for(int Counter = 0; Counter < Chckboxes.size(); Counter++){
					
					Chckboxes.get(Counter).click();
					//	System.out.println("checking");
						try{
							WebElement hardstop=driver.findElement(By.xpath("//p[@class='hardStop']"));
							if(hardstop.isDisplayed())
							Chckboxes.get(Counter).click();
						}
						catch(Exception ex){
							//System.out.println("check box 'none of the above' selected");
						}
					}	
			}
			}
			
	}
	
	
	public void launchIcon()
	{
		try
		{
		waitToBeDisplayed(2);
		driver.get("http://biqapolicycenter.thehartford.com/pc/PolicyCenter.do");
		driver.findElement(By.id("SubmissionWizard:WizardMenuActions-btnInnerEl")).click();
		driver.findElement(By.id("SubmissionWizard:WizardMenuActions:WizardMenuActions_Goto:launchICON-itemEl")).click();
		driver.findElement(By.id("ReferralReasonDoc_menuLink")).click();
		}
		  catch(Exception e)
          {
             //System.out.println("No Value present");
             } 
  
		
	}
	
	
	public void InternalDisposition()
	{

	       try
	       {
	    	  
	              WebElement ReferralReason = driver.findElement(By.xpath("//*[@id='work_item_menu']"));

	         List<WebElement> referFlagList = ReferralReason.findElements(By.xpath("//*[contains(@name,'Referralflag_selectList')]"));

	         String Disposition=dataTable.getData("InternalDisposition", "RDO_Disposition");
	        
	         
	         if(!Disposition.equalsIgnoreCase("declined"))
	         {
	               
	              
	               for(int i=0;i<referFlagList.size();i++)
	               {
	                      Select newdropdown= new Select(referFlagList.get(i));
	                 List<WebElement> Disposition_list =newdropdown.getOptions();  
	                 for(int j=0;j<Disposition_list.size();j++)
	                 {
	                           String Disposition_listvalue = Disposition_list.get(j).getText(); 
	                           System.out.println(Disposition_listvalue);
	                           if(Disposition_listvalue.toLowerCase().contains("i accept"))
	                           {
	                                   newdropdown.selectByVisibleText(Disposition_listvalue);
	                             break;      
	                           }
	                 }
	                 
	               }
	         }
	         
	         
	         
	         else if(Disposition.equalsIgnoreCase("declined"))
	         {
	               String Disposition_listvalue = null;
	               int count = 0;
	               
	               for(int i=0;i<referFlagList.size();i++)
	               {
	            	   if(i==0)
	            	   {
	            		   Select newdropdown= new Select(referFlagList.get(i));
	                       List<WebElement> Disposition_list =newdropdown.getOptions(); 
	                       for(int j=0;j<Disposition_list.size();j++)
	                       {
	                                  Disposition_listvalue = Disposition_list.get(j).getText(); 
	                                 if(Disposition_listvalue.contains("decline"))
	                                 {
	                                         newdropdown.selectByVisibleText(Disposition_listvalue);
	                                         break;
	                                      
	                                 }
	                       } 
	            	   }
	            	   
	             else
	                 {
	                      Select newdropdown= new Select(referFlagList.get(i));
	                 List<WebElement> Disposition_list =newdropdown.getOptions();  
	                 for(int j=0;j<Disposition_list.size();j++)
	                 {
	                            Disposition_listvalue = Disposition_list.get(j).getText(); 
	                           if(Disposition_listvalue.contains("accept"))
	                           {
	                                   newdropdown.selectByVisibleText(Disposition_listvalue);
	                             break;      
	                           }
	                           else
	                           {
	                        	   newdropdown.selectByIndex(2);
	                               break;       
	                           }
	                 }
	                 }
	                
	               }
	         }
	       }
	       
	       
	           catch(Exception e)
	           {
	              System.out.println("No Value present");
	              } 
	   
	}

	
	public void billingInfo()
    {      
           waitToBeDisplayed(3);
           try
           {
           WebElement frame1=driver.findElement(By.xpath("//div[@id='cpp_results_lightbox']/iframe"));
           driver.switchTo().frame(frame1);
           WebElement acc=driver.findElement(By.xpath("//*[@id='PaymentMethodPart']//span[contains(text(),'Checking account')]"));
           acc.click();
           WebElement savingsacc=driver.findElement(By.xpath("//*[@id='PaymentMethodPart']//div/a[contains(text(),'Savings account')]"));
           savingsacc.click();
           WebElement Routingnumber=driver.findElement(By.xpath("//input[@name='routingNumber']"));
           Routingnumber.sendKeys("211371638");
           WebElement Accnumber=driver.findElement(By.xpath("//*[@id='oneTimeTableEFTId']//input[@name='acctNumber']"));
           Accnumber.sendKeys("1526478523");
           WebElement next=driver.findElement(By.xpath("//*[@id='nextButton']"));
           next.click();
           WebElement submit=driver.findElement(By.xpath("//*[@id='SubmitButton']"));
           submit.click();
           WebElement finish=driver.findElement(By.xpath("//*[@id='Finish']"));
           report.updateTestLog("Billing screen information is entered", "Billing screen information is entered", Status.PASS);
           finish.click();
           
           driver.switchTo().defaultContent();
           
           }
           catch(Exception e)
           {
                  report.updateTestLog("Billing screen information is not entered", "Billing screen information is not entered", Status.FAIL);      
           }
    }

	
	
	public String createTemFile() throws IOException{
        String path=frameworkParameters.getRelativePath() + "\\Sample.txt"; 
        File file=new File(path);
        try{
               if(!file.exists()){
                     file.createNewFile();
               }

               FileWriter fWrite=new FileWriter(file);
               BufferedWriter writer=new BufferedWriter(fWrite);
               try{
                     writer.write("Sample");
                     writer.newLine();
                     writer.close();
               }
               catch(Exception e){}
        }
        catch(Exception e1){}

        return file.getCanonicalPath();

 }

 public void uploadFile() throws IOException{
        String filePath=createTemFile();
        driver.findElement(By.xpath("//*[@id='fileAttachment']")).sendKeys(filePath);

        driver.findElement(By.xpath("//*[@id='fileAttachSuccess']")).getText().contains("The file has been uploaded successfully.");
        report.updateTestLog("Upload file in Refer Underwriting screen", "The file has been uploaded successfully.", Status.PASS);
 }

 public void outputPolicyDetails(){
		 String policyName= driver.findElement(By.id("headerCustomerName")).getText();
		 String policyID= driver.findElement(By.id("headerPolicyNumber")).getText();
		 dataTable.putData("PolicyDetails", "ELE_PolicyID",policyID);
		 dataTable.putData("PolicyDetails", "ELE_PolicyName",policyName);
		/*String strPolicyNum = policyID.split(":")[1].trim();
		String strPolicySymbol = strPolicyNum.substring(2,5);*/
		String strPolicyNumberPC = policyID.substring(policyID.length()-6);
		//dataTable.putData("SearchPolicyPC", "LST_PolicySymbol",strPolicySymbol);
		dataTable.putData("PolicyDetails", "EDI_PolicyNumberPC",strPolicyNumberPC);
	}

	public void loginPC()
	{
    ArrayList<String> allwindows1=new ArrayList<String>(driver.getWindowHandles());
    String parentWin="";
    System.out.println(driver.getTitle());
    for (String winHandle : allwindows1) {
           driver.switchTo().window(winHandle);
           System.out.println(driver.getTitle());
           if(driver.getTitle().contains("ICON |") || driver.getTitle().contains("")) {
                 parentWin=driver.getWindowHandle();
           }
           else{
                 driver.close();
           }
    }
    driver.switchTo().window(parentWin);

     driver.navigate().to("http://biqapolicycenter.thehartford.com/pc/PolicyCenter.do");

	}
	public void searchPolicyPC()
	{
		String strPolicy = dataTable.getData("PolicyDetails", "EDI_PolicyNumberPC");
		driver.findElement(By.xpath("//*[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:policyNumber-inputEl']")).sendKeys(strPolicy);;
	}
	
	public void searchPolicyICON()
	{
		String strPolicy = dataTable.getData("SearchPolicyPC", "EDI_PolicyNumberPC");
		
		driver.findElement(By.id("keywordPolicyNumber")).sendKeys(strPolicy);
	}
	
	
	
	
	
	
	
	

	
	public static void waitToBeDisplayed(int sec) {
			try {
				int requiredtime=sec*1000;
				Thread.sleep(requiredtime);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	
public static String SelectQuery(String TargetColumnName, String TableName, String SourceColumnName, String SourceValue ) throws SQLException{
		
		Statement statement = null;		 
		ResultSet resultSet = null;
		String result = null;
		statement = Getconnection();		 
		
		String Query = "SELECT " + TargetColumnName + " FROM " + TableName + " WHERE " + SourceColumnName + " ='" + SourceValue + "'";	 		 
		 
		resultSet = statement.executeQuery(Query);		 
		while(resultSet.next()) {
        	 result = resultSet.getString(1);
        	 }         
         return result;
     }	
	
	public static String SelectQuery(String TargetColumnName, String TableName, String SourceColumnName_1, String SourceValue_1, String SourceColumnName_2, String SourceValue_2, String SourceColumnName_3, int SourceValue_3 ) throws SQLException{
		
		Statement statement = null;		 
		ResultSet resultSet = null;
		String result = null;
		statement = Getconnection();
		String Query = "SELECT " + TargetColumnName + " FROM " + TableName + " WHERE " + SourceColumnName_1 + " ='" + SourceValue_1 + "' AND " + SourceColumnName_2 + " ='" + SourceValue_2 + "' AND " + SourceColumnName_3 + " ='" + SourceValue_3 + "'";
		resultSet = statement.executeQuery(Query);		 

		while(resultSet.next()) {
        	 result = resultSet.getString(1);
        } 

         return result;
     }	
	
	
	public static int getversionumber(String TableName, String SourceColumnName_1, String SourceValue_1, String SourceColumnName_2, String SourceValue_2) throws SQLException{
		Statement statement = null;		
		ResultSet resultSet = null;
		int result = 0;
		int result1 = 0;		
		statement = Getconnection();		
		String Query = "SELECT  Version FROM " + TableName + " WHERE " + SourceColumnName_1 + " ='" + SourceValue_1 + "' AND " + SourceColumnName_2 + " ='" + SourceValue_2 + "'";
		resultSet = statement.executeQuery(Query);		 
		while(resultSet.next()) {
			String tempres = resultSet.getString(1);
			if (!tempres.isEmpty())			
			{
			result1 = Integer.parseInt(tempres);
			}
        	 if (result < result1)
        	 {
        	 result = result1;    		 
        	 }	 
        }  
		return result;
	}
		
public static void updatequery(String value1, String value2, String value3, int value4 ) throws SQLException{		
		 Statement statement = null;		 
		 statement = Getconnection();		 
		 String Query = "INSERT INTO E2E_Testdata (E2E_Scenario_Name, Field_Name, Field_Value, Version) VALUES ('"+ value1 +"', '"+ value2 +"', '"+ value3 +"', '"+ value4 +"')";	 
		 statement.execute(Query);		 
     }		
/*
if the execution is in debug mode than for any exception below code will through exception and  will wait for the user to 
perform action on that particular field.
*/
public void checkExectionMode()
{
	 if(DEBUG_MODE == true){
		
		 
		 System.out.println("Perform Action");
		
		 Scanner reader = new Scanner(System.in);
			System.out.println("Enter user value");
			
			int e = reader.nextInt();
			
			System.out.println(e); 
			
			}
	 if(DEBUG_MODE == false)
	 {
		    frameworkParameters.setStopExecution(true);
			throw new FrameworkException("issue in reusable component", "Page Execution failed");
			
	 }
} 
	public static Statement Getconnection(){		
		
	  // variables
     Connection connection = null;
     Statement statement = null;
     //Loading or registering Oracle JDBC driver class
     try {

         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
     }
     catch(ClassNotFoundException cnfex) {

         System.out.println("Problem in loading or "
                 + "registering MS Access JDBC driver");
         cnfex.printStackTrace();
     }
     //Opening database connection
     try {
         String msAccDB = "C:/Selenium_Workspace/NewIconFrame_Final/uploadresults_alm/E2E_TestData.accdb";
         String dbURL = "jdbc:ucanaccess://" + msAccDB; 
         //Create and get connection using DriverManager class
         connection = DriverManager.getConnection(dbURL); 
         //Creating JDBC Statement 
         statement = connection.createStatement();		
     	}
     catch(SQLException sqlex){
         sqlex.printStackTrace();
     	}	
     // Returning statement object
		return statement;		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}