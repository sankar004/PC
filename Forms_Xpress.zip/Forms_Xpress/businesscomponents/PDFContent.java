package businesscomponents;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.cognizant.framework.Status;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import supportlibraries.*;

/*
* This is an example on how to extract text from a specific area on the PDF document.
*
* Usage: java org.apache.pdfbox.examples.util.ExtractTextByArea &lt;input-pdf&gt;
*
* @author <a href="mailto:ben@benlitchfield.com">Ben Litchfield</a>
* @version $Revision: 1.2 $
*/


public class PDFContent extends ReusableLibrary
{
	
	
	static String strActFileName, strExpFileName, strActPath, strExpPath, strFooterAct, strFrmName,act_frmname,policy_number;
	static String ExcelResultFile; //= "c:\\PDFValidationDocuments\\Result\\ExcelResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
	static String pdfResultFile; //= "c:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
	static String actualForm;
	static String mockUpForm;
	static String actualForm_name;
	static String mockUpForm_name;
	static String formNumber,formTitle,Package_Name,Form_Number, Forms_not_present,curr_noscope , Curr_mock;
	static String test;
	static String type;
	static String narration;
	static String testcaseName;	
	static String inputFile= "C:\\PDFValidationDocuments\\FormDetails_Compass_StaticDynamic.xls";
	static HSSFWorkbook inputworkbook = null;
    static HSSFSheet inputworksheet = null;    
    static FileInputStream inputfileIn = null;    
    static String compare_type="";
    String section[]=null;
    static PDDocument actdocument = null,mckdocument = null;
    static String Mock_pdfname = null;
   
    
/*private PDFContent()
{
//utility class and should not be constructed.
}*/

public PDFContent(ScriptHelper scriptHelper) {
	super(scriptHelper);
}


/*
* This will print the documents text in a certain area.
*
* @param args The command line arguments.
*
* @throws Exception If there is an error parsing the document.
*/
/*public static void main( String[] args ) throws Exception
{
	
try{
//DynamicContent.Getdynamicformdatasheet();
//Query_Testdata();
	PDFContent obj1 = new PDFContent(scriptHelper);
	 
getInputData();	
}


catch(Exception e){k
	e.printStackTrace();
}
}
*/

public  void getInputData(String CurrentTC) {
	try {
    	//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Iteration3";
    	//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Iteration3";
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Iteration4";
		//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Iteration4";
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\I3_Checkd_actual";
		//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\I3_checkd_mock";
		
		String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Iteration_3_NGS";
		
		String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Iteration3_mock";
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Actual_NGS";
		//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Mock_NGS";
		
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\new";
		//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\new";Actual_NGS
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Iteratin 4 new" ;
		//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Iteration 4 new";
		//String filepath_actual="C:\\Forms_Xpressv2.0\\Actual_Files\\Iteration3_Demo_actual";
    	//String filepath_mock="C:\\Forms_Xpressv2.0\\Mock_Files\\Iteration3_Demo_mock";
    	//File file = new File("d:/test/test.java");
    	//File parentDir = file.getParentFile();\p  
    	File [] arrActFileNames= (new File(filepath_actual)).listFiles(); //To take file names from the specified location
    	File [] arrExpFileNames= (new File(filepath_mock)).listFiles();  
    	//int intActLen =arrActFileNames.length;
    	//int intExpLen=arrExpFileNames.length;
    	String[] arrExpFrmName=new String[2];
    	String[] arrActFrmNme=new String[2];
    	String[] Arr_mockfrm;
    	String[] arr_noscope_forms;
    	 String mock_present = null;
    	 String Current_Tc = null;
    	 int counter = 0;
    	 
    	  //HashMap<Integer,String> page_sort=new HashMap<Integer,String>();
    	 List<Integer> page_sort = new ArrayList<>();
    	 List<Integer> After_sort = new ArrayList<>();
    	//ExcelResultFile = "c:\\PDFValidationDocuments\\Result\\ExcelResult\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
 	   //pdfResultFile = "c:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";					    		 
    	int intPgnum=0 , pdf_pgno =0;
    	String  Act_pdfname  = null;
    	Package_Name = dataTable.getData("Output_PolicyDetails", "Package_Name").replaceAll(" ", "");	
    	 Form_Number = dataTable.getData("Output_PolicyDetails", "Form_Number").replaceAll(" ", "").replaceAll("\n", "");	
    	 
    //	 Current_Tc =  testParameters.getCurrentTestcase();
    	 Arr_mockfrm = Form_Number.split(",");
    	 int no_of_mforms = Arr_mockfrm.length;
    	// strActPath = obj_ActFile.getPath();	//Get the path of the file
 		//strExpPath = obj_ExpFile.getPath();
    	 
 	   for(File obj_ActFile : arrActFileNames)
		{
 		   
 		  strActFileName = obj_ActFile.getName();
 		
 		  Act_pdfname = strActFileName.replaceAll(".pdf", "").replaceAll(" ", "");
 		 //Act_pdfname = "TC_054_Policy+-+01SBAAX1ROD.pdf"
 		  //if(Act_pdfname.matches(Package_Name))
 			 if(Act_pdfname.equals(Package_Name))
 		  {
 				 strActPath = obj_ActFile.getPath();
 			 break;
 		  }
		}
 	   
 	   
 	  CommonClass.Inference_Extraction(strActFileName,strActPath);
 	   
 	   System.out.println("Inference Executed");
 	   
 	   
 	   if(Form_Number=="")
 	   {
 		  report.updateTestLog("No In scope forms are available for this package",PDFContent.Package_Name, Status.PASS);
 	   }
 	   
 	   else
 	   {
 		// for(File obj_ExpFile : arrExpFileNames)
 		  
 		/*
 		  for(int k=0;k<Arr_mockfrm.length;k++) 
 		  {
 			 mock_present =  Arr_mockfrm[k];
 			 
 			 for(File obj_ExpFile : arrExpFileNames)
 	 		 	 				
 	 	 	   {
 			 
 			
 			 
 			 if(mock_present.equalsIgnoreCase(folder_mock))
 			 {
 				counter++;
 			 }
 			
 			 
 			 
 		  }
 		  }
 		   
 		  if(counter == Arr_mockfrm.length) 
 		  {
 			 
 			 report.updateTestLog("All Mock Forms are available in the Folder","Total"+" "+counter , Status.DONE); 
 			  
 		  }
 		  
 		 else
			 {
				 report.updateTestLog("Template not available in Folder",mock_present , Status.FAIL); 
				 
			 }
 		  	*/
 		   		   
 		   
 	  for(int j=0;j<Arr_mockfrm.length;j++)
 		 {
 		   Curr_mock = Arr_mockfrm[j];
 			 // if(Form_Number.contains(Curr_mock))
 		  //System.out.println("Curr_mock"+Curr_mock);
 			  //{
 		  
 		 boolean occurence = false;
 		  
 		  
 		  
 		  
 				 for(File obj_ExpFile : arrExpFileNames)
 			//for(int j=0;j<Arr_mockfrm.length;j++)
 				
 	 	   {
 				intPgnum=0;
 				
 				  strExpFileName = obj_ExpFile.getName();
	 			  Mock_pdfname = strExpFileName.replaceAll(".pdf", "").replaceAll(" ", "");
	 			  //System.out.println("Mock_pdfname"+Mock_pdfname);
 			
 			//if(Mock_pdfname.equalsIgnoreCase(Curr_mock))
 				if(Mock_pdfname.contains(Curr_mock))
 			 
 				//if(Form_Number.contains(Mock_pdfname))
 			{
 				occurence = true;			
 				
 				strExpPath = obj_ExpFile.getPath();	
 				 PDDocument pdDoc = null;
 	       	    COSDocument cosDoc = null; 
 	       	    File file_act = new File(strActPath);
 	       	    File File_mock = new File(strExpPath);
 	       	    
 	       	 /* File file_act = new File(strActPath);
	       	    File File_mock = new File(strExpPath);*/
 	       	    PDFParser parser = new PDFParser(new FileInputStream(file_act));
 	  	        parser.parse();
 	  	        cosDoc = parser.getDocument();
 	  	        pdDoc = new PDDocument(cosDoc);
 	  	        actdocument = PDDocument.load( strActPath );
 	  	        String strFooterAct = CommonClass.Chk_ExpFilename(actdocument,Curr_mock,intPgnum);
 	  	        String strFooterName=null;
 		        if(strFooterAct.contains(";"))
 		        {
 		        String arrFooterAct[] = strFooterAct.split(";");
 		        strFooterName = arrFooterAct[0];
 		        String strpageno = arrFooterAct[1];
 		        
 		        intPgnum = Integer.parseInt(arrFooterAct[1]);
 		      
 		       pdf_pgno = intPgnum + 1;
 		        
 		    //  page_sort.put(pdf_pgno,Mock_pdfname );
 		   //   page_sort.add(pdf_pgno);
 		        
 		       	        
 		        
 		        }
 		       
 	  		formTitle = "NotRequired";
 	  		String[] section={"2"};
 	  		testcaseName = "TC1";
 	  		//type="Static_Columnar";
 	  		type="Simple";
 	  		narration = "NotRequired";
 	  		compare_type = "Word";
 	  		formNumber=Mock_pdfname;
 	  		//ExcelResultFile = "C:\\Forms_Xpressv2.0\\Results\\Excel_Result\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
 	  		//ExcelResultFile = "C:\\Forms_Xpressv2.0\\Results\\Excel_Result\\"+Package_Name+"_"+Form_Number+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
 	  		ExcelResultFile = "C:\\Forms_Xpressv2.0\\Results\\Excel_Result\\"+Package_Name+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
 	   	 	//pdfResultFile = "c:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";

 		        if(strFooterName != null)
 		        {
 	 	 		System.out.println("Mock_Name "+Mock_pdfname);
 	 	 		//policy_number=	Exceldata.GetPolicynumber(act_frmname);
 	 	 		
 	 	 		 policy_number = dataTable.getData("Output_PolicyDetails", "Policy_Number");
 	 	 		System.out.println("policy_number"+policy_number);
 			//LoadPDFAndCompare.LoadPDFAndComparePDF(strActPath,strExpPath,formNumber,formTitle,type,narration,ExcelResultFile,testcaseName,section,compare_type,intPgnum,policy_number);
 			//System.out.println(file.getName());
 			
 	 	 		LoadPDFAndCompare loadobj = new LoadPDFAndCompare(scriptHelper);
 	 	 		loadobj.LoadPDFAndComparePDF(strActPath,strExpPath,Curr_mock,formTitle,type,narration,ExcelResultFile,testcaseName,section,compare_type,intPgnum,policy_number,CurrentTC );
 	 	 	    
 	 	 	//	System.out.println(file.getName());
 	 	 		
 	 	 	//	report.updateTestLog("Form present in Actual and VALIDATED Succesfully",PDFContent.Mock_pdfname, Status.PASS);

 	}
 		    
 		        else
		        {
		        	report.updateTestLog("In Scope Form is not present in Actual",PDFContent.Curr_mock, Status.FAIL);
		        }
 		      
 		 }
 			
 	 	   }
 				 
 				 
 				 if(!occurence)
 				 {
 					report.updateTestLog("Template is missing in the folder",Curr_mock, Status.FAIL); 
 				 }
 				 
 			
 			  }
 	  
 			//break;
 			
	
 	 //report.updateTestLog("Mock Form is missing in the folder",PDFContent.Curr_mock, Status.FAIL);
 	   }	
 		
  Forms_not_present = dataTable.getData("Output_PolicyDetails", "Form_Number_NEG").replaceAll(" ", "");	
 
  
  if(Forms_not_present=="")
  {
	 // report.updateTestLog("",PDFContent.curr_noscope, Status.FAIL);
  }
  
 
  else{
  int outofscope_counter = 0;
 	 arr_noscope_forms	=  Forms_not_present.split(","); 	
 	 for(int i=0;i<arr_noscope_forms.length;i++)
 	 {
 		intPgnum = 0;
 		 curr_noscope = arr_noscope_forms[i];
 		 String strFooterAct = CommonClass.Chk_ExpFilename(actdocument,curr_noscope,intPgnum); 
 		 System.out.println("Footer_txt"+strFooterAct);
 		 if(strFooterAct != "")
 		 {
 			
 			report.updateTestLog("Out of scope form" +curr_noscope+"is present in Package",PDFContent.curr_noscope, Status.FAIL);
 		 }
 		 else
 		 {
 			outofscope_counter++; 
 		 }
 	 }
 	 if(outofscope_counter==arr_noscope_forms.length)
 	 {
 		report.updateTestLog("Out of scope forms are not  present in Package","", Status.PASS);
 	 }
 	 
 	 
 	 
 	 
  }
 	
 		   
		/*for(File obj_ExpFile : arrExpFileNames) 
    	{
			
	
			int intPgnum=0;
    		strActFileName = obj_ActFile.getName();//Get the name of the actual file
    		strExpFileName = obj_ExpFile.getName();//Get the name of the expected file
    		strActPath = obj_ActFile.getPath();	//Get the path of the file
    		strExpPath = obj_ExpFile.getPath();
    		//System.out.println("actualForm_name"+actualForm_name);
    		//System.out.println("mockUpForm_name"+mockUpForm_name);
    		arrExpFrmName = strExpFileName.split("\\.");
    		strFrmName = arrExpFrmName[0].replaceAll(" ","");
    		arrActFrmNme=strActFileName.split("\\.");
    		act_frmname=arrActFrmNme[0].replaceAll(" ","");
    		//System.out.println("fommmmm"+form[0]);
    		 PDDocument pdDoc = null;
      	    COSDocument cosDoc = null; 
      	    File file_act = new File(strActPath);
      	    File File_mock = new File(strExpPath);
      	    PDFParser parser = new PDFParser(new FileInputStream(file_act));
 	        parser.parse();
 	        cosDoc = parser.getDocument();
 	        pdDoc = new PDDocument(cosDoc);
 	        actdocument = PDDocument.load( strActPath );
 	        String strFooterAct = CommonClass.Chk_ExpFilename(actdocument,strFrmName,intPgnum);
 	        String strFooterName=null;
 	        if(strFooterAct.contains(";"))
 	        {
 	        String arrFooterAct[] = strFooterAct.split(";");
 	        strFooterName = arrFooterAct[0];
 	        String strpageno = arrFooterAct[1];
 	        intPgnum = Integer.parseInt(arrFooterAct[1]);
 	        }
    		formTitle = "NotRequired";
    		String[] section={"2"};
    		testcaseName = "TC1";
    		//type="Static_Columnar";
    		type="Simple";
    		narration = "NotRequired";
    		compare_type = "Word";
    		formNumber=strFrmName;
    		//ExcelResultFile = "C:\\Forms_Xpressv2.0\\Results\\Excel_Result\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
    		ExcelResultFile = "C:\\Forms_Xpressv2.0\\Results\\Excel_Result\\"+act_frmname+"_"+strFrmName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
     	 	//pdfResultFile = "c:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+testcaseName+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
    		//if(actualForm_name.matches(mockUpForm_name))
*/     	 	
		//if(row_pointer==1)
			//System.out.println("hello");
	//	ExcelResult.SummaryReport(ExcelResultFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		 catch (NullPointerException e) {
	// TODO Auto-generated catch block
		//ExcelResult.SummaryReport(ExcelResultFile); 
	e.printStackTrace();
}
		finally{
			flushall();
		}
}
private static void flushall() {
	
	if(inputfileIn!=null)
		try {
			inputfileIn.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
//Extract the fields in Dynamic Form
//PDDocument document1 = null;
//document1 = PDDocument.load( "C:\\PDFValidationDocuments\\ActualPDF\\TRAI2WC000412.pdf" );
//ExtractFields(document1);
public static void ExtractFields(PDDocument document){

	//Try extracting the fields
	try{
	PDAcroForm acro=document.getDocumentCatalog().getAcroForm();
	Object[] a=acro.getFields().toArray();
	for(int i=0;i<a.length;i++){
		System.out.println(a[i].toString());
	}
	}
	catch(Exception e){
		e.printStackTrace();
	}
}
/*
 * *
* This will print the usage for this document.
*/
private static void usage()
{
System.err.println( "Usage: java org.apache.pdfbox.examples.util.ExtractTextByArea <input-pdf>" );
}




}
/*PDRectangle Prec=new PDRectangle();
Prec.setLowerLeftX(1);
Prec.setLowerLeftY(491);
Prec.setUpperRightX(300);
Prec.setUpperRightY(181);
*/
//Rectangle rect = new Rectangle(1, 180, 300, 300);
//stripper.addRegion( "class1", rect );
//List allPages = document.getDocumentCatalog().getAllPages();
//PDPage firstPage = (PDPage)allPages.get( 0 );
//stripper.extractRegions( firstPage );
//System.out.println( "Text in the area:" + rect );
//System.out.println( stripper.getTextForRegion( "class1" ) );


//Try extracting the Regions
//List reg=stripper.getRegions();
//Object[] a=reg.toArray();
/*Object[] a=stripper.getRegions().toArray()xzzz;
for(int i=0;i<stripper.getRegions().size();i++)
{	
	System.out.println("**************************************************");
	System.out.println("Region "+ (i+1));
	System.out.println("**************************************************");
	
	System.out.println(stripper.getTextForRegion(a[i].toString()));
	System.out.println("**************************************************");
}*/

//Try extracting the Regions
/*
stripper.extractRegions(firstPage);
List re=stripper.getRegions();
for(int i=0;i<re.size();i++)
System.out.println(re.get(i).toString());
*/
//Try extracting the Annotations
/*List annotations = firstPage.getAnnotations();
for( int j=0; j<annotations.size(); j++ )                   
{                        
	PDAnnotation annot = (PDAnnotation)annotations.get( j );  
	System.out.println(annot.getContents());
	//if( annot instanceof PDAnnotationLink )                        
	//{                            
		//PDAnnotationLink link = (PDAnnotationLink)annot;                            
		//PDAction action = link.getAction();                            
		//String urlText = stripper.getTextForRegion( "" + j );                            
//	}	
}
*/

/*
if(start_point>0 && end_point==0 && (sec_name.trim().contains("GENERAL SECTION")==false)){
 */
/*Rectangle rec_left_text = new Rectangle(x1, y1,310, y2);
stripper.addRegion( "left_text"+counter, rec_left_text );
stripper.extractRegions( firstPage );
text_content=stripper.getTextForRegion( "left_text"+counter ) ;
System.out.println( "Text:" + text_content );		
left_text=left_text+text_content;*/

//System.out.println( "Text:" + left_text );
/* Rectangle rec_right_text = new Rectangle((int) (x2/2)+1, y1, x2, y2);
stripper.addRegion( "right_text"+counter, rec_right_text );
stripper.extractRegions( firstPage );
text_content=stripper.getTextForRegion( "right_text"+counter ) ;
right_text=right_text+text_content; 
}*/

//String section_text=left_text+right_text;
//System.out.println( "Text:" + section_text );
/*x1=1;
y1=start_point+10;
x2=(int) (wd/2);
y2=end_point-start_point;
counter=1;
Rectangle r1 = new Rectangle(x1,y1,x2,y2);
stripper.addRegion( "GenSect_Left", r1 );
stripper.extractRegions( firstPage );
System.out.println( stripper.getTextForRegion( "GenSect_Left" ) );*/


//Extract "GENERAL SECTION" Right side content
/*x1=x2;
y1=start_point+10;
String GenSect_Right="";
counter=counter+1;
while(y1<=ht){
Rectangle r2 = new Rectangle(x1, y1, x2, y2);
stripper.addRegion( "GenSect_Right"+counter, r2 );
stripper.extractRegions( firstPage );
String sec_name1=stripper.getTextForRegion( "GenSect_Right"+counter ) ;
counter=counter+1;
System.out.println( sec_name1 );
//GenSect_Right=GenSect_Right+sec_name;
y1=y1+10; 
}*/
/*
x1=1;
y1=1;
x2=(int) (wd/2);
y2=10;
counter=1;
while(y1<=ht){
Rectangle r1 = new Rectangle(x1, y1, x2, y2);
stripper.addRegion( "R"+counter, r1 );
stripper.extractRegions( firstPage );
System.out.println( "Text in the area:" + r1 );
System.out.println( stripper.getTextForRegion( "R"+counter ) );
counter=counter+1;
y1=y1+10;

}
*/
