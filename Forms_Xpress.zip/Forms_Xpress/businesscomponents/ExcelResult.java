package businesscomponents;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;


public class ExcelResult {
	
	static HSSFWorkbook workbook = null;
    static HSSFSheet worksheet = null;
    static FileOutputStream fileOut = null;
    static FileInputStream fileIn = null;
	
	public ExcelResult() {
		
	}
	
public static void createExcel(String[] result, int i, String formNumber, String excelResultFile) throws IOException{
	File file = new File(excelResultFile);    
	if (!file.exists()) {
		createDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}	
	else{
		openDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}
	//if(h==2)	
	
		flushall();
		
	}

static void openDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	
	fileIn = new FileInputStream(excelResultFile);
	fileOut = new FileOutputStream(excelResultFile);
	if(type == "Narrative"){
		worksheet = workbook.createSheet(formNumber+" NarrationCheck");
		updateSheetHeader(type);
	}
	else{
		if(workbook.getSheet(formNumber)!=null){
		worksheet = workbook.getSheet(formNumber);
	}
	else{
		worksheet = workbook.createSheet(formNumber);
		updateSheetHeader(type);
	}
	}
}

private static void updateDocument(String[] result, int i) throws IOException {
	HSSFRow row1 = worksheet.createRow(i+1);
	
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No/Section No "+(i+2));
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(result[1]);
	
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue(result[2]);
	
	Cell cellA3 = row1.createCell(3);		
	cellA3.setCellValue(result[0]);
	setFontColourForPassFail(cellA3,result[0]);
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue(result[3]);
	//Added by Saravanan to have hyperlink for compared file
	if(cellA4.getStringCellValue().contains("html"))
	{
	HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
	sheet_link.setAddress(result[3]);	
	cellA4.setHyperlink(sheet_link);
	}
	workbook.write(fileOut);
}

static void flushall() throws IOException {
	
	
	fileOut.flush();
	fileOut.close();
	if(fileIn!=null)
	fileIn.close();
	
}

static void createDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	/*HSSFSheet sheet = workbook.getSheet("formNumber");
	if(sheet == null)
	    sheet = workbook.createSheet("formNumber");*/
	
	fileOut = new FileOutputStream(excelResultFile);
	workbook = new HSSFWorkbook();
	worksheet = workbook.createSheet(formNumber);
	updateSheetHeader(type);
	//workbook.getSheet("");
}

static void createDocument_sequence(String Sequence, String excelResultFile, String type) throws FileNotFoundException {
	
	fileOut = new FileOutputStream(excelResultFile);
	workbook = new HSSFWorkbook();
	worksheet = workbook.createSheet("Sequence");
	updateSheetHeader(type);
	//workbook.getSheet("");
	
}

private static void updateSheetHeader(String type) {
	
	   
HSSFRow row1 = worksheet.createRow(0);
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No/Section No");
	Cell cellAa1 = row1.createCell(1);
	cellAa1.setCellValue("PDF_Value");
	Cell cellAa2 = row1.createCell(2);
	cellAa2.setCellValue("Excel_Value");
	Cell cellAa3 = row1.createCell(3);
	cellAa3.setCellValue("Result");
	Cell cellAa4 = row1.createCell(4);
	cellAa4.setCellValue("Comments");

	if(type=="Static"){
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue("Mock");
		
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue("Actual");
	
	Cell cellA3 = row1.createCell(3);
	cellA3.setCellValue("Pass/Fail");
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue("Error Description/HTML Description");
	}
	else if(type=="Dynamic")
	{	
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue("OSP/SFE");
		
		Cell cellA2 = row1.createCell(2);	
		cellA2.setCellValue("CPT");
		
		Cell cellA3 = row1.createCell(3);
		cellA3.setCellValue("Pass/Fail");
		
		Cell cellA4 = row1.createCell(4);
		cellA4.setCellValue("HTMl Description/Error Description");
		/*cell cellA2 = row1.createCell(6);
		cellA2.setCellValue("Mock Line/TestData Value");
		
		//Cell cellA3 = row1.createCell(7);
		cellA3.setCellValue("Pass/Fail");*/
		
	}
	else if(type=="Sequence")
	{	
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue("Matched_Master form Numbers");
		
		Cell cellA2 = row1.createCell(2);	
		cellA2.setCellValue("Form Numbers from Package");
		
		Cell cellA3 = row1.createCell(3);
		cellA3.setCellValue("Pass/Fail");
		
		Cell cellA4 = row1.createCell(4);
		cellA4.setCellValue("Form Numbers not in Master sheet");
		
		Cell cellA6 = row1.createCell(5);
		cellA6.setCellValue("Sequence mismatched Forms");
		
	}
	//Sequence-Cpt-Osp
	else if(type=="Sequence-Cpt-Osp")
	{	
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue("Form Numbers from OSP");
		
		Cell cellA2 = row1.createCell(2);	
		cellA2.setCellValue("Form Numbers from CPT");
		
		Cell cellA3 = row1.createCell(3);
		cellA3.setCellValue("Pass/Fail");
		
		Cell cellA4 = row1.createCell(4);
		cellA4.setCellValue("Form Numbers in OSP but Not in CPT");
		
		Cell cellA6 = row1.createCell(5);
		cellA6.setCellValue("Form Numbers in CPT but Not in OSP");
		
	}
	else if(type=="Narrative"){
		
		Cell cellA6 = row1.createCell(0);
		cellA6.setCellValue("FormNumber");
		
		Cell cellA2 = row1.createCell(1);
		cellA2.setCellValue("page Number in the document");		
			
		Cell cellA3 = row1.createCell(2);
		cellA3.setCellValue("Narration");
		
		Cell cellA4 = row1.createCell(3);
		cellA4.setCellValue("Pass/Fail");
		
	}
	//if(type!="Dynamic")
	makeRowBold(row1);
	for(int size = 0 ;size<7;size++)
	worksheet.autoSizeColumn(size);	
	worksheet.setColumnWidth(1,20*600);	
	worksheet.setColumnWidth(2,20*600);
	//worksheet.setColumnWidth(3,20*256);
	
}

private static CellStyle createBorderedStyle(Workbook wb) {
    CellStyle style = wb.createCellStyle();
    style.setBorderRight(CellStyle.BORDER_THIN);
    style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    style.setBorderBottom(CellStyle.BORDER_THIN);
    style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    style.setBorderLeft(CellStyle.BORDER_THIN);
    style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    style.setBorderTop(CellStyle.BORDER_THIN);
    style.setTopBorderColor(IndexedColors.BLACK.getIndex());
    return style;
}


public static void makeRowBold(Row row){
    CellStyle style = workbook.createCellStyle();//Create style
    Font font = workbook.createFont();//Create font
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
    style.setFont(font);//set it to bold
    style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
    //style.setFillPattern(CellStyle.BORDER_THICK);
    style.setAlignment(CellStyle.ALIGN_CENTER);

    for(int i = 0; i < row.getLastCellNum(); i++){
    	try{//For each cell in the row 
        row.getCell(i).setCellStyle(style);//Set the style
        	}
    	catch(NullPointerException e){
    		row.createCell(i).setCellStyle(style);
    	}
    }
}

static void updateDynamicDocument(ArrayList<String> resultList, int i, String mockOrTestdataValue, String passOrFail) throws IOException {
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
	int col_no=0;
	row1 = worksheet.createRow(i);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   " + (i + 1));

	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(resultList.get(0));
	
	Cell cellB1 = row1.createCell(2);
	System.out.println(resultList.get(1));
	if(!(resultList.get(1).toString().length()<=0))
	{
	cellB1.setCellValue(resultList.get(1));
	
	}
	Cell cellB2 = row1.createCell(3);
	cellB2.setCellValue(passOrFail);	
	setFontColourForPassFail(cellB2,passOrFail);
	workbook.write(fileOut);
		/*for (int n = 0; n < resultList.size(); n++) {

			if (n == 0) 
			{
				row1 = worksheet.createRow(i + 1);
			}
			//rowNumber = row1.getRowNum();
			Cell cellA5 = row1.createCell(0);
			cellA5.setCellValue("Line No   " + (i + 1));

			Cell cellA1 = row1.createCell(n + 1);
			cellA1.setCellValue(resultList.get(n));
			
		
		//row1 = worksheet.getRow(rowNumber);
		Cell cellB1 = row1.createCell(6);
		cellB1.setCellValue(mockOrTestdataValue);
		
		Cell cellB2 = row1.createCell(7);
		cellB2.setCellValue(passOrFail);
		setFontColourForPassFail(cellB2,passOrFail);
		workbook.write(fileOut);
}*/
	}
static void updateDynamicDocument1(ArrayList<String> resultList, int i, String mockOrTestdataValue,ArrayList<String> difference_doc, String passOrFail) throws IOException {
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
	int col_no=0;
	row1 = worksheet.createRow(i);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   " + (i + 1));

	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(resultList.get(0));
	
	Cell cellB1 = row1.createCell(2);
	cellB1.setCellValue(resultList.get(1));
	
	Cell cellB2 = row1.createCell(3);
	cellB2.setCellValue(passOrFail);	
	setFontColourForPassFail(cellB2,passOrFail);
	
	Cell cellB3=row1.createCell(4);
	cellB3.setCellValue(difference_doc.get(0));

	Cell cellB4=row1.createCell(5);
	cellB4.setCellValue(difference_doc.get(1));
	workbook.write(fileOut);
			
}
static void updateDynamicDocument11(ArrayList<String> resultList, int i, String mockOrTestdataValue,ArrayList<String> difference_doc, String passOrFail) throws IOException {
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
	int col_no=0;
	row1 = worksheet.createRow(i);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   " + (i + 1));

	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(resultList.get(0));
	
	Cell cellB1 = row1.createCell(2);
	cellB1.setCellValue(resultList.get(1));
	
	Cell cellB2 = row1.createCell(3);
	cellB2.setCellValue(passOrFail);	
	setFontColourForPassFail(cellB2,passOrFail);
	
	Cell cellB3=row1.createCell(4);
	cellB3.setCellValue(difference_doc.get(0));

	workbook.write(fileOut);
			
}
//Created this to update values for Form Sequencing

static void updateDynamicDocument_Form(ArrayList<String> resultList, int i,String passOrFail ,ArrayList<String> resultList_Missing,ArrayList<String> resultList_Missing_order_form ) throws IOException {
	//ExcelResult.updateDynamicDocument_Form(resultList1,i,passOrFail,resultList_Missing,resultList_Missing_order_form);
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
	int col_no=0;
	row1 = worksheet.createRow(i);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   " + (i + 1));

	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(resultList.get(0));
	
	Cell cellB1 = row1.createCell(2);
	cellB1.setCellValue(resultList.get(1));
	
	Cell cellB2 = row1.createCell(3);
	cellB2.setCellValue(passOrFail);	
	setFontColourForPassFail(cellB2,passOrFail);
	
	Cell cellB3=row1.createCell(4);
	cellB3.setCellValue(resultList_Missing.get(0));
	
	Cell cellB4=row1.createCell(5);
	cellB4.setCellValue(resultList_Missing_order_form.get(0));


	workbook.write(fileOut);
			
}

//Created this to compare forms sequencing for CPT  against OSP
static void updateDynamicDocument_Form_cpr_osp(LinkedList<String> resultList, int i,String passOrFail ,LinkedList<String> resultList_Missing_cpt,LinkedList<String> resultList_Missing_osp ) throws IOException {
	//ExcelResult.updateDynamicDocument_Form(resultList1,i,passOrFail,resultList_Missing,resultList_Missing_order_form);
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
	int col_no=0;
	row1 = worksheet.createRow(i);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No   " + (i + 1));

	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(resultList.get(0));
	
	Cell cellB1 = row1.createCell(2);
	cellB1.setCellValue(resultList.get(1));
	
	Cell cellB2 = row1.createCell(3);
	cellB2.setCellValue(passOrFail);	
	setFontColourForPassFail(cellB2,passOrFail);
	
	Cell cellB3=row1.createCell(4);
	cellB3.setCellValue(resultList_Missing_cpt.get(0));
	
	Cell cellB4=row1.createCell(5);
	cellB4.setCellValue(resultList_Missing_osp.get(0));


	workbook.write(fileOut);
			
}
public static void updateNarrativeDocument(String formNumber, String[] result) throws IOException {
	
HSSFRow row1 = worksheet.createRow(1);
	
		
	Cell cellA1 = row1.createCell(0);
	cellA1.setCellValue(formNumber);
	
	Cell cellA2 = row1.createCell(1);
	cellA2.setCellValue(result[2]);
	
	Cell cellA3 = row1.createCell(2);		
	cellA3.setCellValue(result[1]);
	
	Cell cellA4 = row1.createCell(3);		
	cellA4.setCellValue(result[3]);
	setFontColourForPassFail(cellA4,result[3]);	
	
	workbook.write(fileOut);
}

private static void setFontColourForPassFail(Cell cellA4, String result) {
	HSSFFont font = workbook.createFont();
	HSSFCellStyle cellStyle= workbook.createCellStyle();
	if(result.equals("Fail")){
		font.setColor(HSSFFont.COLOR_RED);
		cellStyle.setFont(font);
		cellA4.setCellStyle(cellStyle);}
	
	else{
		//font.setColor(HSSFColor.DARK_GREEN.index);
		font.setColor(HSSFFont.COLOR_NORMAL);
		cellStyle.setFont(font);
		cellA4.setCellStyle(cellStyle);
	}
	
}

public static void SummaryReport(String excelResultFile) {
	try {
		fileIn = new FileInputStream(excelResultFile);
		fileOut = new FileOutputStream(excelResultFile);
		//workbook = new HSSFWorkbook(fileIn);
		worksheet = workbook.createSheet("Summary Report");
		workbook.setSheetOrder("Summary Report",0);
		updateHeadersInSummerySheet();
		flushall();
		updateSummeryResult(excelResultFile);
		//flushall();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

private static void updateSummeryResult(String excelResultFile) {
	try {
		
	for (int i = 1; i < workbook.getNumberOfSheets(); i++) {
		fileIn = new FileInputStream(excelResultFile);
		fileOut = new FileOutputStream(excelResultFile);
        HSSFSheet sheet = workbook.getSheetAt(i);
        worksheet = workbook.getSheetAt(0); 
       int cellNumber=0;
       String[] summeryResult = new String[2];
        HSSFRow row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		while(cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			if(cell.getStringCellValue()=="Pass/Fail"){
				cellNumber=cell.getColumnIndex();
				break;
			}
		}
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext()) {
	        Row row1 = rowIterator.next();
	        Cell cell1 = row1.getCell(cellNumber);
	        if(cell1.getStringCellValue().equals("Fail")){
	        	summeryResult[1] = "Fail";
	        	summeryResult[0] = sheet.getSheetName();
	        }
		}
		if(summeryResult[1]==null){
			summeryResult[1] = "Pass";
        	summeryResult[0] = sheet.getSheetName();
		} 
		//HSSFFont font = workbook.createFont();
		//HSSFCellStyle cellStyle= workbook.createCellStyle();		   
		int lastRow= worksheet.getLastRowNum();
		HSSFRow row1 = worksheet.createRow(lastRow+1);
		HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_DOCUMENT);
		sheet_link.setAddress("'"+summeryResult[0]+"'!A1");
		Cell cellA5 = row1.createCell(0);
		cellA5.setCellValue(summeryResult[0]);
		cellA5.setHyperlink(sheet_link);
		
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue(summeryResult[1]);
		setFontColourForPassFail(cellA1,summeryResult[1]);
		/*if(summeryResult[1].equals("Fail")){
			font.setColor(HSSFFont.COLOR_RED);
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);}
		else{
			font.setColor(HSSFColor.DARK_GREEN.index);			
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);
		}*/
		workbook.write(fileOut);
		flushall();
    }
		//workbook.write(fileOut);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
}

private static void updateHeadersInSummerySheet() {
	try {	
		CellStyle style = workbook.createCellStyle();//Create style
	    Font font = workbook.createFont();//Create font
	    font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
	    font.setColor(HSSFColor.DARK_BLUE.index);
	    style.setFont(font);//set it to bold
	    //style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
	    //style.setFillPattern(CellStyle.BORDER_THICK);
	    style.setAlignment(CellStyle.ALIGN_CENTER);
		
	HSSFRow row1 = worksheet.createRow(0);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Form Number");
	cellA5.setCellStyle(style);
	worksheet.autoSizeColumn(0);
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue("Pass/Fail");
	cellA1.setCellStyle(style);
	worksheet.autoSizeColumn(1);
	
		workbook.write(fileOut);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	}


























