package businesscomponents;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class DynamicExcelCreation {
	static HSSFWorkbook workbook = null;
	static HSSFSheet worksheet = null;
	static FileOutputStream fileOut = null;
	static FileInputStream fileIn = null;
	
	public DynamicExcelCreation() {
		
		
	}
	public static void createExcelwithFinalValue(ArrayList<String> resultList,
			int i, String excelResultFile, String formNumber, String mockOrTestdataValue, String passOrFail) throws IOException {
		File file = new File(excelResultFile);    
		if (!file.exists()) {
			//ExcelResult.createDocument(formNumber,excelResultFile,"Dynamic");
			ExcelResult.createDocument(formNumber,excelResultFile,"Simple");
			ExcelResult.updateDynamicDocument(resultList,i,mockOrTestdataValue,passOrFail);
		}	
		
		
		else{
			//ExcelResult.openDocument(formNumber,excelResultFile,"Dynamic");
			ExcelResult.openDocument(formNumber,excelResultFile,"Simple");
			System.out.println(resultList+"^^^^^^^^^^^^^^^^^^^^^^^^^^");
			ExcelResult.updateDynamicDocument(resultList,i,mockOrTestdataValue,passOrFail);
		}
			
		ExcelResult.flushall();
			
	}
	
//		private static void createDocument(String formNumber, String excelResultFile) throws IOException {
//			fileOut = new FileOutputStream(excelResultFile);
//			workbook = new HSSFWorkbook();
//			worksheet = workbook.createSheet(formNumber);
//			HSSFRow row = worksheet.createRow(0);
//
//			Cell cellA5 = row.createCell(0);
//			cellA5.setCellValue("Line Number");
//
//			Cell cellA1 = row.createCell(1);
//			cellA1.setCellValue("Actual Line Value");
//			workbook.write(fileOut);
//		
//	}
		

}

//}
