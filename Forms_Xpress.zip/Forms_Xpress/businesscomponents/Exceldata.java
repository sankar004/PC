package businesscomponents;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.cognizant.framework.ExcelDataAccess;


public class Exceldata {

//To Get Form Details
	static String status=null;
       //Get the Form Number & Provide the form details as List
       public static List<String>  GetFormDetails(String FormNumber) throws IOException
       {
    	  
              //Open Excel File
          // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\FormDetails.xls");
           // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\New_Excel.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\ITERATION3_allfiles.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Demo_formdetails.xls");
    	   String relativePath = new File(System.getProperty("user.dir"))
			.getAbsolutePath();    	   
    	   String filepath = relativePath + "\\Datatables\\R1-41TestCases.xls";
    	   File src=new File(filepath);
    	//  File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Final_Iteration3.xls");
              FileInputStream fis=new FileInputStream(src);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
             // HSSFSheet sh1= wb.getSheetAt(0);
             HSSFSheet sh1= wb.getSheet("Dyanamic_field_reference");
              
            //Get Row & Column Count
              int tot_row = sh1.getLastRowNum();
              System.out.println("tot_row = "+tot_row);
              int tot_col = sh1.getRow(0).getLastCellNum();
              //Find the Row number
              boolean formfound = false;
              int rownumber=0;
              
              for(int i=1 ;i<=tot_row;i++){
            	 // String mock_name = 
                     if(sh1.getRow(i).getCell(0)!=null){
                    	 
                    	 
                     if(sh1.getRow(i).getCell(0).getStringCellValue().replaceAll(" ", "").compareToIgnoreCase(FormNumber.replaceAll(" ", ""))==0)
                     {
                           formfound=true;
                           rownumber=i;
                                         break;
                                         
                     }
                    	 
              }
              }
              
              List<String> FormDetails=new ArrayList<String>();
              
              //if not found, Null else read all the columns in list
              if (formfound==false){
                     FormDetails = null;
              }
                     else{
                     String s1;    
                     for(int i=0;i<=tot_col;i++ ){
                           if(sh1.getRow(rownumber).getCell(i)!=null){
                          
             
              String header = sh1.getRow(0).getCell(i).getStringCellValue().toString();
              if(header.startsWith("Dynamic"))
            	  
              {
            	  s1 = sh1.getRow(rownumber).getCell(i).getStringCellValue().toString();
            	  System.out.println("S1"+s1);
            	  if(s1=="")
            	  {
            		 break; 
            	  }
            	  FormDetails.add(s1);
              }
                         
                           }
                     }
              }

              
              //Close the Workbook
              wb.close();
              
              fis.close();
              
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
              src=null;
              return FormDetails;
              
       }
       
       // To get package status
       
       public static String  Getpackagestatus(String FormNumber) throws IOException
       {
    	  
              //Open Excel File
          // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\FormDetails.xls");
           // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\New_Excel.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\ITERATION3_allfiles.xls");
    	   File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Formstatus.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Final_Iteration3.xls");
              FileInputStream fis=new FileInputStream(src);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
              HSSFSheet sh1= wb.getSheetAt(0);
            //Get Row & Column Count
              int tot_row = sh1.getLastRowNum();
              System.out.println("tot_row"+tot_row);
              int tot_col = sh1.getRow(0).getLastCellNum();
              //Find the Row number
              boolean formfound = false;
              int rownumber=0;
              status=null;
              for(int i=1 ;i<=tot_row;i++){
                     if(sh1.getRow(i).getCell(0)!=null){
                     if(sh1.getRow(i).getCell(0).getStringCellValue().replaceAll(" ", "").compareToIgnoreCase(FormNumber.replaceAll(" ",""))==0)
                     {
                           formfound=true;
                           rownumber=i;
                                         break;
                                         
                     }
              }
              }
              
              List<String> FormDetails=new ArrayList<String>();
              
              //if not found, Null else read all the columns in list
              if (formfound==false){
            	  status = null;
              }
                     else{
                     
                    // for(int i=1;i<=tot_col;i++ ){
                         if(sh1.getRow(rownumber).getCell(1)!=null){
                           status = sh1.getRow(rownumber).getCell(1).getStringCellValue();
                           System.out.println("status"+status);
                         }
                          // break;
                           
                        
                         //  FormDetails.add(s1);
                           }
                     
              

              
              //Close the Workbook
             // wb.close();
              fis.close();
              
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
              src=null;
              
              return status;
              
       }
       
       
       // to update static and dynamic status
      
       
       public static String  updatestatus(String FormNumber,String validation_type) throws IOException
       {
    	  
              //Open Excel File
          // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\FormDetails.xls");
           // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\New_Excel.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\ITERATION3_allfiles.xls");
    	   String filepath="C:\\Forms_Xpressv2.0\\Test_Data\\Formstatus.xls";
    	   FileInputStream fis = new FileInputStream(new File(filepath));
    	   //File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Formstatus.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Final_Iteration3.xls");
            //  FileInputStream fis=new FileInputStream(src);
              //Workbook wb = WorkbookFactory.create(fis);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
              HSSFSheet sh1= wb.getSheetAt(0);
             // HSSFCell cell=null;
            //Get Row & Column Count
              int tot_row = sh1.getLastRowNum();
              System.out.println("tot_row"+tot_row);
              int tot_col = sh1.getRow(0).getLastCellNum();
              String value="completed";
              //Find the Row number
              boolean formfound = false;
              int rownumber=0;
              Cell cell=null;
              
              for(int i=1 ;i<=tot_row;i++){
            	  String cellval=sh1.getRow(i).getCell(0).getStringCellValue();
                  System.out.println("cellval"+cellval);
                     if(sh1.getRow(i).getCell(0)!=null){
                     if(sh1.getRow(i).getCell(0).getStringCellValue().replaceAll(" ", "").compareToIgnoreCase(FormNumber)==0)
                     {
                           formfound=true;
                           rownumber=i;
                           
                                         break;
                                         
                     }
              }
              }
              
              
              
              
             // List<String> FormDetails=new ArrayList<String>();
              
              //if not found, Null else read all the columns in list
              if (formfound==false){
                   //  FormDetails = null;
              }
                     else{
                    	 if(validation_type.equals("static_dynamic"))
                    	 {
                    		
                    		  cell=sh1.getRow(rownumber).createCell(1);
                              System.out.println("cell"+cell);
                              cell.setCellValue("Completed");
                    	 }
                     
                    	 if(validation_type.equals("Dynamic"))
                    	 {
                    
                    		
                              cell=sh1.getRow(rownumber).createCell(2);
                              System.out.println("cell"+cell);
                              cell.setCellValue("Completed");
                    		 
                    		 
                    		 
                    	 }
                     
                     if(validation_type.equals("Static"))
                     {
                    	 
                    	 cell=sh1.getRow(rownumber).createCell(3);
                         System.out.println("cell"+cell);
                         cell.setCellValue("Completed");
               		 
                     }
                     
                     cell=sh1.getRow(rownumber).createCell(4);
                     String package_name=PDFContent.act_frmname;
                     cell.setCellValue(package_name);
                     fis.close();
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     
                     fis.close();
                    	 
                          /* if(sh1.getRow(rownumber).getCell(i)!=null){
                           status = sh1.getRow(rownumber).getCell(i).getStringCellValue();
                           break;*/
                           
                        
                         //  FormDetails.add(s1);
                           }
                     
              FileOutputStream outputStream = new FileOutputStream(new File(filepath));
              wb.write(outputStream);
              outputStream.close();
               

              
              //Close the Workbook
              wb.close();
              fis.close();
              
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
             
              
              return status;
              
       }
       
       
       
       
       
 
//To Get Policy Details
      
       //Get teh policy details based on teh given policy number & column name
       public static String  GetPolicyDetails(String PolicyNumber,String ColumnName, String currentTC) throws IOException
       {
              
              //Open Excel File
             // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\TestData.xls");
             // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Demo_Testdata.xls");
    	 // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Demo_formdetails.xls");
    	 String ExecutionMode = "Local" ;
    	   
    	if(ExecutionMode.equals("E2E")){  
    	        String TCName = currentTC; 
    	        String Fieldvalue = "";
    	        String E2ETCName = "";
    	        String E2EFieldName = "";            
    	        int VersionNumber = 0;
    	        if(PolicyNumber=="")
    	        {
    	        	System.out.println("Policy number is null");
    	        }
    	        if(ColumnName=="")
    	        {
    	        	System.out.println("Policy number is null");
    	        }
    	        if(currentTC=="")
    	        {
    	        	System.out.println("Policy number is null");
    	        }
    	        
    	       
    	        try {
    	                   E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
    	                   if(E2ETCName!=null)
    	                   {
    	                   
    	                   E2EFieldName = E2E_DB_Update.Select_E2EFieldName("FIELD_NM", "FIELD_NAME_MASTER", "FIELD_ID", "MASTER_FIELD_ID", "APP_FIELD_NAME_MAPPING", "APP_FIELD_NM",ColumnName,"APP_NM","Output");
    	                   if(E2EFieldName!=null)
    	                   {
    	                   VersionNumber = E2E_DB_Update.getversionumber(E2ETCName, E2EFieldName);
    	                   
    	                   
    	                   Fieldvalue = E2E_DB_Update.getValue(E2ETCName, E2EFieldName, VersionNumber);
    	                   
    	                   }
    	                   }
    	                   else
    	                   {
    	                	   System.out.println("DB values missing");
    	                   }
    	        } catch (SQLException e) {
    	                        e.printStackTrace();
    	        }
    	        return Fieldvalue;                                                                           
    	}else{
    	   
    	  String relativePath = new File(System.getProperty("user.dir"))
			.getAbsolutePath();    	   
    	  String filepath = relativePath + "\\Datatables\\R1-41TestCases.xls";
    	  File src=new File(filepath);
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Final_Iteration3.xls");
    	 // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\ITERATION3_allfiles.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Test_Data.xls");
              FileInputStream fis=new FileInputStream(src);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
              //HSSFSheet sh1= wb.getSheetAt(0);
            HSSFSheet sh1= wb.getSheet("EndToEnd");
              
              //Get Row & Column Count
              int tot_row = sh1.getLastRowNum();
              int tot_col = sh1.getRow(0).getLastCellNum();
              //Find the Row number
              boolean policyfound = false;
              int rownumber=0;
              for(int i=1;i<=tot_row;i++){
                     if(sh1.getRow(i).getCell(0)!=null){
                    	 if(PolicyNumber!=null)	
                    		 
                    	 {
                    	 String value=sh1.getRow(i).getCell(0).getStringCellValue();
                    	 System.out.println(value);
                     if(sh1.getRow(i).getCell(0).getStringCellValue().replaceAll(" ","").compareToIgnoreCase(PolicyNumber)==0){
                    	 //if(sh1.getRow(i).getCell(0).getStringCellValue().contains(PolicyNumber)){
                           policyfound=true;
                           rownumber=i;
                           System.out.println("rownumber"+rownumber);
                                         break;
                     }
                    	 }
                    	 
              }
                    
              }
              String policydetail;
              //if not found, Null else read all the columns in list
              if (policyfound==false){
                     policydetail = "Policy Number not found";
              }
                     else{
                           boolean columnfound = false;

                           int columnnumber = 0;
                     for(int i=1;i<=tot_col;i++ ){
                           if(sh1.getRow(0).getCell(i)!=null){
                                  if(sh1.getRow(0).getCell(i).getStringCellValue().compareToIgnoreCase(ColumnName)==0){
                                         columnfound=true;
                                         columnnumber=i;
                                                       break;
                                  }
                           }
                     }
                           if(columnfound==false){
                                  policydetail = "Column Not Found";
                           }
                           else{
                                  if(sh1.getRow(rownumber).getCell(columnnumber)==null){
                                         policydetail="";
                                  }
                                  else{
                                                policydetail = sh1.getRow(rownumber).getCell(columnnumber).getStringCellValue();
                                         }
                                  }
                           }
              //Close the Workbook
              wb.close();
              fis.close();
              
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
              src=null;
              
              
              
              return policydetail;
              
       }
       
       } 
       // To Get policy number
       
       public static String  GetPolicynumber(String FormNumber) throws IOException
       {
              //Open Excel File
          // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\policy_number.xls");
    	  File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Demo_formdetails.xls");
          // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Final_Iteration3.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\ITERATION3_allfiles.xls");
    	  // File src=new File("C:\\Forms_Xpressv2.0\\Test_Data\\Demo_formdetails.xls");
              FileInputStream fis=new FileInputStream(src);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
              HSSFSheet sh1= wb.getSheetAt(2);
              
              //Get Row & Column Count
              int tot_row = sh1.getLastRowNum();
              System.out.println("tot_row"+tot_row);
              int tot_col = sh1.getRow(0).getLastCellNum();
              //Find the Row number
              boolean formfound = false;
              int rownumber=0;
              for(int i=1 ;i<=tot_row;i++){
            	  String value= sh1.getRow(i).getCell(0).toString();
            	  System.out.println(value);
                     if(sh1.getRow(i).getCell(0)!=null){
                     if(sh1.getRow(i).getCell(0).getStringCellValue().replaceAll(" ", "").compareToIgnoreCase(FormNumber)==0)
                     {
                           formfound=true;
                           rownumber=i;
                                         break;
                                         
                     }
              }
              }
              String FormDetails=null;
              
              //if not found, Null else read all the columns in list
              if (formfound==false){
                     FormDetails = null;
              }
                     else{
                     String s1;    
                     for(int i=1;i<=tot_col;i++ ){
                           if(sh1.getRow(rownumber).getCell(i)!=null){
                           s1 = sh1.getRow(rownumber).getCell(i).getStringCellValue();
                           FormDetails=s1;
                           }
                     }
              }
              //Close the Workbook
              wb.close();
              fis.close();
              
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
              src=null;
              return FormDetails;
              
       }
       
       
       

//To Write Results in Report
       
       //Write the Result in Excel file at teh next new line
       //public static void  WriteReport(String FormNumber,String PageNumber, String ExpValue, String ActValue, String Status, String Line) throws IOException
       public static void  WriteReport(String FormNumber, String ExpValue, String ActValue, String Status) throws IOException
       {
              //Open Excel File
              File src=new File("C:\\PDFValidationDocuments\\TestData\\ITERATION3_new.xls");
              FileInputStream fis=new FileInputStream(src);
              HSSFWorkbook wb=new HSSFWorkbook(fis);
              HSSFSheet sh1= wb.getSheetAt(0);
              
              //Get Row Count
              int tot_row = sh1.getLastRowNum();
              
              //New row in which updates needs to be done
              int new_row = tot_row+1;
              
              //Create New Row
              sh1.createRow(new_row);
              //Create New Columns
              for(int i=0;i<=5;i++){
                     sh1.getRow(new_row).createCell(i);
              }
              
              //Update in Excel
              sh1.getRow(new_row).getCell(0).setCellValue(FormNumber);
            //  sh1.getRow(new_row).getCell(1).setCellValue(PageNumber);
              sh1.getRow(new_row).getCell(2).setCellValue(ExpValue);
              sh1.getRow(new_row).getCell(3).setCellValue(ActValue);
              sh1.getRow(new_row).getCell(4).setCellValue(Status);
              //sh1.getRow(new_row).getCell(5).setCellValue(Line);
              
              //Save the workbook
              FileOutputStream outFile =new FileOutputStream(new File("C:\\PDFValidationDocuments\\TestData\\Result.xls"));
        wb.write(outFile);
              
              //Close the Workbook
              wb.close();
              fis.close();
              //Clean objects
              sh1 = null;
              wb = null;
              fis = null;
              src=null;
              
       }
       
//Test Code:
//Test GetFormDetails Function
      
             /* List<String> FormDetails = GetFormDetails("abcd");
              if(FormDetails==null){
                     System.out.println("Form Number Not found");
              }
              else{
              for (int i = 0; i < FormDetails.size(); i++) {
                  String strings = FormDetails.get(i);
                      System.out.println(strings);
              }
              }
              
              //Test GetPolicyDetails Function
               //GetPolicyDetails("asda4","col15");
             System.out.println(GetPolicyDetails("asda4",col15"));
            //  System.out.println( GetPolicyDetails("asda4","col15"));
              
              //Test WriteReport
              WriteReport("Tes1","Test2","test3","test4","Pass","Test6");*/



}