package businesscomponents;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;

import java.awt.Color;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;

import com.cognizant.framework.Status;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
import com.cognizant.framework.Status;
import com.cognizant.framework.TestParameters;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.Util;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import allocator.*;





public class Simple extends ReusableLibrary {
                static int actual_document_no_of_pages,mock_document_no_of_pages;
                static PDDocument actdocument = null,mckdocument = null;
                static int actFormPages[],mockFormPages[];
                static String act_content=null, mock_content=null,Start_Txt=null,End_Txt,strDyndata=null;
                static String act_content_f=null, mock_content_f=null,Staticdyn_text=null;

                static String outPutForm = "c:\\PDFValidationDocuments\\OutPutPDF\\";
                static int[] actFormPages1;
                static int[] mockFormPages1;
                static String[] dynamicCompareResult = new String[2];
                static String[] array=new String[5];
                static String Act_Top= null;
                static String Mock_Top= null;
                static ArrayList<String> resultList = new ArrayList<String>();
                static String excelResultFile= null;
                static     int x=0;
                static String[] lineSplit = null;
                static String[] lineSplit1 = null;
                static String data=null;
                static String line1=" ";
                static String line2=" ",PDF_Value=" ", Excel_Value=" ";
                static String line3,completion_status,strdynamicstatus,strstaticstatus,validation_type=" ";
                static int LineNo=0,intMckPages;
                static int strt_page,end_page, page_return;
                static boolean flag=true;
                String strData_field,status=null;
                
                //static int[] page_return=new int[100];
                public Simple(ScriptHelper scriptHelper) {
            		super(scriptHelper);
            	}
            	
                
                public void CompareContents(String actualDocument, String mockDocument,String formNumber,String ExcelResultFile,String narration,String formTitle,String compare_type,String testcaseName,int intPgnum,String PolicyNumber, String CurrentTC) throws IOException, COSVisitorException 
                {
                excelResultFile= ExcelResultFile;
                String exceldata[]=null;
                String Textdata[]=null;
                String final_data=null;
                List<String> FormDetails=new ArrayList<String>();
                
                                actdocument = PDDocument.load( actualDocument ); // To convert into pdd document
                                mckdocument = PDDocument.load( mockDocument );
                                intMckPages = CommonClass.GetFormpagesWithoutFooterNo(mckdocument);
                                strt_page = intPgnum;
                                end_page = intPgnum + intMckPages ;
                                act_content_f = CommonClass.GetEntirePageContent_pack(actdocument,strt_page,end_page).replaceAll("\r\n", "").replaceAll(" ","").replaceAll("\\)", "").replaceAll("\\(", "");
                                System.out.println("act_content_f"+act_content_f);
                                mock_content_f=CommonClass.GetEntirePageContent_pack(mckdocument,0,intMckPages).replaceAll("\r\n", "").replaceAll(" ", "").replaceAll("\\)", "").replaceAll("\\(", ""); 
                                //System.out.println("mock_content_f"+mock_content_f);
                                act_content=act_content_f.replaceAll(" ","").replaceAll("\r\n","").replaceAll("\r\n", "").replaceAll("\\(\\)", ""); //To eliminate cosmetic errors. All space will be truncated to give a single string
                                mock_content=mock_content_f.replaceAll(" ","").replaceAll("\r\n","").replaceAll("\\)", "").replaceAll("\\(", "");
                               
                                System.out.println("formNumber"+formNumber);
                                
                             //  completion_status=Exceldata.Getpackagestatus(formNumber);
                                
                                completion_status = null;
                                
                if((completion_status==null)||(completion_status==""))
                {
                            // FormDetails=Exceldata.GetFormDetails(formNumber);
                				FormDetails = null;	
                            //System.out.println("FormDetails_size"+FormDetails.size());
                                if(FormDetails==null)
                                {
                                 System.out.println("NO DYNAMIC CONTENT PRESENT");
                                 }
                                
                                else
                                {
                                validation_type="Dynamic"; 
                                int listlen=FormDetails.size();
                                
                                int ExcelLinelNo=4;
                                String Static_text=null,Dynamic_value=null;                      
                                List<String> Arrdyn_contain=new ArrayList<String>();
                                for(int i=0;i<FormDetails.size();i++)
                                {
                                                 String Excel_fieldname=null;
                                                // boolean Contains_cd= false;
                                                
                               // System.out.println("act_content_f"+act_content_f);
                                strDyndata=FormDetails.get(i);
                                System.out.println("strDyndata"+strDyndata);
                                if(strDyndata=="")
                                                break;
                                if(strDyndata.contains("$$")&&strDyndata.contains("&&"))
                                
                                {
                                System.out.println("strDyndata"+strDyndata);
                                exceldata=strDyndata.split("\\$\\$"); 
                                if(strDyndata.contains("**"))
                                {
                                                Excel_fieldname = exceldata[1].replaceAll(" ", "").replaceAll("\\*\\*", "").replaceAll("splcase", "");
                                                
                                }
                                
                                else
                                {
                                Excel_fieldname = exceldata[1].replaceAll(" ", "");
                                }
                                if(Excel_fieldname.isEmpty())
                                
                                                break;
                                else if(Excel_fieldname.equals("PCRateAsOfDate"))
                                {
                                	System.out.println("Field yet to be updated");
                            		strData_field = null;
                            		
                                }
                                
                                System.out.println("Excel_fieldname = "+Excel_fieldname);
                                Textdata=exceldata[0].split("\\&\\&");
                                String Text_strt = Textdata[0].replaceAll(" ", "").trim();
                                //System.out.println("Text_strt"+Text_strt);
                                String Text_End = Textdata[1].replaceAll(" ", "").trim();
                                //System.out.println("Text_End"+Text_End);
                                Staticdyn_text=getDynamicBtwStaticLine(act_content_f, Text_strt, Text_End).replaceAll("\\)", "").replaceAll("\\(", "").replaceAll("\r\n", "").replaceAll(formNumber, "");
                                System.out.println("Staticdyn_text = "+Staticdyn_text);
                                //String statdyn_value[] = null;
                                //statdyn_value = Staticdyn_text.split("\\%\\%");  // First array has dyn_data and second array has static data without dynamic values
                                //String Dynamic_value=statdyn_value[0].replaceAll("\\(\\)", "");
                                Dynamic_value=Staticdyn_text.toUpperCase();
                                System.out.println("PDF_value = "+Dynamic_value);
                                
                                if(strDyndata.contains("**"))
                                {
                                                Arrdyn_contain.add(Staticdyn_text);
                                                //act_content_f=Static_text;
                                                //Static_text=act_content_f;
                                }
                                else
                                {
                                                
                                                Static_text=act_content_f.replaceFirst(Staticdyn_text, "");
                                                //final_data = dynamic_value + "%%" + Static_text;
                                                act_content_f=Static_text;
                                                System.out.println("act_content_f_replaced"+act_content_f);
                                                System.out.println("Excel_fieldname"+Excel_fieldname);
                                               
                                }
                                try{
                                	
                               strData_field = Exceldata.GetPolicyDetails(PolicyNumber,Excel_fieldname, CurrentTC).toUpperCase();
                               // strData_field = Exceldata.GetPolicyDetails(PolicyNumber,Excel_fieldname);
                                System.out.println("Excel_vaLUE = "+strData_field);
                                	
                                }
                                catch(Exception e)
                                {
                                	System.out.println("Issue in strdatafield"+Excel_fieldname);
                                	 report.updateTestLog("Fieldname "+Excel_fieldname, "Not available in Database " +"Actual: "+Dynamic_value
     				, Status.FAIL);
                               
                                }
                               
                                
                                
                               // resultList.add(Excel_fieldname+": "+Dynamic_value.toString().replaceAll(" ", ""));
                               // resultList.add(Excel_fieldname+": "+strData_field.toString().replaceAll(" ", ""));
                               
								//report.updateTestLog("Fieldname "+Excel_fieldname, "Expected "+strData_field+ " : " +"Actual "+Dynamic_value+
										//" Passed", Status.DONE);
                          
                                
                                
                                if(strDyndata.contains("**"))
                                {
                                
                                                if(Dynamic_value.replaceAll(" ", "").contains(strData_field.replaceAll(" ", "")))
                                                {
                                                status="Warning-PASS";
                                                             //   Exceldata.WriteReport(formNumber,Dynamic_value,strData_field,status);
                                                                report.updateTestLog("Fieldname "+Excel_fieldname, "Expected: "+strData_field+ "\r\n " +"Actual: "+Dynamic_value
                                										, Status.PASS);
                                                          
                                                          
                                                }
                                                else
                                                {
                                                	report.updateTestLog("Fieldname "+Excel_fieldname, "Expected: "+strData_field+ " \r\n " +"Actual: "+Dynamic_value
                    										, Status.FAIL);
                                                status="Fail";
                                                }
                                              
                                              
                                }
                                else if(strData_field==null)
                                {
                                	System.out.println("Field yet to be updated");
                                }
                                else
                                {
                                if(Dynamic_value.replaceAll(" ", "").equalsIgnoreCase(strData_field.replaceAll(" ", "")))
                                {
                                status="Pass";
                                               // Exceldata.WriteReport(formNumber,Dynamic_value,strData_field,status);
                                                report.updateTestLog("Fieldname "+Excel_fieldname, "Expected: "+strData_field+ "\r\n" +"Actual: "+Dynamic_value
                										, Status.PASS);
                                          
                                }
                                else
                                {
                                                status="Fail";
                                              //  Exceldata.WriteReport(formNumber,Dynamic_value,strData_field,status);
                                                report.updateTestLog("Fieldname "+Excel_fieldname, "Expected: "+strData_field+ "\r\n" +"Actual: "+Dynamic_value
                									, Status.FAIL);
                                        
                                }
                                }
                                
                                System.out.println("Dynamic_value =  "+Dynamic_value);
                                //Exceldata.WriteReport(formNumber,Dynamic_value,strData_field,status);
                               // DynamicExcelCreation.createExcelwithFinalValue(resultList, ExcelLinelNo,excelResultFile,PDFContent.Form_Number+"_"+PDFContent.compare_type,Dynamic_value,status);
                                //DynamicExcelCreation.createExcelwithFinalValue(resultList, ExcelLinelNo,excelResultFile,PDFContent.act_frmname+"_"+PDFContent.compare_type,Dynamic_value,status);
                                resultList.clear();
                               // ExcelLinelNo++;
                                //act_content_f=statdyn_value[1];
                                System.out.println("act_content_f = "+act_content_f);
                                
                                }
                                }
                                
                                for(int i=0;i<Arrdyn_contain.size();i++)
                                {
                                                String Dyn_contain=Arrdyn_contain.get(i).replaceAll(" ","");
                                                
                                                String static_txt=act_content_f.replaceAll(Dyn_contain, "");
                                                act_content_f=static_txt;
                                }
                                //strdynamicstatus=Exceldata.updatestatus(formNumber,validation_type);
                                
                                                
                                                                
                                }
                                
                                 validation_type="Static";
                                 CommonClass commobj = new CommonClass(scriptHelper);
                                 
                                 commobj.ComparebyDefault_simple(act_content_f,mock_content_f,act_content,mock_content,"By Word",0);
                                
                                // strdynamicstatus=Exceldata.updatestatus(formNumber,validation_type);
                                
                               //  validation_type="static_dynamic";
                               // strdynamicstatus=Exceldata.updatestatus(formNumber,validation_type);
                                
                                 
                }
                else
                {
                                System.out.println("FORM ALREADY VALIDATED");
                }
                }
                
                public static String getDynamicBtwStaticLine_single (String actual_data,String first)
                {
                String arrcontent[]=null;
                String final_data=null;
                arrcontent=actual_data.split(first);
                String static_text=arrcontent[0];
                String dynamic_text=arrcontent[1];
                final_data = dynamic_text + "%%" + static_text+first;
                return final_data;
                }
                public static String getDynamicBtwStaticLine (String actual_data,String first,String last) {
                                
                                
                                String strt[]=null;
                                String End[]=null;
                                String final_data=null;
                                String Static_text=null;
                                String dynamic_value=null;
                                int i=0;
                                //String Arrdyn_contain[]=null;
                                List<String> Arrdyn_contain=new ArrayList<String>();
                                if(first.isEmpty())
                                                {
                                                                End=actual_data.split(last);
                                                                dynamic_value=End[0];
                                                }
                                                
                                                
                                else if(last.isEmpty())
                                                {
                                                                End=actual_data.split(first);       
                                                                if(End.length==2)
                                                                {
                                                                dynamic_value=End[1];
                                                }
                                                                else
                                                                                //dynamic_value=End[2];
                                                                dynamic_value=End[End.length-1];
                                                                                
                                                }
                                                                                
                                
                                else
                                                
                                {
                                                if(actual_data.contains(first)&&actual_data.contains(last))
                                                {
                                strt=actual_data.split(first);
                                System.out.println("strt[0]"+strt[0]);
                                System.out.println("strt[1]"+strt[1]);
                                if(strt.length==2)
                                {
                                                End=strt[1].split(last);
                                                dynamic_value=End[0];
                                }
                                
                                else
                                {
                                                
                                int last_len=last.length();
                                for(i=1;i<strt.length;i++)
                                {
                                                //String last_value = last.substring(0, last_len);
                                                System.out.println("last"+last);
                                                if(strt[i].contains(last))
                                                {
                                                                System.out.println("strt[i]"+strt[i]);
                                                                String last_value = strt[i].substring(0, last_len);
                                                                if(last_value.equals(last))
                                                                {
                                                               End=strt[i].split(last);
                                                                dynamic_value=End[0];
                                                                //break;
                                                                }
                                                                else if(!last_value.equals(last))
                                                                {
                                                                End=strt[i].split(last);
                                                                dynamic_value=End[0];
                                                                break;
                                                                }
                                                                //if(End[0].equals(""))
                                                                else if(End[0].isEmpty())
                                                                {
                                                                                dynamic_value="no dynamic value"; // the data between strt and end txt is null
                                                                }
                                                                /*else
                                                                {
                                                                dynamic_value=End[0];
                                                                }*/
                                                }
                                                //else if(i==(strt.length-1))
                                                
                                                /*else
                                                {
                                                                
                                                                dynamic_value="No-Value";
                                                
                                                
                                }
                                */
                                
                                
                                }
                                                }
                                                }
                                                else
                                                {
                                                                dynamic_value="No-Value for Start text or End Text";// No first text found 
                                                 }
                                
                                //int length=dynamic_value.length();
                                System.out.println("dynamic_value"+dynamic_value);
                                //System.out.println("strt[0]"+strt[0]);
                                
                                }
                                
                                return dynamic_value;
                }
                
                
                public static String getDynamicBtwStaticLine_Contain(String actual_data,String first,String last) {
                                String strt[]=null;
                                String End[]=null;
                                String final_data=null;
                                String Static_text=null;
                                strt=actual_data.split(first);
                                System.out.println("strt[0]"+strt[0]);
                                System.out.println("strt[1]"+strt[1]);
                                for(int i=0;i<strt.length;i++)
                                {
                                                if(strt[i].contains(last))
                                                {
                                                                End=strt[i].split(last);
                                                }
                                }
                                //End=strt[1].split(last);
                                //System.out.println("End[0]"+End[0]);
                                //System.out.println("End[1]"+End[1]);
                                String dynamic_value=End[0];
                                int length=dynamic_value.length();
                                System.out.println("dynamic_value"+dynamic_value);
                                System.out.println("strt[0]"+strt[0]);
                                //System.out.println("End[1]"+End[1]);
                                if(strt[0]!=null&&End[1]!=null)
                                {
                                                String dyn_spl=dynamic_value.replaceAll("\\(\\)", "");
                                                System.out.println("dyn_spl"+dyn_spl);
                                //Static_text=strt[0].concat(first).concat(last).concat(End[1]);
                                                
                                                                
                                                Static_text=actual_data.replaceFirst(dyn_spl, "");
                                                
                                                //System.out.println("Static_text"+Static_text);
                                                //Static_text=actual_data.replaceAll(dyn, "");
                                //Static_text = strt[0] + first + last + End[1];
                                final_data = dynamic_value + "%%" + actual_data;
                                }
                                /*if(strt[0]!=null&&End[1]!=null)
                                {
                                String strstatfin_txt=null;
                                Static_text=strt[0].concat(first).concat(last);
                                System.out.println("Static_text"+Static_text);
                                for(int i=1;i<strt.length;i++)
                                {
                                                strstatfin_txt=Static_text+strt[i];
                                                System.out.println("strstatfin_txt"+strstatfin_txt);
                                                Static_text=strstatfin_txt;
                                }
                                for(int i=1;i<End.length;i++)
                                {
                                                strstatfin_txt=Static_text+End[i];
                                                System.out.println("strstatfin_txt"+strstatfin_txt);
                                                Static_text=strstatfin_txt;
                                }
                                final_data = dynamic_value + "%%" + Static_text;
                                }
                                */
                                if(End[1]==null||End[1]==" ")
                                {
                                                Static_text=strt[0].concat(first).concat(last);
                                                final_data = dynamic_value + "%%" + Static_text;
                                }
                if(strt[0]==null||strt[1]==" ")
                                {
                                                Static_text=first.concat(last).concat(End[1]);
                                                final_data = dynamic_value + "%%" + Static_text;
                                }
                                
                                //return new String[] { dynamic_value, Static };
                                return final_data;
                }
                
                
                
                
                
                public static String GetMiddleSectionValues(PDDocument document,int act_from_page,int act_to_page,String section1, String section2,int x_start,int x_width)
                {
                                String section_content="";
                                int from_page,to_page;
                                int start_page_no;
                                from_page=act_from_page;
                                to_page=act_to_page;
                                try
                                {
                                                List allPages = document.getDocumentCatalog().getAllPages();
                                                int start_point=0;                                             
                                                int end_point=0;
                                                start_page_no=-1;
                                                                for(int i=from_page;i<=to_page;i++)
                                                                {
                                                                                PDPage firstPage = (PDPage)allPages.get( i );
                                                                                PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                                                                                stripper.setSortByPosition( true );
                                                                                //stripper.extractRegions( firstPage );
                                                                                //Add Regions and Extract the contents from the Region/*
                                                                                PDRectangle pageSize = firstPage.findMediaBox();
                                                                                float ht=pageSize.getHeight();
                                                                                float wd=pageSize.getWidth();
                                                                                System.out.println( "Page Width:" + wd );
                                                                                System.out.println( "Page Height:" + ht );
                                                                                int x1,y1,x2,y2;
                                                                                //Find the starting point and ending point of the section
                                                                                x1=1;
                                                                                y1=1;
                                                                                x2=(int) (wd);
                                                                                y2=10;
                                                                                int counter=1;                                                                   
                                                                                int no_of_lines=0;
                                                                                String left_text="",right_text="";
                                                                                //String General_section="";                                                                      
                                                                                while(y1<=(int)ht-30)
                                                                                {
                                                                                                Rectangle r1 = new Rectangle(x1, y1, x2, y2);                                                                                      
                                                                                                stripper.addRegion( "R"+counter, r1 );
                                                                                                stripper.extractRegions( firstPage );
                                                                                                String sec_name=stripper.getTextForRegion( "R"+counter ) ;
                                                                                                //System.out.println( stripper.getTextForRegion( "R"+counter ) );
                                                                                                if(sec_name.trim().contains(section1)){
                                                                                                                start_point=y1;
                                                                                                                start_page_no=i;
                                                                                                                System.out.println( "Starting Point:" + r1 );
                                                                                                }
                                                                                                if(sec_name.trim().contains(section2) && section2!=""){
                                                                                                                end_point=y1;
                                                                                                                no_of_lines=end_point-start_point+10;
                                                                                                                System.out.println( "End Point:" + r1 );
                                                                                                                break;
                                                                                                }              
                                                                                                counter=counter+1;        
                                                                                                y1=y1+10;
                                                                                }
                                                                                //if the section does not end in the same page
                                                                                if(start_point>0 && end_point==0 && start_page_no==i)
                                                                                {                                                                                              
                                                                                                no_of_lines=(int)ht-start_point-30;                                                                                        
                                                                                }              
                                                                                //if the section does not end in the same page and the start point is in a different page
                                                                                if(start_point>0 && end_point==0 && start_page_no!=i)
                                                                                {                                                                                              
                                                                                                start_point=1;
                                                                                                no_of_lines=(int)ht-start_point-30;                                                                                        
                                                                                }              
                                                                                //Last section
                                                                                if(start_point>0 && section2=="" && i==to_page && end_point==0)
                                                                                {              
                                                                                                if(start_page_no==i)
                                                                                                no_of_lines=(int)ht-start_point-30;                        
                                                                                                else if(start_page_no<i)
                                                                                                {
                                                                                                                start_point=1;
                                                                                                                no_of_lines=(int)ht-start_point-30;
                                                                                                }
                                                                                }
                                                                                                y2=no_of_lines;
                                                                                                System.out.println(no_of_lines);
                                                                                                PDFTextStripperByArea stripper1 = new PDFTextStripperByArea();
                                                                                                stripper1.setSortByPosition( true );        
                                                                                                Rectangle rec_left_text = new Rectangle(x_start, start_point,x_width, y2);
                                                                                                stripper1.addRegion( "left", rec_left_text);
                                                                                                stripper1.extractRegions( firstPage );    
                                                                                                left_text=stripper1.getTextForRegion( "left" );
                                                                                                                                                                                                
                                                                                                section_content=section_content+left_text;
                                                                                                //if both the start section and end section are found then break from for loop
                                                                                                if(start_point>0 && end_point>0)
                                                                                                {              
                                                                                                                break;
                                                                                                }
                                                                                                //if the section does not end in the same page
                                                                                                if(start_point>0 && end_point==0)
                                                                                                {                                                                                              
                                                                                                                start_point=1;
                                                                                                }              
                                                                }
                                }
                                catch(Exception e)
                                {
                                                
                                }
                                return section_content;
                }
                
                public static String GetMiddleDynamicSectionValues(PDDocument document,int act_from_page,int act_to_page,String section1, String section2,int x_start,int x_width)
                {
                                String section_content="";
                                int from_page,to_page;
                                int start_page_no;
                                from_page=act_from_page;
                                to_page=act_to_page;
                                try
                                
                                {
                                                List allPages = document.getDocumentCatalog().getAllPages();
                                                int start_point=0;                                             
                                                int end_point=0;
                                                start_page_no=-1;
                                                                for(int i=from_page;i<=to_page;i++)
                                                                {
                                                                                PDPage firstPage = (PDPage)allPages.get( i );
                                                                                PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                                                                                stripper.setSortByPosition( true );
                                                                                //stripper.extractRegions( firstPage );
                                                                                //Add Regions and Extract the contents from the Region/*
                                                                                PDRectangle pageSize = firstPage.findMediaBox();
                                                                                float ht=pageSize.getHeight();
                                                                                float wd=pageSize.getWidth();
                                                                                System.out.println( "Page Width:" + wd );
                                                                                System.out.println( "Page Height:" + ht );
                                                                                int x1,y1,x2,y2;
                                                                                //Find the starting point and ending point of the section
                                                                                x1=1;
                                                                                y1=1;
                                                                                x2=(int) (wd);
                                                                                y2=10;
                                                                                int counter=1;                                                                   
                                                                                int no_of_lines=0;
                                                                                String left_text="",right_text="";
                                                                                //String General_section="";                                                                      
                                                                                while(y1<=(int)ht-30)
                                                                                {
                                                                                                Rectangle r1 = new Rectangle(x1, y1, x2, y2);                                                                                      
                                                                                                stripper.addRegion( "R"+counter, r1 );
                                                                                                stripper.extractRegions( firstPage );
                                                                                                String sec_name=stripper.getTextForRegion( "R"+counter ) ;
                                                                                                //System.out.println( stripper.getTextForRegion( "R"+counter ) );
                                                                                                if(sec_name.trim().contains(section1)){
                                                                                                                start_point=y1+10;
                                                                                                                start_page_no=i;
                                                                                                                System.out.println( "Starting Point:" + r1 );
                                                                                                }
                                                                                                if(sec_name.trim().contains(section2) && section2!=""){
                                                                                                                end_point=y1-10;
                                                                                                                no_of_lines=end_point-start_point+10;
                                                                                                                System.out.println( "End Point:" + r1 );
                                                                                                                break;
                                                                                                }              
                                                                                                counter=counter+1;        
                                                                                                y1=y1+10;
                                                                                }
                                                                                //if the section does not end in the same page
                                                                                if(start_point>0 && end_point==0 && start_page_no==i)
                                                                                {                                                                                              
                                                                                                no_of_lines=(int)ht-start_point-30;                                                                                        
                                                                                }              
                                                                                //if the section does not end in the same page and the start point is in a different page
                                                                                if(start_point>0 && end_point==0 && start_page_no!=i)
                                                                                {                                                                                              
                                                                                                start_point=1;
                                                                                                no_of_lines=(int)ht-start_point-30;                                                                                        
                                                                                }              
                                                                                //Last section
                                                                                if(start_point>0 && section2=="" && i==to_page && end_point==0)
                                                                                {              
                                                                                                if(start_page_no==i)
                                                                                                no_of_lines=(int)ht-start_point-30;                        
                                                                                                else if(start_page_no<i)
                                                                                                {
                                                                                                                start_point=1;
                                                                                                                no_of_lines=(int)ht-start_point-30;
                                                                                                }
                                                                                }
                                                                                                y2=no_of_lines;
                                                                                                System.out.println(no_of_lines);
                                                                                                PDFTextStripperByArea stripper1 = new PDFTextStripperByArea();
                                                                                                stripper1.setSortByPosition( true );        
                                                                                                Rectangle rec_left_text = new Rectangle(x_start, start_point,x_width, y2);
                                                                                                stripper1.addRegion( "left", rec_left_text);
                                                                                                stripper1.extractRegions( firstPage );    
                                                                                                left_text=stripper1.getTextForRegion( "left" );
                                                                                                                                                                                                
                                                                                                section_content=section_content+left_text;
                                                                                                //if both the start section and end section are found then break from for loop
                                                                                                if(start_point>0 && end_point>0)
                                                                                                {              
                                                                                                                break;
                                                                                                }
                                                                                                //if the section does not end in the same page
                                                                                                if(start_point>0 && end_point==0)
                                                                                                {                                                                                              
                                                                                                                start_point=1;
                                                                                                }              
                                                                }
                                                                                
                                
                                }
                                catch(Exception e)
                                {
                                                
                                }
                                return section_content;
                }
                
                
                
                
}





