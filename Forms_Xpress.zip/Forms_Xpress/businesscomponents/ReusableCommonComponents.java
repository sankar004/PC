package businesscomponents;


import java.sql.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.cognizant.framework.FrameworkException;
import com.cognizant.framework.Status;
import com.cognizant.framework.TestParameters;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.Util;
import com.cognizant.framework.selenium.SeleniumTestParameters;

import allocator.*;

/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class ReusableCommonComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	//public static WebElement currentObject=null;
	/*static By ORType = null;
	static String Curr_obj = null, value=null;
	static String obj_Name=null;
	static String[] arrobj_name=null;
	static String[] arrdata=null;
	static String obj_type;
	static String[] obj_value=null;
	static String[] type=null;
	static String LegalName=null;
	static boolean Obj_Existence,status=true;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private String currentTC=null;
	private WebElement currentObject=null;*/
	private WebElement currentObject=null;
	private By ORType = null;
	private String Curr_obj = null, value=null;
	private String obj_Name=null;
	private String[] arrobj_name=null;
	private String[] arrdata=null;
	private String obj_type;
	private String[] obj_value=null;
	private String[] type=null;
	private String LegalName=null;
	private boolean Obj_Existence,status=true;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private String currentTC=null; 
	
	
	//static String requiredDetail=null;
	public ReusableCommonComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	public void reusablecomponent(String currentKeyword, String currentTestCase) 
	{
		 boolean DEBUG_MODE = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp")>0;
		try{
			ObjectRepository ORTable = new ObjectRepository(null);
			ORTable.getInputData();
			//Date yourDate = new Date();
			GregorianCalendar date = new GregorianCalendar();
	
			int hour = date.get(Calendar.HOUR);
			int Minute = date.get(Calendar.MINUTE);
			int seconds = date.get(Calendar.SECOND);
			System.out.println("Current time"+hour+":"+Minute+":"+seconds);
			
			currentTC = currentTestCase;
			

			
		//String Data=DriverScript.totaldata;
			//arrdata=Data.split("\\<==>");
			String object=dataTable.getData(currentKeyword, "Object");
			String objectValue=dataTable.getData(currentKeyword, "TestData");
			arrobj_name= object.split("\\;");
			arrdata=objectValue.split("\\;");
		 	Obj_Existence=false;
		 	int objcheckval=0;
		 	//System.out.println("Page start_scenario"+DriverScript.Scenario_name);
		 	//System.out.println("Page start_tc"+DriverScript.TestCase_name);
	        for(int i=0;i<arrobj_name.length;i++)
	        {
	        	type=arrobj_name[i].split("\\_");
 	        	obj_type=type[0];
	        	
        		String[] ObjVal=arrdata[i].toString().trim().split("##");
	        	if(objcheckval==0){
	        		if(obj_type.contains("RDO")||obj_type.contains("GRP")||obj_type.contains("CAL")){
	        			Obj_Existence=true;
	        		}
	        	else
	        	{
	        			Obj_Existence=false;
	        			String objType="By."+ ORTable.getType(arrobj_name[i]);
	    	        	String objelement=ORTable.getElement(arrobj_name[i]);
	    	        	//System.out.println(arrobj_name[i]);
	    	        	waitToBeDisplayed(2);
	    	        	WebElement PageFirstObj=GetwebElement(objType,objelement);
	    	        	Obj_Existence=PageFirstObj.isDisplayed();
	    	        	if(!Obj_Existence){
	    	        		for(int sec=0;(sec<=60 && !Obj_Existence);sec=sec+3){ //Modified by Muthu
	    	        			waitToBeDisplayed(3);
	    	        			Obj_Existence=PageFirstObj.isDisplayed();
	    	        		}
	    	        	}
	    	        	if(Obj_Existence)
    	        			objcheckval=1;
	        		}
	        	}
	        	
	        	if(Obj_Existence==true)
	        	{
	        		for(int obj=0;obj< ObjVal.length ; obj++){
	        			value=ObjVal[obj];
	        			if (value.contains("getdbData_")){
                            value = GetData(value.split("getdbData_")[1]);                                     
	        				}
	        			if(obj==0)
	        			{
	        				if(!obj_type.contains("RDO")&&!obj_type.contains("GRP")&&!obj_type.contains("CAL")){
	    	        			
	    	        			String Type1;
	    	        			if(ORTable.getType(arrobj_name[i])!=null){
	    	        				Type1="By."+ ORTable.getType(arrobj_name[i]);
	    	    	        		Curr_obj=ORTable.getElement(arrobj_name[i]);
	    	    	        		//System.out.println(arrobj_name[i]);
	    	    	        		currentObject=GetwebElement(Type1,Curr_obj);
	    	    	        		//GeneralComponents.highlightobject(driver,properties,LegalEntity);
	    	        			}
	    	        		}
	        		try{
switch(obj_type){
	    	        	
	    	 	        case "LST":
	    	 	        	Select newdropdown= new Select(currentObject);
	    	 	        	List<WebElement> dropdownlist = newdropdown.getOptions();
	    	 	        	boolean valexist=false;
	    	 	           for(int j=0;j<dropdownlist.size();j++){
	    	 	               if(dropdownlist.get(j).getText().equals(value)){
	    	 	            	  valexist=true;
	    	 	                   break;
	    	 	                   }
	    	 	           }
	    	 	           
	    	 	        	if(value.equalsIgnoreCase("random")&&!valexist){
	    	 	        		//int n = (int)(Math.random()*(dropdownlist.size()-1)+2);
	    	 	        		/*Random rand = new Random();
	    	 	        		int  n = rand.nextInt(dropdownlist.size()-1) + 1;*/
	    	 	        		newdropdown.selectByIndex(2);
	    	 	        	}else{
	    	 	        
	    	 	        		newdropdown.selectByVisibleText(value);
	    	 	        	}
	    	         	break;
	    		         		         	
	    	 	       case "EDI":
                           if(value.contains("Automation_Unique")){
                                  SecureRandom r = new SecureRandom();
                                         StringBuilder sb = new StringBuilder( 12 );
                                            for( int E = 0; E < 12; E++ ) 
                                               sb.append( AB.charAt( r.nextInt(AB.length()) ) );
                                           
                                         //System.out.println("Account Name is "+sb.toString());       
                                            value="QAC1"+sb.toString();
                                            
                                            }
                           try{
                                  currentObject.sendKeys(Keys.ENTER);
                                                                    }
                           catch (Exception e){
                            currentObject.sendKeys(Keys.RETURN);
                           }
                                         
                    currentObject.clear();
                           
                    if(value.contains("Today_Date"))
                    {
                  	  LocalDate localDate = LocalDate.now();
                  	  String Date = DateTimeFormatter.ofPattern("MM/dd/yyyy").format(localDate);
                  	  value=Date.toString();
                    }   
                            for (int s = 0; s < value.length(); s++){
                            char c = value.charAt(s);
                            String S = new StringBuilder().append(c).toString();
                            currentObject.sendKeys(S);
                        }
                                  currentObject.sendKeys(Keys.TAB);
                                  
                            break;

	    	 	      case "EDN":
                          try{
                              //LegalEntity.sendKeys(Keys.ENTER);
                              currentObject.click();
                          }
                              catch (Exception e){
                               currentObject.sendKeys(Keys.RETURN);
                              }
                                                          
                          currentObject.clear();
                          for (int s = 0; s < value.length(); s++){
                          char c = value.charAt(s);
                          String S = new StringBuilder().append(c).toString();
                          currentObject.sendKeys(S);
                              }
                                                          currentObject.sendKeys(Keys.TAB);
                          break;
                  

	    	 	       
	    	 	        case "RDO":	
	    	 	        	waitToBeDisplayed(2);
	    	 	        	String[] radio=null;
	    	 	        		//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'no')]/input[@type='radio']
	    		 	        	//*[contains(text(),'Is this building sprinklered?')]/ancestor::div//*[contains(text(),'No') ]/input[@type='radio']
	    		 	        radio=value.split("\\:");
	    	 	        	radio[0]=radio[0].toLowerCase().trim();
	    		 	        	if(radio.length>1){
	    		 	        		
	    		 	        		radio[1]=radio[1].toLowerCase().trim();
	    		 	        		//LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[@class='radioSet']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input"));
	    		 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/input "
	    		 	        				+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
	    		 	        	}
	    		 	        	else
	    		 	        	{
	    		 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] +"')]/input[@type='radio']"));
	    			 	        }
	    		 	        	Boolean EntityEnabled=currentObject.isEnabled();
	    		 	        	 if(EntityEnabled){
	    		 	        		//LegalEntity.click();
	    		 	        		//LegalEntity.sendKeys(Keys.ENTER);
	    		 	        		currentObject.sendKeys(Keys.SPACE);
	    		 	        		waitToBeDisplayed(2);
	    		 	        	}
	    		 	        	
	    		 	        	 /*if(!LegalEntity.isSelected()){
	    		 	        		LegalEntity.click(); 
	    		 	        	 }*/
	    		 	        
	    		 	       break;
	    	 	        	
	    	 	        case "ELE":	
	    	 	        	waitToBeDisplayed(2);
	    	 	        				if(!currentObject.isEnabled()){
	    	 	       	 	        			System.out.println("Obj is not enabled");
	    	 	        					}
	    	 	        					currentObject.click();
	    	 	        	break;
	    	 	        case "CHK":
	    	 	        	if((value.toLowerCase().equals("on")&&!currentObject.isSelected())||((value.toLowerCase().equals("off")&&currentObject.isSelected()))){
	    	 	        		currentObject.click();
	 	        				waitToBeDisplayed(2);	
	    	 	        	}else{
	    	 	        		System.out.println("input for checkbox is "+ value +"not equals to on or off");
	    	 	        	}
	    	 	        		/*while(!LegalEntity.isSelected()){
	    	 	        				LegalEntity.click();
	    	 	        				waitToBeDisplayed(2);
	    							}*/
	    	 	        	
	    	 	        	break;
	    	 	       case "LNK":   
                           waitToBeDisplayed(5);
                           WebDriverWait wait1 = new WebDriverWait(driver, 100); 
                           wait1.until(ExpectedConditions.elementToBeClickable(currentObject));
                          try{
                                 currentObject.click();
                                                                   }
                          catch (Exception e){
                           currentObject.sendKeys(Keys.RETURN);
                           
                           }
                           report.updateTestLog("Required screenshot",currentKeyword, Status.SCREENSHOT);
                          
                           
                           break;

	    	 	      case "BTN":
                          waitToBeDisplayed(5);
                          WebDriverWait wait = new WebDriverWait(driver, 100); 
                           wait.until(ExpectedConditions.elementToBeClickable(currentObject));
                          
                           try{
                                 report.updateTestLog("Required screenshot", currentKeyword, Status.SCREENSHOT);
                                 currentObject.click();
                                                                   }
                          catch (Exception e){
                                 report.updateTestLog("Required screenshot",currentKeyword, Status.SCREENSHOT);
                           currentObject.sendKeys(Keys.RETURN);
                           
                           }
                           
                           
                           break;

	    	 	        case "CAL":	
	    	 	        	invokeFunction(arrobj_name[i].substring(4,arrobj_name[i].length()));
	    	 	        	
	    	 	        	break;
	    	 	       case "GRP":
	    	 	    	   String elementtype=type[1].toLowerCase();
	    	 	    	  switch(elementtype){
	    	 	    	  		case "checkbox":
	    	 	    	  			String[] checkboxgroup=null,individualcheckbox=null;
	    	 	    	  			checkboxgroup=value.split("\\~");
	    	 			 	        for(int chkgrp=0;chkgrp<checkboxgroup.length;chkgrp++){
	    	 			 	        	try{
	    	 			 	        		individualcheckbox=checkboxgroup[chkgrp].split("\\:");
	    	 			 	        		currentObject=driver.findElement(By.id(individualcheckbox[0]));
	    	 			 	        	Boolean LegalEntityStatus=currentObject.isSelected();
	    	 			 	        		if((individualcheckbox[1].toUpperCase().equals("ON") && !LegalEntityStatus )||(individualcheckbox[1].toUpperCase().equals("OFF") && LegalEntityStatus))
	    	 			 	  			{
	    	 			 	        			while(!currentObject.isSelected()){
	    		 		 	        				currentObject.click();
	    		 		 	        				waitToBeDisplayed(2);
	    		 								}
	    	 			 	  			}
	    	 			 	        		
	    	 			 	        	}
	    	 			 	        	catch(Exception chk){
	    	 			 	        		System.out.println(chk + " issue with checkbox" + checkboxgroup[chkgrp] +" is not available" );
	    	 			 	        	}
	    	 			 	        	waitToBeDisplayed(1);
	    	 			 	           }
	    	 	    	  			break;
	    	 	    	  			
	    	 	    	  		case "radiobutton":
	    	 	    	  			String[] radiogroup=null,individualradio=null;
	    	 			 	        radiogroup=value.split("\\~");
	    	 			 	        for(int radgrp=0;radgrp<radiogroup.length;radgrp++){
	    	 			 	        		
	    	 			 	        	individualradio=radiogroup[radgrp].split("\\:");
	    	 			 	        	individualradio[0]=individualradio[0].toLowerCase().trim();
	    	 			 	        	if(individualradio.length>1){
	    	 			 	        		
	    	 			 	        		individualradio[1]=individualradio[1].toLowerCase().trim();
	    	 			 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input[@type='radio']"
	    	 			 	        						+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
	    	 			 	        	}
	    	 			 	        	else
	    	 			 	        	{
	    	 			 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] +"')]/input[@type='radio']"));
	    	 				 	        }
	    	 			 	        	Boolean Entityselectedval=currentObject.isSelected();
	    	 			 	        	if(!Entityselectedval){
	    	 			 	        		
	    	 			 	        		currentObject.sendKeys(Keys.SPACE);
	    	 			 	        	}
	    	 			 	        	waitToBeDisplayed(1);
	    	 			 	        }
	    	 	    	  			break;
	    	 	    	  		case "editbox":
	    	 	    	  			String[] editboxgroup=null,individualeditbox=null;
	    	 	    	  			editboxgroup=value.split("\\~");
	    	 			 	        for(int edtgrp=0;edtgrp<editboxgroup.length;edtgrp++){
	    	 			 	        	individualeditbox=editboxgroup[edtgrp].split("\\:");
	    	 			 	        	try{
	    	 			 	        		currentObject=driver.findElement(By.id(individualeditbox[0]));
	    		 			 	        	for (int a = 0; a < individualeditbox[1].length(); a++){
	    		 				 	   	        char n = individualeditbox[1].charAt(a);
	    		 				 	   	        String S = new StringBuilder().append(n).toString();
	    		 				 	   	        currentObject.sendKeys(S);
	    		 				 	   	    }
	    		 				 	   			currentObject.sendKeys(Keys.TAB);
	    	 			 	        	}catch(Exception ed){
	    	 			 	        		System.out.println(ed + " issue in editbox " + individualeditbox[0] +" is not available" );
	    	 			 	        	}
	    	 			 	        	waitToBeDisplayed(1);
	    	 			 	           }
	    	 	    	  			break;
	    	 	    	  			
	    	 	    	  		case "listbox":
	    	 	    	  			String[] listboxgroup=null,individuallistbox=null;
	    	 	    	  			listboxgroup=value.split("\\~");
	    	 			 	        for(int lstgrp=0;lstgrp<listboxgroup.length;lstgrp++){
	    	 			 	        	individuallistbox=listboxgroup[lstgrp].split("\\:");
	    	 			 	        	try{
	    	 			 	        		currentObject=driver.findElement(By.id(individuallistbox[0]));
	    		 			 	        	 Select individualLST= new Select(currentObject);
	    		 			 	        	individualLST.selectByVisibleText(individuallistbox[1]);
	    	 			 	        	}catch(Exception lst){
	    	 			 	        		System.out.println(lst + " issue in listbox" + individuallistbox[0] +" is not available or "+individuallistbox[1]+" is not available" );
	    	 			 	        	}
	    	 			 	        	waitToBeDisplayed(1);
	    	 			 	        }
	    	 	    	  			break;
	    	 	    	  		}
	    	 	    	   
	    	 	        	break;
	    	 	        
	    	        	}
	        				
	        			}
	        		catch(Exception e)
		        		{
		        			
	 	        			System.out.println(value);
		        			System.out.println("reusable component "+e);
		        			report.updateTestLog("issue in reusable component", currentKeyword, Status.FAIL);
		        			//frameworkParameters.setStopExecution(true);
		        			//throw new FrameworkException("issue in reusable component", "Page Execution failed");
		        			
		        		}
	        			}
	        			else{
	        				dataVerification(value);
	        			}
	        		}
	        	}
	       
	        	else
	        	{
	        		throw new Exception(arrobj_name[i] +" page is not loaded");
	        	}
	                	
	        }
	       // System.out.println("Page_end_scenario"+DriverScript.Scenario_name);
		 	//System.out.println("Page_end_tc"+DriverScript.TestCase_name);
	       report.updateTestLog("successful", "successful", Status.PASS);
		
		 	
		
		}catch(Exception e)
		{
			
			GeneralComponents objGeneralComp = new GeneralComponents(scriptHelper);
			objGeneralComp.checkExectionMode();
			
			//System.out.println("reusable component "+e);
		//	report.updateTestLog("issue in reusable component", "Page execution failed", Status.FAIL);
			
			//frameworkParameters.setStopExecution(true);
			//throw new FrameworkException("issue in reusable component", "Page Execution failed");
			
		}
	}
	
	private WebElement GetwebElement(String Type,String Obj) {
		try{
		WebElement localWeb=null;
		if(Type.contains("id")){
			localWeb=driver.findElement(By.id(Obj));
		}else if(Type.contains("name")){
			localWeb=driver.findElement(By.name(Obj));
		}
		else if(Type.contains("xpath")){
			localWeb=driver.findElement(By.xpath(Obj));
			
		}
		return localWeb;
		} 
		catch (Exception e){
			System.out.println("issue in webelement  "+e);
			return null;
		}
	}
	
	public void dataVerification(String VerificationData) {
		try {
				//waitToBeDisplayed(3);
				ObjectRepository ORTable = new ObjectRepository(null);
				ORTable.getInputData();
        		String Switchval=VerificationData.substring(0,3);
        			WebElement VerifyLegalEntity=null;
        			String VerifyData[]=null,VerifyType="",Curr_verification_obj="";
        			if(!Switchval.contains("RDO")&&!Switchval.contains("CAL")&&!Switchval.contains("WAI")&&!Switchval.contains("SCR")){
        			 VerifyData=VerificationData.split(":");
        			 VerifyType="By."+ ORTable.getType(VerifyData[0]);
        			 Curr_verification_obj=ORTable.getElement(VerifyData[0]);
        			 VerifyLegalEntity=GetwebElement(VerifyType,Curr_verification_obj);
        			}
        			switch(Switchval){
        			case "LST":
    					Select Verifydropdown= new Select(VerifyLegalEntity);
   					 	String SelectedOption=Verifydropdown.getFirstSelectedOption().getText();
   					 	System.out.println("SelectedOption"+SelectedOption);
   						OutputData(VerifyData[0] ,SelectedOption); 
    					if(VerifyData.length>1){        					 
    						 if ((GeneralComponents.SelectQuery("E2E_Fields", "Name_Mapping", "ICON",VerifyData[1] ) != null ) && !(GeneralComponents.SelectQuery("E2E_Fields", "Name_Mapping", "ICON",VerifyData[1])).isEmpty()){
    						 	        							VerifyData[1] = GetData(VerifyData[0]);
    						 	        							} 

    					 if(SelectedOption.equalsIgnoreCase(VerifyData[1])){
    						 report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
    								 SelectedOption+" Passed", Status.DONE); 
    					 }else
    						 throw new Exception("Given selected value "+VerifyData[1]+" does not match with"+ SelectedOption +"==> list verification failed ");
    					}
    					else{
    						boolean ListObjectExistence=false;
	    	        		for(int sec=0;(sec<=60 && !ListObjectExistence);sec=sec+5){
	    	        			waitToBeDisplayed(5);
	    	        			ListObjectExistence=VerifyLegalEntity.isDisplayed();
	    	        		}
	    	        		if(!ListObjectExistence){
	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	        		}else{
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
	    	        		
SelectedOption+" Passed", Status.DONE);
	    	        		}
    					}
    					break;
    		         		         	
    	 	        case "EDI":
    	 	        	
    	 	        	String Screen_value=VerifyLegalEntity.getAttribute("value");
    	 	        	 OutputData(VerifyData[0] ,Screen_value);
    	 	        	if(VerifyData.length>1){
	    	        		
	    	        		if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getAttribute("value"))){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of Value "+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        	 OutputData(VerifyData[0] ,value); 

	    	        		}else if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getText())){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        		}else{
	    	        			throw new Exception(VerifyData[1] +" verification is failed due to the content mismatch");
	    	        		}	        	
	    	        	}
    	 	        	
	    	        	else{
	    	        		boolean EditobjectExistence=false;
	    	        		for(int sec=0;(sec<=60 && !EditobjectExistence);sec=sec+5){
	    	        			waitToBeDisplayed(5);
	    	        			EditobjectExistence=VerifyLegalEntity.isEnabled();
	    	        		}
	    	        		if(!EditobjectExistence){
	    	        			throw new Exception(VerifyData[0]+" "+value +" Object not loaded");
	    	        		}else{
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value"+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        		}
	    	        	}
	        		break;
	        		
    	 	       case "CAL":
   	 	        	
   	 	        	Screen_value=VerifyLegalEntity.getAttribute("value");
   	 	        	 OutputData(VerifyData[0] ,Screen_value);
   	 	        	if(VerifyData.length>1){
	    	        		
	    	        		if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getAttribute("value"))){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        	 OutputData(VerifyData[0] ,value); 

	    	        		}else if(VerifyData[1].equalsIgnoreCase(VerifyLegalEntity.getText())){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        		}else{
	    	        			throw new Exception(VerifyData[1] +" verification is failed due to the content mismatch");
	    	        		}	        	
	    	        	}
   	 	        	
	    	        	else{
	    	        		boolean EditobjectExistence=false;
	    	        		for(int sec=0;(sec<=60 && !EditobjectExistence);sec=sec+5){
	    	        			waitToBeDisplayed(5);
	    	        			EditobjectExistence=VerifyLegalEntity.isEnabled();
	    	        		}
	    	        		if(!EditobjectExistence){
	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	        		}else{
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
	    	        					Screen_value+" Passed", Status.DONE);
	    	        		}
	    	        	}
	        		break;
    	 	        	
    	 	        case "RDO":	
    	 	        		System.out.println("yet to be confirmed");
    	 	        	break;
    	 	        	
    	 	        case "ELE":	
    	 	        	waitToBeDisplayed(5);
    	 	        	Screen_value=VerifyLegalEntity.getAttribute("value");
    	 	        	Screen_value=VerifyLegalEntity.getText();
    	 	        	System.out.println(Screen_value);
    	 	        	OutputData(VerifyData[0] ,Screen_value);
    	 	        	boolean EleobjectExistence=false;
    	        		for(int sec=0;(sec<=60 && !EleobjectExistence);sec=sec+5){
    	        			waitToBeDisplayed(5);
    	        			EleobjectExistence=VerifyLegalEntity.isDisplayed();
    	        		}
    	        		if(!EleobjectExistence){
    	        			throw new Exception(VerifyData[0] +" Object not loaded");
    	        		}else{
    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of value "+
    	        					Screen_value+" Passed", Status.DONE);
    	        		}
    	 	        	break;
    	 	        	
    	 	        case "LNK":	
    	 	        	boolean lnkobjectExistence=false;
    	        		for(int sec=0;(sec<=60 && !lnkobjectExistence);sec=sec+5){
    	        			waitToBeDisplayed(5);
    	        			lnkobjectExistence=VerifyLegalEntity.isDisplayed();
    	        		}
    	        		if(!lnkobjectExistence){
    	        			throw new Exception(VerifyData[0] +" Object not loaded");
    	        		}else{
    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
    		    	        		VerifyData[0]+" Passed", Status.DONE);
    	        		}
    	 	        	
    	 	        	break;
    	 	       case "BTN":	
    	 	    	  boolean BTNobjectExistence=false;
    	 	    	  for(int sec=0;(sec<=60 && !BTNobjectExistence);sec=sec+5){
    	 	    		  waitToBeDisplayed(5);
    	 	    		 //BTNobjectExistence=VerifyLegalEntity.isDisplayed();
    	 	    		 BTNobjectExistence=VerifyLegalEntity.isEnabled();
    	 	    	  }
    	 	    	  if(!BTNobjectExistence){
    	 	    		  throw new Exception(VerifyData[0] +" Object not loaded");
    	 	    	  }else{
    	 	    		  report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
    		    	        		VerifyData[0]+" Passed", Status.DONE);
    	 	    	  }
    	 	        	
    	 	        	break;
    	 	       case "WAI":	
    	 	    	   		VerifyData=VerificationData.split(":");
    	 	    	   		int waittime= Integer.parseInt(VerifyData[1]);
    	 	    	   		waitToBeDisplayed(waittime);
    	 	        	
    	 	        	break;
    	 	       
        			}
        	
      } catch (Exception DV) {
			System.out.println("verification"+DV);
		}
	}
	public static void waitToBeDisplayed(int sec) {
		try {
			int requiredtime=sec*1000;
			Thread.sleep(requiredtime);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void requestedData(String requestedField) {
		try {
			System.out.println("Under Construction");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	
	private void invokeFunction(String Functionname)
			throws IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException {
		Boolean isMethodFound = false;
		final String CLASS_FILE_EXTENSION = ".class";
		File[] packageDirectories = {
				new File(frameworkParameters.getRelativePath()
						+ Util.getFileSeparator() + "businesscomponents")};

		for (File packageDirectory : packageDirectories) {
			File[] packageFiles = packageDirectory.listFiles();
			String packageName = packageDirectory.getName();

			for (int i = 0; i < packageFiles.length; i++) {
				File packageFile = packageFiles[i];
				String fileName = packageFile.getName();

				// We only want the .class files
				if (fileName.endsWith(CLASS_FILE_EXTENSION)) {
					// Remove the .class extension to get the class name
					String className = fileName.substring(0, fileName.length()
							- CLASS_FILE_EXTENSION.length());

					Class<?> reusableMethods = Class.forName(packageName+ "." + className);
					Method executeMethod;
					try {
						// Convert the first letter of the method to lowercase
						// (in line with java naming conventions)
						Functionname = Functionname.substring(0, 1)
								.toLowerCase() + Functionname.substring(1);
						executeMethod = reusableMethods.getMethod(
								Functionname, (Class<?>[]) null);
					} catch (NoSuchMethodException ex) {
						// If the method is not found in this class, search the
						// next class
						continue;
					}

					isMethodFound = true;

					Constructor<?> ctor = reusableMethods
							.getDeclaredConstructors()[0];
					Object businessComponent = ctor.newInstance(scriptHelper);

					executeMethod.invoke(businessComponent, (Object[]) null);
					
					break;
				}
			} 
		}

		if (!isMethodFound) {
			throw new FrameworkException("Keyword " + Functionname
					+ " not found within any class "
					+ "inside the businesscomponents package");
		}
	}

	

	public void OutputData(String FieldName,String Fieldvalue ){	
		//E2E_DB_Update db = new E2E_DB_Update();
		
		String TCName = currentTC;
		String E2ETCName = "";
		String E2EFieldName = "";	
		//int VersionNumber = 0;
		try {
			
			//E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_PC_INIT_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
			E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
		
			//GeneralComponents.SelectQuery("E2E_Scenario", "E2E_ScenarioFlow", "Test_Script_Name", TCName);
			//E2EFieldName = E2E_DB_Update.Select_E2EFieldName("COMMON_FIELD_NM", "APP_FIELD_MAPPING", "APP_FIELD_NM", FieldName, "APP_NM", "ICON");
			E2EFieldName = E2E_DB_Update.Select_E2EFieldName("FIELD_NM", "FIELD_NAME_MASTER", "FIELD_ID", "MASTER_FIELD_ID", "APP_FIELD_NAME_MAPPING", "APP_FIELD_NM",FieldName,"APP_NM","ICON");
					//GeneralComponents.SelectQuery("E2E_Fields", "Name_Mapping", "ICON", FieldName);
			//VersionNumber = GeneralComponents.getversionumber("E2E_Testdata", "E2E_Scenario_Name", TSName, "Field_Name", E2EFeildName);			
			/*if (VersionNumber == 0) {				
				VersionNumber = 1;
				}else{
				VersionNumber = VersionNumber+1;
				}	*/			
			E2E_DB_Update.updatequery(E2ETCName, E2EFieldName, Fieldvalue);	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
    public String GetData(String FieldName){  
        String TCName = currentTC; 
        String Fieldvalue = "";
        String E2ETCName = "";
        String E2EFieldName = "";            
        int VersionNumber = 0;
        try {
                   E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
                   E2EFieldName = E2E_DB_Update.Select_E2EFieldName("FIELD_NM", "FIELD_NAME_MASTER", "FIELD_ID", "MASTER_FIELD_ID", "APP_FIELD_NAME_MAPPING", "APP_FIELD_NM",FieldName,"APP_NM","ICON");
                   VersionNumber = E2E_DB_Update.getversionumber(E2ETCName, E2EFieldName);
                   Fieldvalue = E2E_DB_Update.getValue(E2ETCName, E2EFieldName, VersionNumber);
        } catch (SQLException e) {
                        e.printStackTrace();
        }
        return Fieldvalue;                                                                           
      }
	
}