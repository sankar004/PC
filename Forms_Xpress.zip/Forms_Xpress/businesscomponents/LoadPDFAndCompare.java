package businesscomponents;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;

import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;


public class LoadPDFAndCompare extends ReusableLibrary{

	static PDDocument actualDocument;
	static String outPutForm = "c:\\PDFValidationDocuments\\OutPutPDF\\";
	static int count = 0;
		/*public LoadPDFAndCompare() {
		// TODO Auto-generated constructor stub
	}
		*/public LoadPDFAndCompare(ScriptHelper scriptHelper) {
			super(scriptHelper);
		}
	public  void LoadPDFAndComparePDF(String actualForm, String mockUpForm, String formNumber,String formTitle, String type,String narration,String ExcelResultFile, String testcaseName,String section[], String compare_type,int intPgnum,String policy_number, String CurrentTC) throws IOException {
		try {
			//System.out.println("hiiii  try");
		List<PDPage> list = loadactualPDF(actualForm);
		
		if(type.equals("NonStacked")){
			System.out.println("HI NONSTACKED");
			if(formTitle=="NotRequired")
			{
				//outPutForm = NonStackedLineByLineOutputPDF.getStartEndPageandCreateNewOutPutPDFNonStacked(actualDocument,outPutForm,list,formNumber);
				//NonStackedLineByLineOutputPDF.CompareContents(actualForm, mockUpForm, formNumber,section,compare_type);
			}	
			//else{
				//outPutForm =StackedLineByLineOutputPDF.getStartEndPageandCreateNewOutPutPDFStacked(actualDocument,outPutForm,list,formNumber,formTitle);
			//compareOutputandMock(mockUpForm,formNumber,ExcelResultFile,pdfResultFile);
		//	}
		}
		else if(type.equals("Simple"))
		{
			//System.out.println("hiii simple");
			//Simple.CompareContents(actualForm, mockUpForm, formNumber,ExcelResultFile,narration,formTitle,compare_type,testcaseName,intPgnum,policy_number);	
			Simple pdfobj = new Simple(scriptHelper);
			pdfobj.CompareContents(actualForm, mockUpForm, formNumber,ExcelResultFile,narration,formTitle,compare_type,testcaseName,intPgnum,policy_number, CurrentTC);	
		}
		
		else if(type.equals("IDCard"))
		{
			System.out.println("hii iddd");
		if(formNumber.matches("Form CAF-4388-0") || formNumber.matches("Form CAF-4255-0") || formNumber.matches("Form CAF-4496-0")
			||formNumber.matches("Form CAF-4267-2") || formNumber.matches("Form CAF-4261-0")|| formNumber.matches("Form CAF-4253-2")||formNumber.matches("Form CAF-4493-0")
			|| formNumber.matches("Form CAF-4259-0") || formNumber.matches("Form CAF-4317-1")||formNumber.matches("Form CAF-4235-0")||formNumber.matches("Form CAF-4257-0")
			||formNumber.matches("Form CAF-4205-3")||formNumber.matches("Form CAF-4258-0")||formNumber.matches("WLTR007")||formNumber.matches("Form CAF-4315-1")||formNumber.matches("ACORD 27"))
			
			{
			System.out.println("HELLOOOOOOO");
			//IDCard.CompareContents(actualForm, mockUpForm, formNumber,ExcelResultFile,narration,formTitle,compare_type,testcaseName);
			}
		}
		
		else if(type.equals("Dynamic")){
			String formNumber_Dec;
			String formNumber_Sequence_OSP_CPT;
			String formNumber_Sequence="NotRequired";
			//DynamicContent.DynamicContentPDF(actualDocument,list,formNumber,formTitle,actualForm,mockUpForm,ExcelResultFile,testcaseName);
			
		}
		else if(type.equals("Spl_Dynamic")){
			//DynamicContent.Spl_DynamicContentPDF(actualDocument,list,formNumber,formTitle,actualForm,mockUpForm,ExcelResultFile,testcaseName,compare_type);
			}
		else if(type.equals("Narrative")){
			//String result[] = NarrationSearch.searchForForm(actualDocument,formNumber,narration);
			//ExcelForNarration.createOpenExcelForNarrative(actualForm,formNumber,result,ExcelResultFile);
		}
		else if(type.equals("NonStacked_Columnar")){
			//NonStackedColumnar.ExtractContents(actualForm, mockUpForm, formNumber,section,compare_type);
			
		}
		else if(type.equals("NonStacked_Sequence")){
			//NonStackedSequence.GetSequence(actualForm, mockUpForm, formNumber,section,compare_type);
		}
		/*else if(type.equals("NonStacked_Static_Dynamic")){
			Compare_Static_Dyanamicdata.pdfcomp(mockUpForm,actualForm,compare_type,formNumber);
		}
		else if(type.equals("NonStacked_Static_Dynamic_Columnar")){
			NonStacked_Static_Dynamic_Columnar.pdfcolumn(mockUpForm,actualForm,compare_type,formNumber);
		}
		else if(type.equals("Static_Columnar"))
		{
			NonStacked_Static_Dynamic_Columnar.pdfcolumnstat(mockUpForm,actualForm,compare_type,formNumber);	
		}
		else{
			System.out.println("Type Mismatch");
		}*/
	
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 catch (COSVisitorException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		finally{
			if(actualDocument!=null)
				actualDocument.close();
		}
	}	
	 
	private static void compareOutputandMock(String mockUpForm, String formNumber, String excelResultFile,String pdfResultFile) throws COSVisitorException {
		
		try {
			PDDocument mockdocument =PDDocument.load(mockUpForm);
			PDFTextStripper mocktextStripper=new PDFTextStripper();
			List<PDPage> mocklistOfPages = mockdocument.getDocumentCatalog().getAllPages();
			String mockPages = null;
			
			
			PDDocument outputdocument = PDDocument.load(outPutForm);
			PDFTextStripper outputtextStripper=new PDFTextStripper();
			List<PDPage> outputlistOfPages = outputdocument.getDocumentCatalog().getAllPages();
			String outputPages = null;
						
				mocktextStripper.setStartPage(1); 
				mocktextStripper.setEndPage(mocklistOfPages.size());
				mockPages = mocktextStripper.getText(mockdocument);	
			
				outputtextStripper.setStartPage(1); 
				outputtextStripper.setEndPage(mocklistOfPages.size());
				outputPages = outputtextStripper.getText(outputdocument);
			
				CompareLineByLineMockAndOutPut(mockPages,outputPages,formNumber,excelResultFile,pdfResultFile);
				deleteOutputPDF(outPutForm);
				
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

		
	private static void deleteOutputPDF(String outPutForm2) {
		File filedelete = new File(outPutForm2);		 
		filedelete.delete();

		
	}
	private static void CompareLineByLineMockAndOutPut(String mockPages,
			String outputPages, String formNumber, String excelResultFile,String pdfResultFile) throws IOException, COSVisitorException {
		String[] mocklLineSplit = null;
		String[] outputlLineSplit = null ;
		
		mocklLineSplit = mockPages.split("\r\n");
		outputlLineSplit = outputPages.split("\r\n");
		
		boolean mockLinehighest = mocklLineSplit.length > outputlLineSplit.length;
		int linelowest;
		int wordlowest;
		String Result[] = new String[4];
		
		
		if(mockLinehighest)
			linelowest = outputlLineSplit.length;
		else 
			
			linelowest = mocklLineSplit.length;
		
		for(int i=0,j=0; i< linelowest || j< linelowest ;i++,j++){
			
						
			if(mocklLineSplit[i].trim().equals(outputlLineSplit[j].trim()))
			{
				Result[0] = "Pass";
				Result[1] = mocklLineSplit[i];
				Result[2] = outputlLineSplit[j];
				Result[3]= "No Error";
			}
			else{
				
				String[] mockWordsinLine = mocklLineSplit[i].split(" ");
				System.out.println("---------------------------------------");
				System.out.println("Line "+ i+ " "+mocklLineSplit[i]);
				String[] outPutWordinLine = outputlLineSplit[i].split(" ");
				System.out.println(outputlLineSplit[i]);
				boolean mockword = mockWordsinLine.length > outPutWordinLine.length;
				if(mockword)
					wordlowest = outPutWordinLine.length;
				else 
					wordlowest = mockWordsinLine.length;
				int l;	
				for(l=0;l<wordlowest;l++){
					
					if(mockWordsinLine[l].equals(outPutWordinLine[l]))
					{
						Result[0] = "Pass";
					}
					else{
						Result[0] = "Fail";
						Result[1] = mocklLineSplit[i];
						Result[2] = outputlLineSplit[j];
						if(outPutWordinLine[l].equals("")){
							outPutWordinLine[l] = "<space>";
						}
						if(l>0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l] +" " + outPutWordinLine[l+1];
						else if(l>0 & l==(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l];
						else if(l==0 & (outPutWordinLine[l].length()==1))
							Result[3] = outPutWordinLine[l];
						else if(l==0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l];
						else
							Result[3] = outPutWordinLine[l];
						
						break;
					}
				}
				if(l==wordlowest){
					Result[0] = "Fail";
					Result[1] = mocklLineSplit[i];
					Result[2] = outputlLineSplit[j];
					if(mockword)
						Result[3]= mocklLineSplit[i].substring(outPutWordinLine.length, mockWordsinLine.length);
					else
						Result[3]= outputlLineSplit[i].substring(mockWordsinLine.length, outPutWordinLine.length);
				}
				
			}
//			int h=1;
//			if(i==(linelowest-1)){
//				h= 2;
//			}
			if(Result[0]=="Fail"){				
				count++;
			}
			else{
				count=0;
			}
			if(count>20){
				System.out.println("---------------To Do------------------");
			//	Result = CompareWordByWordIfLineFails.compareWordByWord(mockPages,outputPages);
				formNumber = formNumber+" WordByWord";
				i=0;
				PDFResult.createUpdatePDF(Result,i,formNumber,pdfResultFile);
				ExcelResult.createExcel(Result,i,formNumber,excelResultFile);
				break;
			}
			else{
			PDFResult.createUpdatePDF(Result,i,formNumber,pdfResultFile);
			ExcelResult.createExcel(Result,i,formNumber,excelResultFile);
			}
		}		
		count =0;
	}

	
	private static List<PDPage> loadactualPDF(String actualForm) throws IOException {
		
		
			PDDocument actualDocumen = new PDDocument();
			actualDocumen = PDDocument.load(actualForm);
			actualDocument = actualDocumen;
			//PDDocument newdocument = new PDDocument();
			List<PDPage> list = actualDocument.getDocumentCatalog().getAllPages();			
			return list;
		
		
	}
	public static String GenratrateCurrentDate() {
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String dateTime = dateFormat.format(date);
		dateTime= dateTime.replace("/", "");
		dateTime= dateTime.replace(":", "");
		return dateTime;
	}
		
	}


