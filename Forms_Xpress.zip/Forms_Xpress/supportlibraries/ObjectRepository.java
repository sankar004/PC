package supportlibraries;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.Util;
import com.cognizant.framework.selenium.SeleniumTestParameters;

//import allocator.ParallelRunner;


public class ObjectRepository {
	
	static HSSFWorkbook inputworkbook = null;
    static HSSFSheet inputworksheet = null;    
    static FileInputStream inputfileIn = null;
    static HashMap <String, Object[]> ORTables = new HashMap <String, Object[]>();
    private final FrameworkParameters frameworkParameters = FrameworkParameters.getInstance();
    @SuppressWarnings("unused")
	private final SeleniumTestParameters testParameters;
    /**
	 * DriverScript constructor
	 * 
	 * @param testParameters
	 *            A {@link SeleniumTestParameters} object
	 */
	
	public ObjectRepository(SeleniumTestParameters testParameters) {
		this.testParameters = testParameters;
		//getInputData();
		
	}

	//static String inputFile=properties.getProperty("ORTablePath");	
	
   
	public void getInputData() {
		
		File inputfiles = new File(frameworkParameters.getRelativePath()
				+ Util.getFileSeparator() + "ObjectRepository\\ObjectRepository.xls");
		
		
		try {
			inputfileIn = new FileInputStream(inputfiles);		
			inputworkbook = new HSSFWorkbook(inputfileIn);
			
			
				inputworksheet = inputworkbook.getSheetAt(0); 
							
			Iterator<Row> rowIterator = inputworksheet.iterator();
			
			while(rowIterator.hasNext()){
				
		        Row row1 = rowIterator.next();
		        String ORName="";
		        String ORtype="";
		        String ORelement="";
		        
		        Cell cell1 = row1.getCell(0);
		        if(cell1!=null){
		        			ORName = cell1.getStringCellValue().trim();
		       	        }
		        Cell cell2 = row1.getCell(1);
		        if(cell2!=null){
		        	ORtype = cell2.getStringCellValue().trim();
		       	  }
		        
		        Cell cell3 = row1.getCell(2);
		        if(cell3!=null){
		        	cell3.setCellType(Cell.CELL_TYPE_STRING);
			       ORelement = cell3.getStringCellValue().trim();
		       	      }		        		  
		        if(ORName!=""){
		        	//System.out.println(ORName);
		        	ORTables.put(ORName, new Object[]{ORtype,ORelement});
		        }
		      
		        
			}
		} catch (IOException e) {
			System.out.println(e);
		} catch(Exception e){
			System.out.println(e);
		}
	}
	public String getType(String ORName) {
		
		Object[] value = ORTables.get(ORName);
		String type= (String) value[0];
		return type;
	}

	public int getElement(int ORName) {
		Object[] value = ORTables.get(ORName);
		int element= (int) value[1];		
		return element;
	}
	public String getElement(String ORName) {
		Object[] value = ORTables.get(ORName);
		String element= (String) value[1];		
		return element;
	}
	
}
