package allocator;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.openqa.selenium.Platform;

import businesscomponents.E2E_DB_Update;

import com.cognizant.framework.selenium.*;
import com.cognizant.framework.ExcelDataAccessforxlsm;
import com.cognizant.framework.FrameworkParameters;
import com.cognizant.framework.IterationOptions;
import com.cognizant.framework.Settings;

/**
 * Class to manage the batch execution of test scripts within the framework
 * 
 * @author Cognizant
 */
public class Allocator {
	private FrameworkParameters frameworkParameters = FrameworkParameters
			.getInstance();
	private Properties properties;
	private Properties mobileProperties;
	private ResultSummaryManager resultSummaryManager = ResultSummaryManager
			.getInstance();
	
	
	public final String currentScenario=null;
	public final String currentTestcase=null;
	private static Socket socket = null;
	private static DataInputStream serverStreamIn = null;
	private static String testCaseName = null;
	private static ConcurrentLinkedQueue<String> testCaseNames = new ConcurrentLinkedQueue<String>();
	private static boolean Shutdown = false; 

	/**
	 * The entry point of the test batch execution <br>
	 * Exits with a value of 0 if the test passes and 1 if the test fails
	 * 
	 * @param args
	 *            Command line arguments to the Allocator (Not applicable)
	 */
	public static void main(String[] args) {
		Allocator allocator = new Allocator();
		allocator.driveBatchExecution();
	}

	private void driveBatchExecution() {
		resultSummaryManager.setRelativePath();
		properties = Settings.getInstance();
		mobileProperties = Settings.getMobilePropertiesInstance();
		String runConfiguration;
		if (System.getProperty("RunConfiguration") != null) {
			runConfiguration = System.getProperty("RunConfiguration");
		} else {
			runConfiguration = properties.getProperty("RunConfiguration");
		}
		resultSummaryManager.initializeTestBatch(runConfiguration);

		int nThreads = Integer.parseInt(properties
				.getProperty("NumberOfThreads"));
		resultSummaryManager.initializeSummaryReport(nThreads);

		resultSummaryManager.setupErrorLog();

		String E2EExecutionMode =properties.getProperty("E2EExecutionMode");
		    int testBatchStatus;
		    if(E2EExecutionMode.equals("E2E")){
	                RecevieE2ETests.start();                                               
	                testBatchStatus = executeTestBatchE2E(nThreads);
	                	try {
	                                RecevieE2ETests.join();
	                	}catch (InterruptedException e) {
	                               // TODO Auto-generated catch block
	                            e.printStackTrace();
	                     }
	            }
	    	else{
                	testBatchStatus = executeTestBatch(nThreads);                                               
	            } 
	    resultSummaryManager.wrapUp(false);
		resultSummaryManager.launchResultSummary();

		System.exit(testBatchStatus);
	}
	/***** When working with SeeTest/Perfecto Parellel  *****/
	/*private int executeTestBatch(int nThreads) {
        List<SeleniumTestParameters> testInstancesToRun = getRunInfo(frameworkParameters
                     .getRunConfiguration());
        ExecutorService parallelExecutor = Executors
                     .newFixedThreadPool(nThreads);
        ParallelRunner testRunner = null;
        int i=0;
  while(i<testInstancesToRun.size())
  {
         System.out.println("I:"+i);
         int size=i+nThreads;
         //System.out.println("First For");
         for(int currentTestInstance=size-nThreads;currentTestInstance<size;currentTestInstance++)
         {
        testRunner = new ParallelRunner(
                     testInstancesToRun.get(currentTestInstance));
          parallelExecutor.execute(testRunner);
         
         if(frameworkParameters.getStopExecution()) {
               break;
         }
         }

  parallelExecutor.shutdown();
  while(!parallelExecutor.isTerminated()) {
               try {
                     Thread.sleep(3000);
               } catch (InterruptedException e) {
                     e.printStackTrace();
               }
        } 
  System.out.println("Waitng for thread to stop");
  i=size;
  }
  if (testRunner == null) {
               return 0; // All tests flagged as "No" in the Run Manager
        } else {
               return testRunner.getTestBatchStatus();
        }
 }*/

	
	private int executeTestBatch(int nThreads) {
		List<SeleniumTestParameters> testInstancesToRun = getRunInfo(frameworkParameters
				.getRunConfiguration());
		ExecutorService parallelExecutor = Executors
				.newFixedThreadPool(nThreads);
		ParallelRunner testRunner = null;

		for (int currentTestInstance = 0; currentTestInstance < testInstancesToRun
				.size(); currentTestInstance++) {
			testRunner = new ParallelRunner(
					testInstancesToRun.get(currentTestInstance));
			parallelExecutor.execute(testRunner);

			if (frameworkParameters.getStopExecution()) {
				break;
			}
		}

		parallelExecutor.shutdown();
		while (!parallelExecutor.isTerminated()) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (testRunner == null) {
			return 0; // All tests flagged as "No" in the Run Manager
		} else {
			return testRunner.getTestBatchStatus();
		}
	}
	private int executeTestBatchE2E(int nThreads) {
		ExecutorService parallelExecutor = Executors
				.newFixedThreadPool(nThreads);
		ParallelRunner testRunner = null;            

        while(!testCaseNames.isEmpty() || Shutdown == false){ 
                                        
        	if(!(testCaseNames.size() == 0)){      		
        	
		List<SeleniumTestParameters> testInstancesToRun = getRunInfoE2E(frameworkParameters
				.getRunConfiguration());
		

		for (int currentTestInstance = 0; currentTestInstance < testInstancesToRun
				.size(); currentTestInstance++) {
			testRunner = new ParallelRunner(
					testInstancesToRun.get(currentTestInstance));
			parallelExecutor.execute(testRunner);

			if (frameworkParameters.getStopExecution()) {
				break;
			}
			}
        	}
        }

		parallelExecutor.shutdown();
		while (!parallelExecutor.isTerminated()) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (testRunner == null) {
			return 0; // All tests flagged as "No" in the Run Manager
		} else {
			return testRunner.getTestBatchStatus();
		}
	}




	private List<SeleniumTestParameters> getRunInfo(String sheetName) {
		ExcelDataAccessforxlsm runManagerAccess = new ExcelDataAccessforxlsm(
				frameworkParameters.getRelativePath(), "Run Manager");
		runManagerAccess.setDatasheetName(sheetName);

		int nTestInstances = runManagerAccess.getLastRowNum();
		List<SeleniumTestParameters> testInstancesToRun = new ArrayList<SeleniumTestParameters>();

		for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
			String executeFlag = runManagerAccess.getValue(currentTestInstance,
					"Execute");

			if ("Yes".equalsIgnoreCase(executeFlag)) {
				String currentScenario = runManagerAccess.getValue(
						currentTestInstance, "TestScenario");
				String currentTestcase = runManagerAccess.getValue(
						currentTestInstance, "TestCase");
				SeleniumTestParameters testParameters = new SeleniumTestParameters(
						currentScenario, currentTestcase);

				testParameters.setCurrentTestInstance("Instance"
						+ runManagerAccess.getValue(currentTestInstance,
								"TestInstance"));
				testParameters.setCurrentTestDescription(runManagerAccess
						.getValue(currentTestInstance, "Description"));

				String iterationMode = runManagerAccess.getValue(
						currentTestInstance, "IterationMode");
				if (!"".equals(iterationMode)) {
					testParameters.setIterationMode(IterationOptions
							.valueOf(iterationMode));
				} else {
					testParameters
							.setIterationMode(IterationOptions.RUN_ALL_ITERATIONS);
				}

				String startIteration = runManagerAccess.getValue(
						currentTestInstance, "StartIteration");
				if (!"".equals(startIteration)) {
					testParameters.setStartIteration(Integer
							.parseInt(startIteration));
				}
				String endIteration = runManagerAccess.getValue(
						currentTestInstance, "EndIteration");
				if (!"".equals(endIteration)) {
					testParameters.setEndIteration(Integer
							.parseInt(endIteration));
				}

				String executionMode = runManagerAccess.getValue(
						currentTestInstance, "ExecutionMode");
				if (!"".equals(executionMode)) {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(executionMode));
				} else {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(properties
									.getProperty("DefaultExecutionMode")));
				}

				String toolName = runManagerAccess.getValue(
						currentTestInstance, "MobileToolName");
				if (!"".equals(toolName)) {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(toolName));
				} else {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(mobileProperties
									.getProperty("DefaultMobileToolName")));
				}

				String executionPlatform = runManagerAccess.getValue(
						currentTestInstance, "MobileExecutionPlatform");
				if (!"".equals(executionPlatform)) {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform
									.valueOf(executionPlatform));
				} else {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform.valueOf(mobileProperties
									.getProperty("DefaultMobileExecutionPlatform")));
				}

				String mobileOSVersion = runManagerAccess.getValue(
						currentTestInstance, "MobileOSVersion");
				if (!"".equals(mobileOSVersion)) {
					testParameters.setmobileOSVersion(mobileOSVersion);
				}

				String deviceName = runManagerAccess.getValue(
						currentTestInstance, "DeviceName");
				if (!"".equals(deviceName)) {
					testParameters.setDeviceName(deviceName);
				} else {
					testParameters.setDeviceName(mobileProperties
							.getProperty("DefaultDevice"));
				}

				String browser = runManagerAccess.getValue(currentTestInstance,
						"Browser");
				if (!"".equals(browser)) {
					testParameters.setBrowser(Browser.valueOf(browser));
				} else {
					testParameters.setBrowser(Browser.valueOf(properties
							.getProperty("DefaultBrowser")));
				}
				String browserVersion = runManagerAccess.getValue(
						currentTestInstance, "BrowserVersion");
				if (!"".equals(browserVersion)) {
					testParameters.setBrowserVersion(browserVersion);
				}
				String platform = runManagerAccess.getValue(
						currentTestInstance, "Platform");
				if (!"".equals(platform)) {
					testParameters.setPlatform(Platform.valueOf(platform));
				} else {
					testParameters.setPlatform(Platform.valueOf(properties
							.getProperty("DefaultPlatform")));
				}
				String seeTestPort = runManagerAccess.getValue(
                        currentTestInstance, "SeeTestPort");
				if (!"".equals(seeTestPort)) {
					testParameters.setSeeTestPort(seeTestPort);
				} else {
					testParameters.setSeeTestPort(properties
                                        .getProperty("SeeTestDefaultPort"));
				}
				testInstancesToRun.add(testParameters);
			}
		}

		return testInstancesToRun;
	}
	
	
	private List<SeleniumTestParameters> getRunInfoE2E(String sheetName) {
		ExcelDataAccessforxlsm runManagerAccess = new ExcelDataAccessforxlsm(
				frameworkParameters.getRelativePath(), "Run Manager");
		runManagerAccess.setDatasheetName(sheetName);

		int nTestInstances = runManagerAccess.getLastRowNum();
		List<SeleniumTestParameters> testInstancesToRun = new ArrayList<SeleniumTestParameters>();
		  for (int currentTestCaseno = 0; currentTestCaseno < testCaseNames.size() ; currentTestCaseno++){
              String CurrentTC = testCaseNames.remove(); 
		for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
			/*String executeFlag = runManagerAccess.getValue(currentTestInstance,
					"Execute");*/
			String currentTestcase = runManagerAccess.getValue(
					currentTestInstance, "TestCase");

			//if ("Yes".equalsIgnoreCase(executeFlag)) {
			if (currentTestcase.equalsIgnoreCase(CurrentTC)) { 
				String currentScenario = runManagerAccess.getValue(
						currentTestInstance, "TestScenario");
				 currentTestcase = runManagerAccess.getValue(
						currentTestInstance, "TestCase");
				SeleniumTestParameters testParameters = new SeleniumTestParameters(
						currentScenario, currentTestcase);

				testParameters.setCurrentTestInstance("Instance"
						+ runManagerAccess.getValue(currentTestInstance,
								"TestInstance"));
				testParameters.setCurrentTestDescription(runManagerAccess
						.getValue(currentTestInstance, "Description"));

				String iterationMode = runManagerAccess.getValue(
						currentTestInstance, "IterationMode");
				if (!"".equals(iterationMode)) {
					testParameters.setIterationMode(IterationOptions
							.valueOf(iterationMode));
				} else {
					testParameters
							.setIterationMode(IterationOptions.RUN_ALL_ITERATIONS);
				}

				String startIteration = runManagerAccess.getValue(
						currentTestInstance, "StartIteration");
				if (!"".equals(startIteration)) {
					testParameters.setStartIteration(Integer
							.parseInt(startIteration));
				}
				String endIteration = runManagerAccess.getValue(
						currentTestInstance, "EndIteration");
				if (!"".equals(endIteration)) {
					testParameters.setEndIteration(Integer
							.parseInt(endIteration));
				}

				String executionMode = runManagerAccess.getValue(
						currentTestInstance, "ExecutionMode");
				if (!"".equals(executionMode)) {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(executionMode));
				} else {
					testParameters.setExecutionMode(ExecutionMode
							.valueOf(properties
									.getProperty("DefaultExecutionMode")));
				}

				String toolName = runManagerAccess.getValue(
						currentTestInstance, "MobileToolName");
				if (!"".equals(toolName)) {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(toolName));
				} else {
					testParameters.setMobileToolName(MobileToolName
							.valueOf(mobileProperties
									.getProperty("DefaultMobileToolName")));
				}

				String executionPlatform = runManagerAccess.getValue(
						currentTestInstance, "MobileExecutionPlatform");
				if (!"".equals(executionPlatform)) {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform
									.valueOf(executionPlatform));
				} else {
					testParameters
							.setMobileExecutionPlatform(MobileExecutionPlatform.valueOf(mobileProperties
									.getProperty("DefaultMobileExecutionPlatform")));
				}

				String mobileOSVersion = runManagerAccess.getValue(
						currentTestInstance, "MobileOSVersion");
				if (!"".equals(mobileOSVersion)) {
					testParameters.setmobileOSVersion(mobileOSVersion);
				}

				String deviceName = runManagerAccess.getValue(
						currentTestInstance, "DeviceName");
				if (!"".equals(deviceName)) {
					testParameters.setDeviceName(deviceName);
				} else {
					testParameters.setDeviceName(mobileProperties
							.getProperty("DefaultDevice"));
				}

				String browser = runManagerAccess.getValue(currentTestInstance,
						"Browser");
				if (!"".equals(browser)) {
					testParameters.setBrowser(Browser.valueOf(browser));
				} else {
					testParameters.setBrowser(Browser.valueOf(properties
							.getProperty("DefaultBrowser")));
				}
				String browserVersion = runManagerAccess.getValue(
						currentTestInstance, "BrowserVersion");
				if (!"".equals(browserVersion)) {
					testParameters.setBrowserVersion(browserVersion);
				}
				String platform = runManagerAccess.getValue(
						currentTestInstance, "Platform");
				if (!"".equals(platform)) {
					testParameters.setPlatform(Platform.valueOf(platform));
				} else {
					testParameters.setPlatform(Platform.valueOf(properties
							.getProperty("DefaultPlatform")));
				}
				String seeTestPort = runManagerAccess.getValue(
                        currentTestInstance, "SeeTestPort");
				if (!"".equals(seeTestPort)) {
					testParameters.setSeeTestPort(seeTestPort);
				} else {
					testParameters.setSeeTestPort(properties
                                        .getProperty("SeeTestDefaultPort"));
				}
				testInstancesToRun.add(testParameters);
			}
			}
		  }

		return testInstancesToRun;
	}
		
	Thread RecevieE2ETests = new Thread(){
		public void run(){  
	        try {
	            Thread.sleep(15000);
	    socket = new Socket("10.219.71.247", 8001);
	           // socket = new Socket("10.219.65.61", 8001);
	    DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
	    outputStream.writeUTF("Selenium_ICON");
	    serverStreamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
	    while (testCaseName == null || (testCaseName != null && !testCaseName.equalsIgnoreCase("shutdown"))) {
	    testCaseName = null;
	    testCaseName = serverStreamIn.readUTF();// reading from socket
	    System.out.println("Message Received From Server =" + testCaseName);
	        if (testCaseName != null && !testCaseName.equalsIgnoreCase("shutdown")) {
	                        
                //String DBTC = dataInputStream.readUTF();// reading from socket
                //System.out.println(DBTC);
                String Array[] = testCaseName.split("\\|");
                testCaseName = Array[0] ;
                System.out.println("Message Received From Server =" + testCaseName);
                testCaseNames.add(testCaseName);
                udaptemachinename(testCaseName);
                
                //testCaseNames.add(testCaseName);
                System.out.println("Added TestCase Into concurrent linked queue. TestCaseName Received from Server ="
                                                + testCaseName);                                                                                            
                                                                                
	        }
	                System.out.println("Waiting for Server to send TestCaseName to execute....");                                                                                
	                }              
	 
	            } catch (Exception e) {

	            	}              
	        	System.out.println("E2E Test Execution Completed");
	                    Shutdown = true;
	                    
	                    }              
		@SuppressWarnings("static-access")
		public void udaptemachinename(String tcName){
		       
		       String hostname = "Unknown";

		    try {
		           InetAddress addr;
		           addr = InetAddress.getLocalHost();
		           hostname = addr.getHostName();
		           System.out.println("Hostname " + hostname);
		    } catch (UnknownHostException ex) {
		           System.out.println("Hostname can not be resolved");
		    }
		    E2E_DB_Update db = new E2E_DB_Update();
		    try {
		              db.Update_Machine_Name(hostname, tcName);
		       } catch (SQLException e) {
		              // TODO Auto-generated catch block
		              e.printStackTrace();
		       }
		}

	        };
	} 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
