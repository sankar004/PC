package businesscomponents;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class E2E_DB_Update {
	
    public static void Update_Machine_Name(String machineName, String testCase) throws SQLException{
        
        Connection connection = Getconnection();
        Statement statement = connection.createStatement();  
         
         //String Query = "UPDATE " + TableName + " SET " + TargetColumnName + " = '"+"PASSED"+"'"+" WHERE "+ SourceColumnName_1 + " ='" + SourceValue_1 +"'";
        //String Query = "UPDATE " + TableName + " SET " + TargetColumnName + " ='" + SourceValue_1 +"'"+" WHERE "+ SourceColumnName_1 + " ='" + SourceValue_2 +"'";
       // String Query = "UPDATE E2E_TESTCASES SET EXEC_MACH_NM = '"+ machineName + "' , EXEC_START_TIME = SYSDATE WHERE CALLED_TEST_CASE_ID  ='" + testCase +"'";
	String Query = "UPDATE E2E_TESTCASES SET EXEC_MACH_NM = '"+ machineName + "' , EXEC_START_TIME = SYSDATE WHERE CALLED_TEST_CASE_ID  ='" + testCase +"', TEST_CASE_STAT_DESC = 'In Progress'"; 
        statement.executeQuery(Query); 
         closeconnection(statement,connection);
        } 
                
public static String Select_E2EScenarioName(String TargetColumnName, String TableName, String SourceColumnName, String SourceValue ) throws SQLException{
			
			ResultSet resultSet = null;
			String result = null;
			Connection connection = Getconnection();
			Statement statement = connection.createStatement();    
			
			String Query = "SELECT " + TargetColumnName + " FROM " + TableName + " WHERE " + SourceColumnName + " ='" + SourceValue + "'";                 
			 
			resultSet = statement.executeQuery(Query);             
			                while(resultSet.next()) {
			                 result = resultSet.getString(1);
			                 }        
			closeconnection(statement,connection);
			return result;
} 
public static String Select_E2EFieldName(String TargetColumnName, String TableName, String SourceColumnName_1, String SourceValue_1, String InnerTableName, String SourceColumnName_2, String SourceValue_2, String SourceColumnName_3, String SourceValue_3) throws SQLException{
	       
	         ResultSet resultSet = null;
	        String result = null;
	        Connection connection = Getconnection();
	        Statement statement = connection.createStatement();  
	        // String Query1 = "SELECT " + TargetColumnName + " FROM " + TableName + " WHERE " + SourceColumnName_1 + " ='" + SourceValue_1 + "' AND " + SourceColumnName_2 + " ='" + SourceValue_2 + "'";
	        String Query = "SELECT " + TargetColumnName + " FROM " + TableName + " WHERE " + SourceColumnName_1 + " ="+"(SELECT "+ SourceValue_1 + " FROM " + InnerTableName +" WHERE "+ SourceColumnName_2 + " ='" + SourceValue_2 + "' AND " + SourceColumnName_3 + " ='" + SourceValue_3 + "')";
	        resultSet = statement.executeQuery(Query);             
	
	                        while(resultSet.next()) {
	                          result = resultSet.getString(1);
	                        } 
	                         closeconnection(statement,connection);
	                                       return result;
}    
	        
	        public static void Update_Result(String TableName, String TargetColumnName, String SourceValue_1, String SourceColumnName_1, String SourceValue_2) throws SQLException{
	                                                            
	                        Connection connection = Getconnection();
	                        Statement statement = connection.createStatement();  
	                         
	                         //String Query = "UPDATE " + TableName + " SET " + TargetColumnName + " = '"+"PASSED"+"'"+" WHERE "+ SourceColumnName_1 + " ='" + SourceValue_1 +"'";
	                        //String Query = "UPDATE " + TableName + " SET " + TargetColumnName + " ='" + SourceValue_1 +"'"+" WHERE "+ SourceColumnName_1 + " ='" + SourceValue_2 +"'";
	                        String Query = "UPDATE " + TableName + " SET EXEC_END_TIME = SYSDATE,"  + TargetColumnName + " ='" + SourceValue_1 +"'"+" WHERE "+ SourceColumnName_1 + " ='" + SourceValue_2 +"'";
	                        statement.executeQuery(Query); 
	                         closeconnection(statement,connection);
	                        } 

                public static void updatequery(String value1, String value2, String value3) throws SQLException{              
                               
                    Connection connection = Getconnection();
                    Statement statement = connection.createStatement(); 
                   
                   //  String Query = "INSERT INTO E2E_TRANS (TRANS_ID, E2E_TEST_CASE_ID, TRANS_KEY_NM, TRANS_KEY_VALUE) VALUES ('1', '"+ value1 +"', '"+ value2 +"', '"+ value3 +"')";      
                      String Query = "INSERT INTO E2E_TRANS (E2E_TEST_CASE_ID, TRANS_KEY_NM, TRANS_KEY_VALUE,LAST_UPDT_TMSP,LAST_UPDT_APPL_NM) VALUES ('"+ value1 +"', '"+ value2 +"', '"+ value3 +"',SYSDATE ,'ICON')";
                     statement.execute(Query);   
                     closeconnection(statement,connection);
                }        

                public static int getversionumber(String SourceValue_1, String SourceValue_2) throws SQLException{
                                ResultSet resultSet = null;
                                int result = 0;
                                int result1 = 0;                   
                                Connection connection = Getconnection();
                                Statement statement = connection.createStatement();                        
                                String Query = "SELECT  TRANS_ID FROM E2E_TRANS WHERE E2E_TEST_CASE_ID ='" + SourceValue_1 + "' AND TRANS_KEY_NM ='" + SourceValue_2 + "'";
                                resultSet = statement.executeQuery(Query);                    
                                while(resultSet.next()) {
                                                String tempres = resultSet.getString(1);
                                                if (!tempres.isEmpty())                                 
                                                {
                                                result1 = Integer.parseInt(tempres);
                                                }
                 if (result < result1)
                 {
                 result = result1;                                
                 }             
        }  
                                closeconnection(statement,connection);
                                return result;
                }
                
                public static String getValue(String SourceValue_1, String SourceValue_2, int SourceValue_3) throws SQLException{
                                ResultSet resultSet = null;
                                String result = null;         
                                Connection connection = Getconnection();
                                Statement statement = connection.createStatement();                        
                                String Query = "SELECT  TRANS_KEY_VALUE FROM E2E_TRANS WHERE E2E_TEST_CASE_ID ='" + SourceValue_1 + "' AND TRANS_KEY_NM ='" + SourceValue_2 + "' AND TRANS_ID ='" + SourceValue_3 + "'";
                                resultSet = statement.executeQuery(Query);                    
                                 while(resultSet.next()) {
                                                  result = resultSet.getString(1);
                                                } 
                                                 closeconnection(statement,connection);
                                                               return result;
                }
                
                
                
                
public static Connection Getconnection(){        
        
          // variables
                    Connection connection = null;
                    Statement statement = null;
      //Loading or registering Oracle JDBC driver class
      try {

          Class.forName("oracle.jdbc.driver.OracleDriver");
          
      }
      catch(ClassNotFoundException cnfex) {

          System.out.println("Problem in loading or "
                  + "registering Oracle JDBC driver");
          cnfex.printStackTrace();
      }
      //Opening database connection
      try {
          //String msAccDB = "C:/Selenium_Workspace/NewIconFrame_Final/uploadresults_alm/E2E_TestData.accdb";
          //String msAccDB = "C:/E2EWorkspace/ComPASExecutable/E2EDB/E2EMASTERDB_be.accdb";
          //String dbURL = "jdbc:ucanaccess://" + msAccDB; 
          //Create and get connection using DriverManager class
          connection = DriverManager.getConnection("jdbc:oracle:thin:@xdhfd2-oltpnp-scan:1521/SEL_QA_OLTP_APP3579.thehartford.com","SELENIUM_APPL","sElpL45#2");  
          //Creating JDBC Statement                 
        }
      catch(SQLException sqlex){
          sqlex.printStackTrace();
       }      
      // Returning statement object
               return connection;          
        }

                 public static void closeconnection(Statement statement,Connection connection){  
                                 try {                                       
                                                statement.close();
                                                //connection.close();
                                } catch (SQLException e) {
                                                                System.out.println("Error in closing DB Connection : " + e);
                                }
                                 finally {
                                	 
                                	 try {
										connection.close();
									} catch (SQLException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}                                	 
                                 }
                                  
                 } 
}
