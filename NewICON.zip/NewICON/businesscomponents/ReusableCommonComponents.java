package businesscomponents;


import java.sql.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Date;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import supportlibraries.*;

import com.beust.jcommander.internal.Nullable;
import com.cognizant.framework.FrameworkException;
import com.cognizant.framework.Status;
import com.cognizant.framework.TestParameters;
//import com.cognizant.framework.TestParameters;
import com.cognizant.framework.Util;
import com.cognizant.framework.selenium.SeleniumTestParameters;
import com.google.common.base.Predicate;

import allocator.*;

/**
 * Class for storing general purpose business components
 * @author Cognizant
 */
public class ReusableCommonComponents extends ReusableLibrary {
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
/*	public static WebElement LegalEntity=null;
	static By ORType = null;
	static String Curr_obj = null, value=null;
	static String obj_Name=null;
	static String[] arrobj_name=null;
	static String[] arrdata=null;
	static String obj_type;
	static String[] obj_value=null;
	static String[] type=null;
	static String LegalName=null;
	static boolean Obj_Existence,status=true;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";*/
	
	private WebElement currentObject=null;
	private By ORType = null;
	private String Curr_obj = null, value=null;
	private String obj_Name=null;
	private String[] arrobj_name=null;
	private String[] arrdata=null;
	private String obj_type;
	private String[] obj_value=null;
	private String[] type=null;
	private String LegalName=null;
	private boolean Obj_Existence,status=true;
	static final String AB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private String currentTC=null; 
	String Type1;
	GeneralComponents objGeneralComp = new GeneralComponents(scriptHelper);
	

	JavascriptExecutor js = (JavascriptExecutor) driver.getWebDriver();
	//static String requiredDetail=null;
	public ReusableCommonComponents(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}
	
	public void reusablecomponent(String currentKeyword, String currentTestCase) 
	{
		TestParameters tstParam = new TestParameters("R1-41TestCases",currentTestCase);
		 boolean DEBUG_MODE = java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString().indexOf("-agentlib:jdwp")>0;
//		try{
			ObjectRepository ORTable = new ObjectRepository(null);
			ORTable.getInputData();
			//Date yourDate = new Date();
			GregorianCalendar date = new GregorianCalendar();
			int hour = date.get(Calendar.HOUR);
			int Minute = date.get(Calendar.MINUTE);
			int seconds = date.get(Calendar.SECOND);
			long startTime, endTime, exeTime;
			System.out.println("Current time"+hour+":"+Minute+":"+seconds);
			
			currentTC = currentTestCase;
			System.out.println(currentTC);
			
		//String Data=DriverScript.totaldata;
			//arrdata=Data.split("\\<==>");
			String object=dataTable.getData(currentKeyword, "Object");
			String objectValue=dataTable.getData(currentKeyword, "TestData");
			arrobj_name= object.split("\\;");
			arrdata=objectValue.split("\\;");
		 	Obj_Existence=false;
		 	int objcheckval=0;
		 	int retryObj = 0;
		 	startTime = System.currentTimeMillis();
		 	//System.out.println("Page start_scenario"+DriverScript.Scenario_name);
		 	//System.out.println("Page start_tc"+DriverScript.TestCase_name);
	        for(int i=0;i<arrobj_name.length;i++)
	        {
	        	System.out.println("Current TC =" + currentTC + " ...... && ...... Current Obj = "  +  arrobj_name[i]);
	        	type=arrobj_name[i].split("\\_");
 	        	obj_type=type[0];
	        	
        		String[] ObjVal=arrdata[i].toString().trim().split("##");
	        	if(objcheckval==0){
	        		if(obj_type.contains("RDO")||obj_type.contains("GRP")||obj_type.contains("CAL")){
	        			Obj_Existence=true;
	        		}
	        	else
	        	{
	        		try{
	        			Obj_Existence=false;
	        			String objType="By."+ ORTable.getType(arrobj_name[i]);
	    	        	String objelement=ORTable.getElement(arrobj_name[i]);
	    	        	if (objType.contains("Object not found")){
		        			System.out.println(objType);
		        			System.out.println(objType);		       
		        			report.updateTestLog(currentKeyword, objType , Status.FAIL);	
		        			tstParam.seterrMsg(objType);
		        			objGeneralComp.checkExectionMode(objType);
	    	        	}
	    	        	//System.out.println(arrobj_name[i]);
	    	        	//waitToBeDisplayed(2);
	    	        	
		    	        	WebElement PageFirstObj=GetwebElement(objType,objelement);
		    	        	Obj_Existence=isDisplayesUI(PageFirstObj);
		    	        	if(!Obj_Existence && (ObjVal.length > 1) ){
		    	        			String objType_Last ="By."+ ORTable.getType(ObjVal[1]);
		    	        			String objelement_Last=ORTable.getElement(ObjVal[1]);
		    	        			WebElement PageLastObj=GetwebElement(objType_Last,objelement_Last);
				    	        	Obj_Existence=isDisplayesUI(PageLastObj);
				    	        	if(Obj_Existence){
				    	        			PageLastObj.click();
				    	        			String errMsg = "Trying to fix the issue by re-selecting the previour screen object. Screen not navigating to the right page. Screen Name: " + currentKeyword + ", Object Name: " + arrobj_name[i];
						        			System.out.println(errMsg);		       
						        			report.updateTestLog(currentKeyword, errMsg , Status.DONE);	
				    	        			PageFirstObj=GetwebElement(objType,objelement);
				    	        			Obj_Existence=isDisplayesUI(PageFirstObj);
		    	        		}
		    	        	}
		    	        	if(Obj_Existence){
	    	        			objcheckval=1;
		    	        	}
		    	        	else{
		    	        		String errMsg = "Screen not loaded successfully. Object in screen not available. Screen Name: " + currentKeyword + ", Object Name: " + arrobj_name[i];
			        			System.out.println("Error in Finding Object from UI ");
			        			System.out.println(errMsg);		       
			        			report.updateTestLog(currentKeyword, errMsg , Status.FAIL);	
			        			tstParam.seterrMsg(errMsg);
			        			objGeneralComp.checkExectionMode(errMsg);
		    	        	}
	        		
	    	        	}
	    	        	catch(Exception e){
	    	        		String errMsg = "Exception on screen load.Object in screen not available. Screen Name: " + currentKeyword + ", Object Name: " + arrobj_name[i];
		        			System.out.println("Error in Finding Object from UI "+ e);
		        			System.out.println(errMsg);		       
		        			report.updateTestLog(currentKeyword, errMsg ,  Status.FAIL);	
		        			tstParam.seterrMsg(errMsg);
		        			objGeneralComp.checkExectionMode(errMsg);
	    	        	}
	        		}
	        	}
	        	
	        	
		        	if(Obj_Existence==true)
		        	{
		        		
		        		for(int obj=0;obj< ObjVal.length ; obj++){
		        			value=ObjVal[obj];
		        			if (value.contains("getdbData_")){
	                            value = GetData(value.split("getdbData_")[1]);                                     
		        				}
		        			if(obj==0)
		        			{
		        				if(!obj_type.contains("RDO")&&!obj_type.contains("GRP")&&!obj_type.contains("CAL")){
		    	        			
		    	        			
		    	        			if(ORTable.getType(arrobj_name[i])!=null){
		    	        				try {
			    	        				Type1="By."+ ORTable.getType(arrobj_name[i]);
			    	    	        		Curr_obj=ORTable.getElement(arrobj_name[i]);
			    	    	        		//System.out.println(arrobj_name[i]);
			    	    	        		currentObject=GetwebElement(Type1,Curr_obj);
		    	    	        		//GeneralComponents.highlightobject(driver,properties,LegalEntity);
		    	        				}
		    	        				catch (Exception e) {
		    	        					
		    	        					String errMsg = "Object in screen not available. Screen Name: " + currentKeyword + ", Object Name: " + arrobj_name[i];
		    			        			System.out.println("Error in Finding Object from UI "+ e);
		    			        			System.out.println(errMsg);		       
		    			        			report.updateTestLog(currentKeyword, errMsg , Status.FAIL);	
		    			        			tstParam.seterrMsg(errMsg);
		    			        			objGeneralComp.checkExectionMode(errMsg);
		    	        				}
		    	        			}
		    	        		}
		        
					        		try{
					    	        	switch(obj_type){
					    	        	
						    	 	        case "LST":
						    	 	        	for(int l=0; l<5;l++){
					                                try {
					                         //JavaScriptDynamicWait(currentObject, js);
					                         //waitForJSandJQueryToLoad();
					                         
					                         Select newdropdown= new Select(currentObject);
					                         List<WebElement> dropdownlist = newdropdown.getOptions();
					                         boolean valexist=false;
					                         int j;
					                      for(j=0;j<dropdownlist.size();j++){
					                           System.out.println("dropdown value = "+dropdownlist.get(j).getText());
					                           System.out.println(value);
					                          if(dropdownlist.get(j).getText().equals(value)){
					                           valexist=true;
					                              break;
					                              }
					                      }
					                      
					                         if(value.equalsIgnoreCase("random")&&!valexist){
					                                int n = (int)(Math.random()*(dropdownlist.size()-1)+1);
					                                /*Random rand = new Random();
					                                int  n = rand.nextInt(dropdownlist.size()-1) + 1;*/
					                                newdropdown.selectByIndex(n);
					                         }else{
					                                /* try{*/
					                                        
					                                        
					                                        /*
					                                         for(int l=0; l<5;l++)
					                                      try {*/
					                                       newdropdown.selectByVisibleText(value);
					                                       break;
					                                       //newdropdown.selectByIndex(j);
					                                         /* break;
					                                      } catch(StaleElementReferenceException e) {
					                                        e.toString();
					                                  System.out.println("Trying to recover from a stale element :" + e.getMessage());
					                                 waitToBeDisplayed(1);     
					                                    
					                                  }*/
					
					                                         
					                                         
					                          /*           newdropdown.selectByVisibleText(value); 
					                                 }     catch(StaleElementReferenceException e){
					                                       //JavaScriptDynamicWait(currentObject, js);
					                                       waitToBeDisplayed(5);      
					                                       newdropdown.selectByVisibleText(value);                                             
					                                 }                   
					                                */
					                                
					                         }
					                                } catch(StaleElementReferenceException e) {
					                                      currentObject=GetwebElement(Type1,Curr_obj);
					                                e.toString();
					                          System.out.println("Trying to recover from a stale element :" + e.getMessage());
					                         //waitToBeDisplayed(2);   
					                            
					                           }
					                         }
					                  break;
					
						    		         		         	
						    	 	       case "EDI":
					   
						    	 	    	  WebElement element = (new WebDriverWait(driver, 10))
						    	 	    	   .until(ExpectedConditions.elementToBeClickable(currentObject));
						    	 	    	
						    	 	    	  
					                           if(value.contains("Automation_Unique")){
					                               SecureRandom r = new SecureRandom();
					                               StringBuilder sb = new StringBuilder( 12 );
					                                   for( int E = 0; E < 12; E++ ) 
					                                      sb.append( AB.charAt( r.nextInt(AB.length()) ) );
					                                  
					                                //System.out.println("Account Name is "+sb.toString());             
					                                   value=sb.toString();
					                                   value = "QAC1_" + value; // This is to create policy for QA2 environment
					                                   
					                                   }
					                           for(int l=0; l<10;l++)
					                        	  try {
							                           try{
							                               //LegalEntity.sendKeys(Keys.ENTER);
							                                               currentObject.click();
							                                                                                                                               }
							                               catch (Exception e){
							                                currentObject.sendKeys(Keys.RETURN);
							                               }
							                                                           
							                           currentObject.clear();
							
							                                  if(value.contains("Today_Date"))
							                           {
							                              LocalDate localDate = LocalDate.now();
							                              String Date = DateTimeFormatter.ofPattern("MM/dd/yyyy").format(localDate);
							                              value=Date.toString();
							                           }  
							                            /*      for (int s = 0; s < value.length(); s++){
							                                   char c = value.charAt(s);
							                                   String S = new StringBuilder().append(c).toString();
							                                   currentObject.sendKeys(S);
							                               }*/         
					//		                          System.out.println("Before Send keys");
							                          currentObject.sendKeys(value);
					                                  currentObject.sendKeys(Keys.TAB);
					                                  
					                                 
					                                  break;
					                        	  } 
					                           catch(StaleElementReferenceException e) {
							                           e.toString();
							                           System.out.println("Trying to recover from a stale element :" + e.getMessage());
							                           waitToBeDisplayed(1);     
					                                    
					                                  } 
					                           
					
					                           break;
					                           
						    	 	      case "EDN":
					                          try{
					                              //LegalEntity.sendKeys(Keys.ENTER);
					                              currentObject.click();
					                          }
					                              catch (Exception e){
					                               currentObject.sendKeys(Keys.RETURN);
					                              }
					                                                          
					                          currentObject.clear();
					                          for (int s = 0; s < value.length(); s++){
					                          char c = value.charAt(s);
					                          String S = new StringBuilder().append(c).toString();
					                          currentObject.sendKeys(S);
					                              }
					                                                          currentObject.sendKeys(Keys.TAB);
					                          break;
					                  
					
						    	 	       
						    	 	        case "RDO":	
						    	 	        	waitToBeDisplayed(2);
						    	 	        	String[] radio=null;
						    	 	        		//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'no')]/input[@type='radio']
						    		 	        	//*[contains(text(),'Is this building sprinklered?')]/ancestor::div//*[contains(text(),'No') ]/input[@type='radio']
						    		 	        radio=value.split("\\:");
						    	 	        	radio[0]=radio[0].toLowerCase().trim();
						    		 	        	if(radio.length>1){
						    		 	        		
						    		 	        		radio[1]=radio[1].toLowerCase().trim();
						    		 	        		//LegalEntity=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[@class='radioSet']//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input"));
						    		 	        		//currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/input "
						    		 	        				//+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
						    		 	        		currentObject = (new WebDriverWait(driver, 60))
							    		 	     	 	    	   .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/input "
							   	    		 	        				+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ radio[1]+"') ]/preceding-sibling::input[@type='radio']")));
							    		 	        	
						    		 	        	
						    		 	        	}
						    		 	        	else
						    		 	        	{
						    		 	        		//currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] +"')]/input[@type='radio']"));
						    		 	        		currentObject = (new WebDriverWait(driver, 60))
						    		 	     	 	    	   .until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + radio[0] +"')]/input[@type='radio']")));
						    		 	        	
						    		 	        	
						    		 	        	}
						    		 	        	Boolean EntityEnabled=currentObject.isEnabled();
						    		 	        	 if(EntityEnabled){
						    		 	        		//LegalEntity.click();
						    		 	        		//LegalEntity.sendKeys(Keys.ENTER);
						    		 	        		currentObject.sendKeys(Keys.SPACE);
						    		 	        		//waitToBeDisplayed(2);
						    		 	        	}
						    		 	        	
						    		 	        	 /*if(!LegalEntity.isSelected()){
						    		 	        		LegalEntity.click(); 
						    		 	        	 }*/
						    		 	        
						    		 	       break;
						    	 	        	
						    	 	        case "ELE":	
					//	    	 	        	waitToBeDisplayed(2);
						    	 	        			
					 	    	 	        					currentObject.click();
						    	 	        	break;
						    	 	        case "CHK":
						    	 	        	if((value.toLowerCase().equals("on")&&!currentObject.isSelected())||((value.toLowerCase().equals("off")&&currentObject.isSelected()))){
						    	 	        		currentObject.click();
						 	        				//waitToBeDisplayed(2);	
						    	 	        	}else{
						    	 	        		System.out.println("input for checkbox is "+ value +"not equals to on or off");
						    	 	        	}
						    	 	        		/*while(!LegalEntity.isSelected()){
						    	 	        				LegalEntity.click();
						    	 	        				waitToBeDisplayed(2);
						    							}*/
						    	 	        	
						    	 	        	break;
						    	 	       case "LNK":   
					                           //waitToBeDisplayed(2);//modified by muthu 
//					                           WebDriverWait wait1 = new WebDriverWait(driver, 100); 
//					                           wait1.until(ExpectedConditions.elementToBeClickable(currentObject));
					                          try{
					//                        	  report.updateTestLog("Required screenshot","page screenshot", Status.SCREENSHOT);
					                                 currentObject.click();
					                                                                   }
					                          catch (Exception e){
					//                        	  report.updateTestLog("Required screenshot","page screenshot", Status.SCREENSHOT);
					                           currentObject.sendKeys(Keys.RETURN);
					                           
					                           }
					//                          
					                          
					                           
					                           break;
					
						    	 	      case "BTN":
					                         // waitToBeDisplayed(2);//modified by muthu 
					                          WebDriverWait wait = new WebDriverWait(driver, 100); 
					                           wait.until(ExpectedConditions.elementToBeClickable(currentObject));
					                          
					                           try{
					//                                 report.updateTestLog("Required screenshot","page screenshot", Status.SCREENSHOT);
					                                 currentObject.click();
					                                                                   }
					                          catch (Exception e){
					//                                 report.updateTestLog("Required screenshot","page screenshot", Status.SCREENSHOT);
					                           currentObject.sendKeys(Keys.RETURN);
					                           
					                           }
					                           
					                           
					                           break;
					
						    	 	        case "CAL":	
						    	 	        	invokeFunction(arrobj_name[i].substring(4,arrobj_name[i].length()));
						    	 	        	
						    	 	        	break;
						    	 	       case "GRP":
						    	 	    	   String elementtype=type[1].toLowerCase();
						    	 	    	  switch(elementtype){
						    	 	    	  		case "checkbox":
						    	 	    	  			String[] checkboxgroup=null,individualcheckbox=null;
						    	 	    	  			checkboxgroup=value.split("\\~");
						    	 			 	        for(int chkgrp=0;chkgrp<checkboxgroup.length;chkgrp++){
						    	 			 	        	try{
						    	 			 	        		individualcheckbox=checkboxgroup[chkgrp].split("\\:");
						    	 			 	        		currentObject=driver.findElement(By.id(individualcheckbox[0]));
						    	 			 	        	Boolean LegalEntityStatus=currentObject.isSelected();
						    	 			 	        		if((individualcheckbox[1].toUpperCase().equals("ON") && !LegalEntityStatus )||(individualcheckbox[1].toUpperCase().equals("OFF") && LegalEntityStatus))
						    	 			 	  			{
						    	 			 	        			while(!currentObject.isSelected()){
						    		 		 	        				currentObject.click();
						    		 		 	        				waitToBeDisplayed(2);
						    		 								}
						    	 			 	  			}
						    	 			 	        		
						    	 			 	        	}
						    	 			 	        	catch(Exception chk){
						    	 			 	        		System.out.println(chk + " issue with checkbox" + checkboxgroup[chkgrp] +" is not available" );
						    	 			 	        	}
						    	 			 	        	waitToBeDisplayed(1);
						    	 			 	           }
						    	 	    	  			break;
						    	 	    	  			
						    	 	    	  		case "radiobutton":
						    	 	    	  			String[] radiogroup=null,individualradio=null;
						    	 			 	        radiogroup=value.split("\\~");
						    	 			 	        for(int radgrp=0;radgrp<radiogroup.length;radgrp++){
						    	 			 	        		
						    	 			 	        	individualradio=radiogroup[radgrp].split("\\:");
						    	 			 	        	individualradio[0]=individualradio[0].toLowerCase().trim();
						    	 			 	        	if(individualradio.length>1){
						    	 			 	        		
						    	 			 	        		individualradio[1]=individualradio[1].toLowerCase().trim();
						    	 			 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/input[@type='radio']"
						    	 			 	        						+ "|//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/ancestor::div[1]//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'"+ individualradio[1]+"') ]/preceding-sibling::input[@type='radio']")); 
						    	 			 	        	}
						    	 			 	        	else
						    	 			 	        	{
						    	 			 	        		currentObject=driver.findElement(By.xpath("//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] + "')]/preceding-sibling::input[@type='radio'] | //*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'" + individualradio[0] +"')]/input[@type='radio']"));
						    	 				 	        }
						    	 			 	        	Boolean Entityselectedval=currentObject.isSelected();
						    	 			 	        	if(!Entityselectedval){
						    	 			 	        		
						    	 			 	        		currentObject.sendKeys(Keys.SPACE);
						    	 			 	        	}
						    	 			 	        	waitToBeDisplayed(1);
						    	 			 	        }
						    	 	    	  			break;
						    	 	    	  		case "editbox":
						    	 	    	  			String[] editboxgroup=null,individualeditbox=null;
						    	 	    	  			editboxgroup=value.split("\\~");
						    	 			 	        for(int edtgrp=0;edtgrp<editboxgroup.length;edtgrp++){
						    	 			 	        	individualeditbox=editboxgroup[edtgrp].split("\\:");
						    	 			 	        	try{
						    	 			 	        		currentObject=driver.findElement(By.id(individualeditbox[0]));
						    		 			 	        	for (int a = 0; a < individualeditbox[1].length(); a++){
						    		 				 	   	        char n = individualeditbox[1].charAt(a);
						    		 				 	   	        String S = new StringBuilder().append(n).toString();
						    		 				 	   	        currentObject.sendKeys(S);
						    		 				 	   	    }
						    		 				 	   			currentObject.sendKeys(Keys.TAB);
						    	 			 	        	}catch(Exception ed){
						    	 			 	        		System.out.println(ed + " issue in editbox " + individualeditbox[0] +" is not available" );
						    	 			 	        	}
						    	 			 	        	waitToBeDisplayed(1);
						    	 			 	           }
						    	 	    	  			break;
						    	 	    	  			
						    	 	    	  		case "listbox":
						    	 	    	  			String[] listboxgroup=null,individuallistbox=null;
						    	 	    	  			listboxgroup=value.split("\\~");
						    	 			 	        for(int lstgrp=0;lstgrp<listboxgroup.length;lstgrp++){
						    	 			 	        	individuallistbox=listboxgroup[lstgrp].split("\\:");
						    	 			 	        	try{
						    	 			 	        		currentObject=driver.findElement(By.id(individuallistbox[0]));
						    		 			 	        	 Select individualLST= new Select(currentObject);
						    		 			 	        	individualLST.selectByVisibleText(individuallistbox[1]);
						    	 			 	        	}catch(Exception lst){
						    	 			 	        		System.out.println(lst + " issue in listbox" + individuallistbox[0] +" is not available or "+individuallistbox[1]+" is not available" );
						    	 			 	        	}
						    	 			 	        	waitToBeDisplayed(1);
						    	 			 	        }
						    	 	    	  			break;
						    	 	    	  		}
						    	 	    	   
						    	 	        	break;
						    	 	        
						    	        	}
						        				
						        			}
					        		catch(Exception e)
						        		{
					        				if ((retryObj < 3) && (i != 0)) {
					        						retryObj = retryObj + 1;
					        						System.out.println("Retrying the action for the object "+ arrobj_name[i] + " in the screen " + currentKeyword + " for "+ retryObj + " time.");
					        						report.updateTestLog(currentKeyword, "Retrying the action for the object "+ arrobj_name[i] + " in the screen " + currentKeyword + " for "+ retryObj + " time." , Status.DONE);
					        						i = i - 2;
					        				}
					        				else {
					        					String errMsg = "Issue in selecting or performing action in the screen " + currentKeyword + ". " + arrobj_name[i] + " is either not available or unable to select/enter the value:  " + value;
							        			System.out.println("Error in reusable component "+ e);
							        			System.out.println(errMsg);		       
							        			report.updateTestLog(currentKeyword, errMsg, Status.FAIL);
							        			report.updateTestLog(currentKeyword, "Execution failed even after tree successive try to access the object" ,  Status.FAIL);
							        			retryObj = 0;
							        			tstParam.seterrMsg(errMsg);
							        			objGeneralComp.checkExectionMode("Execution stopped due to application issue");
					        				}
						        			
						        			
						        		}
					        			}
					        			else{
					        				try{
					        					dataVerification(value);
					        				}
					        				catch(Exception e) {
					        					String errMsg = "Issue in verifying the given data from the screen " + currentKeyword + ". Object Name: " + arrobj_name[i] + ", Value: " + value;
							        			System.out.println("Error in reusable component "+ e);
							        			System.out.println(errMsg);		       
							        			report.updateTestLog(currentKeyword, errMsg, Status.FAIL);
					        				}
					        				
					        			}
					        		}
	        	}
	       
	        	else
	        	{
	        		System.out.println(value);
        			String errMsg = "Unable to find the object in the screen " + currentKeyword + ". " + arrobj_name[i] + " is either not available or object property is changed." ;
        			report.updateTestLog(currentKeyword, errMsg, Status.FAIL);
        			tstParam.seterrMsg(errMsg);
        			objGeneralComp.checkExectionMode(errMsg);
	        	}
		        	    	
	        }
	       // System.out.println("Page_end_scenario"+DriverScript.Scenario_name);
		 	//System.out.println("Page_end_tc"+DriverScript.TestCase_name);
	        endTime = System.currentTimeMillis();
	        exeTime = (endTime - startTime)/1000;
	        report.updateTestLog(currentKeyword+" Screen", "Time taken to complete  " + currentKeyword+ " screen: "+ exeTime + " Secs",  Status.DONE);
	        report.updateTestLog(currentKeyword+" Screen", "Execution completed for the screen " + currentKeyword,  Status.PASS);
	       
		
		 	
		 
	        /*}catch(Exception e)
		{
			
			System.out.println(value);
			System.out.println("reusable component "+ e);
			String errMsg = "Issue in extraction or creating objects from data file or object not found in the UI."  ;
//			report.updateTestLog(errMsg , currentKeyword, Status.FAIL);
			objGeneralComp.checkExectionMode(errMsg);
			
			//System.out.println("reusable component "+e);
		//	report.updateTestLog("issue in reusable component", "Page execution failed", Status.FAIL);
			
			//frameworkParameters.setStopExecution(true);
			//throw new FrameworkException("issue in reusable component", "Page Execution failed");
			
		}*/
	}
	
	public WebElement GetwebElement(String Type,String Obj) {
		try{
		WebElement localWeb=null;
		if(Type.contains("id")){
			//localWeb=driver.findElement(By.id(Obj));
		localWeb = (new WebDriverWait(driver, 60))
 	 	    	   .until(ExpectedConditions.presenceOfElementLocated(By.id(Obj)));
		}else if(Type.contains("name")){
			//localWeb=driver.findElement(By.name(Obj));
			localWeb = (new WebDriverWait(driver, 60))
	 	 	    	   .until(ExpectedConditions.presenceOfElementLocated(By.name(Obj)));
		}
		else if(Type.contains("xpath")){
			//localWeb=driver.findElement(By.xpath(Obj));
			localWeb = (new WebDriverWait(driver, 60))
	 	 	    	   .until(ExpectedConditions.presenceOfElementLocated(By.xpath(Obj)));	
		}
		
		//highlightElement(localWeb);	
		
		return localWeb;
		} 
		catch (Exception e){
			String errMsg = "Function Name: GetwebElement. Issue in finding the webelement in UI. Obj Property: "+ Obj + " , Obj Type: "+ Type;
			System.out.println("Error Message: " + e);
			System.out.println(errMsg);
//			 report.updateTestLog("Object not available in UI",errMsg, Status.FAIL); 
			return null;
		}
	}
	
	
    public void highlightElement(WebElement localWeb) throws Exception
    {
          //pro = new ConfigManager("sys");

          try{
            String attributevalue="border:8px solid blue;";//change border width and colour values if required
            JavascriptExecutor executor= (JavascriptExecutor) driver.getWebDriver();
            String getattrib= localWeb.getAttribute("style");
            executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", localWeb, attributevalue);
            //Thread.sleep(100);
            //executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", localWeb, getattrib);
          }
          catch (Exception e){
  			System.out.println("issue in webelement  "+e);
          }
 }

	public void dataVerification(String VerificationData) {
		try {
				//waitToBeDisplayed(3);
				ObjectRepository ORTable = new ObjectRepository(null);
				ORTable.getInputData();
        		String Switchval=VerificationData.substring(0,3);
        			WebElement verifyCurrentObject=null;
        			String VerifyData[]=null,VerifyType="",Curr_verification_obj="";
        			if(!Switchval.contains("RDO")&&!Switchval.contains("WAI")&&!Switchval.contains("SCR")){
        			 VerifyData=VerificationData.split(":");
        			 VerifyType="By."+ ORTable.getType(VerifyData[0]);
        			 Curr_verification_obj=ORTable.getElement(VerifyData[0]);
        			 verifyCurrentObject=GetwebElement(VerifyType,Curr_verification_obj);
        			}
        			if (verifyCurrentObject != null || Switchval.contains("WAI")){
        				switch(Switchval){
	        			case "LST":	        				

	    					Select Verifydropdown= new Select(verifyCurrentObject);
	   					 	String SelectedOption=Verifydropdown.getFirstSelectedOption().getText();
	   					 	System.out.println("SelectedOption "+SelectedOption);
	   						OutputData(VerifyData[0] ,SelectedOption); 
	    					if(VerifyData.length>1){        					 
	    						 if ((GeneralComponents.SelectQuery("E2E_Fields", "Name_Mapping", "ICON",VerifyData[1] ) != null ) && !(GeneralComponents.SelectQuery("E2E_Fields", "Name_Mapping", "ICON",VerifyData[1])).isEmpty()){
	    						 	        							VerifyData[1] = GetData(VerifyData[0]);
	    						 	        							} 
	
	    					 if(SelectedOption.equalsIgnoreCase(VerifyData[1])){
	    						 report.updateTestLog("Verification of "+VerifyData[0], "Expected Value: "+
	    			    	        		VerifyData[1]+", Actual Value:" + SelectedOption, Status.PASS); 
	    					 }else
//	    						 throw new Exception("Given selected value "+VerifyData[1]+" does not match with"+ SelectedOption +"==> list verification failed ");
	    						 report.updateTestLog("Verify VerifyData[0]", " selected value "+VerifyData[1]+" does not match with"+ SelectedOption +"==> list verification failed ", Status.FAIL);
	    					}
	    					else{
	    						boolean ListObjectExistence=false;
	    						ListObjectExistence=verifyCurrentObject.isDisplayed();
		    	        		for(int sec=0;(sec<=60 && !ListObjectExistence);sec=sec+1){
		    	        			waitToBeDisplayed(1);
		    	        			ListObjectExistence=verifyCurrentObject.isDisplayed();
		    	        		}
		    	        		if(!ListObjectExistence){
		    	        			throw new Exception(VerifyData[0] +" Object not loaded");
		    	        		}else{
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of data @ "+ SelectedOption +" Passed", Status.DONE);
		    	        		}
	    					}
	    					break;
	    		         		         	
	    	 	        case "EDI":
	    	 	        case "EDN":	
	    	 	        	
	    	 	        	String Screen_value=verifyCurrentObject.getAttribute("value");
	    	 	        	
	    	 	        	if(VerifyData.length>1){
		    	        		
		    	        		if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getAttribute("value"))){
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
		    	        		VerifyData[1]+" Passed", Status.DONE);
		    	        	 OutputData(VerifyData[0] ,value); 
	
		    	        		}else if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getText())){
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
			    	    	        		VerifyData[1]+" Passed", Status.DONE);
		    	        		}else{
		    	        			report.updateTestLog("Verify VerifyData[0]", " selected value "+VerifyData[1]+" does not match with"+ Screen_value +"==> list verification failed ", Status.FAIL);
		    	        		}	        	
		    	        	}
	    	 	        	
		    	        	else{
		    	        		boolean EditobjectExistence=false;
		    	        		EditobjectExistence=verifyCurrentObject.isEnabled();
		    	        		for(int sec=0;(sec<=60 && !EditobjectExistence);sec=sec+1){
		    	        			waitToBeDisplayed(1);
		    	        			EditobjectExistence=verifyCurrentObject.isEnabled();
		    	        		}
		    	        		if(!EditobjectExistence){
		    	        			throw new Exception(VerifyData[0] +" Object not loaded");
		    	        		}else{
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+ Screen_value +" Passed", Status.DONE);
		    	        			 OutputData(VerifyData[0] ,Screen_value);
		    	        		}
		    	        	}
		        		break;
		        		
	    	 	      /* case "CAL":
	   	 	        	Screen_value=verifyCurrentObject.getAttribute("value");
	   	 	        	 OutputData(VerifyData[0] ,Screen_value);
	   	 	        	if(VerifyData.length>1){
		    	        		
		    	        		if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getAttribute("value"))){
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
		    	        		VerifyData[1]+" Passed", Status.DONE);
		    	        	 OutputData(VerifyData[0] ,value); 
	
		    	        		}else if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getText())){
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
			    	    	        		VerifyData[1]+" Passed", Status.DONE);
		    	        		}else{
		    	        			report.updateTestLog("Verify VerifyData[0]", " selected value "+VerifyData[1]+" does not match with"+ Screen_value +"==> list verification failed ", Status.FAIL);
		    	        		}	        	
		    	        	}
	   	 	        	
		    	        	else{
		    	        		boolean EditobjectExistence=false;
		    	        		for(int sec=0;(sec<=60 && !EditobjectExistence);sec=sec+1){
		    	        			waitToBeDisplayed(1);
		    	        			EditobjectExistence=verifyCurrentObject.isEnabled();
		    	        		}
		    	        		if(!EditobjectExistence){
		    	        			throw new Exception(VerifyData[0] +" Object not loaded");
		    	        		}else{
		    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+ Screen_value +" Passed", Status.DONE);
		    	        		}
		    	        	}
		        		break;*/
	    	 	        	
	    	 	        case "RDO":	
	    	 	        		System.out.println("yet to be confirmed");
	    	 	        	break;
	    	 	        	
	    	 	        case "ELE":	
	    	 	        	//waitToBeDisplayed(5);
	    	 	        	Screen_value=verifyCurrentObject.getAttribute("value");
	    	 	        	if(Screen_value == null){
	    	 	        	Screen_value=verifyCurrentObject.getText();
	    	 	        	}
	    	 	        	System.out.println(Screen_value);
	    	 	        	
	    	 	        	OutputData(VerifyData[0] ,Screen_value);
	    	 	        	if(VerifyData.length>1){
	    	 	        	if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getAttribute("value"))){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    	        		VerifyData[1]+" Passed", Status.DONE);
	    	        	 OutputData(VerifyData[0] ,value); 

	    	        		}else if(VerifyData[1].equalsIgnoreCase(verifyCurrentObject.getText())){
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
		    	    	        		VerifyData[1]+" Passed", Status.DONE);
	    	        		}else{
	    	        			report.updateTestLog("Verify VerifyData[0]", " selected value "+VerifyData[1]+" does not match with"+ Screen_value +"==> list verification failed ", Status.FAIL);
	    	        		}	
	    	 	        	}
	    	 	        	boolean EleobjectExistence=false;
	    	 	        	EleobjectExistence=verifyCurrentObject.isDisplayed();
	    	        		for(int sec=0;(sec<=60 && !EleobjectExistence);sec=sec+1){
	    	        			waitToBeDisplayed(1);
	    	        			EleobjectExistence=verifyCurrentObject.isDisplayed();
	    	        		}
	    	        		if(!EleobjectExistence){
	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	        		}else{
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+ Screen_value +" Passed", Status.DONE);
	    	        		}
	    	 	        	break;
	    	 	        	
	    	 	        case "LNK":		
	    	 	        	//waitToBeDisplayed(5);
	    	 	        	boolean lnkobjectExistence=false;
	    	        		for(int sec=0;(sec<=60 && !lnkobjectExistence);sec=sec+1){
	    	        			waitToBeDisplayed(1);
	    	        			lnkobjectExistence=verifyCurrentObject.isDisplayed();
	    	        		}
	    	        		if(!lnkobjectExistence){
	    	        			throw new Exception(VerifyData[0] +" Object not loaded");
	    	        		}else{
	    	        			report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+
	    		    	        		VerifyData[0]+" Passed", Status.DONE);
	    	        		}
	    	 	        	
	    	 	        	break;
	    	 	       case "BTN":	
	    	 	    	  boolean BTNobjectExistence=false;
	    	 	    	  for(int sec=0;(sec<=60 && !BTNobjectExistence);sec=sec+1){
	    	 	    		  waitToBeDisplayed(1);
	    	 	    		 //BTNobjectExistence=VerifyLegalEntity.isDisplayed();
	    	 	    		 BTNobjectExistence=verifyCurrentObject.isEnabled();
	    	 	    	  }
	    	 	    	  if(!BTNobjectExistence){
	    	 	    		  throw new Exception(VerifyData[0] +" Object not loaded");
	    	 	    	  }else{
	    	 	    		  report.updateTestLog("Verification of "+VerifyData[0], "Verification of object @ "+ VerifyData[0] +" Passed", Status.DONE);
	    	 	    	  }
	    	 	        	
	    	 	        	break;
	    	 	       case "WAI":	
	    	 	    	   		VerifyData=VerificationData.split(":");
	    	 	    	   		int waittime= Integer.parseInt(VerifyData[1]);
	    	 	    	   		waitToBeDisplayed(waittime);
	    	 	        	
	    	 	        	break;
	    	 	      /* case "SCR":
	    	 	    	  report.updateTestLog("Required screenshot", "page screenshot", Status.SCREENSHOT);
	    	 	    	   break;
	        	 	        */
	        			}
        			}
        			else{
        				System.out.println("Error in verification function: ");	
        	    	  	System.out.println("Issue in verification functional. Expectd object is not available in the UI, Obj Name: "+ VerifyData[0] );
        	    	  	 report.updateTestLog("Issue in Verification function", "Issue in verification functional. Verification text: " + VerificationData, Status.FAIL);
        			}
        				
        			
      } catch (Exception DV) {
    	  
    	  	System.out.println("Error in verification function: "+DV);	
    	  	System.out.println("Issue in verification functional. Verification text: " + VerificationData );
    	  	 report.updateTestLog("Issue in Verification function", "Issue in verification functional. Verification text: " + VerificationData, Status.FAIL);
		}
		
	}
	public static void waitToBeDisplayed(int sec) {
		try {
			int requiredtime=sec*1000;
			Thread.sleep(requiredtime);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void requestedData(String requestedField) {
		try {
			System.out.println("Under Construction");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	
	private void invokeFunction(String Functionname)
			throws IllegalAccessException, InvocationTargetException,
			ClassNotFoundException, InstantiationException {
		Boolean isMethodFound = false;
		final String CLASS_FILE_EXTENSION = ".class";
		File[] packageDirectories = {
				new File(frameworkParameters.getRelativePath()
						+ Util.getFileSeparator() + "businesscomponents")};

		for (File packageDirectory : packageDirectories) {
			File[] packageFiles = packageDirectory.listFiles();
			String packageName = packageDirectory.getName();

			for (int i = 0; i < packageFiles.length; i++) {
				File packageFile = packageFiles[i];
				String fileName = packageFile.getName();

				// We only want the .class files
				if (fileName.endsWith(CLASS_FILE_EXTENSION)) {
					// Remove the .class extension to get the class name
					String className = fileName.substring(0, fileName.length()
							- CLASS_FILE_EXTENSION.length());

					Class<?> reusableMethods = Class.forName(packageName+ "." + className);
					Method executeMethod;
					try {
						// Convert the first letter of the method to lowercase
						// (in line with java naming conventions)
						Functionname = Functionname.substring(0, 1)
								.toLowerCase() + Functionname.substring(1);
						executeMethod = reusableMethods.getMethod(
								Functionname, (Class<?>[]) null);
					} catch (NoSuchMethodException ex) {
						// If the method is not found in this class, search the
						// next class
						continue;
					}

					isMethodFound = true;

					Constructor<?> ctor = reusableMethods
							.getDeclaredConstructors()[0];
					Object businessComponent = ctor.newInstance(scriptHelper);

					executeMethod.invoke(businessComponent, (Object[]) null);
					
					break;
				}
			} 
		}

		if (!isMethodFound) {
			throw new FrameworkException("Function Name: " + Functionname
					+ " not found within any class "
					+ "inside the businesscomponents package");
		}
	}

	

	public void OutputData(String FieldName,String Fieldvalue ){	
		//E2E_DB_Update db = new E2E_DB_Update();
		
		String TCName = currentTC;
		String E2ETCName = "";
		String E2EFieldName = "";	
		//int VersionNumber = 0;
		if (Fieldvalue != null && !Fieldvalue.isEmpty() ){
		try {
			
			E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
			if (E2ETCName == null){
				
				System.out.println("E2E TC Name is not avalable in E2E DB for the TC" + TCName);
				
			}else{		
						E2EFieldName = E2E_DB_Update.Select_E2EFieldName("FIELD_NM", "FIELD_NAME_MASTER", "FIELD_ID", "MASTER_FIELD_ID", "APP_FIELD_NAME_MAPPING", "APP_FIELD_NM",FieldName,"APP_NM","ICON");
					}
			
			if (E2EFieldName == null){
				
				System.out.println("E2E Field Name is not avalable in E2E DB for the Field " + FieldName);
				
			}else{
				System.out.println(E2ETCName +" " + E2EFieldName + " " + Fieldvalue);
				E2E_DB_Update.updatequery(E2ETCName, E2EFieldName, Fieldvalue);	
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Issue in Output data component. Field Name: " + FieldName + "Field Value: " + Fieldvalue);		
		}
		}else{
			
			System.out.println("Null value Retrived from Application for the Field " + FieldName);
		}
	}
	
    public String GetData(String FieldName){  
        String TCName = currentTC; 
        String Fieldvalue = "";
        String E2ETCName = "";
        String E2EFieldName = "";            
        int VersionNumber = 0;
        try {
                   E2ETCName = E2E_DB_Update.Select_E2EScenarioName("E2E_TEST_CASE_ID", "E2E_TESTCASES", "CALLED_TEST_CASE_NM", TCName);
                   E2EFieldName = E2E_DB_Update.Select_E2EFieldName("FIELD_NM", "FIELD_NAME_MASTER", "FIELD_ID", "MASTER_FIELD_ID", "APP_FIELD_NAME_MAPPING", "APP_FIELD_NM",FieldName,"APP_NM","ICON");
                   VersionNumber = E2E_DB_Update.getversionumber(E2ETCName, E2EFieldName);
                   Fieldvalue = E2E_DB_Update.getValue(E2ETCName, E2EFieldName, VersionNumber);
        } catch (SQLException e) {
        	e.printStackTrace();
        	System.out.println("Issue in retreving data from E2E DB. Field Name: " + FieldName);	
            
        }
        return Fieldvalue;                                                                           
      }
	
    
    public boolean JavaScriptDynamicWait(WebElement sElement,
            JavascriptExecutor js) throws Exception {
   /*  boolean status = false;
     for (int i = 1; i <= 60; i++) {
            System.out.println("Document Ajax State = "
                         + js.executeScript("return Ext.Ajax.isLoading();")
                                       .toString());
            Boolean isAjaxRunning = Boolean.valueOf(js.executeScript("return jQuery.active") == 0); // returns true if ajax call
                                                                               // is currently in progress
                         .toString());
            if (isAjaxRunning.booleanValue()) {
                   status = true;
                   break;
            }
            Thread.sleep(1000);// wait for one secnod then check if ajax is
                                             // completed
     }*/
     WebDriverWait wait = new WebDriverWait(driver.getWebDriver(), 60);
    wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.id("pleaseWait"))));// (By.id(readAttriID1)));
     // logger.info("End Wait....2");
     return status;
}

    public boolean waitForJSandJQueryToLoad() {

        WebDriverWait wait = new WebDriverWait(driver, 30);

        // wait for jQuery to load
        ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
          @Override
          public Boolean apply(WebDriver driver) {
            try {
              return ((Long) js.executeScript("return jQuery.active") == 0);
            }
            catch (Exception e) {
              // no jQuery present
              return true;
            }
          }
        };

        // wait for Javascript to load
        ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
          @Override
          public Boolean apply(WebDriver driver) {
            return js.executeScript("return document.readyState")
            .toString().equals("complete");
          }
        };

      return wait.until(jQueryLoad) && wait.until(jsLoad);
    }
   
    public boolean isDisplayesUI(WebElement objUI){
    	
    	if (objUI == null){
    		return false;
    	}
    	else{
    		try{
        		return objUI.isDisplayed();        		
        	}
        	catch (NoSuchElementException e){
        		return false;
        	}
    	
    	}
    	
    	
    			
    }
    
 public void launchpcqa(){
    	
		driver.get("http://biqa2policycenter.thehartford.com/pc/PolicyCenter.do");
		driver.manage().window().maximize();
    }

    
    
	public void pcvalidation()
	{

/*		driver.findElement(By.xpath("//*[@id='TabBar:SearchTab-btnInnerEl']")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Policies') and contains(@class,'x-tree-node-text ')]")).click();
		//String policynum=dataTable.getData("Pcvalidation", "Policy");
		//ReusableCommonComponents obj=new ReusableCommonComponents(scriptHelper);
		String DTpolicynumber_num =GetData("ELE_PolicyNumber");
		System.out.println(DTpolicynumber_num);
		String policynum=DTpolicynumber_num.substring(DTpolicynumber_num.length()-6,DTpolicynumber_num.length());
		driver.findElement(By.xpath("//*[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:policyNumber-inputEl']")).sendKeys(policynum);*/
		
		waitToBeDisplayed(3);
		driver.findElement(By.xpath("//*[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search']")).click();
		waitToBeDisplayed(3);
		driver.findElement(By.xpath("//*[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearch_ResultsLV:0:PolicyNumber']")).click();
		waitToBeDisplayed(3);
		JavascriptExecutor jsDriver = (JavascriptExecutor)driver.getWebDriver();
		String SUB=dataTable.getData("Pcvalidation", "CAL_Pcvalidation_SUB");
		jsDriver.executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath("//*[@id='HIGPolicyFile_Summary:0:Subject']")));
		driver.findElement(By.xpath("//*[contains(@id,'HIGPolicyFile_Summary') and contains(text(),'"+SUB+"')]")).click();
		String subject=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:Subject-inputEl']")).getText().replaceAll(" ", "");
		String description=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:Description-inputEl']")).getText();
		String assignedto=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:AssignedTo-inputEl']")).getText();
		String spacesub=SUB.replaceAll(" ","");
		//PC content validation
		if(spacesub.contains(subject))
		{
			report.updateTestLog("Subject should be as expected", "Subject is as expected", Status.PASS);
			System.out.println("Subject PASS");
		}
		else
	    {
	    	System.out.println("Subject FAIL");
	    	report.updateTestLog("Subject should be as expected", "Subject is as expected", Status.FAIL);
	    }
		String des=dataTable.getData("Pcvalidation", "Description");
		if(description.contains(des))
		{
			report.updateTestLog("Description should be as expected", "Description is as expected", Status.PASS);
			System.out.println("Description PASS");
		}
		else
	    {
	    	System.out.println("Description FAIL");
	    	report.updateTestLog("Description should be as expected", "Description is as expected", Status.FAIL);
	    }
		String assignto=dataTable.getData("Pcvalidation", "Assignedto");
//		if(assignedto.contains(assignto))
//		{
//			report.updateTestLog("Assigned to should be as expected", "Assigned to is as expected", Status.PASS);
//			System.out.println("Assigned to PASS");
//		}
		//Date calculation
		WebElement targetdate=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:TargetDate-inputEl']"));
		jsDriver.executeScript("arguments[0].scrollIntoView(true);",targetdate);
		String target=targetdate.getText();
		System.out.println("Target date"+target);
		String escalationdate=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:EscalationDate-inputEl']")).getText();
		System.out.println("Escalation date"+escalationdate);
		
		
		Date date=new Date();
	    Calendar calendar = Calendar.getInstance();
	    date=calendar.getTime(); 
	    SimpleDateFormat s;
	    s=new SimpleDateFormat("MM/dd/yy");

	    System.out.println(s.format(date));
	    String targdtdays=dataTable.getData("Pcvalidation", "Targetdate");
	    int days =Integer.parseInt(targdtdays);
	    
	    for(int i=0;i<days;i++)
	    {	    	
	    	
	    	calendar.add(Calendar.DATE, 1);
	    	
	    	 int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
	         if (dayOfWeek == Calendar.SATURDAY) { 
	        	
	        	calendar.add(Calendar.DATE, 2);
	        	
	        	
	         } 
	         else if (dayOfWeek == Calendar.SUNDAY) { 
	        	
	        	 calendar.add(Calendar.DATE, 1);
	        	
	         } 
	        
	        

	    }
	    date=calendar.getTime(); 
	    s=new SimpleDateFormat("MM/dd/YYYY");
	    System.out.println(s.format(date));
	    String caltargdate=s.format(date);
	    if(target.equals(caltargdate))
	    {
				report.updateTestLog("Target date should be as expected", "Target date is as expected", Status.PASS);
				System.out.println("Target date pass PASS");
		}
	    else
	    {
	    	System.out.println("target date FAIL");
	    	report.updateTestLog("Target date should be as expected", "Target date is as expected", Status.FAIL);
	    }
	    Date date1=new Date();
	    Calendar calendar1 = Calendar.getInstance();
	    date1=calendar1.getTime(); 
	    SimpleDateFormat s1;
	    s1=new SimpleDateFormat("MM/dd/YYYY");

	    System.out.println(s1.format(date1));
	    String escdtdays=dataTable.getData("Pcvalidation", "Escalationdate");
	    int days1 = Integer.parseInt(escdtdays);
	    System.out.println(days1);
	    for(int i=0;i<days1;i++)
	    {	  
	    	calendar1.add(Calendar.DATE, 1);
	    	
	    	 int dayOfWeek = calendar1.get(Calendar.DAY_OF_WEEK);
	         if (dayOfWeek == Calendar.SATURDAY) { 
	        	
	        	calendar1.add(Calendar.DATE, 2);
	        	
	        	
	         } 
	         else if (dayOfWeek == Calendar.SUNDAY) { 
	        	
	        	 calendar1.add(Calendar.DATE, 1);
	        	
	         } 

	    }
	    date1=calendar1.getTime(); 
	    s1=new SimpleDateFormat("MM/dd/YYYY");
	    System.out.println(s1.format(date1));
	    String calescdt=s1.format(date1);
	    if(escalationdate.equals(calescdt))
	    {
				report.updateTestLog("Escalation date should be as expected", "Escalation date is as expected", Status.PASS);
				System.out.println("Escalation pass PASS");
		}
	    else
	    {
	    	System.out.println("Escalation date FAIL");
	    	report.updateTestLog("Escalation date should be as expected", "Escalation date is as expected", Status.FAIL);
	    }
	    
	    WebElement SCoffshoreque=driver.findElement(By.xpath("//*[@id='ActivityDetailWorksheet:ActivityDetailScreen:ActivityDetailDV:AssignedTo-inputEl']"));

	    if(SCoffshoreque.getText().contains("SC Offshore UA -"))
	    {
	    	report.updateTestLog("Assigned to should be as expected", "Assigned to is as expected", Status.PASS);
			System.out.println("Assigned to PASS");
	    }
	    else
	    {
	    	System.out.println("Assigned to FAIL");
	    	report.updateTestLog("Assigned to should be as expected", "Assigned to is as expected", Status.FAIL);
	    }
	}
	
	public void loginPC()
	{
//    ArrayList<String> allwindows1=new ArrayList<String>(driver.getWindowHandles());
//    String parentWin="";
//    System.out.println(driver.getTitle());
//    for (String winHandle : allwindows1) {
//           driver.switchTo().window(winHandle);
//           System.out.println(driver.getTitle());
//           if(driver.getTitle().contains("ICON |") || driver.getTitle().contains("")) {
//                 parentWin=driver.getWindowHandle();
//           }
//           else{
//                 driver.close();
//           }
//    }
//   driver.switchTo().window(parentWin);

     driver.navigate().to("http://biqapolicycenter.thehartford.com/pc/PolicyCenter.do");
     driver.manage().window().maximize();

	}
	public void searchPolicyPC()
	{
		String strpolicy=GetData("ELE_ReAccessPolicy");
		String finalpolicynumber=strpolicy.substring(5,11);
//		String strPolicy = dataTable.getData("PolicyDetails", "EDI_PolicyNumberPC");
		driver.findElement(By.xpath("//*[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:policyNumber-inputEl']")).sendKeys(finalpolicynumber);;
	}
	
	public void searchPolicyICON()
	{
		String strPolicy = dataTable.getData("SearchPolicyPC", "EDI_PolicyNumberPC");
		
		driver.findElement(By.id("keywordPolicyNumber")).sendKeys(strPolicy);
	}
    
}

