/*     */ package de.dbsystel.custom.teststep;
/*     */ 
/*     */ import com.eviware.soapui.config.TestStepConfig;
/*     */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepResult;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepWithProperties;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansion;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansionContainer;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansionUtils;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunContext;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunner;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult.TestStepStatus;
/*     */ import com.eviware.soapui.support.UISupport;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationBuilder;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DataSourceLoopTestStep extends WsdlTestStepWithProperties implements PropertyExpansionContainer
/*     */ {
/*  22 */   public String dstarget = "";
/*  23 */   public String dssource1 = "";
/*     */   
/*     */ 
/*     */   protected DataSourceLoopTestStep(WsdlTestCase testCase, TestStepConfig config, boolean forLoadTest)
/*     */   {
/*  28 */     super(testCase, config, true, forLoadTest);
/*  29 */     if (!forLoadTest) {
/*  30 */       setIcon(UISupport.createImageIcon("datasourceloop.png"));
/*     */     }
/*  32 */     if (config.getConfig() != null)
/*     */     {
/*  34 */       readConfig(config);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readConfig(TestStepConfig config)
/*     */   {
/*  40 */     XmlObjectConfigurationReader reader = new XmlObjectConfigurationReader(config.getConfig());
/*  41 */     dstarget = reader.readString("dstarget", "");
/*  42 */     dssource1 = reader.readString("dssource1", "");
/*     */   }
/*     */   
/*     */   private void updateConfig()
/*     */   {
/*  47 */     XmlObjectConfigurationBuilder builder = new XmlObjectConfigurationBuilder();
/*  48 */     builder.add("dstarget", dstarget);
/*  49 */     builder.add("dssource1", dssource1);
/*  50 */     ((TestStepConfig)getConfig()).setConfig(builder.finish());
/*     */   }
/*     */   
/*     */   public String getTarget()
/*     */   {
/*  55 */     return dstarget;
/*     */   }
/*     */   
/*     */   public void setTarget(String dstarget)
/*     */   {
/*  60 */     String old = this.dstarget;
/*  61 */     this.dstarget = dstarget;
/*  62 */     updateConfig();
/*  63 */     notifyPropertyChanged("dstarget", old, dstarget);
/*     */   }
/*     */   
/*     */   public String getDataSource()
/*     */   {
/*  68 */     return dssource1;
/*     */   }
/*     */   
/*     */   public void setDataSource(String dssource1)
/*     */   {
/*  73 */     String old = this.dssource1;
/*  74 */     this.dssource1 = dssource1;
/*  75 */     updateConfig();
/*  76 */     notifyPropertyChanged("dssource1", old, dssource1);
/*     */   }
/*     */   
/*     */   public TestStepResult run(TestCaseRunner testRunner, TestCaseRunContext context) {
/*  80 */     WsdlTestStepResult result = new WsdlTestStepResult(this);
/*  81 */     if (DataSourceTestStep.iteration == 0) {
/*  82 */       result.setStatus(TestStepResult.TestStepStatus.OK);
/*     */     } else {
/*  84 */       result.setStatus(TestStepResult.TestStepStatus.OK);
/*  85 */       result.addMessage("Iteration - " + DataSourceTestStep.iteration);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     return result;
/*     */   }
/*     */   
/*     */   public PropertyExpansion[] getPropertyExpansions()
/*     */   {
/* 102 */     List<PropertyExpansion> result = new ArrayList();
/* 103 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "dstarget"));
/* 104 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "dssource1"));
/* 105 */     return (PropertyExpansion[])result.toArray(new PropertyExpansion[result.size()]);
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.DataSourceLoopTestStep
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */