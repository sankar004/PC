/*    */ package de.dbsystel.custom.teststep;
/*    */ 
/*    */ import com.eviware.soapui.impl.EmptyPanelBuilder;
/*    */ import com.eviware.soapui.model.PanelBuilder;
/*    */ import com.eviware.soapui.model.util.PanelBuilderFactory;
/*    */ import com.eviware.soapui.ui.desktop.DesktopPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceLoopTestStepPanelBuilderFactory
/*    */   implements PanelBuilderFactory<DataSourceLoopTestStep>
/*    */ {
/*    */   public PanelBuilder<DataSourceLoopTestStep> createPanelBuilder()
/*    */   {
/* 16 */     return new DataSourceLoopTestStepPanelBuilder();
/*    */   }
/*    */   
/*    */   public Class<DataSourceLoopTestStep> getTargetModelItem() {
/* 20 */     return DataSourceLoopTestStep.class;
/*    */   }
/*    */   
/*    */   public static class DataSourceLoopTestStepPanelBuilder
/*    */     extends EmptyPanelBuilder<DataSourceLoopTestStep>
/*    */   {
/*    */     public DesktopPanel buildDesktopPanel(DataSourceLoopTestStep modelItem)
/*    */     {
/* 28 */       return new DataSourceLoopTestStepDesktopPanel(modelItem);
/*    */     }
/*    */     
/*    */     public boolean hasDesktopPanel() {
/* 32 */       return true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.DataSourceLoopTestStepPanelBuilderFactory
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */