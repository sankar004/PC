/*    */ package de.dbsystel.custom.teststep;
/*    */ 
/*    */ import com.eviware.soapui.impl.EmptyPanelBuilder;
/*    */ import com.eviware.soapui.model.PanelBuilder;
/*    */ import com.eviware.soapui.model.util.PanelBuilderFactory;
/*    */ import com.eviware.soapui.ui.desktop.DesktopPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EqualsTestStepPanelBuilderFactory
/*    */   implements PanelBuilderFactory<EqualsTestStep>
/*    */ {
/*    */   public PanelBuilder<EqualsTestStep> createPanelBuilder()
/*    */   {
/* 16 */     return new EqualsTestStepPanelBuilder();
/*    */   }
/*    */   
/*    */   public Class<EqualsTestStep> getTargetModelItem() {
/* 20 */     return EqualsTestStep.class;
/*    */   }
/*    */   
/*    */   public static class EqualsTestStepPanelBuilder
/*    */     extends EmptyPanelBuilder<EqualsTestStep>
/*    */   {
/*    */     public DesktopPanel buildDesktopPanel(EqualsTestStep modelItem)
/*    */     {
/* 28 */       return new EqualsTestStepDesktopPanel(modelItem);
/*    */     }
/*    */     
/*    */     public boolean hasDesktopPanel() {
/* 32 */       return true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.EqualsTestStepPanelBuilderFactory
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */