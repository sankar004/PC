/*     */ package de.dbsystel.custom.teststep;
/*     */ 
/*     */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*     */ import com.eviware.soapui.support.components.JUndoableTextField;
/*     */ import com.eviware.soapui.support.components.SimpleBindingForm;
/*     */ import com.eviware.soapui.ui.support.ModelItemDesktopPanel;
/*     */ import com.jgoodies.binding.PresentationModel;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.text.Document;
/*     */ 
/*     */ public class EqualsTestStepDesktopPanel extends ModelItemDesktopPanel<EqualsTestStep>
/*     */ {
/*     */   private javax.swing.JLabel label;
/*     */   private String fileName;
/*     */   private JFileChooser jFileChooser;
/*     */   private JButton brwButton;
/*     */   private JComboBox TargetStep;
/*     */   private JUndoableTextField ResponsePath;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PresentationModel<EqualsTestStep> equalsTestStepPresentationModel;
/*     */   
/*     */   public EqualsTestStepDesktopPanel(EqualsTestStep modelItem)
/*     */   {
/*  34 */     super(modelItem);
/*  35 */     buildUI();
/*     */   }
/*     */   
/*     */   private void buildUI()
/*     */   {
/*  40 */     equalsTestStepPresentationModel = new PresentationModel(getModelItem());
/*  41 */     SimpleBindingForm form = new SimpleBindingForm(equalsTestStepPresentationModel);
/*  42 */     form.addSpace();
/*  43 */     form.appendHeading("Equals Assertion");
/*  44 */     form.addSpace();
/*  45 */     form.addSpace();
/*  46 */     form.addSpace();
/*  47 */     form.append("Select Target Step", cmbTarget());
/*  48 */     form.append("Response Path", textFieldResponse());
/*  49 */     form.addComponentWithoutLabel(browseButton());
/*  50 */     form.getPanel().setBorder(javax.swing.BorderFactory.createEmptyBorder(3, 3, 3, 3));
/*  51 */     add(new javax.swing.JScrollPane(form.getPanel()));
/*     */   }
/*     */   
/*     */   private JComboBox cmbTarget()
/*     */   {
/*  56 */     TargetStep = new JComboBox();
/*  57 */     TargetStep.getModel().setSelectedItem(((EqualsTestStep)getModelItem()).getTarget());
/*  58 */     for (int i = 0; i < ((EqualsTestStep)getModelItem()).getTestCase().getTestStepCount(); i++) {
/*  59 */       if ((((EqualsTestStep)getModelItem()).getTestCase().getTestStepAt(i) instanceof com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStep)) {
/*  60 */         TargetStep.addItem(((EqualsTestStep)getModelItem()).getTestCase().getTestStepAt(i).getName().toString());
/*     */       }
/*     */     }
/*  63 */     TargetStep.setPreferredSize(new Dimension(200, 20));
/*     */     
/*  65 */     TargetStep.getModel().addListDataListener(new com.eviware.soapui.support.ListDataChangeListener()
/*     */     {
/*     */       public void dataChanged(ListModel listModel) {
/*  68 */         ((EqualsTestStep)getModelItem()).setTarget(TargetStep.getModel().getSelectedItem().toString());
/*     */       }
/*     */       
/*  71 */     });
/*  72 */     return TargetStep;
/*     */   }
/*     */   
/*     */   private javax.swing.JComponent textFieldResponse() {
/*  76 */     ResponsePath = new JUndoableTextField(((EqualsTestStep)getModelItem()).getResponse());
/*  77 */     ResponsePath.getDocument().addDocumentListener(new com.eviware.soapui.support.DocumentListenerAdapter()
/*     */     {
/*     */ 
/*     */       public void update(Document document)
/*     */       {
/*  82 */         ((EqualsTestStep)getModelItem()).setResponse(ResponsePath.getText());
/*     */       }
/*     */       
/*  85 */     });
/*  86 */     ResponsePath.setPreferredSize(new Dimension(300, 20));
/*  87 */     return ResponsePath;
/*     */   }
/*     */   
/*  90 */   private JButton browseButton() { brwButton = new JButton("");
/*  91 */     brwButton.setText("Browse");
/*     */     
/*  93 */     brwButton.addActionListener(new ClassBrowse());
/*  94 */     return brwButton;
/*     */   }
/*     */   
/*     */   public class ClassBrowse implements java.awt.event.ActionListener { public ClassBrowse() {}
/*     */     
/*  99 */     public void actionPerformed(ActionEvent e) { jFileChooser = new JFileChooser();
/* 100 */       jFileChooser.setDialogTitle("Select a file");
/* 101 */       FileNameExtensionFilter xmlfilter = new FileNameExtensionFilter("xml files (*.xml)", new String[] { "xml" });
/* 102 */       FileNameExtensionFilter txtfilter = new FileNameExtensionFilter("txt files (*.txt)", new String[] { "txt" });
/* 103 */       jFileChooser.setFileFilter(txtfilter);
/* 104 */       jFileChooser.setFileFilter(xmlfilter);
/* 105 */       int returnVal = jFileChooser.showOpenDialog((java.awt.Component)e.getSource());
/* 106 */       if (returnVal == 0) {
/* 107 */         File file = jFileChooser.getSelectedFile();
/*     */         try {
/* 109 */           fileName = file.toString();
/* 110 */           ResponsePath.setText(fileName);
/*     */         } catch (Exception ex) {
/* 112 */           System.out.println("problem accessing file" + file.getAbsolutePath());
/*     */         }
/*     */       }
/*     */       else {
/* 116 */         System.out.println("File access cancelled by user.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt)
/*     */   {
/* 123 */     super.propertyChange(evt);
/*     */     
/* 125 */     String newValue = String.valueOf(evt.getNewValue());
/* 126 */     if (evt.getPropertyName().equals("eqtarget"))
/*     */     {
/* 128 */       if (!newValue.equals(TargetStep.getModel().getSelectedItem().toString())) {
/* 129 */         TargetStep.getModel().setSelectedItem(newValue);
/*     */       }
/* 131 */     } else if (evt.getPropertyName().equals("response"))
/*     */     {
/* 133 */       if (!newValue.equals(ResponsePath.getText())) {
/* 134 */         ResponsePath.setText(newValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.EqualsTestStepDesktopPanel
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */