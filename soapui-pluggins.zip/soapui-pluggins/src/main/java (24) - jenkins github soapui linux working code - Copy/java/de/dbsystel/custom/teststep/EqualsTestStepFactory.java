/*    */ package de.dbsystel.custom.teststep;
/*    */ 
/*    */ import com.eviware.soapui.config.TestStepConfig;
/*    */ import com.eviware.soapui.config.TestStepConfig.Factory;
/*    */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*    */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
/*    */ import com.eviware.soapui.impl.wsdl.teststeps.registry.WsdlTestStepFactory;
/*    */ 
/*    */ public class EqualsTestStepFactory extends WsdlTestStepFactory
/*    */ {
/*    */   private static final String EMAIL_STEP_ID = "equals";
/*    */   
/*    */   public EqualsTestStepFactory()
/*    */   {
/* 15 */     super("equals", "Equals Assertion", "Checks the actual response xml is equal to predefined xml", "equals.png");
/*    */   }
/*    */   
/*    */   public WsdlTestStep buildTestStep(WsdlTestCase testCase, TestStepConfig config, boolean forLoadTest) {
/* 19 */     return new EqualsTestStep(testCase, config, forLoadTest);
/*    */   }
/*    */   
/*    */   public TestStepConfig createNewTestStep(WsdlTestCase testCase, String name) {
/* 23 */     TestStepConfig testStepConfig = TestStepConfig.Factory.newInstance();
/* 24 */     testStepConfig.setType("equals");
/* 25 */     testStepConfig.setName(name);
/* 26 */     return testStepConfig;
/*    */   }
/*    */   
/*    */   public boolean canCreate() {
/* 30 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.EqualsTestStepFactory
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */