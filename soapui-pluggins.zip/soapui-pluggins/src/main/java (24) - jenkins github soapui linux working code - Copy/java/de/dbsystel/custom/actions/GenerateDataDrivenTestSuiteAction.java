package de.dbsystel.custom.actions;

import com.eviware.soapui.config.TestStepConfig;
import com.eviware.soapui.impl.wsdl.WsdlInterface;
import com.eviware.soapui.impl.wsdl.WsdlOperation;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStep;
import com.eviware.soapui.impl.wsdl.teststeps.registry.WsdlTestRequestStepFactory;
import com.eviware.soapui.support.action.support.AbstractSoapUIAction;
import de.dbsystel.custom.FunctionLibrary;

public class GenerateDataDrivenTestSuiteAction extends AbstractSoapUIAction<WsdlInterface>
{
	public GenerateDataDrivenTestSuiteAction()
	{
		super("Generate DD TestSuite", "Generates TestSuite in Datadriven approach");
	}

	public void perform(WsdlInterface target, Object param)
	{
		String testSuiteSuffix = " TestSuite";
		String testCasePrefix = "";
		String testCaseSuffix = "";
		testCasePrefix = FunctionLibrary.getProperty("GenerateDDTestSuite.Testcaseprefix");
		testCaseSuffix = FunctionLibrary.getProperty("GenerateDDTestSuite.Testcasesuffix");
		WsdlTestSuite testSuite = target.getProject().addNewTestSuite(target.getName().toString() + testCaseSuffix);
		int totalOperations = target.getOperationCount();

		for (int iOperation = 0; iOperation < totalOperations; iOperation++)
		{	
			String operationName = target.getOperationAt(iOperation).getName().toString();
			int testCaseNo = iOperation + 1;
			String testcaseName = testCasePrefix + testCaseNo + " " + operationName + " " + testCaseSuffix;
			WsdlTestCase testCase = testSuite.addNewTestCase(testcaseName.trim());
			testCase.addTestStep("datasource1", "DataSource");
			WsdlOperation operation = target.getOperationAt(iOperation);
			WsdlTestRequestStepFactory testRequestStepFactory = new WsdlTestRequestStepFactory();
			TestStepConfig config = WsdlTestRequestStepFactory.createConfig(operation, operationName);
			WsdlTestRequestStep testRequestStep = (WsdlTestRequestStep)testCase.addTestStep(config);
			testRequestStep.getTestRequest().setRequestContent(target.getOperationAt(iOperation).getRequestAt(0).getRequestContent().toString());
			testCase.addTestStep("datasourceloop1", "DataSourceLoop");
		}
	}
}