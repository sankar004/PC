package de.dbsystel.custom.actions;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStep;
import com.eviware.soapui.support.UISupport;
import com.eviware.soapui.support.action.support.AbstractSoapUIAction;
import de.dbsystel.custom.FunctionLibrary;
import de.dbsystel.custom.listeners.TestSuiteListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class ExportInputParametersAction extends AbstractSoapUIAction<WsdlTestRequestStep>
{
	public static String excelFilePath;
	public static String sheetName = "";
	public static final String SOAPUI_ACTION_ID = "GenerateExcelFile";
	static String[] splitString;
	static String[] splitString2; boolean flag = true;

	public ExportInputParametersAction() {
		super("Generate Excel", "Generates Excel with Input Parameters");
	}

	public void perform(WsdlTestRequestStep target, Object param)
	{
		String directory = TestSuiteListener.currentDir;
		String testdatafolderpath = "";
		testdatafolderpath = FunctionLibrary.getProperty("GenerateDDTestSuite.Testdata.Path");

		if (testdatafolderpath.isEmpty()) {
			String defaulttestdatafolderpath = directory + "input-testdata\\";
			File file = new File(defaulttestdatafolderpath);
			if (!file.exists()) {
				file.mkdir();
			}
			testdatafolderpath = defaulttestdatafolderpath;
		}
		
		String testSuiteName = target.getTestCase().getTestSuite().getName().toString();
		File filetestSuite = new File(testdatafolderpath + testSuiteName);
		if (!filetestSuite.exists()) {
			filetestSuite.mkdir();
		}
		testdatafolderpath = testdatafolderpath + testSuiteName + "\\";
		excelFilePath = testdatafolderpath + "\\" + target.getTestCase().getName().toString() + "_" + FunctionLibrary.getDate(0, "MM_dd_yyyy_h_mm_ss") + ".xls";
		
		try {
			FunctionLibrary.generateBlankExcel(excelFilePath);
		} catch (FileNotFoundException ex) {
			UISupport.showErrorMessage("Excel updation: " + ex.getMessage().toString());
			System.out.println("Excel updation: " + ex.getMessage().toString());
			ex.printStackTrace();
		} catch (Exception ex1) {
			UISupport.showErrorMessage("Excel updation: " + ex1.getMessage().toString());
			System.out.println("Excel updation: " + ex1.getMessage().toString());
			ex1.printStackTrace();
		}    

		ArrayList<String> inputParameters = new ArrayList();
		com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequest testRequest = target.getTestRequest();
		sheetName = target.getName().toString();
		String content = testRequest.getRequestContent();
		splitString = content.split("\\n");
		
		for (int k = 1; k < splitString.length; k++) {
			String linecontent = splitString[k];
			String keyValue = "";
			if (linecontent.contains("?") == true) {
				splitString2 = linecontent.split("\\?");
				for (int m = 1; m < splitString2.length; m++) {
					String linecontent2 = splitString2[m];
					if (linecontent2.contains(":")) {
						int startchar = linecontent2.indexOf(":");
						int endchar = linecontent2.indexOf(">");
						keyValue = linecontent2.substring(startchar + 1, endchar);
					}
					else {
						int startchar = linecontent2.indexOf("<");
						int endchar = linecontent2.indexOf(">");
						keyValue = linecontent2.substring(startchar + 1, endchar);
					}
					inputParameters.add(keyValue);
				}
				target.getTestCase().setPropertyValue(keyValue, "");
			}
		}
		
		try {
			FunctionLibrary.updateInputParameteters(sheetName, inputParameters, excelFilePath);
		} catch (IOException e) {
			UISupport.showInfoMessage("Excel updation: " + e.getMessage().toString());
			System.out.println("Excel updation: " + e.getMessage().toString());
			e.printStackTrace();
		}
	}
}