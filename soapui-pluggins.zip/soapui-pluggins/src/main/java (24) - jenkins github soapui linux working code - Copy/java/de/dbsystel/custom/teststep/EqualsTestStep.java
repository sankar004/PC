/*     */ package de.dbsystel.custom.teststep;
/*     */ 
/*     */ import com.eviware.soapui.config.TestStepConfig;
/*     */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStep;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepResult;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepWithProperties;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansion;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansionUtils;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunContext;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunner;
/*     */ import com.eviware.soapui.model.testsuite.TestStep;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult.TestStepStatus;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult;
/*     */ import com.eviware.soapui.support.UISupport;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationBuilder;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationReader;
/*     */ import groovy.util.Node;
/*     */ import groovy.util.XmlNodePrinter;
/*     */ import groovy.util.XmlParser;
/*     */ import groovy.xml.XmlUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.custommonkey.xmlunit.DetailedDiff;
/*     */ import org.custommonkey.xmlunit.Diff;
/*     */ import org.custommonkey.xmlunit.Difference;
/*     */ import org.custommonkey.xmlunit.XMLUnit;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class EqualsTestStep extends WsdlTestStepWithProperties implements com.eviware.soapui.model.propertyexpansion.PropertyExpansionContainer
/*     */ {
/*  34 */   private String eqStepTarget = "";
/*  35 */   private String eqStepResponse = "";
/*     */   
/*     */   protected EqualsTestStep(WsdlTestCase testCase, TestStepConfig config, boolean forLoadTest)
/*     */   {
/*  39 */     super(testCase, config, true, forLoadTest);
/*  40 */     if (!forLoadTest) {
/*  41 */       setIcon(UISupport.createImageIcon("equals.png"));
/*     */     }
/*  43 */     if (config.getConfig() != null)
/*     */     {
/*  45 */       readConfig(config);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readConfig(TestStepConfig config)
/*     */   {
/*  51 */     XmlObjectConfigurationReader reader = new XmlObjectConfigurationReader(config.getConfig());
/*  52 */     eqStepTarget = reader.readString("eqtarget", "");
/*  53 */     eqStepResponse = reader.readString("response", "");
/*     */   }
/*     */   
/*     */   private void updateConfig()
/*     */   {
/*  58 */     XmlObjectConfigurationBuilder builder = new XmlObjectConfigurationBuilder();
/*  59 */     builder.add("eqtarget", eqStepTarget);
/*  60 */     builder.add("response", eqStepResponse);
/*  61 */     ((TestStepConfig)getConfig()).setConfig(builder.finish());
/*     */   }
/*     */   
/*     */   public String getTarget()
/*     */   {
/*  66 */     return eqStepTarget;
/*     */   }
/*     */   
/*     */   public void setTarget(String eqtarget)
/*     */   {
/*  71 */     String old = eqStepTarget;
/*  72 */     eqStepTarget = eqtarget;
/*  73 */     updateConfig();
/*  74 */     notifyPropertyChanged("eqtarget", old, eqtarget);
/*     */   }
/*     */   
/*     */   public String getResponse()
/*     */   {
/*  79 */     return eqStepResponse;
/*     */   }
/*     */   
/*     */   public void setResponse(String response)
/*     */   {
/*  84 */     String old = eqStepResponse;
/*  85 */     eqStepResponse = response;
/*  86 */     updateConfig();
/*  87 */     notifyPropertyChanged("response", old, response);
/*     */   }
/*     */   
/*     */ 
/*     */   public com.eviware.soapui.model.testsuite.TestStepResult run(TestCaseRunner testRunner, TestCaseRunContext context)
/*     */   {
/*  93 */     WsdlTestStepResult result = new WsdlTestStepResult(this);
/*     */     
/*  95 */     StringWriter writer = new StringWriter();
/*     */     
/*  97 */     Diff xmlDiff = null;
/*     */     
/*  99 */     Node expXml = null;
/* 100 */     Node expResponse = null;
/* 101 */     String expResponseFinal = "";
/* 102 */     XmlParser xmlParser = null;
/*     */     
/*     */ 
/*     */ 
/* 106 */     int currTestStep = context.getCurrentStepIndex();
/* 107 */     String soapRequestName = context.expand(eqStepTarget).toString();
/* 108 */     if (!soapRequestName.isEmpty()) {
/* 109 */       TestStep testStep = testRunner.getTestCase().getTestStepByName(soapRequestName);
/*     */       
/* 111 */       if ((testStep instanceof WsdlTestRequestStep)) {
/* 112 */         String actResponseFinal = testStep.getPropertyValue("response").toString();
/*     */         
/*     */ 
/*     */ 
/* 116 */         String expRespFilePath = context.expand(eqStepResponse).toString();
/* 117 */         if (expRespFilePath != "")
/*     */         {
/*     */           try {
/* 120 */             xmlParser = new XmlParser();
/* 121 */             expResponse = xmlParser.parse(expRespFilePath);
/* 122 */             String expResponse1 = "";
/* 123 */             expResponse1 = XmlUtil.serialize(expResponse);
/* 124 */             expXml = xmlParser.parseText(expResponse1);
/* 125 */             new XmlNodePrinter(new PrintWriter(writer)).print(expXml);
/* 126 */             String expResponse2 = writer.toString();
/* 127 */             Node expXml2 = null;
/* 128 */             expXml2 = xmlParser.parseText(expResponse2);
/* 129 */             expResponseFinal = XmlUtil.serialize(expXml2);
/*     */           } catch (IOException e) {
/* 131 */             e.printStackTrace();
/* 132 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 133 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           } catch (SAXException e) {
/* 135 */             e.printStackTrace();
/* 136 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 137 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           } catch (Exception e) {
/* 139 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 140 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 145 */           XMLUnit.setIgnoreWhitespace(true);
/* 146 */           XMLUnit.setIgnoreComments(true);
/* 147 */           XMLUnit.setIgnoreDiffBetweenTextAndCDATA(true);
/* 148 */           XMLUnit.setNormalizeWhitespace(true);
/*     */           
/*     */           try
/*     */           {
/* 152 */             xmlDiff = new Diff(expResponseFinal, actResponseFinal);
/* 153 */             if (xmlDiff.identical() == true) {
/* 154 */               result.setStatus(TestStepResult.TestStepStatus.OK);
/*     */             } else {
/* 156 */               String allDifferences = "";
/*     */               
/* 158 */               Diff diff = new Diff(expResponseFinal, actResponseFinal);
/* 159 */               DetailedDiff detDiff = new DetailedDiff(diff);
/* 160 */               List differences = detDiff.getAllDifferences();
/* 161 */               for (Object object : differences) {
/* 162 */                 Difference difference = (Difference)object;
/* 163 */                 allDifferences = difference.toString() + "\n" + allDifferences;
/*     */               }
/* 165 */               result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 166 */               result.addMessage(allDifferences);
/*     */             }
/*     */           } catch (SAXException e) {
/* 169 */             e.printStackTrace();
/* 170 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 171 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           } catch (IOException e) {
/* 173 */             e.printStackTrace();
/* 174 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 175 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           } catch (Exception e) {
/* 177 */             result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 178 */             result.addMessage("Error  " + e.getMessage().toString());
/*     */           }
/*     */         } else {
/* 181 */           result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 182 */           result.addMessage("Expected Response file path is not specified");
/*     */         }
/*     */       } else {
/* 185 */         result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 186 */         result.addMessage("Target Step is not a SoapRequest Step");
/*     */       }
/*     */     } else {
/* 189 */       result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 190 */       result.addMessage("Target Step is empty");
/*     */     }
/*     */     
/*     */ 
/* 194 */     return result;
/*     */   }
/*     */   
/*     */   public PropertyExpansion[] getPropertyExpansions()
/*     */   {
/* 199 */     List<PropertyExpansion> result = new ArrayList();
/* 200 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "eqtarget"));
/* 201 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "response"));
/* 202 */     return (PropertyExpansion[])result.toArray(new PropertyExpansion[result.size()]);
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.EqualsTestStep
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */