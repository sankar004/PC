
package de.dbsystel.custom;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.eviware.soapui.SoapUI;

import de.dbsystel.custom.listeners.TestSuiteListener;

public class FunctionLibrary
{
	public static boolean run = true;

	public static void generateMasterExcel(String excelPath) throws IOException {
		if (!excelPath.isEmpty()) {
			File fileReport = new File(excelPath);
			if (!fileReport.exists()) {
				try {
					HSSFWorkbook workbook = new HSSFWorkbook();
					try {
						FileOutputStream out = new FileOutputStream(new File(excelPath));
						workbook.write(out);
						out.close();
						System.out.println("Test suite report sheet is created in file: "+excelPath);
						run = false;
					} catch (Exception e) {
						com.eviware.soapui.support.UISupport.showErrorMessage(excelPath + " file creation failed " + e.getMessage().toString());
						System.out.println(excelPath + " Test suite report file creation failed " + e.getMessage().toString());
						e.printStackTrace();
					}
				} catch (Exception e) {
					System.out.println(excelPath + " file creation failed " + e.getMessage().toString());
				}
			}
		} else {
			System.out.println("No excel path found");
		}
	}

	public static void updateMasterReport(String filePath, String testSuiteName, String testCaseName, int testCaseNo, int totalSteps, String testCasestatus,String date, String duration) throws IOException
	{
		java.io.FileInputStream input_document = null;
		try {
			input_document = new java.io.FileInputStream(new File(filePath));
			HSSFWorkbook workbookMaster = new HSSFWorkbook(input_document);
			HSSFSheet masterSheet = workbookMaster.getSheet(testSuiteName);
			if (masterSheet == null) {
				masterSheet = workbookMaster.createSheet(testSuiteName);
				HSSFRow row = masterSheet.createRow(0);
				HSSFCell cellTCNo = row.createCell(0);
				HSSFCell cellTCName = row.createCell(1);
				HSSFCell cellTotalSteps = row.createCell(2);
				HSSFCell cellTCStatus = row.createCell(3);
				HSSFCell cellTCDate = row.createCell(4);
				HSSFCell cellTCDuration = row.createCell(5);
				cellTCNo.setCellValue("Sl No");
				cellTCName.setCellValue("TestCase Name");
				cellTotalSteps.setCellValue("Total Steps");
				cellTCStatus.setCellValue("Status");
				cellTCDate.setCellValue("Execution Date");
				cellTCDuration.setCellValue("Duration in ms");         

				HSSFCellStyle masterHeaderstyle = workbookMaster.createCellStyle();
				masterHeaderstyle.setFillForegroundColor((short)44);
				masterHeaderstyle.setFillPattern((short)1);
				HSSFFont masterHeaderfont = workbookMaster.createFont();
				masterHeaderfont.setBoldweight((short)700);
				masterHeaderfont.setFontHeightInPoints((short)13);
				masterHeaderstyle.setFont(masterHeaderfont);

				for (int iHeaderRow = 0; iHeaderRow < row.getLastCellNum(); iHeaderRow++) {
					row.getCell(iHeaderRow).setCellStyle(masterHeaderstyle);
				}
			}
			int totalRows = masterSheet.getPhysicalNumberOfRows();
			HSSFRow rowMaster = null;
			HSSFCell cell5 = null;
			boolean tcFound = false;       

			HSSFCellStyle redstyle = workbookMaster.createCellStyle();
			HSSFFont redfont = workbookMaster.createFont();
			redfont.setColor(org.apache.poi.ss.usermodel.IndexedColors.RED.getIndex());
			redfont.setBoldweight((short)700);
			redstyle.setFont(redfont);
			HSSFCellStyle greenstyle = workbookMaster.createCellStyle();
			HSSFFont greenfont = workbookMaster.createFont();
			greenfont.setColor(org.apache.poi.ss.usermodel.IndexedColors.GREEN.getIndex());
			greenfont.setBoldweight((short)700);
			greenstyle.setFont(greenfont);       

			for (int iRow = 0; iRow < totalRows; iRow++) {
				HSSFRow row = masterSheet.getRow(iRow);
				HSSFCell cellA = row.getCell(1);
				String testCase1 = cellA.getStringCellValue().toString();
				if (testCase1.equalsIgnoreCase(testCaseName)) {
					rowMaster = masterSheet.getRow(iRow);
					tcFound = true;
					HSSFCell cell0 = rowMaster.getCell(0);
					HSSFCell cell1 = rowMaster.getCell(1);
					HSSFCell cell2 = rowMaster.getCell(2);
					HSSFCell cell3 = rowMaster.getCell(3);
					HSSFCell cell4 = rowMaster.getCell(4);
					cell5 = rowMaster.getCell(5);
					cell0.setCellValue(testCaseNo);
					cell1.setCellValue(testCaseName);
					cell2.setCellValue(totalSteps);
					cell3.setCellValue(testCasestatus);
					if (testCasestatus == "PASSED") {
						cell1.setCellStyle(greenstyle);
						cell3.setCellStyle(greenstyle);
					} else {
						cell1.setCellStyle(redstyle);
						cell3.setCellStyle(redstyle);
					}
					cell4.setCellValue(date);
					cell5.setCellValue(duration);
				} else if ((!tcFound) && (iRow == totalRows - 1)) {
					rowMaster = masterSheet.createRow(totalRows);
					HSSFCell cell0 = rowMaster.createCell(0);
					HSSFCell cell1 = rowMaster.createCell(1);
					HSSFCell cell2 = rowMaster.createCell(2);
					HSSFCell cell3 = rowMaster.createCell(3);
					HSSFCell cell4 = rowMaster.createCell(4);
					cell5 = rowMaster.createCell(5);
					cell0.setCellValue(testCaseNo);
					cell1.setCellValue(testCaseName);
					cell2.setCellValue(totalSteps);
					cell3.setCellValue(testCasestatus);
					if (testCasestatus == "PASSED") {
						cell1.setCellStyle(greenstyle);
						cell3.setCellStyle(greenstyle);
					} else {
						cell1.setCellStyle(redstyle);
						cell3.setCellStyle(redstyle);
					}
					cell4.setCellValue(date);
					cell5.setCellValue(duration);
				}
			}

			masterSheet.autoSizeColumn(1);
			masterSheet.autoSizeColumn(2);
			masterSheet.autoSizeColumn(3);
			masterSheet.autoSizeColumn(4);
			masterSheet.autoSizeColumn(5);
			try {
				FileOutputStream out = new FileOutputStream(new File(filePath));
				workbookMaster.write(out);
				out.close();
				SoapUI.log("Writing test case  result to excel." + testCaseName +":"+testCasestatus);
				System.out.println("Writing test case  result to excel." + testCaseName +":"+testCasestatus);
			} catch (Exception e) {
				System.out.println(filePath + " Unexcepted Error in Excel updation " + e.getMessage().toString());
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	public static void updateReport(String filePath, String testCaseName, java.util.ArrayList<String> testStepResults) throws IOException {
		java.io.FileInputStream input_document = null;
		try {
			input_document = new java.io.FileInputStream(new File(filePath));

			HSSFWorkbook workbookTestCase = new HSSFWorkbook(input_document);

			HSSFSheet testCaseSheet = workbookTestCase.getSheet(testCaseName);
			if (testCaseSheet != null) {
				int testCaseSheetIndex = workbookTestCase.getSheetIndex(testCaseName);
				workbookTestCase.removeSheetAt(testCaseSheetIndex);
			}
			testCaseSheet = workbookTestCase.createSheet(testCaseName);
			HSSFRow testStepHeaderRow = testCaseSheet.createRow(0);       

			HSSFCellStyle testStepFailRed = workbookTestCase.createCellStyle();
			HSSFFont testStepFailRedF = workbookTestCase.createFont();
			testStepFailRedF.setColor(org.apache.poi.ss.usermodel.IndexedColors.RED.getIndex());
			testStepFailRedF.setBoldweight((short)700);
			testStepFailRed.setFont(testStepFailRedF);       

			HSSFCellStyle testStepPassGreen = workbookTestCase.createCellStyle();
			HSSFFont testStepPassGreenF = workbookTestCase.createFont();
			testStepPassGreenF.setColor(org.apache.poi.ss.usermodel.IndexedColors.GREEN.getIndex());
			testStepPassGreenF.setBoldweight((short)700);
			testStepPassGreen.setFont(testStepPassGreenF);       

			HSSFCell headerStepNo = testStepHeaderRow.createCell(0);
			HSSFCell headerStepName = testStepHeaderRow.createCell(1);
			HSSFCell headerStepExp = testStepHeaderRow.createCell(2);
			HSSFCell headerStepAct = testStepHeaderRow.createCell(3);
			HSSFCell headerStepStatus = testStepHeaderRow.createCell(4);
			HSSFCell headerDuration = testStepHeaderRow.createCell(5);
			HSSFCell headerRequest = testStepHeaderRow.createCell(6);
			HSSFCell headerResponse = testStepHeaderRow.createCell(7);

			headerStepNo.setCellValue("Step No");
			headerStepName.setCellValue("Step Name");
			headerStepExp.setCellValue("Assertions Type");
			headerStepAct.setCellValue("Assertions Status");
			headerStepStatus.setCellValue("Exec Status");
			headerDuration.setCellValue("Duration in ms");
			headerRequest.setCellValue("Request");
			headerResponse.setCellValue("Response");
			
			HSSFCellStyle styleHeader = workbookTestCase.createCellStyle();
			styleHeader.setFillForegroundColor((short)44);
			styleHeader.setFillPattern((short)1);
			HSSFFont font = workbookTestCase.createFont();
			font.setBoldweight((short)700);
			font.setFontHeightInPoints((short)11);
			styleHeader.setFont(font);
			
			for (int iColHeader = 0; iColHeader < testStepHeaderRow.getLastCellNum(); iColHeader++) {
				testStepHeaderRow.getCell(iColHeader).setCellStyle(styleHeader);
			}       

			HSSFCellStyle styleWrap = workbookTestCase.createCellStyle();
			styleWrap.setWrapText(true);

			int totalTestSteps = testStepResults.size();
			for (int iTestStepRow = 1; iTestStepRow <= totalTestSteps; iTestStepRow++) {
				HSSFRow testStepRow = testCaseSheet.createRow(iTestStepRow);
				String testStepDetails = (String)testStepResults.get(iTestStepRow - 1);
				String[] arrStepDetails = testStepDetails.split(";;"); 
				SoapUI.log("Step results: " + Arrays.toString(arrStepDetails));
				System.out.println("Step results: " + Arrays.toString(arrStepDetails));

				for (int iStepDetailCol = 0; iStepDetailCol < arrStepDetails.length; iStepDetailCol++) {
					HSSFCell cell = testStepRow.createCell(iStepDetailCol);
					cell.setCellValue(arrStepDetails[iStepDetailCol]);
					if (iStepDetailCol == 4) {
						if (arrStepDetails[iStepDetailCol].toString().equalsIgnoreCase("OK")) {
							cell.setCellStyle(testStepPassGreen);
						} else {
							cell.setCellStyle(testStepFailRed);
						}
					}

					if ((iStepDetailCol == 6) || (iStepDetailCol == 7)) {
						org.apache.poi.ss.usermodel.CreationHelper HelperReqResp = workbookTestCase.getCreationHelper();

						if((iStepDetailCol == 6))
						{
							cell.setCellValue("Request");
						}
						else
						{
							cell.setCellValue("Response");
						}

						org.apache.poi.ss.usermodel.Hyperlink linkReqResp = HelperReqResp.createHyperlink(4);
						File f = new File(arrStepDetails[iStepDetailCol]);
						linkReqResp.setAddress(f.getCanonicalPath());
						cell.setHyperlink(linkReqResp);
					}
					if ((iStepDetailCol == 2) || (iStepDetailCol == 3)) {
						cell.setCellStyle(styleWrap);
					}
				}
			}
			testCaseSheet.autoSizeColumn(1);
			testCaseSheet.autoSizeColumn(2);
			testCaseSheet.autoSizeColumn(3);
			testCaseSheet.autoSizeColumn(4);
			testCaseSheet.autoSizeColumn(5);
			testCaseSheet.autoSizeColumn(6);
			testCaseSheet.autoSizeColumn(7);
			try
			{
				FileOutputStream out = new FileOutputStream(new File(filePath));
				workbookTestCase.write(out);
				out.close();
				/*System.out.println("Writing result to excel: " + String.join("", testStepResults));*/
				System.out.println(filePath + " updated successfully");
			} catch (Exception e) {
				System.out.println(filePath + " Unexcepted Error in Excel updation " + e.getMessage().toString());
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	}

	public static String getDate(int period, String format) {
		java.util.Calendar currDate = java.util.Calendar.getInstance();
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat(format);
		currDate.add(5, period);
		String date = formatter.format(currDate.getTime());
		return date;
	}

	public static void generateBlankExcel(String excelFilePath) throws FileNotFoundException
	{
		try
		{
			HSSFWorkbook workbook = new HSSFWorkbook();
			try {
				FileOutputStream out = new FileOutputStream(new File(excelFilePath));
				workbook.write(out);
				out.close();
				SoapUI.log("Test step report is updated successfully in report file "+excelFilePath);
				System.out.println("Test step report is updated successfully in report file "+excelFilePath);
			} catch (FileNotFoundException ex) {
				com.eviware.soapui.support.UISupport.showErrorMessage(" file creation failed " + ex.getMessage().toString());
				System.out.println(excelFilePath + " file creation failed " + ex.getMessage().toString());
				ex.printStackTrace();
			}       

		}
		catch (Exception e)
		{
			System.out.println(excelFilePath + " file creation failed " + e.getMessage().toString());
		}
	}

	public static void updateInputParameteters(String sheetName, java.util.ArrayList<String> inputParameters, String excelFilePath) throws IOException {
		java.io.FileInputStream input_document = null;
		
		try {
			input_document = new java.io.FileInputStream(new File(excelFilePath));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		HSSFWorkbook workbook = new HSSFWorkbook(input_document);
		HSSFSheet sheetInput = workbook.createSheet(sheetName);
		int arraySize = inputParameters.size();
		HSSFRow row = sheetInput.createRow(0);
		HSSFCell cell0 = row.createCell(0);
		cell0.setCellValue("Provide test data");

		for (int iRowHeader = 0; iRowHeader < arraySize; iRowHeader++) {
			HSSFCell cell = row.createCell(iRowHeader + 1);
			cell.setCellValue((String)inputParameters.get(iRowHeader));
		}        

		HSSFCellStyle yellowstyle = workbook.createCellStyle();
		yellowstyle.setFillForegroundColor((short)13);
		yellowstyle.setFillPattern((short)1);
		HSSFFont masterHeaderfont = workbook.createFont();
		masterHeaderfont.setBoldweight((short)700);
		masterHeaderfont.setFontHeightInPoints((short)13);
		yellowstyle.setFont(masterHeaderfont);

		for (int iRowHeader = 1; iRowHeader < arraySize; iRowHeader++) {
			HSSFCell cell = row.getCell(iRowHeader);
			String temp = cell.getStringCellValue().toString();
			for (int iRowHeader2 = iRowHeader + 1; iRowHeader2 <= arraySize; iRowHeader2++) {
				HSSFCell cell2 = row.getCell(iRowHeader2);
				String temp2 = cell2.getStringCellValue().toString();
				if (temp2.equalsIgnoreCase(temp)) {
					cell.setCellStyle(yellowstyle);
					cell2.setCellStyle(yellowstyle);
				}
			}
		}
		
		try
		{
			FileOutputStream out = new FileOutputStream(new File(excelFilePath));
			workbook.write(out);
			out.close();
			System.out.println(excelFilePath + " " + sheetName + " updated successfully");
		} catch (Exception e) {
			System.out.println(excelFilePath + " Unexcepted Error in Excel updation " + e.getMessage().toString());
			e.printStackTrace();
		}
	}

	public static String getProperty(String key) {				

		File file = new File(TestSuiteListener.currentDir.split("test-assets")[0] + "config"+TestSuiteListener.folderSeparatorForOs+"parameters.properties");
		String value = "";
		java.io.FileInputStream fileInput = null;
		java.util.Properties properties = null;
		
		try {
			fileInput = new java.io.FileInputStream(file);
			properties = new java.util.Properties();
			properties.load(fileInput);
			value = properties.getProperty(key);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return value;
	}

	public static void writeContent(String filepath, String rawRequestResponse) {
		java.io.BufferedWriter writer = null;
		
		try {
			writer = new java.io.BufferedWriter(new java.io.FileWriter(filepath));
			writer.write(rawRequestResponse); return;
		}
		catch (IOException localIOException1) {}finally
		{
			try {
				if (writer != null) {
					writer.close();
				}
			}
			catch (IOException localIOException3) {}
		}
	}
}