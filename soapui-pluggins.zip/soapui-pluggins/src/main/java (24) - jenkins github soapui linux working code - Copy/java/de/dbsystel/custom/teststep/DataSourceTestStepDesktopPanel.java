/*     */ package de.dbsystel.custom.teststep;
/*     */ 
/*     */ import com.eviware.soapui.support.DocumentListenerAdapter;
/*     */ import com.eviware.soapui.support.components.JUndoableTextField;
/*     */ import com.eviware.soapui.support.components.SimpleBindingForm;
/*     */ import com.eviware.soapui.ui.support.ModelItemDesktopPanel;
/*     */ import com.jgoodies.binding.PresentationModel;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.text.Document;
/*     */ 
/*     */ public class DataSourceTestStepDesktopPanel extends ModelItemDesktopPanel<DataSourceTestStep>
/*     */ {
/*     */   private JUndoableTextField File;
/*     */   private JUndoableTextField Worksheet;
/*     */   private JUndoableTextField StartAtCell;
/*     */   private JCheckBox IgnoreEmpty;
/*     */   private String fileName;
/*     */   public boolean IgnoreEmptyselected;
/*     */   private javax.swing.JList propList;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private JFileChooser jFileChooser;
/*     */   private JButton brwButton;
/*     */   private JSplitPane split;
/*     */   private PresentationModel<DataSourceTestStep> dataSourceTestStepPresentationModel;
/*     */   
/*     */   public DataSourceTestStepDesktopPanel(DataSourceTestStep modelItem)
/*     */   {
/*  44 */     super(modelItem);
/*  45 */     buildUI();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildUI()
/*     */   {
/*  59 */     add(createDataSourceFields());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void propertyChange(PropertyChangeEvent evt)
/*     */   {
/*  66 */     super.propertyChange(evt);
/*     */     
/*  68 */     String newValue = String.valueOf(evt.getNewValue());
/*  69 */     if (evt.getPropertyName().equals("file"))
/*     */     {
/*  71 */       if (!newValue.equals(File.getText())) {
/*  72 */         File.setText(newValue);
/*     */       }
/*  74 */     } else if (evt.getPropertyName().equals("worksheet"))
/*     */     {
/*  76 */       if (!newValue.equals(Worksheet.getText())) {
/*  77 */         Worksheet.setText(newValue);
/*     */       }
/*  79 */     } else if (evt.getPropertyName().equals("startatcell"))
/*     */     {
/*  81 */       if (!newValue.equals(StartAtCell.getText()))
/*  82 */         StartAtCell.setText(newValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private JPanel createPropertiesPanel() {
/*  87 */     JPanel panel = new JPanel();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     panel.setBorder(BorderFactory.createTitledBorder("Properties"));
/*  99 */     panel.setEnabled(false);
/* 100 */     panel.setForeground(Color.LIGHT_GRAY);
/* 101 */     return panel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JComponent createDataSourceFields()
/*     */   {
/* 116 */     dataSourceTestStepPresentationModel = new PresentationModel(getModelItem());
/* 117 */     SimpleBindingForm form = new SimpleBindingForm(dataSourceTestStepPresentationModel);
/* 118 */     form.addSpace();
/* 119 */     form.appendHeading("Configuration");
/* 120 */     form.addSpace();
/* 121 */     form.addSpace();
/* 122 */     form.addSpace();
/* 123 */     form.append("File:", textFieldFile());
/* 124 */     form.addComponentWithoutLabel(browseButton());
/* 125 */     form.append("Worksheet:", textFieldWorksheet());
/* 126 */     form.append("Start At Cell:", textFieldStartAt());
/* 127 */     form.append("Ignore Empty", checkBoxIgnoreEmpty());
/* 128 */     form.getPanel().setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/* 129 */     return new javax.swing.JScrollPane(form.getPanel());
/*     */   }
/*     */   
/*     */   private JButton browseButton()
/*     */   {
/* 134 */     brwButton = new JButton();
/* 135 */     brwButton.setText("Browse");
/*     */     
/* 137 */     brwButton.addActionListener(new ClassBrowse());
/* 138 */     return brwButton;
/*     */   }
/*     */   
/*     */   public class ClassBrowse implements ActionListener { public ClassBrowse() {}
/*     */     
/* 143 */     public void actionPerformed(ActionEvent e) { jFileChooser = new JFileChooser();
/* 144 */       jFileChooser.setDialogTitle("Select an excel file");
/* 145 */       FileNameExtensionFilter exlfilter = new FileNameExtensionFilter("excel files (*.xls)", new String[] { "xls" });
/* 146 */       jFileChooser.setFileFilter(exlfilter);
/* 147 */       int returnVal = jFileChooser.showOpenDialog((java.awt.Component)e.getSource());
/* 148 */       if (returnVal == 0) {
/* 149 */         File file = jFileChooser.getSelectedFile();
/*     */         try {
/* 151 */           fileName = file.toString();
/* 152 */           File.setText(fileName);
/*     */         } catch (Exception ex) {
/* 154 */           System.out.println("problem accessing file" + file.getAbsolutePath());
/*     */         }
/*     */       }
/*     */       else {
/* 158 */         System.out.println("File access cancelled by user.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private JUndoableTextField textFieldFile() {
/* 164 */     File = new JUndoableTextField(((DataSourceTestStep)getModelItem()).getFile());
/* 165 */     File.getDocument().addDocumentListener(new DocumentListenerAdapter()
/*     */     {
/*     */ 
/*     */       public void update(Document document)
/*     */       {
/* 170 */         ((DataSourceTestStep)getModelItem()).setFile(File.getText());
/*     */       }
/* 172 */     });
/* 173 */     File.setPreferredSize(new Dimension(300, 20));
/*     */     
/*     */ 
/*     */ 
/* 177 */     return File;
/*     */   }
/*     */   
/* 180 */   private JUndoableTextField textFieldWorksheet() { Worksheet = new JUndoableTextField(((DataSourceTestStep)getModelItem()).getWorksheet());
/* 181 */     Worksheet.getDocument().addDocumentListener(new DocumentListenerAdapter()
/*     */     {
/*     */ 
/*     */       public void update(Document document)
/*     */       {
/* 186 */         ((DataSourceTestStep)getModelItem()).setWorksheet(Worksheet.getText());
/*     */       }
/* 188 */     });
/* 189 */     Worksheet.setPreferredSize(new Dimension(100, 20));
/*     */     
/*     */ 
/*     */ 
/* 193 */     return Worksheet;
/*     */   }
/*     */   
/*     */   private JUndoableTextField textFieldStartAt() {
/* 197 */     StartAtCell = new JUndoableTextField(((DataSourceTestStep)getModelItem()).getStartAt());
/* 198 */     StartAtCell.getDocument().addDocumentListener(new DocumentListenerAdapter()
/*     */     {
/*     */ 
/*     */       public void update(Document document)
/*     */       {
/* 203 */         ((DataSourceTestStep)getModelItem()).setStartAt(StartAtCell.getText());
/*     */       }
/* 205 */     });
/* 206 */     StartAtCell.setPreferredSize(new Dimension(50, 20));
/* 207 */     StartAtCell.setEnabled(false);
/* 208 */     if (StartAtCell.getText().isEmpty()) {
/* 209 */       StartAtCell.setText("B2");
/*     */     }
/* 211 */     return StartAtCell;
/*     */   }
/*     */   
/* 214 */   private JCheckBox checkBoxIgnoreEmpty() { IgnoreEmpty = new JCheckBox("Select if rows containing empty data should be skipped");
/* 215 */     IgnoreEmpty.getModel().setSelected(((DataSourceTestStep)getModelItem()).getIgnoreEmpty().booleanValue());
/* 216 */     ActionListener actionListener = new ActionListener() {
/*     */       public void actionPerformed(ActionEvent actionEvent) {
/* 218 */         AbstractButton abstractButton = (AbstractButton)actionEvent.getSource();
/* 219 */         IgnoreEmptyselected = abstractButton.getModel().isSelected();
/* 220 */         ((DataSourceTestStep)getModelItem()).setIgnoreEmpty(Boolean.valueOf(IgnoreEmptyselected));
/*     */       }
/* 222 */     };
/* 223 */     IgnoreEmpty.addActionListener(actionListener);
/* 224 */     return IgnoreEmpty;
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.DataSourceTestStepDesktopPanel
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */