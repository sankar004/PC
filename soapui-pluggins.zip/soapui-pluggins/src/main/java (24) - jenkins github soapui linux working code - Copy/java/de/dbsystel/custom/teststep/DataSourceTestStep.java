/*     */ package de.dbsystel.custom.teststep;
import com.eviware.soapui.SoapUI;
/*     */ 
/*     */ import com.eviware.soapui.config.TestStepConfig;
/*     */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepResult;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStepWithProperties;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansion;
/*     */ import com.eviware.soapui.model.propertyexpansion.PropertyExpansionUtils;
/*     */ import com.eviware.soapui.model.testsuite.TestCase;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunContext;
/*     */ import com.eviware.soapui.model.testsuite.TestCaseRunner;
/*     */ import com.eviware.soapui.model.testsuite.TestStep;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult.TestStepStatus;
/*     */ import com.eviware.soapui.model.testsuite.TestStepResult;
/*     */ import com.eviware.soapui.support.GroovyUtils;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationBuilder;
/*     */ import com.eviware.soapui.support.xml.XmlObjectConfigurationReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ 
/*     */ public class DataSourceTestStep extends WsdlTestStepWithProperties implements com.eviware.soapui.model.propertyexpansion.PropertyExpansionContainer
/*     */ {
/*     */   private String file;
/*     */   private String worksheet;
/*     */   private String startatcell;
/*     */   private boolean ignoreempty;
/*     */   public static int totalIterations;
/*     */   public static int iteration;
/*     */   
/*     */   protected DataSourceTestStep(WsdlTestCase testCase, TestStepConfig config, boolean forLoadTest)
/*     */   {
/*  38 */     super(testCase, config, true, forLoadTest);
/*     */     
/*  40 */     if (!forLoadTest) {
/*  41 */       setIcon(com.eviware.soapui.support.UISupport.createImageIcon("datasource.png"));
/*     */     }
/*  43 */     if (config.getConfig() != null)
/*     */     {
/*  45 */       readConfig(config);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void readConfig(TestStepConfig config)
/*     */   {
/*  52 */     XmlObjectConfigurationReader reader = new XmlObjectConfigurationReader(config.getConfig());
/*  53 */     file = reader.readString("file", "");
/*  54 */     worksheet = reader.readString("worksheet", "");
/*  55 */     startatcell = reader.readString("startatcell", "");
/*  56 */     ignoreempty = reader.readBoolean("ignoreempty", false);
/*     */   }
/*     */   
/*     */   private void updateConfig()
/*     */   {
/*  61 */     XmlObjectConfigurationBuilder builder = new XmlObjectConfigurationBuilder();
/*  62 */     builder.add("file", file);
/*  63 */     builder.add("worksheet", worksheet);
/*  64 */     builder.add("startatcell", startatcell);
/*  65 */     builder.add("ignoreempty", ignoreempty);
/*  66 */     ((TestStepConfig)getConfig()).setConfig(builder.finish());
/*     */   }
/*     */   
/*     */   public String getFile() {
/*  70 */     return file;
/*     */   }
/*     */   
/*     */   public void setFile(String file)
/*     */   {
/*  75 */     String old = this.file;
/*  76 */     this.file = file;
/*  77 */     updateConfig();
/*  78 */     notifyPropertyChanged("file", old, file);
/*     */   }
/*     */   
/*     */   public String getWorksheet() {
/*  82 */     return worksheet;
/*     */   }
/*     */   
/*     */   public void setWorksheet(String worksheet)
/*     */   {
/*  87 */     String old = this.worksheet;
/*  88 */     this.worksheet = worksheet;
/*  89 */     updateConfig();
/*  90 */     notifyPropertyChanged("worksheet", old, worksheet);
/*     */   }
/*     */   
/*     */   public String getStartAt() {
/*  94 */     return startatcell;
/*     */   }
/*     */   
/*     */   public void setStartAt(String startatcell)
/*     */   {
/*  99 */     String old = this.startatcell;
/* 100 */     this.startatcell = startatcell;
/* 101 */     updateConfig();
/* 102 */     notifyPropertyChanged("startatcell", old, startatcell);
/*     */   }
/*     */   
/*     */   public Boolean getIgnoreEmpty() {
/* 106 */     return Boolean.valueOf(ignoreempty);
/*     */   }
/*     */   
/*     */   public void setIgnoreEmpty(Boolean ignoreempty)
/*     */   {
/* 111 */     Boolean old = Boolean.valueOf(this.ignoreempty);
/* 112 */     this.ignoreempty = ignoreempty.booleanValue();
/* 113 */     updateConfig();
/* 114 */     notifyPropertyChanged("ignoreempty", old, ignoreempty);
/*     */   }
/*     */   
/* 117 */   public com.eviware.soapui.model.testsuite.TestStepResult run(TestCaseRunner testRunner, TestCaseRunContext context) {
	GroovyUtils utils = new GroovyUtils(context);
/* 118 */     WsdlTestStepResult result = new WsdlTestStepResult(this);
/* 119 */     result.setStatus(TestStepResult.TestStepStatus.OK);
/*     */     
/*     */ 
/*     */ 
/* 123 */     String currentStepName = context.getCurrentStep().getName().toString();
/* 124 */     int totalSteps = testRunner.getTestCase().getTestStepCount();
/* 125 */     String dataSourceLoopTarget = "";
/* 126 */     String dataSourceLoopDatasource = "";
/*     */     DataFormatter formatter = new DataFormatter();
/*     */ 		String propName = "";
				String propVal = "";
/* 129 */     int datasourceloopStepNumber = 0;
/* 130 */     Boolean datasourceloopFlag = Boolean.valueOf(false);
/* 131 */     for (int i = testRunner.getRunContext().getCurrentStepIndex(); i < totalSteps; i++) {
/* 132 */       WsdlTestStep testStep = (WsdlTestStep)testRunner.getTestCase().getTestStepAt(i);
/* 133 */       String datasourceloop = ((TestStepConfig)testStep.getConfig()).getType().toString();
/* 134 */       if (datasourceloop.contains("datasourceloop1")) {
/* 135 */         datasourceloopFlag = Boolean.valueOf(true);
/* 136 */         datasourceloopStepNumber = i + 1;
/*     */         
/* 138 */         DataSourceLoopTestStep dataSourceLoopTestStep = (DataSourceLoopTestStep)testRunner.getTestCase().getTestStepAt(datasourceloopStepNumber - 1);
/* 139 */         dataSourceLoopTarget = dataSourceLoopTestStep.getTarget().toString();
/* 140 */         dataSourceLoopDatasource = dataSourceLoopTestStep.getDataSource().toString();
/*     */         
/* 142 */         if ((!dataSourceLoopTarget.isEmpty()) && (!dataSourceLoopDatasource.isEmpty()))
/*     */         {
/*     */ 
/* 145 */           int targetStepNumber = 0;
/* 146 */           Boolean datasourcetargetFlag = Boolean.valueOf(false);
/* 147 */           for (int j = 0; j < totalSteps; j++) {
/* 148 */             WsdlTestStep testStep1 = (WsdlTestStep)testRunner.getTestCase().getTestStepAt(j);
/* 149 */             String loopStepName = testStep1.getName().toString();
/* 150 */             if (loopStepName.equalsIgnoreCase(dataSourceLoopTarget)) {
/* 151 */               targetStepNumber = j + 1;
/* 152 */               datasourcetargetFlag = Boolean.valueOf(true);
/*     */               
/* 154 */               if (dataSourceLoopDatasource.equalsIgnoreCase(currentStepName))
/*     */               {
/* 156 */                 FileInputStream inpObj = null;
/*     */                 try {
/* 158 */                   inpObj = new FileInputStream(file);
/*     */                 } catch (FileNotFoundException e) {
/* 160 */                   e.printStackTrace();
/*     */                 }
/* 162 */                 HSSFWorkbook workbook = null;
/*     */                 try {
/* 164 */                   workbook = new HSSFWorkbook(inpObj);
/*     */                 } catch (IOException e) {
/* 166 */                   e.printStackTrace();
/*     */                 }
/* 168 */                 HSSFSheet sheet = workbook.getSheet(worksheet);
/* 169 */                 if (sheet != null)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/* 174 */                   int totalRows = sheet.getPhysicalNumberOfRows();
/* 175 */                   totalIterations = totalRows - 1;
/* 176 */                   HSSFRow headerObj = sheet.getRow(0);
/* 177 */                   int totalProperties = headerObj.getPhysicalNumberOfCells();
							
/* 178 */                   for (int iRow = 1; iRow < totalRows; iRow++) {
/* 179 */                     iteration = iRow;
/* 180 */                     HSSFRow rowObj = sheet.getRow(iRow);
/* 181 */                     if ((isEmptyRow(rowObj, totalProperties) != true) || (ignoreempty != true))
/*     */                     {
/*     */ 
/* 184 */                       int cols = headerObj.getPhysicalNumberOfCells();
								
								
/* 185 */                       for (int c = 1; c < cols; c++) {
/* 186 */                         HSSFCell headercellObj = headerObj.getCell(c);							
/* 187 */                         HSSFCell cellObj = rowObj.getCell(c);

							propName = String.valueOf(formatter.formatCellValue(headercellObj).trim());
							propVal = String.valueOf(formatter.formatCellValue(cellObj).trim());
/* 188 */                         testRunner.getTestCase().setPropertyValue(propName, null);
/*     */                         try {
/* 190 */                           testRunner.getTestCase().setPropertyValue(propName, propVal);
/*     */                         }
/*     */                         catch (NullPointerException localNullPointerException) {}
/*     */                       }
 
/* 214 */                       for (int k = targetStepNumber - 1; k < datasourceloopStepNumber; k++) {
/* 215 */                         String testStepToRun = testRunner.getTestCase().getTestStepAt(k).getName().toString();
/*     */                         
/* 217 */                         testRunner.runTestStepByName(testStepToRun);
/*     */                       }
/*     */                     }
/*     */                   }
/* 221 */                   totalIterations = 0;
/* 222 */                   iteration = 0;
/*     */                 } else {
/* 224 */                   result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 225 */                   result.addMessage("Worksheet " + worksheet + " not found");
/*     */                 }
/* 227 */                 break; }
/* 228 */               result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 229 */               result.addMessage("First DataSource loop step [Step Number: " + datasourceloopStepNumber + "] has a different source name: " + dataSourceLoopDatasource);
/*     */               
/* 231 */               break; }
/* 232 */             if ((!datasourcetargetFlag.booleanValue()) && (j == totalSteps - 1)) {
/* 233 */               result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 234 */               result.addMessage("No datasource target step in the given testcase: " + dataSourceLoopTarget);
/*     */             }
/*     */           }
/*     */           
/* 238 */           break;
/*     */         }
/* 240 */         result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 241 */         result.addMessage("Datasource loop Target and DataSource not avaialable. Target: " + dataSourceLoopTarget + " Source: " + dataSourceLoopDatasource);
/*     */       }
/* 243 */       else if ((!datasourceloopFlag.booleanValue()) && (i == totalSteps - 1)) {
/* 244 */         result.setStatus(TestStepResult.TestStepStatus.FAILED);
/* 245 */         result.addMessage("No datasource loop step in the given testcase");
/*     */       }
/*     */     }
/* 248 */     return result;
/*     */   }
/*     */   

		

/*     */   public PropertyExpansion[] getPropertyExpansions()
/*     */   {
/* 253 */     List<PropertyExpansion> result = new java.util.ArrayList();
/* 254 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "file"));
/* 255 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "worksheet"));
/* 256 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "startatcell"));
/* 257 */     result.addAll(PropertyExpansionUtils.extractPropertyExpansions(this, this, "ignoreempty"));
/* 258 */     return (PropertyExpansion[])result.toArray(new PropertyExpansion[result.size()]);
/*     */   }
/*     */   
/* 261 */   public boolean isEmptyRow(HSSFRow row, int totalCols) { boolean isEmptyRow = true;
/* 262 */     for (int cellNum = 1; cellNum < totalCols; cellNum++) {
/* 263 */       String str = row.getCell(cellNum, HSSFRow.CREATE_NULL_AS_BLANK).getStringCellValue();
/*     */       
/*     */ 
/*     */ 
/* 267 */       if (!str.toString().isEmpty()) {
/* 268 */         isEmptyRow = false;
/* 269 */         break;
/*     */       }
/*     */     }
/* 272 */     return isEmptyRow;
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.DataSourceTestStep
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */