/*     */ package de.dbsystel.custom.teststep;
/*     */ 
/*     */ import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
/*     */ import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
/*     */ import com.eviware.soapui.model.testsuite.TestStep;
/*     */ import com.eviware.soapui.support.ListDataChangeListener;
/*     */ import com.eviware.soapui.support.components.JUndoableTextField;
/*     */ import com.eviware.soapui.support.components.SimpleBindingForm;
/*     */ import com.eviware.soapui.ui.support.ModelItemDesktopPanel;
/*     */ import com.jgoodies.binding.PresentationModel;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListModel;
/*     */ 
/*     */ public class DataSourceLoopTestStepDesktopPanel
/*     */   extends ModelItemDesktopPanel<DataSourceLoopTestStep>
/*     */ {
/*  25 */   private JUndoableTextField TargetStep = null;
/*  26 */   private JUndoableTextField DataSourceStep = null;
/*     */   private JLabel label;
/*     */   private JComboBox cmbTargetStep;
/*     */   private JComboBox cmbDataSourceStep;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private PresentationModel<DataSourceLoopTestStep> dataSourceLoopTestStepPresentationModel;
/*     */   
/*     */   public DataSourceLoopTestStepDesktopPanel(DataSourceLoopTestStep modelItem)
/*     */   {
/*  35 */     super(modelItem);
/*  36 */     buildUI();
/*     */   }
/*     */   
/*     */   private void buildUI() {
/*  40 */     dataSourceLoopTestStepPresentationModel = new PresentationModel(getModelItem());
/*  41 */     SimpleBindingForm form = new SimpleBindingForm(dataSourceLoopTestStepPresentationModel);
/*  42 */     form.addSpace();
/*  43 */     form.appendHeading("Configure DataSource Loop");
/*  44 */     form.addSpace();
/*  45 */     form.append(title());
/*  46 */     form.addSpace();
/*  47 */     form.addSpace();
/*  48 */     form.addSpace();
/*  49 */     form.append("Target Step:", cmbTarget());
/*  50 */     form.append("DataSource Step:", cmbDataSource());
/*  51 */     form.getPanel().setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
/*  52 */     add(new JScrollPane(form.getPanel()));
/*     */   }
/*     */   
/*     */   private JComboBox cmbTarget() {
/*  56 */     cmbTargetStep = new JComboBox();
/*  57 */     cmbTargetStep.getModel().setSelectedItem(((DataSourceLoopTestStep)getModelItem()).getTarget());
/*  58 */     for (int i = 0; i < ((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepCount(); i++) {
/*  59 */       if (((((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepAt(i) instanceof TestStep)) && (!(((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepAt(i) instanceof DataSourceLoopTestStep))) {
/*  60 */         cmbTargetStep.addItem(((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepAt(i).getName().toString());
/*     */       }
/*     */     }
/*  63 */     cmbTargetStep.setPreferredSize(new Dimension(200, 20));
/*     */     
/*  65 */     cmbTargetStep.getModel().addListDataListener(new ListDataChangeListener()
/*     */     {
/*     */       public void dataChanged(ListModel listModel) {
/*  68 */         ((DataSourceLoopTestStep)getModelItem()).setTarget(cmbTargetStep.getModel().getSelectedItem().toString());
/*     */       }
/*     */       
/*  71 */     });
/*  72 */     return cmbTargetStep;
/*     */   }
/*     */   
/*     */   private JComboBox cmbDataSource() {
/*  76 */     cmbDataSourceStep = new JComboBox();
/*  77 */     cmbDataSourceStep.getModel().setSelectedItem(((DataSourceLoopTestStep)getModelItem()).getDataSource());
/*  78 */     for (int i = 0; i < ((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepCount(); i++) {
/*  79 */       if ((((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepAt(i) instanceof DataSourceTestStep)) {
/*  80 */         cmbDataSourceStep.addItem(((DataSourceLoopTestStep)getModelItem()).getTestCase().getTestStepAt(i).getName().toString());
/*     */       }
/*     */     }
/*  83 */     cmbDataSourceStep.setPreferredSize(new Dimension(200, 20));
/*     */     
/*  85 */     cmbDataSourceStep.getModel().addListDataListener(new ListDataChangeListener()
/*     */     {
/*     */       public void dataChanged(ListModel listModel) {
/*  88 */         ((DataSourceLoopTestStep)getModelItem()).setDataSource(cmbDataSourceStep.getModel().getSelectedItem().toString());
/*     */       }
/*     */       
/*  91 */     });
/*  92 */     return cmbDataSourceStep;
/*     */   }
/*     */   
/*     */   private JLabel title() {
/*  96 */     label = new JLabel("Set options for this DataSourceLoop step");
/*  97 */     label.setFont(new Font("Arial", 0, 12));
/*  98 */     label.setPreferredSize(new Dimension(200, 20));
/*  99 */     return label;
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt)
/*     */   {
/* 104 */     super.propertyChange(evt);
/*     */     
/* 106 */     String newValue = String.valueOf(evt.getNewValue());
/* 107 */     if (evt.getPropertyName().equals("dstarget"))
/*     */     {
/* 109 */       if (!newValue.equals(TargetStep.getText())) {
/* 110 */         TargetStep.setText(newValue);
/*     */       }
/* 112 */     } else if (evt.getPropertyName().equals("dssource1"))
/*     */     {
/* 114 */       if (!newValue.equals(DataSourceStep.getText())) {
/* 115 */         DataSourceStep.setText(newValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\SoapInstallationFolder\Soapuiplus-v3.1-Installer\INSTALLER\soapuiplus-v3.1-archive\soapuiplus-v3.1.jar
 * Qualified Name:     de.dbsystel.custom.teststep.DataSourceLoopTestStepDesktopPanel
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */