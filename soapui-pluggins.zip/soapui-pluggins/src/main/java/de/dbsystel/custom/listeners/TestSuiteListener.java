package de.dbsystel.custom.listeners;
import com.eviware.soapui.SoapUI;

import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestCaseRunner;
import com.eviware.soapui.model.testsuite.TestSuiteRunContext;
import com.eviware.soapui.model.testsuite.TestSuiteRunner;
import de.dbsystel.custom.FunctionLibrary;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

public class TestSuiteListener implements com.eviware.soapui.model.testsuite.TestSuiteRunListener
{
	public static String reportFilePath = "";
	public static String reportfolderpath = "";
	public static boolean testSuiteRunFlag = false;
	public String testSuiteName = "";
	public String testCaseName = "";
	public static String currentDir ="";
	public static String osName;
	public static String folderSeparatorForOs;
	
	public void beforeRun(TestSuiteRunner testSuiteRunner, TestSuiteRunContext testSuiteRunContext) {
		String osName = System.getProperty("os.name");
		if(osName.contains("Windows"))
		{
			SoapUI.log("Operating System is: "+osName);
			System.out.println("Operating System is: "+osName);
			folderSeparatorForOs = "\\";
		}else
		{
			SoapUI.log("Operating System is: "+osName);
			System.out.println("Operating System is: "+osName);
			folderSeparatorForOs = "/";
		}
		
		currentDir = FunctionLibrary.getProperty("CreateExcelReport.Save.Report.Path"); 
		if(testSuiteRunner.getTestSuite().getProject().getPropertyValue("RUN_PATH").length()<1)
		{
			setProjectProperties(testSuiteRunner);
		}
		setTestSuiteProperties(testSuiteRunner);
		this.testSuiteName = testSuiteRunner.getTestSuite().getName().toString();
		testSuiteRunFlag = true;
		String testSuiteName = testSuiteRunner.getTestSuite().getName().toString();
		String dateTimeStamp = "";			
		if(testSuiteRunner.getTestSuite().getProject().getPropertyValue("RUN_PATH").isEmpty())
		{
			int y=1;
			boolean isNotResultFolderCreated = true;
			while(isNotResultFolderCreated )
			{	
				reportfolderpath = FunctionLibrary.getProperty("CreateExcelReport.Save.Report.Path");
				if (reportfolderpath.isEmpty()) 
				{
					String defaultreportfolderpath = currentDir + folderSeparatorForOs+"reports"+folderSeparatorForOs;
					File fileFolderPath = new File(defaultreportfolderpath);
					if (!fileFolderPath.exists()) 
					{	        	    	   
						fileFolderPath.mkdir();
						SoapUI.log("Created folder...."+fileFolderPath);
						System.out.println("Created folder...."+fileFolderPath);
						reportfolderpath = defaultreportfolderpath;
						isNotResultFolderCreated = false;
					}

				}else
				{
					String dynamicResultFolderName = FunctionLibrary.getDate(0, "ddMMYYYY")+ "-Runs" + y; 			      

					if (!new File(reportfolderpath+dynamicResultFolderName).exists()) 
					{
						reportfolderpath = reportfolderpath+dynamicResultFolderName;	
						new File(reportfolderpath).mkdir();
						SoapUI.log("Created folder....."+reportfolderpath);
						System.out.println("Created folder...."+reportfolderpath);
						isNotResultFolderCreated = false;
					}
				} 
				y++;
			}
		}
		testSuiteRunner.getTestSuite().getProject().setPropertyValue("RUN_PATH", reportfolderpath);
		reportfolderpath=reportfolderpath+ folderSeparatorForOs +testSuiteName;
		new File(reportfolderpath).mkdir();  
		SoapUI.log("Created folder...."+reportfolderpath);
		System.out.println("Created folder...."+reportfolderpath);
		File fileReport = new File(reportfolderpath);
		
		if (fileReport.isFile()) {
			reportFilePath = reportfolderpath;
		} else if (fileReport.isDirectory()) {
			String newReport = FunctionLibrary.getProperty("CreateExcelReport.Save.Report.New");
			if (newReport.equalsIgnoreCase("yes")) {
				dateTimeStamp = FunctionLibrary.getDate(0, "MM_dd_yyyy_HH_mm_ss");
			} else {
				dateTimeStamp = FunctionLibrary.getDate(0, "MM_dd_yyyy");
			}
			reportFilePath = reportfolderpath + folderSeparatorForOs +testSuiteName + ".xls";

		}
		try {
			FunctionLibrary.generateMasterExcel(reportFilePath);
		} catch (java.io.IOException e) {
			com.eviware.soapui.support.UISupport.showInfoMessage(reportFilePath + " is not generated successfully. Please check! save report file path in config file");
		}
	}

	public void afterRun(TestSuiteRunner testSuiteRunner, TestSuiteRunContext testSuiteRunContext) { testSuiteRunFlag = false;
		
		reportfolderpath = reportfolderpath.replace(folderSeparatorForOs + this.testSuiteName,"" );	
	
	}

	public void beforeTestCase(TestSuiteRunner testSuiteRunner, TestSuiteRunContext testSuiteRunContext, TestCase testCase) {}

	public void afterTestCase(TestSuiteRunner testSuiteRunner, TestSuiteRunContext testSuiteRunContext, TestCaseRunner testCaseRunner)
	{
		TestCase testCase = testCaseRunner.getTestCase();
		testCaseName = testCase.getName().toString();
		int testCaseNo = testCaseRunner.getTestCase().getTestSuite().getIndexOfTestCase(testCase) + 1;
		int testCaseStepsCount = testCaseRunner.getRunContext().getTestRunner().getResults().size();
		String testCaseStatus = testCaseRunner.getRunContext().getTestRunner().getStatus().toString();
		
		if (testCaseStatus.equals("FINISHED")) {
			testCaseStatus = "PASSED";
		}
		String testCaseDate = new java.util.Date(testCaseRunner.getRunContext().getTestRunner().getStartTime()).toString();
		String testCaseDuration = String.valueOf(testCaseRunner.getRunContext().getTestRunner().getTimeTaken());

		try
		{
			FunctionLibrary.updateMasterReport(reportFilePath, testSuiteName, testCaseName, testCaseNo, testCaseStepsCount,  testCaseStatus,testCaseDate, testCaseDuration);
		}
		catch (java.io.IOException e) {
			e.printStackTrace();
		}
	}


	public void setProjectProperties(TestSuiteRunner testRunner) {
		
		String rootFolder = testRunner.getTestSuite().getProject().getPath().split(testRunner.getTestSuite().getProject().getName())[0];
		Object propFilePath = rootFolder+"project-variables"+ folderSeparatorForOs +testRunner.getTestSuite().getProject().getName()+".xls";
		SoapUI.log("Project properties are loading from file: "+ propFilePath);
		System.out.println("Project properties are loading from file: "+ propFilePath);
		if(!(propFilePath==null))
		{
			FileInputStream inpObj = null;
			
			try {

				inpObj = new FileInputStream(propFilePath.toString());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			HSSFWorkbook workbook = null;
			try {
				workbook = new HSSFWorkbook(inpObj);
			} catch (IOException e) {
				e.printStackTrace();
			}

			HSSFSheet sheet = workbook.getSheet("project-variables");
			if(sheet!=null)
			{
				int noOfRows = sheet.getLastRowNum();
				Row rowWithColumnNames = sheet.getRow(0);
				rowWithColumnNames.getPhysicalNumberOfCells();
				String settingsKey ="";
				String settingsValue = "";

				Iterator<Row> rowIterator = sheet.iterator();
				DataFormatter formatter = new DataFormatter();
				for(int m=0;m<=noOfRows;m++)
				{
					Row rowCurrent = rowIterator.next();
					if(m<=0){
						continue;
					}

					settingsKey = String.valueOf(formatter.formatCellValue((rowCurrent.getCell(1))).trim());
					settingsValue = String.valueOf(formatter.formatCellValue((rowCurrent.getCell(2))).trim());
					testRunner.getTestSuite().getProject().setPropertyValue(settingsKey, null);
					
					try {
						testRunner.getTestSuite().getProject().setPropertyValue(settingsKey, settingsValue);
					}
					catch (NullPointerException localNullPointerException) {

					}
				}

			}
			else 
			{
				SoapUI.log("Excel sheet is not found");
				System.out.println("Excel sheet is not found");
			}

		}

	}

	public void setTestSuiteProperties(TestSuiteRunner testRunner) {

		String rootFolder = testRunner.getTestSuite().getProject().getPath().split(testRunner.getTestSuite().getProject().getName())[0];
		Object propFilePath = rootFolder+"input-testdata"+ folderSeparatorForOs+ testRunner.getTestSuite().getName()+folderSeparatorForOs+testRunner.getTestSuite().getName()+".xls";
		SoapUI.log("Test suite properties are loading from file: "+ propFilePath);
		System.out.println("Test suite properties are loading from file: "+ propFilePath);
		
		if(!(propFilePath==null))
		{
			FileInputStream inpObj = null;
			try {

				inpObj = new FileInputStream(propFilePath.toString());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			HSSFWorkbook workbook = null;
			try {
				workbook = new HSSFWorkbook(inpObj);
			} catch (IOException e) {
				e.printStackTrace();
			}

			//Get first/desired sheet from the workbook
			HSSFSheet sheet = workbook.getSheet(testRunner.getTestSuite().getName().replace(" ","_"));

			if (sheet != null)
			{
				int noOfRows = sheet.getLastRowNum();
				Row rowWithColumnNames = sheet.getRow(0);
				rowWithColumnNames.getPhysicalNumberOfCells();
				String settingsKey ="";
				String settingsValue = "";

				//Iterate through each rows one by one
				Iterator<Row> rowIterator = sheet.iterator();
				DataFormatter formatter = new DataFormatter();
				for(int m=0;m<=noOfRows;m++)
				{
					Row rowCurrent = rowIterator.next();
					if(m<=0){
						continue;
					}

					settingsKey = String.valueOf(formatter.formatCellValue((rowCurrent.getCell(1))).trim());
					settingsValue = String.valueOf(formatter.formatCellValue((rowCurrent.getCell(2))).trim());

					testRunner.getTestSuite().setPropertyValue(settingsKey, null);
					try {
						testRunner.getTestSuite().setPropertyValue(settingsKey, settingsValue);
					}
					catch (NullPointerException localNullPointerException) {

					}
				}
			}
			else {
				SoapUI.log("Excel sheet is not found. "+testRunner.getTestSuite().getName().replace(" ","_")+". Replace spaces in sheetname with underscore");
				System.out.println("Excel sheet is not found. "+testRunner.getTestSuite().getName().replace(" ","_")+". Replace spaces in sheetname with underscore");
			}

		}

	}

}
