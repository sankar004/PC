package de.dbsystel.custom.listeners;
import com.eviware.soapui.SoapUI; 
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestRequestStep;
import com.eviware.soapui.impl.wsdl.teststeps.WsdlTestStep;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.basic.ResponseSLAAssertion;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.basic.SimpleContainsAssertion;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.basic.SimpleNotContainsAssertion;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.basic.XPathContainsAssertion;
import com.eviware.soapui.impl.wsdl.teststeps.assertions.basic.XQueryContainsAssertion;
import com.eviware.soapui.model.iface.MessageExchange;
import com.eviware.soapui.model.testsuite.Assertable;
import com.eviware.soapui.model.testsuite.TestAssertion;
import com.eviware.soapui.model.testsuite.TestCaseRunContext;
import com.eviware.soapui.model.testsuite.TestCaseRunner;
import com.eviware.soapui.model.testsuite.TestStep;
import com.eviware.soapui.model.testsuite.TestStepResult;
import com.eviware.soapui.support.UISupport;
import de.dbsystel.custom.FunctionLibrary;
import de.dbsystel.custom.teststep.DataSourceLoopTestStep;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

public class TestRunListener extends com.eviware.soapui.model.support.TestRunListenerAdapter
{
	public String testSuiteName = "";
	public String testCaseName = "";
	public int iterationData = 0;
	public static ArrayList<String> arrStepResult;
	int testStepNo = 0;
	public static String savedRespFolder = "";
	public String dataSourceLoopTarget = "";
	public String dataSourceLoopDatasource = "";
	public int disablestartstep = 0;
	public int disablestopstep = 0;
	public String reportFilePath = "";
	public int assertionNo;

	public void beforeRun(TestCaseRunner testRunner, TestCaseRunContext runContext) {
		String storeFolderPath = "";
		String rootFolder = testRunner.getTestCase().getTestSuite().getProject().getPath().split(testRunner.getTestCase().getTestSuite().getProject().getName())[0];
		arrStepResult = new ArrayList();
		testStepNo = 0;
		iterationData = 0;
		de.dbsystel.custom.teststep.DataSourceTestStep.iteration = 0;
		testSuiteName = testRunner.getTestCase().getTestSuite().getName().toString();
		testCaseName = testRunner.getTestCase().getName().toString();

		if (TestSuiteListener.testSuiteRunFlag) 
		{
			reportFilePath = TestSuiteListener.reportFilePath;
		} 
		else 
		{
			String reportfolderpath = "";
			//String dateTimeStamp = "";

			reportfolderpath = FunctionLibrary.getProperty("CreateExcelReport.Save.Report.Path");
			if (reportfolderpath.isEmpty()) {

				String defaultreportfolderpath = rootFolder + TestSuiteListener.folderSeparatorForOs+ "reports" + TestSuiteListener.folderSeparatorForOs;

				File fileFolderPath = new File(defaultreportfolderpath);
				if (!fileFolderPath.exists()) {
					SoapUI.log("Folder not exists"+fileFolderPath);
					System.out.println("Folder not exists"+fileFolderPath);
					fileFolderPath.mkdir();
				}
				else
				{SoapUI.log("Folder already exists"+fileFolderPath);
				System.out.println("Folder already exists"+fileFolderPath);
				}

				reportfolderpath = defaultreportfolderpath;
			}

			//dateTimeStamp = FunctionLibrary.getDate(0, "MM_dd_yyyy_HH_mm_ss");
			reportFilePath = (reportfolderpath + testCaseName + ".xls");
			try {
				FunctionLibrary.generateBlankExcel(reportFilePath);
			} catch (FileNotFoundException ex) {
				UISupport.showErrorMessage("Excel updation: " + ex.getMessage().toString());
				System.out.println("Excel updation: " + ex.getMessage().toString());
				ex.printStackTrace();
			} catch (Exception ex1) {
				UISupport.showErrorMessage("Excel updation: " + ex1.getMessage().toString());
				System.out.println("Excel updation: " + ex1.getMessage().toString());
				ex1.printStackTrace();
			}
		}
		storeFolderPath = TestSuiteListener.reportfolderpath ;

		File filetestCase = new File(storeFolderPath  + TestSuiteListener.folderSeparatorForOs + testCaseName);
		if (!filetestCase.exists()) {
			filetestCase.mkdir();
		}
		savedRespFolder = storeFolderPath + TestSuiteListener.folderSeparatorForOs + testCaseName + TestSuiteListener.folderSeparatorForOs;

		if (FunctionLibrary.getProperty("CreateExcelReport.Save.Response").equalsIgnoreCase("Yes")) {
			File fileReqResp = new File(savedRespFolder);
			if (!fileReqResp.exists()) {
				UISupport.showErrorMessage(savedRespFolder + " is not a valid folder path. Please check! the request responses are not saved");
			}
		}

		int totalSteps = testRunner.getTestCase().getTestStepCount();
		int datasourceloopStepNumber = 0;
		Boolean datasourceloopFlag = Boolean.valueOf(false);

		for (int i = 0; i < totalSteps; i++) {

			WsdlTestStep testStep = (WsdlTestStep)testRunner.getTestCase().getTestStepAt(i);
			String datasourceloop = ((com.eviware.soapui.config.TestStepConfig)testStep.getConfig()).getType().toString();
			if (datasourceloop.contains("datasourceloop1")) {
				datasourceloopFlag = Boolean.valueOf(true);
				datasourceloopStepNumber = i;
				DataSourceLoopTestStep dataSourceLoopTestStep = (DataSourceLoopTestStep)testRunner.getTestCase().getTestStepAt(datasourceloopStepNumber);
				dataSourceLoopTarget = dataSourceLoopTestStep.getTarget().toString();
				dataSourceLoopDatasource = dataSourceLoopTestStep.getDataSource().toString();
			}
			else {
				if (datasourceloopFlag.booleanValue() == true)
					break;
			}
		}

		disablestartstep = testRunner.getTestCase().getTestStepIndexByName(dataSourceLoopTarget);
		disablestopstep = datasourceloopStepNumber;
		for (int i1 = disablestartstep; i1 < disablestopstep; i1++) 
		{
			try {				

				if ((testRunner.getTestCase().getTestStepAt(i1) instanceof WsdlTestRequestStep)) {
					WsdlTestRequestStep testRequest = (WsdlTestRequestStep)testRunner.getTestCase().getTestStepAt(i1);
					testRequest.setDisabled(true);
				} else if ((testRunner.getTestCase().getTestStepAt(i1) instanceof WsdlTestStep)) {
					WsdlTestStep testStep1 = (WsdlTestStep)testRunner.getTestCase().getTestStepAt(i1);
					testStep1.setDisabled(true);
				}

			}catch(ArrayIndexOutOfBoundsException e)
			{

			}
		}
	}

	public void afterRun(TestCaseRunner testRunner, TestCaseRunContext runContext) {
		try {
			FunctionLibrary.updateReport(reportFilePath, testCaseName, arrStepResult);

			for (int i = disablestartstep; i < disablestopstep; i++) 
			{
				try {					
				
					if ((testRunner.getTestCase().getTestStepAt(i) instanceof WsdlTestRequestStep)) {
						WsdlTestRequestStep testRequest = (WsdlTestRequestStep)testRunner.getTestCase().getTestStepAt(i);
						testRequest.setDisabled(false);
					} else if ((testRunner.getTestCase().getTestStepAt(i) instanceof WsdlTestStep)) {
						WsdlTestStep testStep = (WsdlTestStep)testRunner.getTestCase().getTestStepAt(i);
						testStep.setDisabled(false);
					}
				}catch(ArrayIndexOutOfBoundsException e)
				{
	
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			UISupport.showInfoMessage("Update Report " + e.getMessage().toString());
		}
	}

	public void afterStep(TestCaseRunner testRunner, TestCaseRunContext runContext, TestStepResult result)
	{
		testStepNo += 1;

		String requestFilePath = "";
		String responseFilepath = "";
		String responseName; 
		MessageExchange testStepMsgExg = null;
		String responseContent; if (FunctionLibrary.getProperty("CreateExcelReport.Save.Response").equalsIgnoreCase("Yes"))
		{
			if ((result.getTestStep() instanceof WsdlTestRequestStep)) {
				iterationData += 1;

				String stepName = result.getTestStep().getName().toString();
				testStepMsgExg  = (MessageExchange)result;

				String dateStampRequest = FunctionLibrary.getDate(0, "ddMMyyyy_hmmssSSS");
				String requestName = "REQUEST_" + stepName + "_" + dateStampRequest;
				String requestContent = testStepMsgExg.getRequestContentAsXml();
				requestFilePath = savedRespFolder + requestName + ".xml";
				FunctionLibrary.writeContent(requestFilePath, requestContent);

				String dateStampResponse = FunctionLibrary.getDate(0, "ddMMyyyy_hmmssSSS");
				responseName = "RESPONSE_" + stepName + "_" + dateStampResponse;
				responseContent = testStepMsgExg.getResponseContentAsXml();
				responseFilepath = savedRespFolder + responseName + ".xml";
				FunctionLibrary.writeContent(responseFilepath, responseContent);
			}
		}

		String testStepName = result.getTestStep().getName().toString();
		String testStepAssertions = "";
		String testStepStatus = "";

		String testStepDuration = "";
		testStepAssertions = generateSoapUIExpectedResult(result.getTestStep());

		String actualMessages = "";
		if (result.getMessages().length > 0) {
			actualMessages = actualMessages + "";
			for (int str1 = 0; str1 < result.getMessages().length; str1++) { 
				String msg = result.getMessages()[str1];
				if(msg.split(" comparison ").length>1)
				{
					msg = msg.split(" comparison ")[1].replaceAll("failed", "Failed");
					msg = msg.replace(", expecting",":\nexpecting");
				}

				actualMessages = msg + "\n";
			}
		}else
		{
			if(assertionNo>1)
			{
				actualMessages = "All are Valid" ;
			}
			else if(assertionNo==1)
			{
				actualMessages = "Valid" ;
			}
			else if(assertionNo==0)
			{
				actualMessages = "" ;
			}
		}
		actualMessages =actualMessages.trim();
		testStepStatus = result.getStatus().toString();
		String testStepTimeStamp = new Date(result.getTimeStamp()).toString();
		testStepDuration = String.valueOf(result.getTimeTaken());	
		arrStepResult.add(testStepNo + ";;" + testStepName + ";;" + testStepAssertions + ";;" + actualMessages + ";;" + testStepStatus + ";;"+ testStepDuration + ";;" + requestFilePath + ";;" + responseFilepath);
		assertionNo = 0;
	}

	private String generateSoapUIExpectedResult(TestStep wsdlTestStep) {
		String expAssertions = "";
		try
		{
			Assertable testStep = (Assertable)wsdlTestStep;
		} catch (ClassCastException e) { Assertable testStep;
		return "";
		}
		Assertable testStep = (Assertable)wsdlTestStep;
		assertionNo = 0;

		for (TestAssertion ta : testStep.getAssertionList())
		{
			if (!ta.isDisabled()) {
				assertionNo += 1;


				expAssertions = expAssertions + "\n" + assertionNo + ". " + ta.getName();
				if ((ta instanceof SimpleContainsAssertion))
				{
					String simplecontains = "[" + ((SimpleContainsAssertion)ta).getToken().toString();
					expAssertions = expAssertions + " - " + simplecontains + "]";
				}
				if ((ta instanceof SimpleNotContainsAssertion))
				{
					String simplenotcontains = "[" + ((SimpleNotContainsAssertion)ta).getToken().toString();
					expAssertions = expAssertions + "\n" + simplenotcontains + "]";
				}
				if ((ta instanceof XPathContainsAssertion))
				{
					String xpath = "";
					if(((XPathContainsAssertion)ta).getPropertyExpansions().length>0)
					{ 
						xpath = "[" + ((XPathContainsAssertion)ta).getPath() + " - " + ((XPathContainsAssertion)ta).getPropertyExpansions()[0].getProperty().getValue();
					}
					else
					{
						xpath = "[" + ((XPathContainsAssertion)ta).getPath() + " - " + ((XPathContainsAssertion)ta).getExpectedContent();
					}
					expAssertions = expAssertions + " - " + xpath + "]";				
				}
				if ((ta instanceof XQueryContainsAssertion))
				{

					String xquery = "[" + ((XQueryContainsAssertion)ta).getPath() + " - " + ((XQueryContainsAssertion)ta).getExpectedContent();
					expAssertions = expAssertions + " - " + xquery + "]";
				}
				if ((ta instanceof ResponseSLAAssertion))
				{
					String responsesla = "[" +  ((ResponseSLAAssertion)ta).getSLA().toString();
					expAssertions = expAssertions + " - " + responsesla + "]";
				}
			}
		}
		return expAssertions.trim();
	}


}
