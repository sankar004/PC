package com.e2etestreport.constants;

public class E2EConstants {
	public static final String IN_PROGRESS = "In Progress";
	public static final String PASSED = "Passed";
	public static final String FAILED = "Failed";
	public static final String INITIALIZED = "Initialized";
	public static final String ALL = "All";
	public static final int MAX_DATA_POINT = 10;
	public static final String NEW = "New";
	public static final String TIMED_OUT ="Timed Out";

}
