package com.e2etestreport.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.e2etestreport.constants.E2EConstants;
import com.e2etestreport.response.E2EResultRow;
import com.e2etestreport.response.E2EResultSet;
import com.e2etestreport.response.OverallStatus;
import com.e2etestreport.response.ToolDetailVo;
import com.e2etestreport.utilities.DBConnectionManager;

public class E2EReportUtilityDAO {

	private Connection ucaConn;
	private Statement st;
	private ResultSet rs;
	private static Map<String, String> statusMap = new HashMap<>();

	static {
		statusMap.put(E2EConstants.IN_PROGRESS, "In Progress");
		statusMap.put(E2EConstants.PASSED, "Passed");
		statusMap.put(E2EConstants.FAILED, "Failed");
		statusMap.put(E2EConstants.INITIALIZED, "Initialized");
		statusMap.put(E2EConstants.NEW, "New");
		statusMap.put(E2EConstants.TIMED_OUT, "Timed Out");
	}

	// private static Logger log = Logger.getLogger(E2EReportUtilityDAO.class);

	public E2EReportUtilityDAO() {/*
								 * 
								 * boolean isValidConnection = false; int
								 * attempt = 0; while (!isValidConnection &&
								 * attempt < 10) { try { attempt++; ucaConn =
								 * DBConnectionManager
								 * .getInstance().getConnection(); //
								 * ucaConn.setAutoCommit(true);
								 * //ucaConn.setTransactionIsolation
								 * (Connection.TRANSACTION_READ_UNCOMMITTED); st
								 * = ucaConn.createStatement(); // TestCaseID
								 * ResultSet rsTest =
								 * st.executeQuery("select 1 from dual"); if
								 * (rsTest.next()) { //
								 * log.info("Acquired valid connection attempt ="
								 * + // attempt); isValidConnection = true; }
								 * 
								 * } catch (SQLException e) { // log.error(
								 * "Error getting connection from ucanaccess driver attempt ="
								 * // +attempt); // TODO Auto-generated catch
								 * block e.printStackTrace(); } }
								 */
	}

	public E2EResultSet retrieveResultRecords(String searchCriteria) {
		E2EResultSet e2eResultSet = new E2EResultSet();
		List<E2EResultRow> e2eResultList = new ArrayList<E2EResultRow>();
		ucaConn = DBConnectionManager.getInstance().getConnection();
		try {
			st = ucaConn.createStatement();
			String status = null;
			if (searchCriteria != null) {
				if (!searchCriteria.isEmpty()) {
					status = statusMap.get(searchCriteria);
				}
			}
			String query = "select E2E_TEST_CASE_ID, CALLED_TEST_CASE_ID , TOOL_NM, TEST_CASE_STAT_DESC,COMMENTS, EXEC_START_TIME, EXEC_END_TIME, "
					+ "APP_NM, EXEC_MACH_NM, TC_VALIDATION_STATUS,DEPEND_ON_TC_ID, round((EXEC_END_TIME - EXEC_START_TIME)*24*60) elapstime from E2E_TESTCASES where RUN_IND = 'Y'";
			if (status != null && !status.isEmpty()) {
				query = query + " and TEST_CASE_STAT_DESC = '" + status + "'";
				System.out.println(query);
			}
			rs = st.executeQuery(query + "order by E2E_TEST_CASE_ID");
			Map<String, String> urlMap = new HashMap<String, String>();
			urlMap.put("QTP", "\\\\ad1hfdnas026\\DFSAnchor-ComPAS\\ComPAS\\temp\\E2E\\UFTReports");
			urlMap.put("Selenium",
					"\\\\teams.thehartford.com\\team\\ComPASR2\\QA\\QA Documents\\07. Automation\\Execution Reports\\HTMLReports");
			while (rs.next()) {
				E2EResultRow e2eResultRow = new E2EResultRow();

				e2eResultRow.setE2eApplication(rs.getString("APP_NM"));
				e2eResultRow.setExecutingMachine(rs.getString("EXEC_MACH_NM"));
				e2eResultRow.setExecutionStartTime(rs.getTimestamp("EXEC_START_TIME"));
				e2eResultRow.setExecutionEndTime(rs.getTimestamp("EXEC_END_TIME"));
				e2eResultRow.setE2EQCTCaseName(rs.getString("CALLED_TEST_CASE_ID"));
				e2eResultRow.setE2EStatus(rs.getString("TEST_CASE_STAT_DESC"));
				e2eResultRow.setE2ETCaseId(rs.getString("E2E_TEST_CASE_ID"));
				e2eResultRow.setValidationStatus(rs.getString("TC_VALIDATION_STATUS"));
				e2eResultRow.setE2ETool(rs.getString("TOOL_NM"));
				e2eResultRow.setDependOnTestCaseId(rs.getString("DEPEND_ON_TC_ID"));
				e2eResultRow.setComments(rs.getString("COMMENTS"));
				e2eResultRow.setDurationMinutes(rs.getString("elapstime"));
				String url = null;
				if (e2eResultRow.getE2ETool() != null) {
					if (e2eResultRow.getE2ETool().toLowerCase().contains("Selenium".toLowerCase())) {
						url = urlMap.get("Selenium");
					} else {
						url = urlMap.get(e2eResultRow.getE2ETool());
					}
				}
				e2eResultRow.setReportUrl(url);

				e2eResultList.add(e2eResultRow);
			}
			e2eResultSet.setE2eResultSet(e2eResultList);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);

		}

		return e2eResultSet;
	}

	public OverallStatus retrieveOverAllStatus() {
		OverallStatus overAllStatus = new OverallStatus();
		int totalNumberOfE2ETestCases = 0;
		int numberOfE2ETestCasesCompleted = 0;
		int numberOfE2ETestCasesInProgress = 0;

		int numberOfE2ETestCasesPassed = 0;
		int numberOfE2ETestCasesFailed = 0;

		int totalNumberOfIndividualE2ETestCases = 0;
		int numberOfIndividualTestCasedInProgress = 0;
		int numberOfIndividualTestCasesPassed = 0;
		int numberOfIndividualTestCasesFailed = 0;
		int totalTimedOutTestCases =0;

		ucaConn = DBConnectionManager.getInstance().getConnection();

		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("select count(distinct(E2E_TEST_CASE_ID)) from E2E_TESTCASES WHERE RUN_IND = 'Y'");
			if (rs.next()) {
				totalNumberOfE2ETestCases = rs.getInt(1);
			}
			rs = st.executeQuery("Select count(*) from E2E_TESTCASES WHERE RUN_IND = 'Y'");
			if (rs.next()) {
				totalNumberOfIndividualE2ETestCases = rs.getInt(1);
			}

			/*
			 * rs = st.executeQuery(
			 * "Select count(*) from E2E_TESTCASES WHERE TEST_CASE_STAT_DESC = 'In Progress' and RUN_IND = 'Y'"
			 * ); if (rs.next()) { numberOfIndividualTestCasedInProgress =
			 * rs.getInt(1); }
			 * 
			 * rs = st.executeQuery(
			 * "Select count(*) from E2E_TESTCASES WHERE TEST_CASE_STAT_DESC = 'Passed' and RUN_IND = 'Y'"
			 * ); if (rs.next()) { numberOfIndividualTestCasesPassed =
			 * rs.getInt(1); }
			 * 
			 * rs = st.executeQuery(
			 * "Select count(*) from E2E_TESTCASES WHERE TEST_CASE_STAT_DESC = 'Failed' and RUN_IND = 'Y'"
			 * ); if (rs.next()) { numberOfIndividualTestCasesFailed =
			 * rs.getInt(1); }
			 */
			String query = "select sum(CASE WHEN TEST_CASE_STAT_DESC = 'Initialized' THEN 1 ELSE 0 END) initialized,"
					+ "sum(CASE WHEN TEST_CASE_STAT_DESC = 'In Progress' THEN 1 ELSE 0 END) progress,"
					+ "sum(CASE WHEN TEST_CASE_STAT_DESC = 'Passed' THEN 1 ELSE 0 END) passed,"
					+ "sum(CASE WHEN TEST_CASE_STAT_DESC = 'Timed Out' THEN 1 ELSE 0 END) timedout,"
					+ "sum(CASE WHEN TEST_CASE_STAT_DESC = 'Failed' THEN 1 ELSE 0 END) failed"
					+ " from E2E_TESTCASES where RUN_IND='Y'";

			rs = st.executeQuery(query);
			if (rs.next()) {
				numberOfIndividualTestCasedInProgress = rs.getInt("progress");
				numberOfIndividualTestCasesPassed = rs.getInt("passed");
				numberOfIndividualTestCasesFailed = rs.getInt("failed");
				totalTimedOutTestCases = rs.getInt("timedout");
			}

			numberOfE2ETestCasesCompleted = numberOfIndividualTestCasesPassed + numberOfIndividualTestCasesFailed;
			overAllStatus.setNumberOfE2ETestCasedInProgress(numberOfE2ETestCasesInProgress);
			overAllStatus.setNumberOfE2ETestCasesCompleted(numberOfE2ETestCasesCompleted);
			overAllStatus.setTotalTimedOutTestCases(totalTimedOutTestCases);
			overAllStatus.setNumberOfE2ETestCasesFailed(numberOfE2ETestCasesFailed);
			overAllStatus.setNumberOfE2ETestCasesPassed(numberOfE2ETestCasesPassed);
			overAllStatus.setNumberOfIndividualTestCasedInProgress(numberOfIndividualTestCasedInProgress);
			// overAllStatus.setNumberOfIndividualTestCasesCompleted(numberOfIndividualTestCasesCompleted);
			overAllStatus.setNumberOfIndividualTestCasesFailed(numberOfIndividualTestCasesFailed);
			overAllStatus.setNumberOfIndividualTestCasesPassed(numberOfIndividualTestCasesPassed);
			overAllStatus.setTotalNumberOfE2ETestCases(totalNumberOfE2ETestCases);
			overAllStatus.setTotalNumberOfIndividualE2ETestCases(totalNumberOfIndividualE2ETestCases);

			
			String qry = "select e2e_test_case_id,count(*) total, sum(CASE WHEN TEST_CASE_STAT_DESC = 'Passed' THEN 1 ELSE 0 END) passed "
					+ ", sum(CASE WHEN TEST_CASE_STAT_DESC = 'Failed' THEN 1 ELSE 0 END) failed from "
					+ " e2e_testcases where run_ind='Y' and e2e_test_case_id in (select distinct(e2e_test_case_id) from e2e_testcases where run_ind='Y') "
					+ " group by e2e_test_case_id ";

			rs = st.executeQuery(qry);
			int totalDistinctPassedTestcases = 0;
			int totalDistinctFailedTestcases = 0;
			int totalDistinctPassedCount = 0;
			int totalDistinctTestCases = 0;
			while (rs.next()) {
				// String e2eTestCaseId =rs.getString("e2e_test_case_id");
				 totalDistinctPassedCount = rs.getInt("passed");
				 totalDistinctTestCases = rs.getInt("total");
				if(rs.getInt("failed") >0){
					totalDistinctFailedTestcases++;
				}else if (totalDistinctTestCases == totalDistinctPassedCount) {
					totalDistinctPassedTestcases++;
				}
			}
			overAllStatus.setTotalDistinctPassedTestcases(totalDistinctPassedTestcases);
			overAllStatus.setTotalDistinctFailedTestcases(totalDistinctFailedTestcases);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		return overAllStatus;
	}

	public List<ToolDetailVo> getClientWiseDetails() {
		
		String query = "select EXEC_MACH_NM, count(*) totalTCs, sum(CASE WHEN TEST_CASE_STAT_DESC = 'Initialized' THEN 1 ELSE 0 END) initialized,"
				 + " sum(CASE WHEN TEST_CASE_STAT_DESC = 'In Progress' THEN 1 ELSE 0 END) progress,"
				 + " sum(CASE WHEN TEST_CASE_STAT_DESC = 'Queued' THEN 1 ELSE 0 END) queued,"
				 + " sum(CASE WHEN TEST_CASE_STAT_DESC = 'Passed' THEN 1 ELSE 0 END) passed,"
				 + " sum(CASE WHEN TEST_CASE_STAT_DESC = 'Timed Out' THEN 1 ELSE 0 END) timedout,"
				 + " sum(CASE WHEN TEST_CASE_STAT_DESC = 'Failed' THEN 1 ELSE 0 END) failed"
				 + "  from E2E_TESTCASES e where RUN_IND='Y' group by EXEC_MACH_NM  order by passed desc ";
		ucaConn = DBConnectionManager.getInstance().getConnection();

		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery(query);
			List<ToolDetailVo> vos = new ArrayList<>();
			while(rs.next()) {
				ToolDetailVo vo = new ToolDetailVo();
				vo.setMachineName(rs.getString("EXEC_MACH_NM"));
				vo.setInitializedTestcases(rs.getInt("initialized"));
				vo.setPassedTestcases(rs.getInt("passed"));
				vo.setFailedTestcases(rs.getInt("failed"));
				vo.setInProgressTestcases(rs.getInt("progress"));
				vo.setTimedOutTestcases(rs.getInt("timedout"));
				vo.setTestcasesCount(rs.getInt("totalTCs"));
				vo.setQueuedTestcases(rs.getInt("queued"));
				vo.setCompletedTestcases(rs.getInt("passed") + rs.getInt("failed"));
				vos.add(vo);
			}
			return vos;
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		
		return null;
	}

	

}
