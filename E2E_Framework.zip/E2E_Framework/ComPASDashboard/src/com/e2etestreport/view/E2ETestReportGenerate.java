package com.e2etestreport.view;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e2etestreport.DAO.E2EReportUtilityDAO;
import com.e2etestreport.response.E2EResultSet;
import com.e2etestreport.response.OverallStatus;
import com.google.gson.Gson;

public class E2ETestReportGenerate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public E2ETestReportGenerate() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String searchCriteria = null;
		File directory = new File(".");
		String sConfigfilespath = directory.getCanonicalPath() + "\\Config";
		searchCriteria = request.getParameter("search_criteria");
		System.out.println("Inside doGet selected state =" + request.getParameter("search_criteria")
				+ " canonical path=" + sConfigfilespath);

		

		E2EResultSet e2eResultSet = null;
		E2EReportUtilityDAO e2eUtilDAO = new E2EReportUtilityDAO();
		e2eResultSet = e2eUtilDAO.retrieveResultRecords(searchCriteria);

		OverallStatus overAllStatus = null;
		overAllStatus = e2eUtilDAO.retrieveOverAllStatus();

		//e2eUtilDAO.closeConnections();
		e2eUtilDAO = null;

		String json = new Gson().toJson(overAllStatus);
		System.out.println("json =" + json);

		String jsonArray = new Gson().toJson(e2eResultSet);
		System.out.println("json Array =" + jsonArray);

		response.setContentType("application/json");
		String bothJson = "[" + json + "," + jsonArray + "]";
		// response.getWriter().write(json);
		response.getWriter().write(bothJson);
	}
}
