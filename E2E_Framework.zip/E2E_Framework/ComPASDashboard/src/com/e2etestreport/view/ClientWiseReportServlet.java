package com.e2etestreport.view;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e2etestreport.DAO.E2EReportUtilityDAO;
import com.e2etestreport.response.ToolDetailVo;
import com.e2etestreport.response.ToolDetailVos;
import com.google.gson.Gson;

public class ClientWiseReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ClientWiseReportServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		E2EReportUtilityDAO e2eUtilDAO = new E2EReportUtilityDAO();
		List<ToolDetailVo> vos = e2eUtilDAO.getClientWiseDetails();
		ToolDetailVos tools= new ToolDetailVos();
		tools.setToolDetailVos(vos);
			response.setContentType("application/json");
			String jsonArray = new Gson().toJson(tools);
			System.out.println("vos--- =" + jsonArray);
			String responseJson = "[" + jsonArray + "]";
			response.getWriter().write(responseJson);
	}
}
