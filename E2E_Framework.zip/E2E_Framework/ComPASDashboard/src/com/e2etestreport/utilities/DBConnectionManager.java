package com.e2etestreport.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;


public class DBConnectionManager {

	String databaseUrl = "jdbc:oracle:thin:@xdhfd2-oltpnp-scan:1521/SEL_QA_OLTP_APP3579.thehartford.com";
	String userName = "SELENIUM_APPL";
	String password = "sElpL45#2";
	static Logger log = Logger.getLogger(DBConnectionManager.class);
	


	private static DBConnectionManager dbConnectionManager = new DBConnectionManager();

	public static DBConnectionManager getInstance() {
		return dbConnectionManager;
	}

	private DBConnectionManager() {
		initializeConnection();
	}

	public DBConnectionManager(
	// String databaseName,
			String databaseUrl, String userName, String password) {
		this.databaseUrl = databaseUrl;
		this.userName = userName;
		this.password = password;
		initializeConnection();
	}

	
	private void initializeConnection() {
		
			System.out.println("Proceeding with new connections");
			// Adding new connection instance until the pool is full
			createNewConnection();
		
	
	}


	// Creating a connection
	private Connection createNewConnection() {
		Connection connection = null;

		try {
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 connection=DriverManager.getConnection(
			 databaseUrl,userName,password);
		} catch (SQLException sqle) {
			System.err.println("SQLException: " + sqle);
			return null;
		} catch (ClassNotFoundException cnfe) {
			System.err.println("ClassNotFoundException: " + cnfe);
			return null;
		}

		return connection;
	}

	
	public synchronized Connection getConnection() {
				// Producing same connection
		return createNewConnection();
	}
	
	
	//Closing Statement
	public void closeStatement(Statement st) {
		if (st != null) {
			try {
				st.close();
			} catch (SQLException e) {
				log.error("Closing Statement: " + e);
			}
		}
	}
	
	//Closing Prepared Statement
	public void closePreparedStatement(PreparedStatement pst) {
		if (pst != null) {
			try {
				pst.close();
			} catch (SQLException e) {
				log.error("Closing Statement: " + e);
			}
		}
	}

	// Closing Result set
	public void closeResultSet(ResultSet rs) {
		
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				log.error("Closing Result Set: " + e);
			}
		}
	}
	
	public void closeConnection(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				log.error("Closing Connection: " + e);
			}
		}
	}

	public void closeAll(Connection conn, Statement stmt, ResultSet rs) {

		try {
			closeResultSet(rs);
		} finally {
			try {
				closeStatement(stmt);
			} finally {
				closeConnection(conn);
			}
		}

	}
	public void closeAll(Connection conn, PreparedStatement pst, ResultSet rs) {

		try {
			closeResultSet(rs);
		} finally {
			try {
				closePreparedStatement(pst);
			} finally {
				closeConnection(conn);
			}
		}

	}
	
	
	
	
	
}
