package com.e2etestreport.response;

public class OverallStatus {
	private int totalNumberOfE2ETestCases = 0;
	private int numberOfE2ETestCasesCompleted = 0;
	private int numberOfE2ETestCasesPassed = 0;
	private int numberOfE2ETestCasesFailed = 0;

	private int numberOfE2ETestCasedInProgress = 0;

	private int totalNumberOfIndividualE2ETestCases = 0;
	private int numberOfIndividualTestCasesCompleted = 0;
	private int numberOfIndividualTestCasedInProgress = 0;
	private int numberOfIndividualTestCasesPassed = 0;

	private int numberOfIndividualTestCasesFailed = 0;

	int numberOfSeleniumTestCases = 0;
	int numberOfQTPTestCases = 0;
	int numberOfSeleniumTestCasesCompleted = 0;
	int numberOfQTPTestCasesCompleted = 0;
	int totalDistinctPassedTestcases;
	int totalDistinctFailedTestcases;
	int totalTimedOutTestCases;

	public int getNumberOfSeleniumTestCases() {
		return numberOfSeleniumTestCases;
	}

	public void setNumberOfSeleniumTestCases(int numberOfSeleniumTestCases) {
		this.numberOfSeleniumTestCases = numberOfSeleniumTestCases;
	}

	public int getNumberOfQTPTestCases() {
		return numberOfQTPTestCases;
	}

	public void setNumberOfQTPTestCases(int numberOfQTPTestCases) {
		this.numberOfQTPTestCases = numberOfQTPTestCases;
	}

	public int getNumberOfSeleniumTestCasesCompleted() {
		return numberOfSeleniumTestCasesCompleted;
	}

	public void setNumberOfSeleniumTestCasesCompleted(int numberOfSeleniumTestCasesCompleted) {
		this.numberOfSeleniumTestCasesCompleted = numberOfSeleniumTestCasesCompleted;
	}

	public int getNumberOfQTPTestCasesCompleted() {
		return numberOfQTPTestCasesCompleted;
	}

	public void setNumberOfQTPTestCasesCompleted(int numberOfQTPTestCasesCompleted) {
		this.numberOfQTPTestCasesCompleted = numberOfQTPTestCasesCompleted;
	}

	public int getNumberOfIndividualTestCasesPassed() {
		return numberOfIndividualTestCasesPassed;
	}

	public void setNumberOfIndividualTestCasesPassed(int numberOfIndividualTestCasesPassed) {
		this.numberOfIndividualTestCasesPassed = numberOfIndividualTestCasesPassed;
	}

	public int getNumberOfIndividualTestCasesFailed() {
		return numberOfIndividualTestCasesFailed;
	}

	public void setNumberOfIndividualTestCasesFailed(int numberOfIndividualTestCasesFailed) {
		this.numberOfIndividualTestCasesFailed = numberOfIndividualTestCasesFailed;
	}

	public int getNumberOfE2ETestCasesPassed() {
		return numberOfE2ETestCasesPassed;
	}

	public void setNumberOfE2ETestCasesPassed(int numberOfE2ETestCasesPassed) {
		this.numberOfE2ETestCasesPassed = numberOfE2ETestCasesPassed;
	}

	public int getNumberOfE2ETestCasesFailed() {
		return numberOfE2ETestCasesFailed;
	}

	public void setNumberOfE2ETestCasesFailed(int numberOfE2ETestCasesFailed) {
		this.numberOfE2ETestCasesFailed = numberOfE2ETestCasesFailed;
	}

	public int getTotalNumberOfE2ETestCases() {
		return totalNumberOfE2ETestCases;
	}

	public void setTotalNumberOfE2ETestCases(int totalNumberOfE2ETestCases) {
		this.totalNumberOfE2ETestCases = totalNumberOfE2ETestCases;
	}

	public int getNumberOfE2ETestCasesCompleted() {
		return numberOfE2ETestCasesCompleted;
	}

	public void setNumberOfE2ETestCasesCompleted(int numberOfE2ETestCasesCompleted) {
		this.numberOfE2ETestCasesCompleted = numberOfE2ETestCasesCompleted;
	}

	public int getNumberOfE2ETestCasedInProgress() {
		return numberOfE2ETestCasedInProgress;
	}

	public void setNumberOfE2ETestCasedInProgress(int numberOfE2ETestCasedInProgress) {
		this.numberOfE2ETestCasedInProgress = numberOfE2ETestCasedInProgress;
	}

	public int getTotalNumberOfIndividualE2ETestCases() {
		return totalNumberOfIndividualE2ETestCases;
	}

	public void setTotalNumberOfIndividualE2ETestCases(int totalNumberOfIndividualE2ETestCases) {
		this.totalNumberOfIndividualE2ETestCases = totalNumberOfIndividualE2ETestCases;
	}

	public int getNumberOfIndividualTestCasesCompleted() {
		return numberOfIndividualTestCasesCompleted;
	}

	public void setNumberOfIndividualTestCasesCompleted(int numberOfIndividualTestCasesCompleted) {
		this.numberOfIndividualTestCasesCompleted = numberOfIndividualTestCasesCompleted;
	}

	public int getNumberOfIndividualTestCasedInProgress() {
		return numberOfIndividualTestCasedInProgress;
	}

	public void setNumberOfIndividualTestCasedInProgress(int numberOfIndividualTestCasedInProgress) {
		this.numberOfIndividualTestCasedInProgress = numberOfIndividualTestCasedInProgress;
	}

	public int getTotalDistinctPassedTestcases() {
		return totalDistinctPassedTestcases;
	}

	public void setTotalDistinctPassedTestcases(int totalDistinctPassedTestcases) {
		this.totalDistinctPassedTestcases = totalDistinctPassedTestcases;
	}

	public int getTotalTimedOutTestCases() {
		return totalTimedOutTestCases;
	}

	public void setTotalTimedOutTestCases(int totalTimedOutTestCases) {
		this.totalTimedOutTestCases = totalTimedOutTestCases;
	}

	public int getTotalDistinctFailedTestcases() {
		return totalDistinctFailedTestcases;
	}

	public void setTotalDistinctFailedTestcases(int totalDistinctFailedTestcases) {
		this.totalDistinctFailedTestcases = totalDistinctFailedTestcases;
	}

	

}
