package com.e2etestreport.response;

import java.util.Date;

public class E2EResultRow {
	private String e2ETCaseId;
	private String e2EQCTCaseName;
	private String e2ETool;
	private String e2eApplication;
	private String executingMachine;
	private Date executionStartTime;
	private Date executionEndTime;
	private String e2EStatus;
	private String validationStatus;
	private String reportUrl;
	private String dependOnTestCaseId;
	private String comments;
	private String durationMinutes;

	public String getExecutingMachine() {
		return executingMachine;
	}

	public void setExecutingMachine(String executingMachine) {
		this.executingMachine = executingMachine;
	}

	public String getE2eApplication() {
		return e2eApplication;
	}

	public void setE2eApplication(String e2eApplication) {
		this.e2eApplication = e2eApplication;
	}

	public String getE2ETCaseId() {
		return e2ETCaseId;
	}

	public void setE2ETCaseId(String e2etCaseId) {
		e2ETCaseId = e2etCaseId;
	}

	public String getE2EQCTCaseName() {
		return e2EQCTCaseName;
	}

	public void setE2EQCTCaseName(String e2eqctCaseName) {
		e2EQCTCaseName = e2eqctCaseName;
	}

	public String getE2ETool() {
		return e2ETool;
	}

	public void setE2ETool(String e2eTool) {
		e2ETool = e2eTool;
	}

	public String getE2EStatus() {
		return e2EStatus;
	}

	public void setE2EStatus(String e2eStatus) {
		e2EStatus = e2eStatus;
	}

	public Date getExecutionStartTime() {
		return executionStartTime;
	}

	public void setExecutionStartTime(Date executionStartTime) {
		this.executionStartTime = executionStartTime;
	}

	public Date getExecutionEndTime() {
		return executionEndTime;
	}

	public void setExecutionEndTime(Date executionEndTime) {
		this.executionEndTime = executionEndTime;
	}

	public String getValidationStatus() {
		return validationStatus;
	}

	public void setValidationStatus(String validationStatus) {
		this.validationStatus = validationStatus;
	}

	public String getReportUrl() {
		return reportUrl;
	}

	public void setReportUrl(String reportUrl) {
		this.reportUrl = reportUrl;
	}

	public String getDependOnTestCaseId() {
		return dependOnTestCaseId;
	}

	public void setDependOnTestCaseId(String dependOnTestCaseId) {
		this.dependOnTestCaseId = dependOnTestCaseId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDurationMinutes() {
		return durationMinutes;
	}

	public void setDurationMinutes(String durationMinutes) {
		this.durationMinutes = durationMinutes;
	}

}
