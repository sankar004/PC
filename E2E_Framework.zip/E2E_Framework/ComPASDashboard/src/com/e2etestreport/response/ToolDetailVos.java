package com.e2etestreport.response;

import java.util.List;

public class ToolDetailVos {
	
	private List<ToolDetailVo> toolDetailVos;

	public List<ToolDetailVo> getToolDetailVos() {
		return toolDetailVos;
	}

	public void setToolDetailVos(List<ToolDetailVo> toolDetailVos) {
		this.toolDetailVos = toolDetailVos;
	}

}
