package com.e2etestreport.response;

public class ToolDetailVo {
	
	private String machineName;
	private int initializedTestcases;
	private int passedTestcases;
	private int failedTestcases;
	private int inProgressTestcases;
	private int timedOutTestcases;
	private int queuedTestcases;
	private int testcasesCount;
	private int completedTestcases;
	public String getMachineName() {
		return machineName;
	}
	public void setMachineName(String machineName) {
		this.machineName = machineName;
	}
	public int getInitializedTestcases() {
		return initializedTestcases;
	}
	public void setInitializedTestcases(int initializedTestcases) {
		this.initializedTestcases = initializedTestcases;
	}
	public int getPassedTestcases() {
		return passedTestcases;
	}
	public void setPassedTestcases(int passedTestcases) {
		this.passedTestcases = passedTestcases;
	}
	public int getFailedTestcases() {
		return failedTestcases;
	}
	public void setFailedTestcases(int failedTestcases) {
		this.failedTestcases = failedTestcases;
	}
	public int getInProgressTestcases() {
		return inProgressTestcases;
	}
	public void setInProgressTestcases(int inProgressTestcases) {
		this.inProgressTestcases = inProgressTestcases;
	}
	public int getTimedOutTestcases() {
		return timedOutTestcases;
	}
	public void setTimedOutTestcases(int timedOutTestcases) {
		this.timedOutTestcases = timedOutTestcases;
	}
	public int getTestcasesCount() {
		return testcasesCount;
	}
	public void setTestcasesCount(int testcasesCount) {
		this.testcasesCount = testcasesCount;
	}
	public int getQueuedTestcases() {
		return queuedTestcases;
	}
	public void setQueuedTestcases(int queuedTestcases) {
		this.queuedTestcases = queuedTestcases;
	}
	public int getCompletedTestcases() {
		return completedTestcases;
	}
	public void setCompletedTestcases(int completedTestcases) {
		this.completedTestcases = completedTestcases;
	}
	
	
}
