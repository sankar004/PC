/**
 * 
 */
//var app = angular.module('myApp', ["angular-dialgauge"]);

var app = angular.module('myApp', ['easypiechart', 'angularUtils.directives.dirPagination']);
/*app.controller('chartCtrl', ['$scope', function ($scope) {
    $scope.percent = 65;
    $scope.options = {
        animate:{
            duration:0,
            enabled:false
        },
        barColor:'#2C3E50',
        scaleColor:false,
        lineWidth:20,
        lineCap:'circle'
    };
}]);*/


app.controller('myCtrl', function($scope, $http) {
    $scope.searchCriterias = ["All", "New","Initialized", "In Progress", "Passed", "Failed", "Timed Out"];
    $scope.initialValue = 28;
    $scope.initialIncrementer = 0;
    
    
    
    $scope.displayChart = function() {
    	
		$scope.anotherOptions = {
			animate:{
				duration:0,
				enabled:false
			},
			barColor:'#4CAF50',
			scaleColor:false,
			lineWidth:20,
			lineCap:'circle'
		};

    	 $scope.gauge5 = 60;//Math.floor(Math.random() * 50);
    };
    
    $scope.displayChart();

  /*  $http({
	 		method : 'GET',
            url : '/E2ETestReport/e2eTestReportView',
            params: { state_name: $scope.selectedState }
    }).success(function(data, status, headers, config) {
            $scope.results = data.e2eResultSet;
    }).error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
    });*/
    
    // Function to get the data
    $scope.getData = function(){
    	$http({
   		 		method : 'GET',
	                url : '/ComPASDashboard/e2eTestReportView',
	                params: { search_criteria: $scope.selectedSearchCriteria, time_to_refresh: $.now() },
	                headers: {
	        	        common: {
	        	            "Cache-Control": "no-cache",
	        	            "If-Modified-Since": "0",
	        	            "Pragma": "no-cache"
	        	        }
	        	    }
	        }).success(function(data, status, headers, config) {
	               /* $scope.results = data.e2eResultSet;
	                $scope.overAllresults = data;*/
	        	 	console.log(data[0]);
	        	    console.log(data[1]);
	                $scope.results = data[1].e2eResultSet;
	                $scope.overAllresults = data[0];
	                
	                /*$scope.percent = (($scope.overAllresults.numberOfE2ETestCasesCompleted / $scope.overAllresults.totalNumberOfE2ETestCases) * 100);*/
	                $scope.percent = Number(($scope.overAllresults.numberOfE2ETestCasesCompleted / $scope.overAllresults.totalNumberOfIndividualE2ETestCases) * 100).toFixed(2);
	                $scope.anotherPercent = (($scope.overAllresults.numberOfE2ETestCasesCompleted / $scope.overAllresults.totalNumberOfIndividualE2ETestCases) * 100).toFixed(2);
	        }).error(function(data, status, headers, config) {
	                // called asynchronously if an error occurs
	                // or server returns response with an error status.
	        });
       
    };
    
    $scope.getData();
    setInterval($scope.getData, 10000);
    
    $scope.submitCreatePolicy = function () {
    
        $scope.errortext = "";
        if (!$scope.selectedSearchCriteria) {$scope.errortext = "Please select status to filter below result.";}
        else{
        	 $http({
        		 		method : 'GET',
		                url : '/ComPASDashboard/e2eTestReportView',
		                params: { search_criteria: $scope.selectedSearchCriteria, time_to_refresh: $.now() },
			        	headers: {
			        	        common: {
			        	            "Cache-Control": "no-cache",
			        	            "If-Modified-Since": "0",
			        	            "Pragma": "no-cache"
			        	        }
			        	    }
		        }).success(function(data, status, headers, config) {
		        	   console.log(data[0]);
		        	   console.log(data[1]);
		                $scope.results = data[1].e2eResultSet;
		                $scope.overAllresults = data[0];
		                
		                $scope.percent = (($scope.overAllresults.numberOfE2ETestCasesCompleted / $scope.overAllresults.totalNumberOfIndividualE2ETestCases) * 100).toFixed(2);
		            	$scope.anotherPercent = (($scope.overAllresults.numberOfE2ETestCasesCompleted / $scope.overAllresults.totalNumberOfIndividualE2ETestCases) * 100).toFixed(2);
		            	
		        }).error(function(data, status, headers, config) {
		                // called asynchronously if an error occurs
		                // or server returns response with an error status.
		        });
            
            }
        };
        

        });