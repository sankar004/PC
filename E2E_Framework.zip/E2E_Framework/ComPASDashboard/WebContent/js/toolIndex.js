/**
 * 
 */
//var app = angular.module('myApp', ["angular-dialgauge"]);

var app = angular.module('client', ['easypiechart', 'angularUtils.directives.dirPagination']);



app.controller('clientCtrl', function($scope, $http) {
   
    // Function to get the data
    $scope.getData = function(){
    	$http({
   		 		method : 'GET',
	                url : '/ComPASDashboard/e2eTestClientReportView',
	                params: { search_criteria: $scope.selectedSearchCriteria, time_to_refresh: $.now() },
	                headers: {
	        	        common: {
	        	            "Cache-Control": "no-cache",
	        	            "If-Modified-Since": "0",
	        	            "Pragma": "no-cache"
	        	        }
	        	    }
	        }).success(function(data, status, headers, config) {
	               /* $scope.results = data.e2eResultSet;
	                $scope.overAllresults = data;*/
	        	 	console.log(data[0]);
	                $scope.result = data[0].toolDetailVos;
	                
	        }).error(function(data, status, headers, config) {
	                // called asynchronously if an error occurs
	                // or server returns response with an error status.
	        });
       
    };
    
    $scope.getData();
    setInterval($scope.getData, 10000);
    
        

        });