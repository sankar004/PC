package com.pc.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.testng.log4testng.Logger;

import com.pc.constants.PCConstants;
import com.pc.utilities.DBConnectionManager;
public class E2EUtilityDAO{


	private Connection ucaConn;
	private Statement 	st;
	private ResultSet rs;
	private static Logger log = Logger.getLogger(E2EUtilityDAO.class);
	
	public E2EUtilityDAO(){
		try {
			boolean isValidConnection = false;
			int attempt =0;
			ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
			while(!isValidConnection && attempt < 10) {
				try{
					 attempt++;
					 /*Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
					 //String url = "jdbc:ucanaccess:////ad1.prod/hig/commercial/ComPAS/temp/E2E/Binit/E2EMASTERDB_be.accdb"; 
					 String url = PCConstants.E2e_DB; 
					 ucaConn = DriverManager.getConnection(url);
				
					// ucaConn.setAutoCommit(true);
					 ucaConn.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
					 st = ucaConn.createStatement();*/
					 
					 ucaConn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
                     st = ucaConn.createStatement();
					 
					 //TestCaseID
					 ResultSet rsTest= st.executeQuery("select 1 from dual");
					 if(rsTest.next()){
						 log.info("Acquired valid connection attempt =" + attempt);
						 isValidConnection = true;
					 }
					 
				}catch (SQLException e) {
					log.error("Error getting connection from ucanaccess driver attempt =" +attempt);
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
		} catch (Exception e) {
			log.error("Error getting connection from ucanaccess driver 1");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	
	
	public String retrieveTransKeyValue(String e2eTestCaseId, String keyName){
		String policyNumber = null;
		try {
			rs = st.executeQuery("Select trans_key_value from E2E_TRANS where trans_id = ( Select max(trans_id) from E2E_TRANS where E2E_TEST_CASE_ID='"
					+ e2eTestCaseId
					+ "' and upper(TRANS_KEY_NM )= upper('"+keyName+"'))");
			if(rs.next()){
				policyNumber = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			/*try {
				st.close();
				ucaConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		
		return policyNumber;
	}
	
		
	public boolean updateE2ETrans(String e2eTestCaseId, String keyName,String keyValue){
		boolean status = false;
		/*Date curDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("M/d/yyyy h:m:s aaa");
		String dateToStr = format.format(curDate);*/
		try {
			//String query =  "MERGE INTO TRANS bi USING (Select '"+ e2eTestCaseId +"' as E2E_TCASE_ID from dual) bo ON bi.E2E_TCASE_ID = bo.E2E_TCASE_ID" +
              //      " WHEN MATCHED THEN Update set POLICYNO = '"+ policyNumber +"', APPLICATION = 'Selenium', LAST_UPDATE_TIMESTAMP ='"+dateToStr +"', E2E_TCASE_ID = '"+e2eTestCaseId +"' WHEN NOT MATCHED THEN insert(POLICYNO, E2E_TCASE_ID, APPLICATION, LAST_UPDATE_TIMESTAMP) values ( '"+ policyNumber +"','"+e2eTestCaseId +"','Selenium','"+dateToStr+ "') ";
			String query = "insert into E2E_TRANS(TRANS_KEY_NM, TRANS_KEY_VALUE,E2E_TEST_CASE_ID,LAST_UPDT_TMSP,LAST_UPDT_APPL_NM) VALUES('"+keyName+"','"+keyValue+"','"+e2eTestCaseId+"',SYSDATE ,'PC')";
			log.info("executing query = "+query);
			status = st.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			/*try {
			st.close();
			ucaConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		return status;
	
	}
	
	public boolean updateE2EMasterStatus( String Id, String statusValue){
		boolean status = false;
		/*Date curDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("M/d/yyyy h:m:s aaa");
		String dateToStr = format.format(curDate);*/
		String computerName = null;
		String ipAddress = null;
		//String lastUpdateTimeStamp = null;
		String duration = "";
		
		try {
			  InetAddress addr = InetAddress.getLocalHost();            
			  ipAddress = addr.getHostAddress(); //gets the ip address of current machine
			  computerName = addr.getHostName(); //gets computer name of current machine
		} catch (UnknownHostException e) {
		}
		
		try {
			if(statusValue != null && statusValue.length() >0 
					&& (statusValue.equalsIgnoreCase("Passed") || statusValue.equalsIgnoreCase("Failed"))){
					//String getLastUpdateTimeStamp = "Select LAST_UPDT_TMSP from E2E_TESTCASES where SEQ_NUM = '"+Id+"'";
				String getDuration = "Select round((sysdate - LAST_UPDT_TMSP)*24*60) from E2E_TESTCASES where SEQ_NUM = '"+Id+"'";
					
					Statement st1 = ucaConn.createStatement();
					rs = st1.executeQuery(getDuration);
					if(rs.next()){
						//lastUpdateTimeStamp = rs.getString(1);
						duration = rs.getString(1);
					}
					
					/*if( lastUpdateTimeStamp != null && lastUpdateTimeStamp.length() >0){
						Date date1;
						try {
							date1 = format.parse(lastUpdateTimeStamp);
							long difference = curDate.getTime() - date1.getTime(); //milliseconds
							long diffMinutes = difference / (60 * 1000) % 60;
							duration = String.valueOf(diffMinutes);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}*/
					
					st1.close();
			}
			//setting the computername as grid
			computerName = "GRID";
			//String query =  "MERGE INTO E2E_TESTCASES bi USING (Select '"+ Id +"' as SEQ_NUM from dual) bo ON bi.SEQ_NUM = bo.SEQ_NUM" +
            //        " WHEN MATCHED THEN Update set TEST_CASE_STAT_DESC = '"+ statusValue +"', EXEC_ELAPS_MIN='"+duration +"',EXEC_MACH_NM ='"+computerName+"',LAST_UPDT_TMSP = '"+dateToStr +"' WHEN NOT MATCHED THEN insert(TEST_CASE_STAT_DESC,EXEC_ELAPS_MIN, EXEC_MACH_NM, LAST_UPDT_TMSP) values ( '"+ statusValue +"','"+duration+"','"+computerName +"','"+dateToStr +"' ) ";
			String query =  "MERGE INTO E2E_TESTCASES bi USING (Select '"+ Id +"' as SEQ_NUM from dual) bo ON (bi.SEQ_NUM = bo.SEQ_NUM)" +
                    " WHEN MATCHED THEN Update set TEST_CASE_STAT_DESC = '"+ statusValue +"', EXEC_ELAPS_MIN='"+duration +"',EXEC_MACH_NM ='"+computerName+"',LAST_UPDT_TMSP = SYSDATE WHEN NOT MATCHED THEN insert(TEST_CASE_STAT_DESC,EXEC_ELAPS_MIN, EXEC_MACH_NM, LAST_UPDT_TMSP) values ( '"+ statusValue +"','"+duration+"','"+computerName +"',SYSDATE ) ";
			
			log.info("executing query = "+query);
			status = st.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			/*try {
				st.close();
				ucaConn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		}
		return status;
	
	}
	
	public void closeConnections(){
		try {
			st.close();
			ucaConn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
