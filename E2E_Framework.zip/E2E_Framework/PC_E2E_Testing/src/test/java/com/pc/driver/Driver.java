package com.pc.driver;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.E2ETestCaseUtil;
import com.pc.utilities.HTML;
import com.pc.utilities.LocalDriverFactory;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.RemoteDriverFactory;
import com.pc.utilities.ReportUtil;
import com.pc.utilities.XlsxReader;

public class Driver 
{	
	   static  Logger log =Logger.getLogger(Common.class);
	   private Socket socket              = null;
	  // private DataInputStream  console   = null;
	  // private DataOutputStream streamOut = null;
	   private DataInputStream serverStreamIn =  null;
	   
	   private static ConcurrentLinkedQueue<String> testCaseNames = new ConcurrentLinkedQueue<String>();
	   
	   @BeforeSuite
	   public void loadConfig() throws Exception {
		
		    PropertyConfigurator.configure("log4j.properties");
			try {
				
				
				HTML.fnSummaryInitialization("Execution Summary Report");
				System.out.println("end2endTestCaseName = executeTestCase=");
				//commented below line for end to end framework
				//XlsxReader.getInstance().addTestCasesFromDataSheetName(testCaseNames);
				System.out.println( "Inside BeforeSuite"); 
			
				//console   = new DataInputStream(System.in);
			    //streamOut = new DataOutputStream(socket.getOutputStream());
				if(HTML.properties.getProperty("E2E").equalsIgnoreCase("YES"))
				{
					for (int i=0; i<Integer.parseInt(HTML.properties.getProperty("VERYLONGWAIT")); i++)
			        { 
			            try 
			            {
			            	Thread.sleep(5000);
			            	//socket = new Socket("10.254.19.50", 8001);
			            	socket = new Socket("localhost", 8001);
			            	DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());
			            	//outputStream.writeUTF(PCConstants.SELENIUM);
			            	outputStream.writeUTF("Selenium_E2E_Client");
							serverStreamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
							break;
			            }catch (InterruptedException e) {
			            	
			            }
			            catch(java.net.ConnectException e){
			                System.out.println("waiting for E2E server to open connection on port 8001. Exception details below");
			            	e.printStackTrace();
			            }
			               
			          }

				}else
				{
				   	boolean status = false;
				    PropertyConfigurator.configure("log4j.properties");
					try 
					{
							HTML.fnSummaryInitialization("Execution Summary Report");
							status = XlsxReader.getInstance().addTestCasesFromDataSheetName(testCaseNames);
							System.out.println("Inside BeforeSuite");
							if(HTML.properties.getProperty("DataBaseUpdate").equalsIgnoreCase("YES"))
							{
								ReportUtil.loadTestCases();
							}
							
								if(!status)
								{
									log.info("None of the testcase selected as 'YES' to execute");
									System.out.println("None of the testcase selected as 'YES' to execute");
									System.exit(0);
								}
					} 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						log.error("Thread ID = " + Thread.currentThread().getId() + " Error Occured =" +e.getMessage(), e);
					}	
				}
				
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	   }
	
	
	
	
	
	@Parameters({ "DataSheetName","Region","end2endTestCaseName","executeTestCase" })
	@Test(priority=1,enabled=true,invocationCount = 5,threadPoolSize=5)
	public void testParallele2e3(String DataSheetName, String Region, String end2endTestCaseName, String executeTestCase ) throws Exception
	{
		//System.out.println("end2endTestCaseName =" + end2endTestCaseName +" executeTestCase="+executeTestCase);
		log.info("end2endTestCaseName =" + end2endTestCaseName +" executeTestCase="+executeTestCase);
		//testCaseNames.add(executeTestCase);
		
		boolean exitLoop = false;
		boolean isTestCasePass = false;
		String testCaseName = null;
		try{
        	testCaseName = testCaseNames.remove();
        } catch(java.util.NoSuchElementException e){
        	exitLoop = true;
        }
		if (testCaseName==null){
			exitLoop = true;
		}
		//while(!exitLoop){
		while(true){
			if (testCaseName != null){ //added this if condition for end to end testing
				log.info("Running test case in testParallele2e3 = " + testCaseName);
				boolean e2eTesting = false;
				String executorMachine = null;
				 //Logic to Handle E2E Test Case execution Start
				E2ETestCaseUtil e2eTestCaseUtil = null;
				if(testCaseName.contains("|")){
					e2eTesting = true;
					e2eTestCaseUtil = new E2ETestCaseUtil();
					
					System.out.println("Before test "+ testCaseName);
					testCaseName = e2eTestCaseUtil.e2eInitE2ETestCaseExecution(testCaseName);
					System.out.println("After test "+ testCaseName);
					executorMachine = e2eTestCaseUtil.getExecutorMachine();
				}
				//Logic to Handle E2E Test Case execution End
				
				String execMode = HTML.properties.getProperty("EXECUTIONMODE");
				  //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				WebDriver driver = null;
				System.out.println("TestParallel3  Started = " + Thread.currentThread().getId());
				System.out.println( " Mode =" + execMode ); 
				if(execMode.equalsIgnoreCase(PCConstants.executionModeLocal)){
					driver = LocalDriverFactory.getInstance().createNewDriver();
				}else {
					driver = RemoteDriverFactory.getInstance().createNewDriver();
				}
				
				System.out.println("TestParallel3  Started = " + Thread.currentThread().getId());
				System.out.println("Test PArallel3 driver = " + driver  ); 
				Common common = new Common();
				CommonManager.getInstance().setCommon(common);
		        ManagerDriver.getInstance().setWebDriver(driver);
				//common.setDriver(driver);
		        //common.setCommon(common);
		        System.out.println("Thread ID = " + Thread.currentThread().getId() + " common = "+ common);
		        System.out.println("Checking E2e runtest "+ testCaseName + " "+DataSheetName+ " "+ Region );
		        isTestCasePass = common.RunTest("RunModeNo",testCaseName,DataSheetName,Region);
		        System.out.println("isTEscasePass "+isTestCasePass + " "+ e2eTesting);
		        //Logic to Handle E2E Test Case execution Start
		        if(e2eTesting && isTestCasePass){ 
		        	e2eTestCaseUtil.updateTestResultsintoDB();
		        	e2eTestCaseUtil.upDateE2EStatus("Passed");
		        	e2eTestCaseUtil = null;//Mark for Garbage collection
		        } else if(e2eTesting && !isTestCasePass ){
		        	e2eTestCaseUtil.upDateE2EStatus("Failed");
		        	e2eTestCaseUtil = null;//Mark for Garbage collection
		        }
		        	
		        //Logic to Handle E2E Test Case execution End
		        
		        testCaseName = null;
		    }
			try{
	        	testCaseName = testCaseNames.remove();
	        } catch(java.util.NoSuchElementException e){
	        	exitLoop = true;
	        }
	        if (testCaseName==null){
				exitLoop = true;
			}
		}
	}
	
	//added this method for end to end testing
	@Parameters({ "DataSheetName","Region","end2endTestCaseName","executeTestCase" })
	@Test(priority=1,enabled=true)
	public void populateConcurrentLinkedQueue(String DataSheetName, String Region, String end2endTestCaseName, String executeTestCase ) throws Exception
	{
		
		log.info(" inside populateConcurrentLinkedQueue -> end2endTestCaseName: " + end2endTestCaseName);
		String testCaseName= null;
		if(HTML.properties.getProperty("E2E").equalsIgnoreCase("YES"))
		{
		while(testCaseName == null || ( testCaseName!= null && !testCaseName.equalsIgnoreCase("shutdown")))
		{
			testCaseName = null;
			testCaseName = serverStreamIn.readUTF();//reading from socket
			log.info("Message Received From Server =" + testCaseName);
			if(testCaseName != null && !testCaseName.equalsIgnoreCase("shutdown")){
				testCaseNames.add(testCaseName); //populating into concurrentlinkedqueue
				log.info("Added TestCase Into concurrent linked queue. TestCaseName Received from Server =" + testCaseName);
			}
			log.info("Waiting for the another test case from server....");
		    if(testCaseName.equalsIgnoreCase("shutdown")){
		    	System.exit(0);
		    }
	  	
	  	/*System.out.println("Enter Message to send to Server =" + textFromServer);
	  	testCaseName = console.readLine();//DataInputStream.readUTF(console);
        streamOut.writeUTF(line);
        streamOut.flush();*/
		}
		}
	}
	
	   @AfterSuite
	   public void exitConfig() {
		
		    	try {
		    		XlsxReader.getInstance().closeConnections();
					HTML.fnSummaryCloseHtml(HTML.properties.getProperty("Release"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println( "Inside AfterSuite"); 
		}
	
}
