package com.utility;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

/**
 * 
 * @author cpg7279
 *
 */
public class TestcasesDatabaseUtility {
	public static final Logger LOGGER = Logger.getLogger(TestcasesDatabaseUtility.class.getName());
	private static final String CONFIG_PROPERTIES_FILE = "config.properties";
	static Properties properties = null; 
	static final String FILE_LOCATION_KEY = "Testcases.file.location";
	private static final String DB_URL_KEY = "database.url";
	private static final String DB_USERNAME_KEY = "database.userName";
	private static final String DB_PASSWORD_KEY = "database.password";
	static String sheetName = "E2E_Testcases";
	static Workbook workbook;
	
	
	public static void main(String[] args) {
		loadProperties();
		if(properties == null){
			LOGGER.log(Level.SEVERE, "Properties file is not available and terminationg the execution.");
			return;
		}
		LOGGER.info(CONFIG_PROPERTIES_FILE +" file loaded.");
		workbook = XlsUtility.loadWorkbook(properties.getProperty(FILE_LOCATION_KEY));
		if(workbook == null){
			LOGGER.log(Level.SEVERE, "Workbook is not available and terminationg the execution.");
			return;
		}
		LOGGER.info("data file loaded");
		try {
			readXlsAndUpdateDatabase();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private static void readXlsAndUpdateDatabase() throws Exception {
		HashMap<String, Integer> map = new HashMap<>();
		HashMap<String, Integer> colPlaceMap = new HashMap<>();
		List<String> invalidColumnsList = new ArrayList<>();
		invalidColumnsList.add("Operation");
		
		List<String> conditionColumnsList = Arrays.asList(properties.getProperty("condition.columns").split(","));
		
		XlsUtility.readXLSHeader(sheetName , map);
		Sheet sheet = workbook.getSheet(sheetName);
		if(sheet == null){
			LOGGER.log(Level.SEVERE, sheetName + " is not present in the xls file");
		}
		String databaseUrl=properties.getProperty(DB_URL_KEY);
		String userName=properties.getProperty(DB_USERNAME_KEY);
		String password=properties.getProperty(DB_PASSWORD_KEY);
		Connection dbConnection = DatabaseUtility.createConnection(databaseUrl , userName, password);
		String sql = "insert into e2e_testcases(";
		StringBuilder columns = new StringBuilder();
		StringBuilder placeHolders = new StringBuilder();
		int position = 1;
		for(String colName : map.keySet()){
			if(!invalidColumnsList.contains(colName)){
				if(columns.length() > 0){
					columns.append(" , ");
					placeHolders.append(" , ");
				}
				columns.append(colName);
				placeHolders.append("?");
				colPlaceMap.put(colName, position++);
			}
		}
		 // + placeHolders + ")";
		Statement statement = dbConnection.createStatement();
		for(int rowIndex=0;rowIndex<= sheet.getLastRowNum();rowIndex++){
			sql = sql + columns.toString() +" ) values ( ";
			Row currentRow = sheet.getRow(rowIndex);
			Integer opPosition = map.get("Operation");
			if(opPosition == null)
				continue;
			Cell cell = currentRow.getCell(opPosition);
			if(cell == null)
			 continue;
			String operation = cell.getStringCellValue();
			if("insert".equalsIgnoreCase(operation)){
				StringBuilder values = new StringBuilder();
				for (String colName : map.keySet()) {
					if (!invalidColumnsList.contains(colName)) {
						Cell valueCell = currentRow.getCell(map.get(colName));
						String value = XlsUtility.getCellValue(valueCell);// valueCell.getStringCellValue();
//						System.out.println(colPlaceMap.get(colName) + " : " + colName + " : "+map.get(colName) + value);
						// statement.setString(colPlaceMap.get(colName), value);
						if (values.length() > 0) {
							values.append(" , ");
						}
						values.append("'" + value + "'");
					}
				}
				sql =sql + values.toString() + ")";
				System.out.println(sql);
				
				statement.executeUpdate(sql);
			}else if("update".equalsIgnoreCase(operation)){
				columns = null;
				columns = new StringBuilder();
				String uSql = "update e2e_testcases set ";
				for (String colName : map.keySet()) {
					if (!invalidColumnsList.contains(colName) && !conditionColumnsList.contains(colName)) {
						Cell valueCell = currentRow.getCell(map.get(colName));
						String value = XlsUtility.getCellValue(valueCell);// valueCell.getStringCellValue();
//						System.out.println(colPlaceMap.get(colName) + " : " + colName + " : "+map.get(colName)+ value);
						// statement.setString(colPlaceMap.get(colName), value);
						if (columns.length() > 0) {
							columns.append(" , ");
						}
						columns.append(colName + " = '" + value + "'");
					}
				}
				columns.append(" , LAST_UPDT_TMSP= sysdate where ");
				StringBuilder sb = new StringBuilder();
				for(String colName : conditionColumnsList){
					if(sb.length() > 0){
						sb.append(" and ");
					}
					Cell valueCell = currentRow.getCell(map.get(colName));
					String value = XlsUtility.getCellValue(valueCell);
					sb.append( colName + " = '"+value+"' ");
					
				}
				uSql =uSql + columns.toString() + sb.toString();
				System.out.println(uSql);
				statement.executeUpdate(uSql);
			}
			
			sql="insert into e2e_testcases( ";
		}
		
	}

	private static void loadProperties() {
		InputStream input = null;
		try {

			input = new FileInputStream(CONFIG_PROPERTIES_FILE);
			properties = new Properties();
			properties.load(input);
		}catch(Exception e){
			LOGGER.log(Level.SEVERE, CONFIG_PROPERTIES_FILE+ " not present");
		}
		
	}
	

}
