package com.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;

public class XlsUtility {
	public static final Logger LOGGER = Logger.getLogger(XlsUtility.class.getName());
	static Workbook workbook;
	static Workbook loadWorkbook(String dataFile) {
		FileInputStream in = null;
		try {
			in = new FileInputStream(dataFile);
			  workbook = WorkbookFactory.create(in);
		}  catch (Exception e) {
			LOGGER.log(Level.SEVERE, dataFile + " not present");
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
					LOGGER.log(Level.SEVERE, dataFile + " not present");
				}
		}
		return workbook;
	}
	static void readXLSHeader(String sheetName , HashMap<String, Integer> map) throws Exception {
		
		Sheet sheet = workbook.getSheet(sheetName);
		if(sheet == null){
			LOGGER.log(Level.SEVERE , sheetName+" is not present in excel file");
		}
			
		Row firstRow = sheet.getRow(0);
		int lastCellNum = firstRow.getLastCellNum();
		for (int index = 0; index < lastCellNum; index++) {
			Cell cell = firstRow.getCell(index);
			if(cell == null)
				continue;
			String cellValue = cell.getStringCellValue();
			if (cellValue != null) {
					map.put(String.valueOf(cellValue).trim() , cell.getColumnIndex());
			}
		}
	}
	public static String getCellValue(Cell cell) {
		if (cell == null)
			return "";
		if (cell.getCellType() == Cell.CELL_TYPE_STRING)
			return cell.getStringCellValue();
		else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			String cellText = NumberToTextConverter.toText(cell
					.getNumericCellValue());
			if (HSSFDateUtil.isCellDateFormatted(cell)) {
				double d = cell.getNumericCellValue();
				Calendar cal = Calendar.getInstance();
				cal.setTime(HSSFDateUtil.getJavaDate(d));
				int Year = cal.get(Calendar.YEAR);
				int Day = cal.get(Calendar.DAY_OF_MONTH);
				int Month = cal.get(Calendar.MONTH) + 1;
				cellText = Day + "/" + Month + "/"
						+ (String.valueOf(Year)).substring(2);
			}
			return cellText;
		} else if (cell.getCellType() == Cell.CELL_TYPE_FORMULA)
			return cell.getStringCellValue();
		else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
			return "";
		else
			return String.valueOf(cell.getBooleanCellValue());
	}

}
