/**
 * 
 */
//var app = angular.module('myApp', ["angular-dialgauge"]);
var app = angular.module('myApp', [ 'easypiechart',
		'angularUtils.directives.dirPagination', 'nvd3' ]);  //We are including modules that is pierchart module tables and pagination module
/*app.controller('chartCtrl', ['$scope', function ($scope) {
 $scope.percent = 65;
 $scope.options = {
 animate:{
 duration:0,
 enabled:false
 },
 barColor:'#2C3E50',
 scaleColor:false,
 lineWidth:20,
 lineCap:'circle'
 };
 }]);*/

app
		.controller(
				'myCtrl',
				function($scope, $http) {
					$scope.searchCriterias = [ "All"];
				
					
					$scope.initialValue = 28;

					$scope.displayChart = function() {
						console.log("It is called....");

						$scope.anotherOptionsPass = {
							animate : {
								duration : 0,
								enabled : false
							},
							barColor : '#4CAF50',
							scaleColor : false,
							lineWidth : 20,
							lineCap : 'circle'
						};

						$scope.anotherOptionsFail = {
							animate : {
								duration : 0,
								enabled : false
							},
							barColor : '#f44336',
							scaleColor : false,
							lineWidth : 20,
							lineCap : 'circle'
						};

						$scope.anotherOptionsNoRun = {
							animate : {
								duration : 0,
								enabled : false
							},
							barColor : '#cddc39',
							scaleColor : false,
							lineWidth : 20,
							lineCap : 'circle'
						};

						$scope.gauge5 = 60;//Math.floor(Math.random() * 50);
					};
					console.log("It is going to call");
					$scope.displayChart();

					$scope.sort = function(keyname) {
						console.log("Sort called::::");
						$scope.sortBy = keyname; //set the sortBy to the param passed
						$scope.reverse = !$scope.reverse; //if true make it false and vice versa
					}

					// Function to get the data
					$scope.getData = function() {
						$http(
								{
									method : 'GET',
									url : '/ComPASRegDashboard/regressionTestReportView',
									params : {
										search_criteria : $scope.selectedSearchCriteria,
										//search_criteria :"HFDVDI017611",
										time_to_refresh : $.now()
									},
									headers : {
										common : {
											"Cache-Control" : "no-cache",
											"If-Modified-Since" : "0",
											"Pragma" : "no-cache"
										}
									}
								})
								.success(
										function(data, status, headers, config) {
											
											console.log("In Success::::");
											console.log("Data is "+data[0]);
											console.log("Data1 is :"+data[1].regressionResultRow[1]);
											

											$scope.regressionResults = data[0];
											$scope.results = data[1].regressionResultRow;
											$scope.failureReasons = data[2];
											$scope.searchCriterias = data[3];
											
											console.log("TestCaseResultRow is.*****..:::"+ $scope.cases)
											console.log("In regressionResults is:::"+$scope.regressionResults.totalPassTestCasesCnt)
																					
											$scope.passAnotherPercent = (($scope.regressionResults.totalPassTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);
											$scope.passPercent = (($scope.regressionResults.totalPassTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);

											$scope.failPercent = (($scope.regressionResults.totalfailTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);
											$scope.failAnotherPercent = (($scope.regressionResults.totalfailTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);

											$scope.noRunPercent = (($scope.regressionResults.initializedTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);
											$scope.noRunAnotherPercent = (($scope.regressionResults.initializedTestCasesCnt / $scope.regressionResults.totalTestCasesCnt) * 100);

											$scope.manualExecutionTime = $scope.regressionResults.totalTestCasesCnt * 0.5;
											$scope.automationEffort = 0.20 * $scope.regressionResults.totalTestCasesCnt * 0.25;
											$scope.currentSavings = $scope.manualExecutionTime - $scope.automationEffort;
											
											$scope.utilizationPercent = $scope.regressionResults.totalUtilizationPercent.toFixed(2);
											
											failBarChartGraphArray =  $scope.regressionResults.failGraphDataPoints;
											passBarChartGraphArray = $scope.regressionResults.passGraphDataPoints;
											console.log(failBarChartGraphArray);
											console.log(passBarChartGraphArray);
											$scope.dataForStackedBarChart[0].values = failBarChartGraphArray;
											$scope.dataForStackedBarChart[1].values = passBarChartGraphArray;
											
											if (!isNaN($scope.noRunPercent)) {
												$scope.noRunPercent = Math
														.round(
																$scope.noRunPercent,
																2);
											}
											if (!isNaN($scope.noRunAnotherPercent)) {
												$scope.noRunAnotherPercent = Math
														.round(
																$scope.noRunAnotherPercent,
																2);
											}

											if (!isNaN($scope.passAnotherPercent)) {
												$scope.passAnotherPercent = Math
														.round(
																$scope.passAnotherPercent,
																2);
											}
											if (!isNaN($scope.passPercent)) {
												$scope.passPercent = Math
														.round(
																$scope.passPercent,
																2);
											}
											if (!isNaN($scope.failPercent)) {
												$scope.failPercent = Math
														.round(
																$scope.failPercent,
																2);
											}
											if (!isNaN($scope.failAnotherPercent)) {
												$scope.failAnotherPercent = Math
														.round(
																$scope.failAnotherPercent,
																2);
											}
											//$scope.options1.chart.yDomain = [0,250];
											//$scope.options1.chart.xDomain = [0,250];  
											$scope.update();

										})
								.error(function(data, status, headers, config) {
									// called asynchronously if an error occurs
									// or server returns response with an error status.
								});

					};

					$scope.options2 = {
				            chart: {
				                type: 'multiBarChart',
				                height: 200,
				                margin : {
				                    top: 20,
				                    right: 20,
				                    bottom: 45,
				                    left: 45
				                },
				                x : function(d) {
									return d[0];
								},
								y : function(d) {
									return d[1];
								},
								
				                clipEdge: true,
				                duration: 500,
				                grouped: true,
				                xAxis: {
				                    axisLabel: 'Time',
				                    showMaxMin: false,
				                    tickFormat: function(d){
				                        return d3.time.format('%d-%b %X')(new Date(d));//d3.time.format('%c')(new Date(d));//d3.time.format('%x')(new Date(d));//d3.format(',f')(d);
				                    }
				                },
				                yAxis: {
				                    axisLabel: 'Percentage',
				                    axisLabelDistance: -20,
				                    tickFormat: function(d){
				                        return d3.format(',.2f')(d);
				                    }
				                }
				            }
				        };
					
					$scope.options1 = {
						chart : {
							type : 'lineChart',
							height : 450,
							margin : {
								top : 20,
								right : 20,
								bottom : 40,
								left : 55
							},
							x : function(d) {
								return d[0];
							},
							y : function(d) {
								return d[1];
							},
							
							// x: function(d){ return d.x; },
							// y: function(d){ return d.y; },
							useInteractiveGuideline : true,
							dispatch : {
								stateChange : function(e) {
									console.log("stateChange");
								},
								changeState : function(e) {
									console.log("changeState");
								},
								tooltipShow : function(e) {
									console.log("tooltipShow");
								},
								tooltipHide : function(e) {
									console.log("tooltipHide");
								}
							},
							xAxis : {
								tickFormat : function(d) {
									return d3.time.format('%X')(new Date(d)); //d3.time.format('%x')(new Date(d));
								},
								axisLabel : 'Time'
							},
							yAxis : {
								axisLabel : 'Total Number of Test Cases Completed',
								tickFormat : function(d) {
									return d3.format('.02f')(d);
								},
								axisLabelDistance : -10
							},
							callback : function(chart) {
								console.log("!!! lineChart callback !!!");
							}
						},
						title : {
							enable : false,
							text : 'Title for Line Chart'
						},
						subtitle : {
							enable : false,
							text : 'Do not display any subtitle',
							css : {
								'text-align' : 'center',
								'margin' : '10px 13px 0px 7px'
							}
						},
						caption : {
							enable : false,
							html : 'do not display any caption',
							css : {
								'text-align' : 'justify',
								'margin' : '10px 13px 0px 7px'
							}
						}
					};

					$scope.options = {
						chart : {
							type : 'stackedAreaChart',
							height : 450,
							margin : {
								top : 20,
								right : 20,
								bottom : 30,
								left : 40
							},
							x : function(d) {
								return d[0];
							},
							y : function(d) {
								return d[1];
							},
							useVoronoi : false,
							clipEdge : true,
							duration : 100,
							useInteractiveGuideline : true,
							xAxis : {
								showMaxMin : false,
								tickFormat : function(d) {
									return "";//d3.time.format('%x')(new Date(d))
								}
							},
							yAxis : {
								tickFormat : function(d) {
									return d3.format(',.2f')(d);
								}
							},
							zoom : {
								enabled : true,
								scaleExtent : [ 1, 10 ],
								useFixedDomain : false,
								useNiceScale : false,
								horizontalOff : false,
								verticalOff : true,
								unzoomEventType : 'dblclick.zoom'
							}
						}
					};
					$scope.run = true;

				
					/*var inProgressGraphArray = [ [ 0, 0 ] ];
					var passGraphArray = [ [ 0, 0 ] ];
					var failGraphArray = [ [ 0, 0 ] ];
					var lineChartGraphArray = [ [ 0, 0 ] ];*/
					
					var inProgressGraphArray  ;
					var passGraphArray ;
					var failGraphArray ;
					var lineChartGraphArray ;
					var failBarChartGraphArray =  [[ 0 , 0] , [ 0 , 0] , [ 0 ,0] , [0 , 0] , [ 0 , 0]];
					var	passBarChartGraphArray =  [[ 0 , 0] , [0 , 0] , [ 0 , 0] , [ 0 , 0] , [ 0 , 0] ];
						
					var inProgressGraphArray1 = [];
					var passGraphArray1 = [];
					var failGraphArray1 = [];
					var lineChartGraphArray1 = [];

					var x = 0;
					var inprogressY = 0;
					var passY = 0;
					var failY = 0;
					var clubbingCount = 9;
					var pointerVal = -5;
					var lastCompletedTestCaseCnt = 0;//$scope.regressionResults.totalTestCasesCompleted;

					var lineChartX = 0;
					
					$scope.dataForStackedBarChart=[{"key" : "Fail",
					       						"values" : failBarChartGraphArray,
					color : '#f44336'							
					},
					 {
						"key" : "Pass",
						"values" : passBarChartGraphArray,
						color : '#4CAF50'
					}
					];
					
					$scope.dataForStackedChart = [ {
						"key" : "Fail",
						"values" : failGraphArray,
						color : '#f44336'
					}, {
						"key" : "Pass",
						"values" : passGraphArray,
						color : '#4CAF50'
					}, {
						"key" : "In Progress",
						"values" : inProgressGraphArray,
						color : '#2196F3'
					} ];

					$scope.dataForLineChart = [ {
						values : lineChartGraphArray,
						key : 'Completed Test Cases',
						color : '#2ca02c'
					} ];

					// var inProgressArray = [1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0,1,1,1,1,0,0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,0,1,1,1,0,1,0,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,0,0,0,0,0,0,0];
					//var passArray = [0,0,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,0,0,1,1,0,1,1,0,1,1,0,1,0,1,0,0,1,0,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,1,0,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,0,0,1,1,0,1,1,0,1,1,0,1,0,1,0,0,1,0,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,0,0,0,1,1,0,1,1,0,1,1,0,1,0,1,0,0,1,0,0,1,0,1,1,0,0,0,1,0,0,0,1,1,1,0,1,0,1,1,1,1,1,1,1,0]
					//var failArray = [0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,1,1,1,0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,1,1,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,1,1,1,0,1,0,0,0,1]

					//using data from data feed table
					// var inProgressArray =[1,1,1,1,1,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,0,1,1,0,1,0,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,0,1,0,0,1,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,1,1,0,1,0,1,0,0,1,1,0,1,0,1,0,1,0,0,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,0,1,0,0,1,1,0,0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0];
					// var passArray =[0,0,0,0,0,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,1,0,0,1,0,1,0,1,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,0,0,0,1,0,0,0,1,0,1,0,1,1,1,0,0,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,1,0,1,0,1,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
					// var failArray = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1,1,0,0,0,1,0,0,0,0,1,0,1,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1];

					$scope.update = function() {
						if (!$scope.run)
							return;

						/* clubbingCount = clubbingCount + 5;
						 pointerVal = pointerVal +5;
						 inprogressY = 0;
						 passY = 0;
						 failY = 0;
						 if(clubbingCount < inProgressArray.length ){
						     for(i=pointerVal; i<clubbingCount;i++){
						  	   inprogressY = inprogressY + inProgressArray[i];
						  	   passY = passY + passArray[i];
						  	   failY = failY + failArray[i];
						     }
						 }*/

						var time = new Date();
						var x = time.getTime();

						var milliSecondTime = Date.parse(time);

						//console.log(x);
						// inProgressGraphArray1.push([x ,inprogressY ]);
						// passGraphArray1.push([x ,passY ]);
						// failGraphArray1.push([x ,failY ]);

						inProgressGraphArray1.push([ x,
								$scope.regressionResults.inProgressDataPoint ]);
						passGraphArray1.push([ x,
								$scope.regressionResults.passDataPoint ]);
						failGraphArray1.push([ x,
								$scope.regressionResults.failDataPoint ]);

						if ($scope.regressionResults.totalTestCasesCompleted == 0) {
							lineChartGraphArray1
									.push([
											milliSecondTime,
											$scope.regressionResults.totalTestCasesCompleted ])
						}

						inProgressGraphArray = inProgressGraphArray1;//[ [ 1025409600000 , 23.041422681023] , [ 1028088000000 , 19.854291255832] , [ 1030766400000 , 21.02286281168] , [ 1033358400000 , 22.093608385173] , [ 1036040400000 , 25.108079299458] , [ 1038632400000 , 26.982389242348] , [ 1041310800000 , 19.828984957662] , [ 1043989200000 , 19.914055036294] , [ 1046408400000 , 19.436150539916] , [ 1049086800000 , 21.558650338602] , [ 1051675200000 , 24.395594061773] , [ 1054353600000 , 24.747089309384] , [ 1056945600000 , 23.491755498807] , [ 1059624000000 , 23.376634878164] , [ 1062302400000 , 24.581223154533] , [ 1064894400000 , 24.922476843538] , [ 1067576400000 , 27.357712939042] , [ 1070168400000 , 26.503020572593] , [ 1072846800000 , 26.658901244878] , [ 1075525200000 , 27.065704156445] , [ 1078030800000 , 28.735320452588] , [ 1080709200000 , 31.572277846319] , [ 1083297600000 , 30.932161503638] , [ 1085976000000 , 31.627029785554] , [ 1088568000000 , 28.728743674232] , [ 1091246400000 , 26.858365172675] , [ 1093924800000 , 27.279922830032] , [ 1096516800000 , 34.408301211324] , [ 1099195200000 , 34.794362930439] , [ 1101790800000 , 35.609978198951] , [ 1104469200000 , 33.574394968037] , [ 1107147600000 , 31.979405070598] , [ 1109566800000 , 31.19009040297] , [ 1112245200000 , 31.083933968994] , [ 1114833600000 , 29.668971113185] , [ 1117512000000 , 31.490638014379] , [ 1120104000000 , 31.818617451128] , [ 1122782400000 , 32.960314008183] , [ 1125460800000 , 31.313383196209] , [ 1128052800000 , 33.125486081852] , [ 1130734800000 , 32.791805509149] , [ 1133326800000 , 33.506038030366] , [ 1136005200000 , 26.96501697216] , [ 1138683600000 , 27.38478809681] , [ 1141102800000 , 27.371377218209] , [ 1143781200000 , 26.309915460827] , [ 1146369600000 , 26.425199957518] , [ 1149048000000 , 26.823411519396] , [ 1151640000000 , 23.850443591587] , [ 1154318400000 , 23.158355444054] , [ 1156996800000 , 22.998689393695] , [ 1159588800000 , 27.9771285113] , [ 1162270800000 , 29.073672469719] , [ 1164862800000 , 28.587640408904] , [ 1167541200000 , 22.788453687637] , [ 1170219600000 , 22.429199073597] , [ 1172638800000 , 22.324103271052] , [ 1175313600000 , 17.558388444187] , [ 1177905600000 , 16.769518096208] , [ 1180584000000 , 16.214738201301] , [ 1183176000000 , 18.729632971229] , [ 1185854400000 , 18.814523318847] , [ 1188532800000 , 19.789986451358] , [ 1191124800000 , 17.070049054933] , [ 1193803200000 , 16.121349575716] , [ 1196398800000 , 15.141659430091] , [ 1199077200000 , 17.175388025297] , [ 1201755600000 , 17.286592443522] , [ 1204261200000 , 16.323141626568] , [ 1206936000000 , 19.231263773952] , [ 1209528000000 , 18.446256391095] , [ 1212206400000 , 17.822632399764] , [ 1214798400000 , 15.53936647598] , [ 1217476800000 , 15.255131790217] , [ 1220155200000 , 15.660963922592] , [ 1222747200000 , 13.254482273698] , [ 1225425600000 , 11.920796202299] , [ 1228021200000 , 12.122809090924] , [ 1230699600000 , 15.691026271393] , [ 1233378000000 , 14.720881635107] , [ 1235797200000 , 15.387939360044] , [ 1238472000000 , 13.765436672228] , [ 1241064000000 , 14.631445864799] , [ 1243742400000 , 14.292446536221] , [ 1246334400000 , 16.170071367017] , [ 1249012800000 , 15.948135554337] , [ 1251691200000 , 16.612872685134] , [ 1254283200000 , 18.778338719091] , [ 1256961600000 , 16.756026065421] , [ 1259557200000 , 19.385804443146] , [ 1262235600000 , 22.950590240168] , [ 1264914000000 , 23.61159018141] , [ 1267333200000 , 25.708586989581] , [ 1270008000000 , 26.883915999885] , [ 1272600000000 , 25.893486687065] , [ 1275278400000 , 24.678914263176] , [ 1277870400000 , 25.937275793024] , [ 1280548800000 , 29.461381693838] , [ 1283227200000 , 27.357322961861] , [ 1285819200000 , 29.057235285673] , [ 1288497600000 , 28.549434189386] , [ 1291093200000 , 28.506352379724] , [ 1293771600000 , 29.449241421598] , [ 1296450000000 , 25.796838168807] , [ 1298869200000 , 28.740145449188] , [ 1301544000000 , 22.091744141872] , [ 1304136000000 , 25.07966254541] , [ 1306814400000 , 23.674906973064] , [ 1309406400000 , 23.418002742929] , [ 1312084800000 , 23.24364413887] , [ 1314763200000 , 31.591854066817] , [ 1317355200000 , 31.497112374114] , [ 1320033600000 , 26.67238082043] , [ 1322629200000 , 27.297080015495] , [ 1325307600000 , 20.174315530051] , [ 1327986000000 , 19.631084213898] , [ 1330491600000 , 20.366462219461] , [ 1333166400000 , 19.284784434185] , [ 1335758400000 , 19.157810257624]];
						passGraphArray = passGraphArray1;
						failGraphArray = failGraphArray1;
						//console.log(graphArray);
						$scope.dataForStackedChart[0].values = failGraphArray;
						$scope.dataForStackedChart[1].values = passGraphArray;
						$scope.dataForStackedChart[2].values = inProgressGraphArray;
						if ($scope.dataForStackedChart[0].values.length > 50) {
							$scope.dataForStackedChart[0].values.shift();
							$scope.dataForStackedChart[1].values.shift();
							$scope.dataForStackedChart[2].values.shift();
						}

						console
								.log("totalTestCasesCompleted ="
										+ $scope.regressionResults.totalTestCasesCompleted+" lastCompletedTestCaseCnt ="
								+ lastCompletedTestCaseCnt +" milliSecondTime =" +milliSecondTime);
						//Code to Update line chart with latest data
						if (lastCompletedTestCaseCnt < $scope.regressionResults.totalTestCasesCompleted) {

							lineChartGraphArray1
									.push([
											milliSecondTime,
											$scope.regressionResults.totalTestCasesCompleted ])
							lineChartGraphArray = lineChartGraphArray1;
							$scope.dataForLineChart[0].values = lineChartGraphArray;
							lastCompletedTestCaseCnt = $scope.regressionResults.totalTestCasesCompleted;

							/*lineChartX++;
							lastCompletedTestCaseCnt = $scope.regressionResults.totalTestCasesCompleted;
							 $scope.dataForLineChart[0].values.push({ x: milliSecondTime,	y: lastCompletedTestCaseCnt});*/

						}
						//  $scope.$apply(); // update both chart
					};

					/*$scope.getInitialLineChartValues = function(){
						var initialValues  = [];
						initialValues.push({x: lineChartX, y: 0});
						
						return [ 
					            {
					                values: initialValues,
					                key: 'Completed Test Cases',
					                color: '#2ca02c'
					            }
					        ];
					};*/
					//  $scope.dataForLineChart = $scope.getInitialLineChartValues();
					$scope.getData();
					setInterval($scope.getData, 15000);
				});