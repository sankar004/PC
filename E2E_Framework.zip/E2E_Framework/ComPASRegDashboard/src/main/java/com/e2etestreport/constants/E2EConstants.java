package com.e2etestreport.constants;

public class E2EConstants {
	public static final String IN_PROGRESS = "In progress";
	public static final String PASSED = "Passed";
	public static final String FAILED = "Failed";
	public static final String ALL = "All";
	public static final int MAX_DATA_POINT = 10;

}
