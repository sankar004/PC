package com.e2etestreport.DAO;

import java.io.ObjectInputStream.GetField;
import java.sql.Connection;

import com.e2etestreport.utilities.DBConnectionManager;

public class TestMain {

	public static void main (String args[]){
		
		// DBConnectionManager.getInstance();
		
		RegressionReportUtilityDAO dao = new RegressionReportUtilityDAO();
		dao.retrieveRegressionStatus();
	}
	
}
