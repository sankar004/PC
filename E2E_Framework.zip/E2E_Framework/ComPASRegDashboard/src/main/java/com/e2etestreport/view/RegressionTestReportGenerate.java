package com.e2etestreport.view;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.e2etestreport.DAO.RegressionReportUtilityDAO;
import com.e2etestreport.response.FailureReasons;
import com.e2etestreport.response.RegressionResultSet;
import com.e2etestreport.response.RegressionStatus;
import com.e2etestreport.utilities.Loadprops;
import com.google.gson.Gson;

public class RegressionTestReportGenerate extends HttpServlet{
    private static final long serialVersionUID = 1L;

    public RegressionTestReportGenerate() {
            super();
    }

    
    /*public static void main(String args[]){
    	List<int[]> A = new ArrayList<int[]>();
        A.add(new int[] {15,20});
        
    	int abc[] [] = new int[5][2];
    	abc[0][0] = 4324234;
    	abc[1][0] =4234;
    	abc[0][1] = 1;
    	abc[1][1] =2;
    	 String jsonArray = new Gson().toJson(A);
         System.out.println("json Array ="+jsonArray);
    }*/
    protected void doGet(HttpServletRequest request,
        HttpServletResponse response) throws ServletException, IOException {
    		//String machineName="HFDVDI017611";
    		String machineName=request.getParameter("search_criteria");
            response.setContentType("application/json");
            //String bothJson = "["+json+","+jsonArray+"]";
            RegressionStatus regressionStatus = null;
			if (Loadprops.properties.size() == 0) {
					Loadprops.initializeSysConfigProperties();
			}
            RegressionReportUtilityDAO reportUtilDAO = new RegressionReportUtilityDAO();
			if (machineName != null && !machineName.equalsIgnoreCase("ALL")) {
				regressionStatus = reportUtilDAO.retrieveRegressionStatus(machineName);
			} else {
				regressionStatus = reportUtilDAO.retrieveRegressionStatus();
			}
			 RegressionResultSet regressionResultSet;
			if (machineName != null && !machineName.equalsIgnoreCase("ALL")) {
				  regressionResultSet = reportUtilDAO.retrieveResultRecords(regressionStatus.getTotalTestCasesCnt(),machineName);
			} else {
				  regressionResultSet = reportUtilDAO.retrieveResultRecords(regressionStatus.getTotalTestCasesCnt());
			}
			
            
            ArrayList <FailureReasons> failureReasons;
            if (machineName != null && !machineName.equalsIgnoreCase("ALL")) {
            	failureReasons = reportUtilDAO.retrieveFailCases(machineName);
			} else {
				 failureReasons = reportUtilDAO.retrieveFailCases();
			}
            
           
           
            
            reportUtilDAO.closeConnections();
            
            String regResultJsonArray = new Gson().toJson(regressionResultSet);
            String failureReasonsJsonArray = new Gson().toJson(failureReasons);
            
            System.out.println("json Array ="+regResultJsonArray);
            System.out.println("json Array for failReasons ="+failureReasonsJsonArray);
            
            ArrayList<String> machines = new ArrayList<String>();
            
            machines = reportUtilDAO.retrieveMachineDetails();
            //adding default option
            machines.add("All");
            
            String regStatusJsonArray = new Gson().toJson(regressionStatus);
            
            System.out.println("json ="+regStatusJsonArray);
            String responseJson = "["+regStatusJsonArray+","+regResultJsonArray+","+failureReasonsJsonArray+","+new Gson().toJson(machines)+"]";
            //response.getWriter().write(regStatusJson);
            response.getWriter().write(responseJson);
    }
}
