package com.e2etestreport.view;

import java.util.List;

public class PolicyDataSet {
	PolicyData[] policydataArray = null;
	List<PolicyData> policyDataArrayList = null;

	public PolicyData[] getPolicydataArray() {
		return policydataArray;
	}

	public List<PolicyData> getPolicyDataArrayList() {
		return policyDataArrayList;
	}

	public void setPolicyDataArrayList(List<PolicyData> policyDataArrayList) {
		this.policyDataArrayList = policyDataArrayList;
	}

	public void setPolicydataArray(PolicyData[] policydataArray) {
		this.policydataArray = policydataArray;
	}
	
}
