package com.e2etestreport.response;

import java.util.ArrayList;
import java.util.List;

public class RegressionStatus {
  private int totalTestCasesCnt = 0;
  private int totalPassTestCasesCnt = 0;
  private int totalfailTestCasesCnt = 0;
  private int inProgressDataPoint = 0;
  private int initializedTestCasesCnt = 0;
  private int passDataPoint = 0;
  private int failDataPoint = 0;
  private int totalTestCasesCompleted = 0;
  private int totalMachineCount = 0;
  private int totalInsutancesCount = 0;
  private double totalUtilizationPercent = 0;
  private String startTime = null;
  private String endTime = null;
  private String lapseTime =null;
  private String graphLapseTime = null;
  List<double[]> passGraphDataPoints = new ArrayList<double[]>();
  List<double[]> failGraphDataPoints = new ArrayList<double[]>();

  
  
public List<double[]> getPassGraphDataPoints() {
	return passGraphDataPoints;
}
public void setPassGraphDataPoints(List<double[]> passGraphDataPoints) {
	this.passGraphDataPoints = passGraphDataPoints;
}
public List<double[]> getFailGraphDataPoints() {
	return failGraphDataPoints;
}
public void setFailGraphDataPoints(List<double[]> failGraphDataPoints) {
	this.failGraphDataPoints = failGraphDataPoints;
}
public String getGraphLapseTime() {
	return graphLapseTime;
}
public void setGraphLapseTime(String graphLapseTime) {
	this.graphLapseTime = graphLapseTime;
}
public String getStartTime() {
	return startTime;
}
public void setStartTime(String startTime) {
	this.startTime = startTime;
}
public String getEndTime() {
	return endTime;
}
public void setEndTime(String endTime) {
	this.endTime = endTime;
}
public String getLapseTime() {
	return lapseTime;
}
public void setLapseTime(String lapseTime) {
	this.lapseTime = lapseTime;
}
public int getTotalMachineCount() {
	return totalMachineCount;
}
public void setTotalMachineCount(int totalMachineCount) {
	this.totalMachineCount = totalMachineCount;
}
public int getTotalInsutancesCount() {
	return totalInsutancesCount;
}
public void setTotalInsutancesCount(int totalInsutancesCount) {
	this.totalInsutancesCount = totalInsutancesCount;
}
public double getTotalUtilizationPercent() {
	return totalUtilizationPercent;
}
public void setTotalUtilizationPercent(double totalUtilizationPercent) {
	this.totalUtilizationPercent = totalUtilizationPercent;
}
public int getInitializedTestCasesCnt() {
	return initializedTestCasesCnt;
}
public void setInitializedTestCasesCnt(int initializedTestCasesCnt) {
	this.initializedTestCasesCnt = initializedTestCasesCnt;
}
public int getTotalTestCasesCompleted() {
	return totalTestCasesCompleted;
}
public void setTotalTestCasesCompleted(int totalTestCasesCompleted) {
	this.totalTestCasesCompleted = totalTestCasesCompleted;
}
public int getInProgressDataPoint() {
	return inProgressDataPoint;
}
public void setInProgressDataPoint(int inProgressDataPoint) {
	this.inProgressDataPoint = inProgressDataPoint;
}
public int getPassDataPoint() {
	return passDataPoint;
}
public void setPassDataPoint(int passDataPoint) {
	this.passDataPoint = passDataPoint;
}
public int getFailDataPoint() {
	return failDataPoint;
}
public void setFailDataPoint(int failDataPoint) {
	this.failDataPoint = failDataPoint;
}
public int getTotalTestCasesCnt() {
	return totalTestCasesCnt;
}
public void setTotalTestCasesCnt(int totalTestCasesCnt) {
	this.totalTestCasesCnt = totalTestCasesCnt;
}
public int getTotalPassTestCasesCnt() {
	return totalPassTestCasesCnt;
}
public void setTotalPassTestCasesCnt(int totalPassTestCasesCnt) {
	this.totalPassTestCasesCnt = totalPassTestCasesCnt;
}
public int getTotalfailTestCasesCnt() {
	return totalfailTestCasesCnt;
}
public void setTotalfailTestCasesCnt(int totalfailTestCasesCnt) {
	this.totalfailTestCasesCnt = totalfailTestCasesCnt;
}
  
  
}
