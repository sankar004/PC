package com.e2etestreport.response;

public class RegressionResultRow {
  private String moduleName = null;
  private int totalTestCaseCnt = 0;
  private double failPercent = 0;
  private double failContributionPercent = 0;
  private int initializedCount = 0;
  private int passCount = 0;
  private int failCount = 0;
	
  
  
public int getInitializedCount() {
	return initializedCount;
}
public void setInitializedCount(int initializedCount) {
	this.initializedCount = initializedCount;
}
public int getPassCount() {
	return passCount;
}
public void setPassCount(int passCount) {
	this.passCount = passCount;
}
public int getFailCount() {
	return failCount;
}
public void setFailCount(int failCount) {
	this.failCount = failCount;
}
public String getModuleName() {
	return moduleName;
}
public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}
public int getTotalTestCaseCnt() {
	return totalTestCaseCnt;
}
public void setTotalTestCaseCnt(int totalTestCaseCnt) {
	this.totalTestCaseCnt = totalTestCaseCnt;
}
public double getFailPercent() {
	return failPercent;
}
public void setFailPercent(double failPercent) {
	this.failPercent = failPercent;
}
public double getFailContributionPercent() {
	return failContributionPercent;
}
public void setFailContributionPercent(double failContributionPercent) {
	this.failContributionPercent = failContributionPercent;
}
	
}
