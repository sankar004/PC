package com.e2etestreport.response;

import java.util.List;

public class RegressionResultSet {
	 List<RegressionResultRow> regressionResultRow = null;

	public List<RegressionResultRow> getRegressionResultRow() {
		return regressionResultRow;
	}

	public void setRegressionResultRow(List<RegressionResultRow> regressionResultRow) {
		this.regressionResultRow = regressionResultRow;
	}
	 

}
