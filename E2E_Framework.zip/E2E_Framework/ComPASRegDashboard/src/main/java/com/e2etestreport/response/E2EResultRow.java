package com.e2etestreport.response;

public class E2EResultRow {
    private String e2ETCaseId = null;
    private String e2EQCTCaseName = null;
    private String e2ETool = null;
    private String e2eApplication = null;
    private String executingMachine = null;
    private String durationMinutes = null;
    
    
    public String getExecutingMachine() {
		return executingMachine;
	}
	public void setExecutingMachine(String executingMachine) {
		this.executingMachine = executingMachine;
	}
	public String getE2eApplication() {
		return e2eApplication;
	}
	public void setE2eApplication(String e2eApplication) {
		this.e2eApplication = e2eApplication;
	}
	private String e2EStatus = null;
    private String e2ETimeStamp = null;
	public String getE2ETCaseId() {
		return e2ETCaseId;
	}
	public void setE2ETCaseId(String e2etCaseId) {
		e2ETCaseId = e2etCaseId;
	}
	public String getE2EQCTCaseName() {
		return e2EQCTCaseName;
	}
	public void setE2EQCTCaseName(String e2eqctCaseName) {
		e2EQCTCaseName = e2eqctCaseName;
	}
	public String getE2ETool() {
		return e2ETool;
	}
	public void setE2ETool(String e2eTool) {
		e2ETool = e2eTool;
	}
	public String getE2EStatus() {
		return e2EStatus;
	}
	public void setE2EStatus(String e2eStatus) {
		e2EStatus = e2eStatus;
	}
	public String getE2ETimeStamp() {
		return e2ETimeStamp;
	}
	public void setE2ETimeStamp(String e2eTimeStamp) {
		e2ETimeStamp = e2eTimeStamp;
	}
	public String getDurationMinutes() {
		return durationMinutes;
	}
	public void setDurationMinutes(String durationMinutes) {
		this.durationMinutes = durationMinutes;
	}
    

}
