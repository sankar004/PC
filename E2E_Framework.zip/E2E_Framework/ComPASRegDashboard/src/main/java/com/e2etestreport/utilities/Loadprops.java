package com.e2etestreport.utilities;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class Loadprops {
	
	private static Logger log = Logger.getLogger(Loadprops.class);
	public static Properties properties = new Properties();

	public static void initializeSysConfigProperties() {
		InputStream is = null;
		try {
				is = Loadprops.class.getClassLoader().getResourceAsStream("/connection.properties");
				properties.load(is);
			log.error("Loaded......");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (is != null)
					is.close();
			} catch (IOException e) {
				log.error("Error occured while loading the config properties file.");
			}
		}
	}

}
