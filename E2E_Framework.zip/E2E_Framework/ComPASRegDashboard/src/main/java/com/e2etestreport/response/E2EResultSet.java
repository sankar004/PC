package com.e2etestreport.response;

import java.util.List;

public class E2EResultSet {
    List<E2EResultRow> e2eResultSet = null;

	public List<E2EResultRow> getE2eResultSet() {
		return e2eResultSet;
	}

	public void setE2eResultSet(List<E2EResultRow> e2eResultSet) {
		this.e2eResultSet = e2eResultSet;
	}
}
