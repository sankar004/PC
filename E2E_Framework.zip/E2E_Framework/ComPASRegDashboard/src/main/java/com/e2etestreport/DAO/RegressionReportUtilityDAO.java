package com.e2etestreport.DAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.e2etestreport.constants.E2EConstants;
import com.e2etestreport.response.RegressionResultRow;
import com.e2etestreport.response.RegressionResultSet;
import com.e2etestreport.response.RegressionStatus;
import com.e2etestreport.response.FailureReasons;
import com.e2etestreport.utilities.DBConnectionManager;

public class RegressionReportUtilityDAO {
	private Connection connection;
	private Statement 	st;
	private ResultSet rs;
	
	private static Logger log = Logger.getLogger(RegressionReportUtilityDAO.class);
	
	public RegressionReportUtilityDAO(){
		
	}
	
	public RegressionStatus retrieveRegressionStatus() {
		RegressionStatus regressionStatus = new RegressionStatus();
		int totalTestCasesCnt = 1;
		int totalPassTestCasesCnt = 1;
		int totalfailTestCasesCnt = 1;
		int inProgressDataPoint = 0;
		int passDataPoint = 0;
		int failDataPoint = 0;
		int totalTestCasesCompleted = 0;
		int initializedTestCasesCnt = 0;
		int totalMachineCount = 0;
		int totalInstancesCount = 0;
		double totalUtilizationPercent = 0;
		String startTime = "";
		String endTime = "";
		String lapseTime = "";
//		String graphStartTime = "";
		String graphEndTime = "";
		String graphLapseTime = "";
		List<double[]> passGraphDataPoints = new ArrayList<double[]>();
		List<double[]> failGraphDataPoints = new ArrayList<double[]>();
		try {
		
			//log.info("Finished.....:");
			connection = DBConnectionManager.getInstance().getConnection();
			log.info("In try connection:::  "+connection);
			st = connection.createStatement();
			log.info("In try st:::  "+st);
			rs = st.executeQuery("Select BATCH_ID, sum(case when TEST_CASE_STAT_DESC = 'Pass' then 1 else 0 end), sum(case when TEST_CASE_STAT_DESC not in ('Pass') "
					+ "then 1 else 0 end), count(*) from TEST_EXEC_STAT_LOG where BATCH_ID is not null group by BATCH_ID order by batch_id desc");
			log.info("In try rs:::  "+rs);
			int count = 0;
			double passPercent = 0;
			double failPercent = 0;
			int passCount = 0;
			int failCount = 0;
			int totalCount = 0;
			//Date batchId = null;
			Timestamp batchId= null;
			
			
			while (rs.next()) {
				batchId = rs.getTimestamp(1);
				if (batchId != null)
					
					
				log.info("In try batchId:::  "+batchId);
				/*batchId =rs.getDate(1);
				//batchId = rs.getDate(1);
				time=rs.getTime(1);
				log.info("In try batchId:::  "+batchId);
				log.info("In try time:::  "+time);*/
				passCount = rs.getInt(2);
				log.info("In try passCount:::  "+passCount);
				failCount = rs.getInt(3);
				log.info("In try failCount:::  "+failCount);
				totalCount = rs.getInt(4);
				if (batchId != null && totalCount > 0) {
					count++;
					log.info("count is:::  "+count);
					
					Long longDate = null;
					DecimalFormat df = new DecimalFormat("#.##");
				
					longDate = batchId.getTime();
					if (passCount > 0) {
						log.info("passCount is:::  "+passCount);
						passPercent = ((float) passCount / totalCount) * 100;
						passGraphDataPoints.add(new double[] { longDate,Double.valueOf(df.format(passPercent)) });
					}
					if (failCount > 0) {
						log.info("failCount is:::  "+failCount);
						failPercent = ((float) failCount / totalCount) * 100;
						failGraphDataPoints.add(new double[] { longDate,Double.valueOf(df.format(failPercent)) });
					}
				}
				if (count == 5) {
					break;
				}
			}
			rs = st.executeQuery("Select EXEC_START_TMSP from TEST_EXEC_STATUS where rownum = 1");
			if (rs.next()) {
				startTime = rs.getString(1);
			}
			rs = st.executeQuery("Select count(distinct(EXEC_MACH_NM)) as totalDistinctMachines, count(*) as totalTC, sum(case when TEST_CASE_STAT_DESC = 'Pass' then 1 else 0 end) as passed, sum(case when TEST_CASE_STAT_DESC = 'Fail' then 1 else 0 end) as Failed, sum(case when TEST_CASE_STAT_DESC = 'Initialized' then 1 else 0 end) as Initialized  from TEST_EXEC_STATUS");
			if (rs.next()) {
				totalTestCasesCnt = rs.getInt("totalTC");
				totalPassTestCasesCnt = rs.getInt("passed");
				totalfailTestCasesCnt = rs.getInt("Failed");
				initializedTestCasesCnt = rs.getInt("Initialized");
				totalMachineCount = rs.getInt("totalDistinctMachines");
				//totalInsutancesCount = rs.getInt("totalDistinctThreads");
			}
			
			rs = st.executeQuery("Select count(distinct(EXEC_THREAD_ID)) totalDistinctThreads from TEST_EXEC_STATUS GROUP BY EXEC_MACH_NM");
			while(rs.next()){
				totalInstancesCount = totalInstancesCount +  rs.getInt("totalDistinctThreads");
			}
			
			rs = st.executeQuery("Select count(distinct(EXEC_THREAD_ID)) from TEST_EXEC_STATUS where TEST_CASE_STAT_DESC ='In Progress' GROUP BY EXEC_MACH_NM");

			int totalInProgressThread = 0;
			while (rs.next()) {
				totalInProgressThread = totalInProgressThread + rs.getInt(1);

			}
			if (totalInProgressThread > 0) {
				totalUtilizationPercent = (((float) totalInProgressThread / (float) totalInstancesCount) * 100);
			}

			rs = st.executeQuery("select sum(case when status = 'In Progress' then 1 else 0 end) as inProgress ,"
					+ "sum(case when status = 'Pass' then 1 else 0 end) as passed ,"
					+ "sum(case when status = 'Fail' then 1 else 0 end) as Failed"
					+ " from (select a.* from data_feed a where rownum<="+E2EConstants.MAX_DATA_POINT+" order by id desc)");
//			graphStartTime = "";
			graphEndTime = "";
			graphLapseTime = "0";
			if (rs.next()) {
				inProgressDataPoint = rs.getInt("inProgress");
				passDataPoint = rs.getInt("passed");
				failDataPoint = rs.getInt("Failed");
			}
			
			/**
			 * following query for retrieving the difference between first record time stamp and last record time stamp.
			 * last record will be the E2EConstants.MAX_DATA_POINT value
			 */
			String s = "select ((f. LAST_UPDT_TMSP-l.LAST_UPDT_TMSP) * 24 * 60), f. LAST_UPDT_TMSP,l.LAST_UPDT_TMSP from "
					+ "(SELECT LAST_UPDT_TMSP FROM DATA_FEED WHERE ROWNUM<=1 ORDER BY ID DESC) f,"
					+ "(select LAST_UPDT_TMSP from  (SELECT  LAST_UPDT_TMSP, rownum as colIndex FROM DATA_FEED WHERE ROWNUM <= "
					+E2EConstants.MAX_DATA_POINT+" ORDER BY ID desc) abc where abc.colIndex="+E2EConstants.MAX_DATA_POINT+") l";
			rs = st.executeQuery(s);
			if(rs.next()){
				graphLapseTime = String.format("%d "
						+ "(s)",
						(rs.getLong(1)));
//				graphStartTime = rs.getString(2);
				graphEndTime = rs.getString(3);
			}
			totalTestCasesCompleted = totalfailTestCasesCnt+ totalPassTestCasesCnt;

			if (startTime != null && graphEndTime != null
					&& graphEndTime.length() > 0 && startTime.length() > 0) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date startDate = null;
				Date endDate = null;
				startDate = format.parse(startTime);
				endDate = format.parse(graphEndTime);
				if (startDate != null && endDate != null) {
					lapseTime = getTimeDiff(endDate, startDate);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		
		
		finally {
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}
		

		regressionStatus.setGraphLapseTime(graphLapseTime);
		regressionStatus.setLapseTime(lapseTime);
		regressionStatus.setStartTime(startTime);
		regressionStatus.setEndTime(endTime);
		regressionStatus.setTotalMachineCount(totalMachineCount);
		regressionStatus.setTotalInsutancesCount(totalInstancesCount);
		regressionStatus.setTotalUtilizationPercent(totalUtilizationPercent);
		regressionStatus.setTotalTestCasesCompleted(totalTestCasesCompleted);
		regressionStatus.setInitializedTestCasesCnt(initializedTestCasesCnt);
		regressionStatus.setFailDataPoint(failDataPoint);
		regressionStatus.setPassDataPoint(passDataPoint);
		regressionStatus.setInProgressDataPoint(inProgressDataPoint);
		regressionStatus.setTotalfailTestCasesCnt(totalfailTestCasesCnt);
		regressionStatus.setTotalPassTestCasesCnt(totalPassTestCasesCnt);
		regressionStatus.setTotalTestCasesCnt(totalTestCasesCnt);
		regressionStatus.setFailGraphDataPoints(failGraphDataPoints);
		regressionStatus.setPassGraphDataPoints(passGraphDataPoints);

		return regressionStatus;
	}
	
public RegressionStatus retrieveRegressionStatus(String machineName) {
		

		RegressionStatus regressionStatus = new RegressionStatus();
		int totalTestCasesCnt = 1;
		int totalPassTestCasesCnt = 1;
		int totalfailTestCasesCnt = 1;
		int inProgressDataPoint = 0;
		int passDataPoint = 0;
		int failDataPoint = 0;
		int totalTestCasesCompleted = 0;
		int initializedTestCasesCnt = 0;
		int totalMachineCount = 0;
		int totalInstancesCount = 0;
		double totalUtilizationPercent = 0;
		String startTime = "";
		String endTime = "";
		String lapseTime = "";
//		String graphStartTime = "";
		String graphEndTime = "";
		String graphLapseTime = "";
		List<double[]> passGraphDataPoints = new ArrayList<double[]>();
		List<double[]> failGraphDataPoints = new ArrayList<double[]>();
		try {
			log.info("In try");
			connection = DBConnectionManager.getInstance().getConnection();
			/*Connection connection=DriverManager.getConnection(  
					"jdbc:oracle:thin:@MXL3450R40:1521/XE","compasuser","password123");  */
			log.info("In try connection:::  "+connection);
			st = connection.createStatement();
			log.info("In try st:::  "+st);
			// In First query we have a machine name in TEST_EXEC_STAT_LOG but it contains some names are as null and some are IPaddress
			rs = st.executeQuery("Select BATCH_ID, sum(case when TEST_CASE_STAT_DESC = 'Pass' then 1 else 0 end), sum(case when TEST_CASE_STAT_DESC not in ('Pass') "
					+ "then 1 else 0 end), count(*) from TEST_EXEC_STAT_LOG where BATCH_ID is not null and EXEC_MACH_NM ='"+machineName+"'  group by BATCH_ID order by batch_id desc");
			log.info("In try rs:::  "+rs);
			int count = 0;
			double passPercent = 0;
			double failPercent = 0;
			int passCount = 0;
			int failCount = 0;
			int totalCount = 0;
			//Date batchId = null;
			Timestamp batchId= null;
			
			
			while (rs.next()) {
				batchId = rs.getTimestamp(1);
				if (batchId != null)
					
					
				log.info("In try batchId:::  "+batchId);
				/*batchId =rs.getDate(1);
				//batchId = rs.getDate(1);
				time=rs.getTime(1);
				log.info("In try batchId:::  "+batchId);
				log.info("In try time:::  "+time);*/
				passCount = rs.getInt(2);
				log.info("In try passCount:::  "+passCount);
				failCount = rs.getInt(3);
				log.info("In try failCount:::  "+failCount);
				totalCount = rs.getInt(4);
				if (batchId != null && totalCount > 0) {
					count++;
					log.info("count is:::  "+count);
					
					Long longDate = null;
					DecimalFormat df = new DecimalFormat("#.##");
				
					longDate = batchId.getTime();
					if (passCount > 0) {
						log.info("passCount is:::  "+passCount);
						passPercent = ((float) passCount / totalCount) * 100;
						passGraphDataPoints.add(new double[] { longDate,Double.valueOf(df.format(passPercent)) });
					}
					if (failCount > 0) {
						log.info("failCount is:::  "+failCount);
						failPercent = ((float) failCount / totalCount) * 100;
						failGraphDataPoints.add(new double[] { longDate,Double.valueOf(df.format(failPercent)) });
					}
				}
				if (count == 5) {
					break;
				}
			}
			//Second query  we can get machine name
			rs = st.executeQuery("Select EXEC_START_TMSP from TEST_EXEC_STATUS where rownum = 1 and EXEC_MACH_NM = '"+machineName+"'");
			if (rs.next()) {
				startTime = rs.getString(1);
			}
			
			//Third query  we can get machine name 
			rs = st.executeQuery("Select count(distinct(EXEC_THREAD_ID)) totalDistinctThreads, count(distinct(EXEC_MACH_NM)) as totalDistinctMachines, count(*) as totalTC, sum(case when TEST_CASE_STAT_DESC = 'Pass' then 1 else 0 end) as passed, sum(case when TEST_CASE_STAT_DESC = 'Fail' then 1 else 0 end) as Failed, sum(case when TEST_CASE_STAT_DESC = 'Initialized' then 1 else 0 end) as Initialized  from TEST_EXEC_STATUS where EXEC_MACH_NM ='"+machineName+"'");
			if (rs.next()) {
				totalTestCasesCnt = rs.getInt("totalTC");
				totalPassTestCasesCnt = rs.getInt("passed");
				totalfailTestCasesCnt = rs.getInt("Failed");
				initializedTestCasesCnt = rs.getInt("Initialized");
				totalMachineCount = rs.getInt("totalDistinctMachines");
				totalInstancesCount = rs.getInt("totalDistinctThreads");
			}
			
			//In Fourth query we can get machine name

			rs = st.executeQuery("Select count(distinct(EXEC_THREAD_ID)) from TEST_EXEC_STATUS where TEST_CASE_STAT_DESC ='In Progress' and  EXEC_MACH_NM ='"+machineName+"'");
			if (rs.next() && totalInstancesCount > 0) {
				int totalInProgressThread = rs.getInt(1);

				 totalUtilizationPercent = (int)(((float)totalInProgressThread / (float)totalInstancesCount) * 100);
			}
			
			//Fifth query we cont get machine name from Data_Feed, So can we add
			
			rs = st.executeQuery("select sum(case when status = 'In Progress' then 1 else 0 end) as inProgress ,"
					+ "sum(case when status = 'Pass' then 1 else 0 end) as passed ,"
					+ "sum(case when status = 'Fail' then 1 else 0 end) as Failed"
					+ " from (select a.* from data_feed a where rownum<="+E2EConstants.MAX_DATA_POINT +"and  EXEC_MACH_NM = '"+machineName+"' order by id desc)");
//			graphStartTime = "";
			graphEndTime = "";
			graphLapseTime = "0";
			if (rs.next()) {
				inProgressDataPoint = rs.getInt("inProgress");
				passDataPoint = rs.getInt("passed");
				failDataPoint = rs.getInt("Failed");
			}
			
			/**
			 * following query for retrieving the difference between first record time stamp and last record time stamp.
			 * last record will be the E2EConstants.MAX_DATA_POINT value
			 */
			
			
			//sixth query we cont get machine name from Data_Feed, So can we add
			
			String s = "select ((f. LAST_UPDT_TMSP-l.LAST_UPDT_TMSP) * 24 * 60), f. LAST_UPDT_TMSP,l.LAST_UPDT_TMSP from "
					+ "(SELECT LAST_UPDT_TMSP FROM DATA_FEED WHERE ROWNUM<=1 ORDER BY ID DESC) f,"
					+ "(select LAST_UPDT_TMSP from  (SELECT  LAST_UPDT_TMSP, rownum as colIndex FROM DATA_FEED WHERE ROWNUM <= "
					+E2EConstants.MAX_DATA_POINT+"and  EXEC_MACH_NM = '"+machineName+"' ORDER BY ID desc) abc where abc.colIndex="+E2EConstants.MAX_DATA_POINT+") l";
			rs = st.executeQuery(s);
			if(rs.next()){
				graphLapseTime = String.format("%d min(s)",
						(rs.getLong(1)));
//				graphStartTime = rs.getString(2);
				graphEndTime = rs.getString(3);
			}
			totalTestCasesCompleted = totalfailTestCasesCnt+ totalPassTestCasesCnt;

			if (startTime != null && graphEndTime != null
					&& graphEndTime.length() > 0 && startTime.length() > 0) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date startDate = null;
				Date endDate = null;
				startDate = format.parse(startTime);
				endDate = format.parse(graphEndTime);
				if (startDate != null && endDate != null) {
					lapseTime = getTimeDiff(endDate, startDate);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}

		regressionStatus.setGraphLapseTime(graphLapseTime);
		regressionStatus.setLapseTime(lapseTime);
		regressionStatus.setStartTime(startTime);
		regressionStatus.setEndTime(endTime);
		regressionStatus.setTotalMachineCount(totalMachineCount);
		regressionStatus.setTotalInsutancesCount(totalInstancesCount);
		regressionStatus.setTotalUtilizationPercent(totalUtilizationPercent);
		regressionStatus.setTotalTestCasesCompleted(totalTestCasesCompleted);
		regressionStatus.setInitializedTestCasesCnt(initializedTestCasesCnt);
		regressionStatus.setFailDataPoint(failDataPoint);
		regressionStatus.setPassDataPoint(passDataPoint);
		regressionStatus.setInProgressDataPoint(inProgressDataPoint);
		regressionStatus.setTotalfailTestCasesCnt(totalfailTestCasesCnt);
		regressionStatus.setTotalPassTestCasesCnt(totalPassTestCasesCnt);
		regressionStatus.setTotalTestCasesCnt(totalTestCasesCnt);
		regressionStatus.setFailGraphDataPoints(failGraphDataPoints);
		regressionStatus.setPassGraphDataPoints(passGraphDataPoints);

		return regressionStatus;
	
	}

	
	public String getTimeDiff(Date dateOne, Date dateTwo) {  
		String diff = "";        
		long timeDiff = Math.abs(dateOne.getTime() - dateTwo.getTime());    
		diff = String.format("%d hour(s) %d min(s)", 
		TimeUnit.MILLISECONDS.toHours(timeDiff), 
		TimeUnit.MILLISECONDS.toMinutes(timeDiff) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(timeDiff)));
		return diff;
		}
	
	public void closeConnections(){
		try {
			st.close();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public ArrayList<FailureReasons> retrieveFailCases() {

		String s = "Select FAILURE_REASON,count(*) as count from Test_Exec_Status "
				+ "where TEST_CASE_STAT_DESC = 'Fail'   Group By FAILURE_REASON order by count desc";

		FailureReasons TestCaseResultRow = null;
		ArrayList<FailureReasons> TestCaseResultRowList = new ArrayList<FailureReasons>();
		try {
			connection = DBConnectionManager.getInstance().getConnection();
			st = connection.createStatement();
			rs = st.executeQuery(s);
			while (rs.next()) {
				TestCaseResultRow = new FailureReasons();
				TestCaseResultRow.setReason(rs.getString(1));
				TestCaseResultRow.setTotalTestCaseCnt(rs.getInt(2));
				TestCaseResultRowList.add(TestCaseResultRow);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}
		return TestCaseResultRowList;
	}
	
	public ArrayList<FailureReasons> retrieveFailCases(String machinename) {

		String s = "Select FAILURE_REASON,count(*) as count from Test_Exec_Status "
				+ "where TEST_CASE_STAT_DESC = 'Fail' "
				+ "And EXEC_MACH_NM = '"+machinename+"'  Group By FAILURE_REASON order by count desc";
		log.info("In Failure Reasons machinename:::  "+machinename);
		FailureReasons TestCaseResultRow = null;
		ArrayList<FailureReasons> TestCaseResultRowList = new ArrayList<FailureReasons>();
		try {
			connection = DBConnectionManager.getInstance().getConnection();
			st = connection.createStatement();
			rs = st.executeQuery(s);
			while (rs.next()) {
				TestCaseResultRow = new FailureReasons();
				TestCaseResultRow.setReason(rs.getString(1));
				log.info("In Failure Reasons reason is:::  "+rs.getString(1));
				TestCaseResultRow.setTotalTestCaseCnt(rs.getInt(2));
				log.info("In Failure Reasons TotalTestCaseCnt is:::  "+rs.getInt(2));
				TestCaseResultRowList.add(TestCaseResultRow);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}
		return TestCaseResultRowList;
	}
	
	public RegressionResultSet retrieveResultRecords(int overAllTotalTestCaseCount){
		RegressionResultSet regressionResultSet = new RegressionResultSet();
		List<RegressionResultRow> regressionResultList = new ArrayList<RegressionResultRow>();
		RegressionResultRow regressionResultRow = null;
		String processingModule = null;
		
		try {
			
			connection = DBConnectionManager.getInstance().getConnection();
			st = connection.createStatement();
			rs= st.executeQuery("Select MODULE, TEST_CASE_STAT_DESC, count(*) from TEST_EXEC_STATUS group by MODULE, TEST_CASE_STAT_DESC");
			while(rs.next()){
				
				String moduleName = rs.getString(1);
				String statusDesc = rs.getString(2);
				int count = rs.getInt(3);
				
				if(moduleName != null &&!moduleName.isEmpty() ){
					if(processingModule == null || (!processingModule.equalsIgnoreCase(moduleName))){
						processingModule = moduleName;
						regressionResultRow = new RegressionResultRow();
						regressionResultRow.setModuleName(moduleName);
						regressionResultList.add(regressionResultRow);
					}
				}
				
				if("Initialized".equalsIgnoreCase(statusDesc) && regressionResultRow != null){
					regressionResultRow.setInitializedCount(count);
				} else if("Pass".equalsIgnoreCase(statusDesc)  && regressionResultRow != null){
					regressionResultRow.setPassCount(count);
				}else if("Fail".equalsIgnoreCase(statusDesc)  && regressionResultRow != null){
					regressionResultRow.setFailCount(count);
				}
			}
			for(RegressionResultRow regResultRow: regressionResultList){
				int totalTestCaseCnt = regResultRow.getPassCount() + regResultRow.getFailCount() +regResultRow.getInitializedCount();
				double failPercent = 0;
				double failContributionPercent = 0;
				String failPercentage = "0" ;
				String failContributionPercentage = "0";
				DecimalFormat decFormat = new DecimalFormat("0.00");
				if(regResultRow.getFailCount() >0){
					failPercent = ((float)regResultRow.getFailCount()/totalTestCaseCnt) * 100;
					failPercentage = decFormat.format(failPercent);
				}
				if(regResultRow.getFailCount() >0 && overAllTotalTestCaseCount > 0){
					failContributionPercent = ((float)regResultRow.getFailCount()/overAllTotalTestCaseCount) * 100;
					failContributionPercentage = decFormat.format(failContributionPercent);
				}
				regResultRow.setFailContributionPercent(Double.valueOf(failContributionPercentage));
				regResultRow.setFailPercent(Double.valueOf(failPercentage));
				regResultRow.setTotalTestCaseCnt(totalTestCaseCnt);
				
			}
			
			regressionResultSet.setRegressionResultRow(regressionResultList);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}
		
		return regressionResultSet;
	}

	public RegressionResultSet retrieveResultRecords(int overAllTotalTestCaseCount, String machinename){
		RegressionResultSet regressionResultSet = new RegressionResultSet();
		List<RegressionResultRow> regressionResultList = new ArrayList<RegressionResultRow>();
		RegressionResultRow regressionResultRow = null;
		String processingModule = null;
		
		try {
			
			connection = DBConnectionManager.getInstance().getConnection();
			st = connection.createStatement();
			rs= st.executeQuery("Select MODULE, TEST_CASE_STAT_DESC, count(*) from TEST_EXEC_STATUS where EXEC_MACH_NM = '"+machinename+"'group by MODULE, TEST_CASE_STAT_DESC");
			while(rs.next()){
				
				String moduleName = rs.getString(1);
				String statusDesc = rs.getString(2);
				int count = rs.getInt(3);
				
				if(moduleName != null &&!moduleName.isEmpty() ){
					if(processingModule == null || (!processingModule.equalsIgnoreCase(moduleName))){
						processingModule = moduleName;
						regressionResultRow = new RegressionResultRow();
						regressionResultRow.setModuleName(moduleName);
						regressionResultList.add(regressionResultRow);
					}
				}
				
				if("Initialized".equalsIgnoreCase(statusDesc) && regressionResultRow != null){
					regressionResultRow.setInitializedCount(count);
				} else if("Pass".equalsIgnoreCase(statusDesc)  && regressionResultRow != null){
					regressionResultRow.setPassCount(count);
				}else if("Fail".equalsIgnoreCase(statusDesc)  && regressionResultRow != null){
					regressionResultRow.setFailCount(count);
				}
			}
			for(RegressionResultRow regResultRow: regressionResultList){
				int totalTestCaseCnt = regResultRow.getPassCount() + regResultRow.getFailCount() +regResultRow.getInitializedCount();
				double failPercent = 0;
				double failContributionPercent = 0;
				String failPercentage = "0" ;
				String failContributionPercentage = "0";
				DecimalFormat decFormat = new DecimalFormat("0.00");
				if(regResultRow.getFailCount() >0){
					failPercent = ((float)regResultRow.getFailCount()/totalTestCaseCnt) * 100;
					failPercentage = decFormat.format(failPercent);
				}
				if(regResultRow.getFailCount() >0 && overAllTotalTestCaseCount > 0){
					failContributionPercent = ((float)regResultRow.getFailCount()/overAllTotalTestCaseCount) * 100;
					failContributionPercentage = decFormat.format(failContributionPercent);
				}
				regResultRow.setFailContributionPercent(Double.valueOf(failContributionPercentage));
				regResultRow.setFailPercent(Double.valueOf(failPercentage));
				regResultRow.setTotalTestCaseCnt(totalTestCaseCnt);
				
			}
			
			regressionResultSet.setRegressionResultRow(regressionResultList);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBConnectionManager.getInstance().closeAll(connection, st, rs);
		}
		
		return regressionResultSet;
	}
	
	
	public ArrayList<String> retrieveMachineDetails(){

		ArrayList<String> machineDetailsList = new ArrayList<String>();
		try {

			connection = DBConnectionManager.getInstance().getConnection();
			st = connection.createStatement();
			rs = st.executeQuery("Select DISTINCT(EXEC_MACH_NM) from TEST_EXEC_STATUS order by EXEC_MACH_NM");
			while (rs.next()) {

				machineDetailsList.add(rs.getString(1));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return machineDetailsList;
	}

}
