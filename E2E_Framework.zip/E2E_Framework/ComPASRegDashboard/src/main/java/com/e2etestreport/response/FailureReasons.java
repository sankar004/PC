package com.e2etestreport.response;

public class FailureReasons {

	private String reason = null;
	private int totalTestCaseCnt = 0;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public int getTotalTestCaseCnt() {
		return totalTestCaseCnt;
	}

	public void setTotalTestCaseCnt(int totalTestCaseCnt) {
		this.totalTestCaseCnt = totalTestCaseCnt;
	}

}
