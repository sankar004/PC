##Login to Database as sysdba (sys/Admin)

CREATE user compasuser identified by password123;

ALTER SYSTEM SET OPEN_CURSORS=1337 SID='*' SCOPE=BOTH;

alter system set processes=300 scope=spfile

#select * from v$resource_limit where resource_name = 'processes';

grant create session to compasuser;
GRANT CREATE TABLE TO compasuser;
grant SELECT ANY TABLE to compasuser
GRANT INSERT ANY TABLE TO compasuser;
GRANT UPDATE ANY TABLE TO compasuser;
GRANT DELETE ANY TABLE TO compasuser;
GRANT CREATE ANY SEQUENCE to compasuser;
GRANT CREATE ANY PROCEDURE to compasuser;
GRANT CREATE ANY TRIGGER to compasuser;    
GRANT CREATE ANY VIEW to compasuser;          

ALTER USER compasuser DEFAULT TABLESPACE USERS;
  
ALTER USER compasuser QUOTA 1024M ON USERS;

