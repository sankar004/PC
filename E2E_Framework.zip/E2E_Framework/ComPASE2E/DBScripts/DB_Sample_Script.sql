Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    EXEC_END_TIME, TC_VALIDATION_STATUS, TC_PICKUP_READY_IND)
 Values
   (174, 'E2E_ICON_TC1', 36849, 'Create Account', 
    'Y', 'Selenium_ICON', 'TC01_WC_Bindable_CreateAccount_Internal', 'TC01_WC_Bindable_CreateAccount_Internal', 'Passed', 
    TO_DATE('3/21/2018 7:02:37 AM', 'MM/DD/YYYY HH:MI:SS AM'), 'Failed ', 'Y');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   ( 66, 'E2E_ICON_TC1', 37038, 'PC Flow', 
    'Y', 'Selenium_PC', 'E2E-15-3', 'E2E-15-3', 'Initialized', 
    'N', 'TC01_WC_Bindable_InProgress_Rerate');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (6, 'E2E_ICON_TC1', 36849, 'Quote', 
    'Y', 'Selenium_ICON', 'TC01_WC_Bindable_InProgress_Quote', 'TC01_WC_Bindable_InProgress_Quote', 'Initialized', 
    'N', 'E2E-15');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   ( 64, 'E2E_ICON_TC1', 36849, 'Reserve', 
    'Y', 'Selenium_ICON', 'TC01_WC_Bindable_InProgress_Reserve', 'TC01_WC_Bindable_InProgress_Reserve', 'Initialized', 
    'N', 'E2E-15-2');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (7, 'E2E_ICON_TC1', 36849, 'Quote Validation', 
    'Y', 'Selenium_PC', 'E2E-15-1', 'E2E-15-1', 'Initialized', 
    'N', 'TC01_WC_Bindable_InProgress_Quote');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (9, 'E2E_ICON_TC1', 36849, 'Pricing Validation', 
    'Y', 'Selenium_PC', 'E2E-15-2', 'E2E-15-2', 'Initialized', 
    'N', 'TC01_WC_Bindable_InProgress_pricing');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (5, 'E2E_ICON_TC1', 36849, 'Draft Validation ', 
    'Y', 'Selenium_PC', 'E2E-15', 'E2E-15', 'Initialized', 
    'N', 'TC01_WC_Bindable_CreateAccount_Internal');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (65, 'E2E_ICON_TC1', 36849, 'Rerate', 
    'Y', 'Selenium_ICON', 'TC01_WC_Bindable_InProgress_Rerate', 'TC01_WC_Bindable_InProgress_Rerate', 'Initialized', 
    'N', 'TC01_WC_Bindable_InProgress_Reserve');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, 
    TC_PICKUP_READY_IND, DEPEND_ON_TC_ID)
 Values
   (8, 'E2E_ICON_TC1', 36849, 'Pricing', 
    'Y', 'Selenium_ICON', 'TC01_WC_Bindable_InProgress_pricing', 'TC01_WC_Bindable_InProgress_pricing', 'Initialized', 
    'N', 'E2E-15-1');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, APP_NM, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, 
    TEST_CASE_STAT_DESC, TC_PICKUP_READY_IND)
 Values
   (586, 'E2E_ICON_TC1', 49010, 'Renewal', 
    'N', 'NPPS', 'Selenium_NPPS', '[1]Scenario 01_E2E_PC_NPPS_Renewal', '[1]Scenario 01_E2E_PC_NPPS_Renewal', 
    'New', 'N');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, APP_NM, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, 
    TEST_CASE_STAT_DESC, TC_PICKUP_READY_IND)
 Values
   (620, 'E2E_ICON_TC1', 42521, 'WI,MA,MS,NY,VA_New Business', 
    'N', 'BUREAU', 'Selenium_Bureau', '[1]Scenario 01_E2E_PC_Bureau_WI,MA,MS,NY,VA_New Business', '[1]Scenario 01_E2E_PC_Bureau_WI,MA,MS,NY,VA_New Business', 
    'New', 'N');
Insert into E2E_TESTCASES
   (SEQ_NUM, E2E_TEST_CASE_E2E_QC_TEST_CASE_E2E_QC_TEST_CASE_NM, 
    RUN_IND, APP_NM, TOOL_NM, CALLED_TEST_CASE_CALLED_TEST_CASE_NM, 
    TEST_CASE_STAT_DESC, TC_PICKUP_READY_IND)
 Values
   (651, 'E2E_ICON_TC1', 49010, 'New Business', 
    'N', 'NPPS', 'Selenium_NPPS', '[1]Scenario 01_E2E_PC_NPPS_New Business', '[1]Scenario 01_E2E_PC_NPPS_New Business', 
    'New', 'N');
COMMIT;

Insert into TOOL_INSTANCE_MAPPING
   (TOOL_NM, INSTANCE_CNT, IS_ACTIVE, REQ_EXEC_TIME)
 Values
   ('Selenium_CUE', 1, 'Y', 120);
Insert into TOOL_INSTANCE_MAPPING
   (TOOL_NM, INSTANCE_CNT, IS_ACTIVE, REQ_EXEC_TIME)
 Values
   ('Selenium_ICON', 2, 'Y', 120);
Insert into TOOL_INSTANCE_MAPPING
   (TOOL_NM, INSTANCE_CNT, IS_ACTIVE, REQ_EXEC_TIME)
 Values
   ('Selenium_PC', 2, 'Y', 120);
COMMIT;


SET DEFINE OFF;
Insert into MACHINE_TOOL_MAPPING
   (IP_ADDR_OR_MACH_NM, TOOL_NM, PARAL_CNT, MACH_STAT_CD, 
    MACH_CMMNT, MACH_TOOL_MAP_ID, LAST_UPDT_BY)
 Values
   ('HFDVDI019061', 'QTP', 1, 'YES', 
    'Muth 2', 1, 'system');
COMMIT;


Insert into FIELD_NAME_MASTER
   (FIELD_ID, FIELD_NM)
 Values
   ('10001', 'AccountNumber');
Insert into FIELD_NAME_MASTER
   (FIELD_ID, FIELD_NM)
 Values
   ('10002', 'PolicyNumber');
Insert into FIELD_NAME_MASTER
   (FIELD_ID, FIELD_NM)
 Values
   ('10003', 'AccountName');
Insert into FIELD_NAME_MASTER
   (FIELD_ID, FIELD_NM)
 Values
   ('10004', 'FEIN');
COMMIT;

Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('302', '10002', 'Policy_Num', 'NPPS');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('141', '10003', 'EDI_LegalName', 'ICON');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('142', '10026', 'LST_LegalEntity', 'ICON');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('143', '10004', 'EDI_FEINNumber', 'ICON');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('144', '10005', 'EDI_StreetName', 'ICON');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('145', '10006', 'EDN_PhoneNumber', 'ICON');
Insert into APP_FIELD_NAME_MAPPING
   (ID, MASTER_FIELD_ID, APP_FIELD_NM, APP_NM)
 Values
   ('146', '10044', 'valelePolicyInfo_NPNNumber', 'PC');
