/**
 * This will trigger the UFT in remote machine and also execute test case in UFT
 * 
 */

var args = WScript.Arguments;
//for (var i= 0; i < args.length; i++) {
    //WScript.Echo(args(i));
//} 
try{
var qtApp = new ActiveXObject("QuickTest.Application",args(0));
qtApp.Launch();
qtApp.Visible = true;
//qtApp.Open("\\\\teams.thehartford.com\\team\\ComPASR2\\QA\\QA Documents\\07. Automation\\Execution Reports\\HTMLReports\\UFT\\GUITest1");
qtApp.Open(args(4));
var qtTest = qtApp.Test;
qtApp.Test.Environment.Value("E2E_TCASE_ID") = args(1);
qtApp.Test.Environment.Value("CALLED_TCASE_NAME") = args(2);
qtApp.Test.Environment.Value("SequenceNo") = args(3);
qtTest.Run(); 
qtTest.Close();
qtApp.Quit();
qtTest = null;
qtApp = null;
} catch (e){
	
}
