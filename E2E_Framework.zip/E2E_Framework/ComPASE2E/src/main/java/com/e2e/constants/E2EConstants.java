package com.e2e.constants;

public class E2EConstants {
	public static final String   executionModeLocal = "Local";
	public static final String   executionModeRemote = "Remote";
	public static final String   DBURL = "DBURL";
	public static final String   QTP = "QTP";
	public static final String   SELENIUM = "Selenium";
	public static final String   PASS = "Pass";
	public static final String   PASSED = "Passed";
	public static final String   NEW = "NEW";
	public static final String   INITIALIZED ="Initialized";
	public static final String   IN_PROGRESS = "In Progress";
	public static final String   QUEUED = "Queued";
	public static final String   TIMED_OUT ="Timed Out";
	public static final String   QUALITYCENTER = "QualityCenter";
	
	public static final String	E2E_MSTR_ID = "E2E_MSTR_ID";
	public static final String  SEQ_NUM = "SEQ_NUM";
	public static final String	E2E_TEST_CASE_ID = "E2E_TEST_CASE_ID"; 
	public static final String	CALLED_TEST_CASE_ID = "CALLED_TEST_CASE_ID"; 
	public static final String	E2E_QC_TEST_CASE_ID = "E2E_QC_TEST_CASE_ID";
	public static final String	E2E_QC_TEST_CASE_NM = "E2E_QC_TEST_CASE_NM";
	public static final String	RUN_IND = "RUN_IND";
	public static final String	APPL_NM = "APPL_NM";
	public static final String	TOOL_NM = "TOOL_NM";
	public static final String	E2E_TEST_CASE_PREDCSR_ID = "E2E_TEST_CASE_PREDCSR_ID";
	public static final String	CALLED_DRVR_NM = "CALLED_DRVR_NM";
	public static final String	CALLED_DRVR_PATH_NM = "CALLED_DRVR_PATH_NM";
	public static final String	QC_DRIVERNAME_ID = "QC_DRIVERNAME_ID";
	public static final String	QC_DRVR_NM ="QC_DRVR_NM";
	public static final String	CALLED_TEST_CASE_NM = "CALLED_TEST_CASE_NM";
	public static final String	STATUS = "STATUS";
	public static final String	LAST_UPDT_TMSP = "LAST_UPDT_TMSP";
	public static final String	OVRRD_TM_OUT = "OVRRD_TM_OUT";
	
	//MACHINETOLLMAPPING columns
	
	public static final String IP_ADDR_OR_MACH_NM ="IP_ADDR_OR_MACH_NM";
	public static final int THREAD_SLEEP_TIME = 10000;
	public static final int MONITOR_THREAD_SLEEP_TIME = 50000;
	
	
	
	
	
	
	
	
	
	
	 


}
