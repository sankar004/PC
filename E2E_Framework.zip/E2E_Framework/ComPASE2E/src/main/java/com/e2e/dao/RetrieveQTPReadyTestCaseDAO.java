package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.utilities.DBConnectionManager;
import com.e2e.vo.TestcaseVo;

/**
 * @author cpg7292
 * This singleton class is to retrieve the QTP test cases for execution
 */
public class RetrieveQTPReadyTestCaseDAO {

	private Connection ucaConn;
	private Statement st;
	private static ResultSet rs;
	private static Logger log = Logger.getLogger(RetrieveQTPReadyTestCaseDAO.class);
	private static RetrieveQTPReadyTestCaseDAO retrieveQTPReadyTestCasesDAO = new RetrieveQTPReadyTestCaseDAO();

	private RetrieveQTPReadyTestCaseDAO() {

	}

	public static RetrieveQTPReadyTestCaseDAO getInstance() {
		return retrieveQTPReadyTestCasesDAO;
	}

	/**
	 * @param ipAddress
	 * @return testcase value object
	 *  Synchronized method to return next QTP testcase for execution based on the order of ID
	 */
	public synchronized TestcaseVo getQTPTestCase(String ipAddress) {
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();

		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select ID, SEQ_NUM, E2E_TEST_CASE_ID, RUN_IND, APP_NM, TOOL_NM, CALLED_DRVR_PATH, CALLED_TEST_CASE_ID, CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, TC_PICKUP_READY_IND, DEPEND_ON_TC_ID from E2E_TESTCASES"
					+ " WHERE RUN_IND = 'Y' AND TOOL_NM='QTP' AND upper(TC_PICKUP_READY_IND) ='Y' AND TEST_CASE_STAT_DESC = '"
					+ E2EConstants.INITIALIZED + "' ORDER BY ID");
			if (rs.next()) {
				TestcaseVo vo = new TestcaseVo();
				vo.setId(rs.getInt("ID"));
				vo.setSeqNum(rs.getInt("SEQ_NUM"));
				vo.setE2eTestCaseId(rs.getString("E2E_TEST_CASE_ID"));
				vo.setRunInd(rs.getString("RUN_IND"));
				vo.setAppNm(rs.getString("APP_NM"));
				vo.setToolNm(rs.getString("TOOL_NM"));
				vo.setCalledDrvrPath(rs.getString("CALLED_DRVR_PATH"));
				vo.setCalledTestCaseId(rs.getString("CALLED_TEST_CASE_ID"));
				vo.setCalledTestCaseNm(rs.getString("CALLED_TEST_CASE_NM"));
				vo.setTestCaseStatDesc(rs.getString("TEST_CASE_STAT_DESC"));
				vo.setTestCasePickupReadyInd(rs.getString("TC_PICKUP_READY_IND"));
				vo.setDependOnTestCaseId(rs.getString("DEPEND_ON_TC_ID"));
				UpdateTestCaseStatusDAO.getInstance().updateTestCaseStatus(E2EConstants.IN_PROGRESS,
							vo.getId(), ipAddress);
				return vo;
			}
		} catch (SQLException e) {
			log.error("Error while getting QTP Sequence Id ");
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		return null;
	}

}
