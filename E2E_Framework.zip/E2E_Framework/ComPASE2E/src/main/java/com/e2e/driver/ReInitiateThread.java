package com.e2e.driver;

import java.util.List;

import org.apache.log4j.Logger;

import com.e2e.dao.MonitorExecutionStatusDAO;
import com.e2e.dao.RetrieveTestCaseStatusDAO;
import com.e2e.dao.UpdateTestCaseStatusDAO;
import com.e2e.vo.TestcaseVo;

/**
 * @author cpg7292
 * This class is to reinstate the dependents of timeout testcases which are passed.
 *
 */
public class ReInitiateThread extends Thread {
	private static final int SLEEP_TIME = 60000;
	static Logger log = Logger.getLogger(ReInitiateThread.class);
	
	@Override
	public void run() {
		try {
			boolean isContinueLoop = true;
			MonitorExecutionStatusDAO monitorExecutionStatusDAO = new MonitorExecutionStatusDAO();
			do{
				Thread.sleep(SLEEP_TIME);
				List<TestcaseVo> vos = RetrieveTestCaseStatusDAO.getInstance().getTestCasesForReinitialize();
				if(vos != null && !vos.isEmpty()){
					for (TestcaseVo vo : vos) {
						UpdateTestCaseStatusDAO.getInstance().updateReadyToPickupStatus(vo.getE2eTestCaseId(),
								vo.getCalledTestCaseId());
						UpdateTestCaseStatusDAO.getInstance().updateReinitiateStatus(vo.getId(),vo.getE2eTestCaseId());
						log.info("tescase [ID:" + vo.getId()
								+ ",E2ETESTCASEID:" + vo.getE2eTestCaseId()
								+ ",CALLEDTESTCASEID"+ vo.getCalledTestCaseId() + "] reinitiated.");
					}
				}
				isContinueLoop = !(monitorExecutionStatusDAO.retrieveOverAllStatus());
			}while(isContinueLoop);
		} catch (Exception e) {
			e.printStackTrace();
			log.info("error occured =" + e.getMessage());
		}
	}
}