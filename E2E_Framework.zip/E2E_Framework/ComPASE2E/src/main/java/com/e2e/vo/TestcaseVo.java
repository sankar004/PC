package com.e2e.vo;

import java.util.Date;

/**
 * @author cpg7292
 * Bean Object to populate the testcase details 
 */
public class TestcaseVo {

	private String qcDrvrNm;
	private String ovrrdTmOut;
	private Date startTime;
	private Date endTime;
	private String execMachNm;
	private String valiationStatus;
	private String e2eQcTestCaseNm;
	private String e2eQcTestCaseId;
	private String calledDrvrPath;
	private int id;
	private int seqNum;
	private String e2eTestCaseId;
	private String runInd;
	private String appNm;
	private String toolNm;
	private String calledTestCaseId;
	private String calledTestCaseNm;
	private String testCaseStatDesc;
	private String testCasePickupReadyInd;
	private String dependOnTestCaseId;

	public String getQcDrvrNm() {
		return qcDrvrNm;
	}

	public void setQcDrvrNm(String qcDrvrNm) {
		this.qcDrvrNm = qcDrvrNm;
	}

	public String getOvrrdTmOut() {
		return ovrrdTmOut;
	}

	public void setOvrrdTmOut(String ovrrdTmOut) {
		this.ovrrdTmOut = ovrrdTmOut;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getValiationStatus() {
		return valiationStatus;
	}

	public void setValiationStatus(String valiationStatus) {
		this.valiationStatus = valiationStatus;
	}

	public String getExecMachNm() {
		return execMachNm;
	}

	public void setExecMachNm(String execMachNm) {
		this.execMachNm = execMachNm;
	}
	
	public String getE2eQcTestCaseNm() {
		return e2eQcTestCaseNm;
	}

	public void setE2eQcTestCaseNm(String e2eQcTestCaseNm) {
		this.e2eQcTestCaseNm = e2eQcTestCaseNm;
	}

	public String getE2eQcTestCaseId() {
		return e2eQcTestCaseId;
	}

	public void setE2eQcTestCaseId(String e2eQcTestCaseId) {
		this.e2eQcTestCaseId = e2eQcTestCaseId;
	}

	public String getCalledDrvrPath() {
		return calledDrvrPath;
	}

	public void setCalledDrvrPath(String calledDrvrPath) {
		this.calledDrvrPath = calledDrvrPath;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(int seqNum) {
		this.seqNum = seqNum;
	}

	public String getE2eTestCaseId() {
		return e2eTestCaseId;
	}

	public void setE2eTestCaseId(String e2eTestCaseId) {
		this.e2eTestCaseId = e2eTestCaseId;
	}

	public String getRunInd() {
		return runInd;
	}

	public void setRunInd(String runInd) {
		this.runInd = runInd;
	}

	public String getAppNm() {
		return appNm;
	}

	public void setAppNm(String appNm) {
		this.appNm = appNm;
	}

	public String getToolNm() {
		return toolNm;
	}

	public void setToolNm(String toolNm) {
		this.toolNm = toolNm;
	}

	public String getCalledTestCaseId() {
		return calledTestCaseId;
	}

	public void setCalledTestCaseId(String calledTestCaseId) {
		this.calledTestCaseId = calledTestCaseId;
	}

	public String getCalledTestCaseNm() {
		return calledTestCaseNm;
	}

	public void setCalledTestCaseNm(String calledTestCaseNm) {
		this.calledTestCaseNm = calledTestCaseNm;
	}

	public String getTestCaseStatDesc() {
		return testCaseStatDesc;
	}

	public void setTestCaseStatDesc(String testCaseStatDesc) {
		this.testCaseStatDesc = testCaseStatDesc;
	}

	public String getTestCasePickupReadyInd() {
		return testCasePickupReadyInd;
	}

	public void setTestCasePickupReadyInd(String testCasePickupReadyInd) {
		this.testCasePickupReadyInd = testCasePickupReadyInd;
	}

	public String getDependOnTestCaseId() {
		return dependOnTestCaseId;
	}

	public void setDependOnTestCaseId(String dependOnTestCaseId) {
		this.dependOnTestCaseId = dependOnTestCaseId;
	}

	@Override
	public String toString() {
		return "TestcaseVo [qcDrvrNm=" + qcDrvrNm + ", ovrrdTmOut=" + ovrrdTmOut + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", execMachNm=" + execMachNm + ", valiationStatus=" + valiationStatus
				+ ", e2eQcTestCaseNm=" + e2eQcTestCaseNm + ", e2eQcTestCaseId=" + e2eQcTestCaseId + ", calledDrvrPath="
				+ calledDrvrPath + ", id=" + id + ", seqNum=" + seqNum + ", e2eTestCaseId=" + e2eTestCaseId
				+ ", runInd=" + runInd + ", appNm=" + appNm + ", toolNm=" + toolNm + ", calledTestCaseId="
				+ calledTestCaseId + ", calledTestCaseNm=" + calledTestCaseNm + ", testCaseStatDesc="
				+ testCaseStatDesc + ", testCasePickupReadyInd=" + testCasePickupReadyInd + ", dependOnTestCaseId="
				+ dependOnTestCaseId + "]";
	}
}
