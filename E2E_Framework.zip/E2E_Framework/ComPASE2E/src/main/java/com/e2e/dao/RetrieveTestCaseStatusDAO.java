package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.utilities.DBConnectionManager;
import com.e2e.vo.TestcaseVo;

public class RetrieveTestCaseStatusDAO {

	private Connection ucaConn;
	private Statement st;
	private ResultSet rs;
	private static Logger log = Logger.getLogger(RetrieveTestCaseStatusDAO.class);

	private static RetrieveTestCaseStatusDAO retrieveTestCasesStatusDAO = new RetrieveTestCaseStatusDAO();

	private RetrieveTestCaseStatusDAO() {

	}

	public static RetrieveTestCaseStatusDAO getInstance() {
		return retrieveTestCasesStatusDAO;
	}

	/**
	 * @param e2eTestCaseId
	 * @param e2eCalledTestCaseId
	 * @param Id
	 * @return status from DB
	 * This method return the test case status description for a particular testcase
	 */
	public String getTestCaseStatus(String e2eTestCaseId, String e2eCalledTestCaseId, int Id) {
		String statusFromDB = null;
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select TEST_CASE_STAT_DESC from E2E_TESTCASES where E2E_TEST_CASE_ID='"
					+ e2eTestCaseId + "' and CALLED_TEST_CASE_ID='" + e2eCalledTestCaseId + "' and ID="
					+ Id );
			if (rs.next()) {
				statusFromDB = rs.getString(1);
			}
		} catch (SQLException e) {
			log.error("getTaskStatus Exception: " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}

		return statusFromDB;
	}
	
	
	/**
	 * @param toolName
	 * @return 
	 * This method returns the number of Initialized testcases for a particular tool
	 */
	public int getInitializedTestCasesCount(String toolName) {
		int inProgressTestCases = 0;
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		ResultSet rS = null;
		Statement stmt = null;

		try {
			stmt = ucaConn.createStatement();
			 rS = stmt.executeQuery("Select count(*) from E2E_TESTCASES WHERE RUN_IND = 'Y' AND UPPER(TOOL_NM)= UPPER('"
					+ toolName + "') AND TEST_CASE_STAT_DESC in ('" + E2EConstants.INITIALIZED + "')");
			if (rS.next()) {
				inProgressTestCases = rS.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, stmt, rS);
		}
		return inProgressTestCases;
	}

	/**
	 * @return
	 * If the timed out testcase complete its execution and the status is pass. This method marks the dependent testcases of the timeout testcase ready for execution
	 * 
	 */
	public List<TestcaseVo> getTestCasesForReinitialize() {
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		Statement stmt = null;
		try {
			List<TestcaseVo> vos = new ArrayList<>();
			stmt = ucaConn.createStatement();
			ResultSet rSet = stmt
					.executeQuery("Select ID, E2E_TEST_CASE_ID, CALLED_TEST_CASE_ID, DEPEND_ON_TC_ID "
							+ "from E2E_TESTCASES WHERE RUN_IND = 'Y' AND REINITIATE_IND='Y' AND TEST_CASE_STAT_DESC in ('"
							+ E2EConstants.PASSED + "')");
			while (rSet.next()) {
				TestcaseVo vo = new TestcaseVo();
				vo.setId(rSet.getInt("ID"));
				vo.setE2eTestCaseId(rSet.getString("E2E_TEST_CASE_ID"));
				vo.setCalledTestCaseId(rSet.getString("CALLED_TEST_CASE_ID"));
				vo.setDependOnTestCaseId(rSet.getString("DEPEND_ON_TC_ID"));
				vos.add(vo);
			}
			return vos;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		return null;
	}


}
