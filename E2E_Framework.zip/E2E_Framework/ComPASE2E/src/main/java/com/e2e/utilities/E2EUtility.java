package com.e2e.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * @author cpg7292
 * utility class to load the properties file.
 */
public class E2EUtility {
	private static Logger log = Logger.getLogger(E2EUtility.class);
	public static Properties properties = new Properties();

	/**
	 * this method loads the properties file.
	 */
	public static void initializeSysConfigProperties() {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream("Config\\Sys.properties");
			properties.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fis != null)
					fis.close();
			} catch (IOException e) {
				log.error("Error occured while loading the config properties file.");
			}
		}
	}

}
