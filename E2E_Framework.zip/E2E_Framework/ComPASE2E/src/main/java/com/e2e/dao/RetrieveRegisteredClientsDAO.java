package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;

import com.e2e.utilities.DBConnectionManager;

/**
 * @author cpg7292
 * Class to get the QTP machines and no of instances for Selenium clients
 */
/**
 * @author cpg7292
 *
 */
public class RetrieveRegisteredClientsDAO {

	private Connection ucaConn;
	private Statement st;
	private static ResultSet rs;
	Logger log = Logger.getLogger(RetrieveRegisteredClientsDAO.class);

	private static RetrieveRegisteredClientsDAO retrieveRegisteredClientsDAO = new RetrieveRegisteredClientsDAO();

	private RetrieveRegisteredClientsDAO() {

	}

	public static RetrieveRegisteredClientsDAO getInstance() {
		return retrieveRegisteredClientsDAO;
	}

	

	/**
	 * @param testMachineIpAddress
	 * This method populates the concurrentLinkedQueue with the QTP machine names
	 */
	public void getIpAddress(ConcurrentLinkedQueue<String> testMachineIpAddress) {
		log.info(" Retrieving QTP Machine details...");
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select IP_ADDR_OR_MACH_NM from MACHINE_TOOL_MAPPING where MACH_STAT_CD='YES' and UPPER(TOOL_NM)='QTP'");
			while (rs.next()) {
				testMachineIpAddress.add(rs.getString("IP_ADDR_OR_MACH_NM"));
			}

		} catch (SQLException e) {
			log.info(" Error while retrieving QTP machine details " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}

	}


	/**
	 * @param mapToolInstances
	 *  This method populates the tools-instance count for Selenium clients in the map
	 */
	public void getToolInstances(HashMap<String, Integer> mapToolInstances) {

		log.info(" Retrieving tool instance count...");
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select TOOL_NM, INSTANCE_CNT from TOOL_INSTANCE_MAPPING where IS_ACTIVE='Y'");
			while (rs.next()) {
				mapToolInstances.put(rs.getString("TOOL_NM"), new Integer(rs.getInt("INSTANCE_CNT")));
			}

		} catch (SQLException e) {
			log.error(" Error while Retrieving tool instances: " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}

	}

}
