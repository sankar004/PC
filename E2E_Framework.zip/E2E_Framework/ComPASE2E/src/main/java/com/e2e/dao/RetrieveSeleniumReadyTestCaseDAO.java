package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.utilities.DBConnectionManager;
import com.e2e.vo.TestcaseVo;

/**
 * @author cpg7292
 * class to retrieve the Selenium test cases.
 */
public class RetrieveSeleniumReadyTestCaseDAO {

	private Connection ucaConn;
	private Statement st;
	private static ResultSet rs;
	private static Logger log = Logger.getLogger(RetrieveSeleniumReadyTestCaseDAO.class);
	private static RetrieveSeleniumReadyTestCaseDAO retrieveReadyTestCasesDAO = new RetrieveSeleniumReadyTestCaseDAO();

	public static RetrieveSeleniumReadyTestCaseDAO getInstance() {
		return retrieveReadyTestCasesDAO;
	}

	private RetrieveSeleniumReadyTestCaseDAO() {

	}

	/**
	 * @param toolName
	 * @return TestcaseVo object
	 * This method returns the next Selenium test case for execution based on the order of ID
	 */
	public synchronized TestcaseVo getSeleniumTestcase(String toolName) {
		log.info("RetrieveSeleniumReadyTestCaseDAO:getSeleniumSeqId: ---> ToolName:" + toolName);
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select ID, SEQ_NUM, E2E_TEST_CASE_ID, RUN_IND, APP_NM, TOOL_NM, QC_DRVR_NM, EXEC_START_TIME, EXEC_END_TIME, EXEC_MACH_NM, TC_VALIDATION_STATUS, E2E_QC_TEST_CASE_NM, E2E_QC_TEST_CASE_ID, CALLED_DRVR_PATH, CALLED_TEST_CASE_ID, CALLED_TEST_CASE_NM, TEST_CASE_STAT_DESC, TC_PICKUP_READY_IND, DEPEND_ON_TC_ID from E2E_TESTCASES WHERE RUN_IND = 'Y' AND UPPER(TOOL_NM)=UPPER('"
					+ toolName
					+ "') AND upper(TC_PICKUP_READY_IND) ='Y' AND TEST_CASE_STAT_DESC = '"
					+ E2EConstants.INITIALIZED + "' ORDER BY ID");
			if (rs.next()) {
				TestcaseVo vo = new TestcaseVo();
				vo.setId(rs.getInt("ID"));
				vo.setSeqNum(rs.getInt("SEQ_NUM"));
				vo.setE2eTestCaseId(rs.getString("E2E_TEST_CASE_ID"));
				vo.setRunInd(rs.getString("RUN_IND"));
				vo.setAppNm(rs.getString("APP_NM"));
				vo.setToolNm(rs.getString("TOOL_NM"));
				vo.setQcDrvrNm(rs.getString("QC_DRVR_NM"));
				vo.setStartTime(rs.getDate("EXEC_START_TIME"));
				vo.setEndTime(rs.getDate("EXEC_END_TIME"));
				vo.setExecMachNm(rs.getString("EXEC_MACH_NM"));
				vo.setValiationStatus(rs.getString("TC_VALIDATION_STATUS"));
				vo.setE2eQcTestCaseNm(rs.getString("E2E_QC_TEST_CASE_NM"));
				vo.setE2eQcTestCaseId(rs.getString("E2E_QC_TEST_CASE_ID"));
				vo.setCalledDrvrPath(rs.getString("CALLED_DRVR_PATH"));
				vo.setCalledTestCaseId(rs.getString("CALLED_TEST_CASE_ID"));
				vo.setCalledTestCaseNm(rs.getString("CALLED_TEST_CASE_NM"));
				vo.setTestCaseStatDesc(rs.getString("TEST_CASE_STAT_DESC"));
				vo.setTestCasePickupReadyInd(rs.getString("TC_PICKUP_READY_IND"));
				vo.setDependOnTestCaseId(rs.getString("DEPEND_ON_TC_ID"));
				UpdateTestCaseStatusDAO.getInstance().updateTestCaseStatus(E2EConstants.QUEUED, vo.getId(),
						vo.getExecMachNm());
				return vo;
			}
		} catch (SQLException e) {
			log.error("Error while retrieving SequenceId: " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		return null;
	}

}
