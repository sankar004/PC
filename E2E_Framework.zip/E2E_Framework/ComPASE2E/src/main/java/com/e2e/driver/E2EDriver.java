package com.e2e.driver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.e2e.constants.E2EConstants;
import com.e2e.dao.MonitorExecutionStatusDAO;
import com.e2e.dao.RetrieveRegisteredClientsDAO;
import com.e2e.dao.RetrieveTestCaseStatusDAO;
//import com.e2e.dao.RetrieveTestCasesDAO;
import com.e2e.dao.UpdateTestCaseStatusDAO;
import com.e2e.utilities.E2EUtility;

public class E2EDriver {
	static Logger log = Logger.getLogger(E2EDriver.class);

	private static ConcurrentLinkedQueue<String> testMachineIpAddress = new ConcurrentLinkedQueue<String>();
	private static HashMap<String, Integer> toolInstances = new HashMap<String, Integer>();
	private static File directory = new File(".");
	//private static ConcurrentLinkedQueue<String> testCaseNames = new ConcurrentLinkedQueue<String>();
	private static String sConfigfilespath = null;
	private static String sVBScriptFilePath = null;
	private static int numberOfQtpMachines;
	private static ServerSocket server = null;

	public void loadConfig() throws Exception {
		PropertyConfigurator.configure("log4j.properties");
		sConfigfilespath = directory.getCanonicalPath() + "\\JavaScripts\\";
		sVBScriptFilePath = directory.getCanonicalPath() + "\\VBScript\\";
		try {
			E2EUtility.initializeSysConfigProperties();
			RetrieveRegisteredClientsDAO.getInstance().getIpAddress(testMachineIpAddress);
			log.info("Retrieving test Machine IP addresses...");
			numberOfQtpMachines = testMachineIpAddress.size();
			RetrieveRegisteredClientsDAO.getInstance().getToolInstances(toolInstances);
			// As per business team commenting out the reinstate logic
			
			//RetrieveTestCasesDAO.getInstance().getTestCaseId(testCaseNames);
			//log.info("avilable test cases ..." + testCaseNames.size());
			//boolean isReInitiateThreadRequired = true;
			
			//Starting QTP threads based on the number of machines configured
			int qtpInitializedTestCases = UpdateTestCaseStatusDAO.getInstance().initializeTestCases(E2EConstants.INITIALIZED , "QTP");
			if(qtpInitializedTestCases > 0){
				new QtpClient().start();
				/*if(isReInitiateThreadRequired){
					new ReInitiateThread().start();
					isReInitiateThreadRequired = false;
				}*/
			}else{
				log.info("no QTP testcases configured");
			}
			server = new ServerSocket(8001);
			int clientNumber = 1;
			
			//Server socket is accepting Selenium clients and starting Accept Client thread
			while (true) {
				log.info("Server started: " + server);
				log.info("Waiting for a client ...");
				Socket socket = server.accept(); // 1. selenium_Pc
				log.info("Server accepted the client ...");
				new AcceptClient(socket, clientNumber).start();
				/*if(isReInitiateThreadRequired){
					new ReInitiateThread().start();
					isReInitiateThreadRequired = false;
				}*/
				clientNumber++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * this thread is used to process the Selenium framework test cases.
	 * Selenium frameworks
	 * 
	 * @author cpg7279
	 * 
	 */
	private static class AcceptClient extends Thread {
		private Socket socket;
		private int clientNumber;
		public AcceptClient(Socket socket, int clientNumber) {
			this.socket = socket;
			this.clientNumber = clientNumber;
			log.info("New connection with client# " + clientNumber + " at " + socket);
		}

		public void run() {
			DataInputStream input = null;
			DataOutputStream outputStream = null;
			String inputFromClient = null;
			try {
				// Retrieving the input from client, if it is Selenium client Initializing test cases 
				input = new DataInputStream(socket.getInputStream());
				inputFromClient = String.valueOf(input.readUTF()).trim();
				log.info(">>>>>>>>>>>>>Connected client tools is :"+ inputFromClient);
				outputStream = new DataOutputStream(socket.getOutputStream());
				if (inputFromClient != null && inputFromClient.contains(E2EConstants.SELENIUM)) {
					if (toolInstances.get(inputFromClient) != null) {
						log.info("E2E will be creating "+toolInstances.get(inputFromClient)+" instances for this client");
						UpdateTestCaseStatusDAO.getInstance().initializeTestCases(E2EConstants.INITIALIZED , inputFromClient);
						int initializedTestCases = RetrieveTestCaseStatusDAO.getInstance().getInitializedTestCasesCount(inputFromClient);
						//Creating Selenium threads based on the configuration
						if (initializedTestCases > 0) {
							for (int i = 0; i < toolInstances.get(inputFromClient).intValue(); i++) {
								new SeleniumThread(outputStream, clientNumber,
										inputFromClient).start();
							}
						}else{
							log.info("no testcases are in intialized state for the tool : "+ inputFromClient);
						}
					}else{
						log.info("No instances for the client "+ inputFromClient+" configured. Please check.");
					}
				}else{
					log.info(">>>>>>>>>>>>>Connected client tools is :"+ inputFromClient+ " is not a Selenium tool. input from the client should contain the \"SELENIUM\" in it.");
				}
				boolean isSystemShutdown = true;
				MonitorExecutionStatusDAO monitorExecutionStatusDAO = new MonitorExecutionStatusDAO();
				do{
					//Retriving the overall status for a particular client, if all the testcases are complete it will shutdown the particular client
					isSystemShutdown = monitorExecutionStatusDAO.retrieveOverAllStatus(inputFromClient);
					if (isSystemShutdown) {
						synchronized (outputStream) {
							log.info(inputFromClient + " Client test cases executed successfully and sending shutdown to client to terminate.");
							outputStream.writeUTF("shutdown");
							outputStream.flush();
							Thread.sleep(E2EConstants.MONITOR_THREAD_SLEEP_TIME);
						}
					}
					Thread.sleep(E2EConstants.MONITOR_THREAD_SLEEP_TIME);
				}while(!isSystemShutdown);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Error handling client# " + clientNumber + ": " + e);
			} finally {
				try {
					if (outputStream != null) outputStream.close();
					if (input != null) input.close();
					if (socket != null) socket.close();
				} catch (IOException e) {
					log.error("Couldn't close a socket, what's going on?");
				}
				log.info("Connection with client# " + clientNumber + " & tool:"+inputFromClient+" closed");
			}
		}
	}

	/**
	 * handles only QTP test cases
	 * 
	 * @author cpg7279
	 * 
	 */
	private static class QtpClient extends Thread {

		public QtpClient() {
			log.info("QTP client initiated to execute QTP test cases.");
		}

		public void run() {
			try {
				for (int i = 0; i < numberOfQtpMachines; i++) {
					new QTPTestCaseThread(sConfigfilespath, sVBScriptFilePath, testMachineIpAddress.remove()).start();
					log.info(" QTP Thread execution started.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Error handling QTP client#:" + e);
			} finally {
				log.info("QTP Connection client thread closed ");
			}
		}

	}
}
