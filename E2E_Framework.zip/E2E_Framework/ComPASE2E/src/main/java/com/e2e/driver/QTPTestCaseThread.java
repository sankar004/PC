package com.e2e.driver;

import java.util.Date;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.dao.MonitorExecutionStatusDAO;
import com.e2e.dao.RetrieveQTPReadyTestCaseDAO;
import com.e2e.dao.RetrieveTestCaseStatusDAO;
import com.e2e.dao.UpdateTestCaseStatusDAO;
import com.e2e.utilities.E2EUtility;
import com.e2e.vo.TestcaseVo;

/**
 * @author cpg7292
 * This class is to execute the QTP testcases.
 */
public class QTPTestCaseThread extends Thread {
	static Logger log = Logger.getLogger(QTPTestCaseThread.class);

	private String sConfigfilespath;
	private String sVBScriptFilePath;
	private String ipAddress;

	public QTPTestCaseThread(String sConfigfilespath, String sVBScriptFilePath, String ipAddress) {
		this.sConfigfilespath = sConfigfilespath;
		this.sVBScriptFilePath = sVBScriptFilePath;
		this.ipAddress = ipAddress;
	}

	@Override
	public void run() {
		try {
			log.info("Starting execution of Thread =" + Thread.currentThread().getId());
			String e2eTestCaseId = null;
			String testCaseId = null;
			boolean isContinueLoop = true;

			if (ipAddress == null) {
				log.error("IPADDRESS Not found for this thread");
			}

			String sleepTime = E2EUtility.properties.getProperty("thread.sleep.time");
			sleepTime = (sleepTime == null || sleepTime.isEmpty()) ? "60000" : sleepTime.trim();
			long configuredExecutionTime = Long.valueOf(E2EUtility.properties.getProperty("execution.cutoff.time.in.mins"));

			MonitorExecutionStatusDAO monitorExecutionStatusDAO = new MonitorExecutionStatusDAO();
			Date timeNow = null;
			long elapsedTime = 0;
			long elapsedTimeInMins = 0;
			long elapsedTimeInSeconds =0;
			//This loop will continue till all the QTP test case 
			while (isContinueLoop) {
				// log.info("Started Executing End To End Test Case# " +
				// e2eTestCaseId);
				//Retrieves the next QTP test case for execution
				TestcaseVo testcaseVo = RetrieveQTPReadyTestCaseDAO.getInstance().getQTPTestCase(ipAddress);
				if (testcaseVo != null) {
					Date startTime = new Date();
					boolean isexecutionComplete = false;
					// boolean isContinueNextTestCase = false;
					String executeStatusFromDB = null;
					e2eTestCaseId = testcaseVo.getE2eTestCaseId();
					testCaseId = testcaseVo.getCalledTestCaseId();

					String tool = testcaseVo.getToolNm();
					log.info("End To End Test Case# " + e2eTestCaseId + " Executing tool =" + tool + " Sequence ID ="
							+ testcaseVo.getId() + " IP Address=" + ipAddress);
					if (tool != null && tool.length() > 0 && tool.equalsIgnoreCase(E2EConstants.QTP)) {

						Runtime r = Runtime.getRuntime();
						if (ipAddress != null && ipAddress.length() > 0) {

							String execCmd = "Wscript.exe \"" + sConfigfilespath + "ExecuteUFT.js\" \"" + ipAddress
									+ "\" \"" + testcaseVo.getE2eTestCaseId() + "\" \""
									+ testcaseVo.getCalledTestCaseId() + "\" \"" + testcaseVo.getSeqNum() + "\" \""
									+ testcaseVo.getCalledDrvrPath() + "\"";

							log.info("Executing Command..... =" + execCmd);
							
							//constructing the command and executing it
							Process p = r.exec(execCmd);

							log.info(execCmd + "Command running at " + new Date()
									+ " and now waiting for it to complete... ");

							while(true){
								executeStatusFromDB = null;
								isexecutionComplete = false;
								// isContinueNextTestCase = false;
								Thread.sleep(Integer.parseInt(sleepTime));

								executeStatusFromDB = RetrieveTestCaseStatusDAO.getInstance().getTestCaseStatus(
										testcaseVo.getE2eTestCaseId(), testcaseVo.getCalledTestCaseId(),
										testcaseVo.getId());

								log.info("E2E Testcase Id: " + testcaseVo.getE2eTestCaseId() + ", Testcase Name: "
										+ testcaseVo.getCalledTestCaseId() + ", status:" + executeStatusFromDB);
								//If the test cases are not in Queued or In Progress, considering it as either Pass/Fail and exiting the loop
								if (!E2EConstants.QUEUED.equalsIgnoreCase(executeStatusFromDB) 
										&& !E2EConstants.IN_PROGRESS.equalsIgnoreCase(executeStatusFromDB)) {
									isexecutionComplete = true;
									break;
								}
								timeNow = new Date();
								elapsedTime = timeNow.getTime() - startTime.getTime();
								elapsedTimeInMins = elapsedTime / (60 * 1000) % 60;
								//If the elapsed time is greater than the configured time returning and terminating the thread.
								if(elapsedTimeInMins >= configuredExecutionTime){
									log.info("teminating the current thread{Machine : "+ipAddress+" with testCaseId: " + testCaseId +"} since it is taking more execution time than the configured execution time("
											+ "configured time:"+configuredExecutionTime+")");
									return;
								}
							}
							log.info(execCmd + ". status checking process finished at " + new Date()
									+ " and status of the testcase is " + executeStatusFromDB);
							//In case of timed-out scenario's this block of code will not execute, as we are returning the thread
							/*if (!isexecutionComplete
									&& (E2EConstants.QUEUED.equalsIgnoreCase(executeStatusFromDB) ||
											E2EConstants.IN_PROGRESS.equalsIgnoreCase(executeStatusFromDB))) {
								log.error("Selenium E2ETestcase Failed. E2E Testcase Id: "
										+ testcaseVo.getE2eTestCaseId() + ", Testcase Name: "
										+ testcaseVo.getCalledTestCaseNm());
								UpdateTestCaseStatusDAO.getInstance().updateTestCaseStatus(E2EConstants.TIMED_OUT,
										testcaseVo.getId(), ipAddress);
								log.error("client : " + tool + " is not compleated the test case(E2E id : "
										+ testcaseVo.getE2eTestCaseId() + "," + "called test case ID:"
										+ testcaseVo.getCalledTestCaseId()
										+ ") execution within the E2E process wait time.");
								timeNow = new Date();
								elapsedTime = timeNow.getTime() - startTime.getTime();
								elapsedTimeInMins = elapsedTime / (60 * 1000) % 60;
								elapsedTimeInSeconds = elapsedTime / 1000 % 60;
								log.error("[" + testcaseVo.getE2eTestCaseId() + "," + testcaseVo.getCalledTestCaseId()
										+ "] started at " + startTime + " and ended at " + timeNow
										+ "  & elapse time(in mins) is :" + elapsedTimeInMins
										+ "elapse time(in secs) is :"+elapsedTimeInSeconds);
							}*/

							p.destroy();
							
							// if the execution is complete and the status if Passed, updating the dependent cases pickup indicator to 'Yes'
							if (isexecutionComplete
									&& (E2EConstants.PASSED.equalsIgnoreCase(executeStatusFromDB))) {
								log.info("UpdateReadyToPickupDAO Step 2 testCaseId =" + testCaseId + " e2eTestCaseId="
										+ e2eTestCaseId);
								UpdateTestCaseStatusDAO.getInstance().updateReadyToPickupStatus(e2eTestCaseId,
										testCaseId);
							}

							log.info("Execution Completed....status.. =" + String.valueOf(isexecutionComplete));
						}

					}
				}

				boolean isTestCasesExecutionCompleted = monitorExecutionStatusDAO.retrieveOverAllStatus("QTP");
				// To check all QTP test cases are completed, if all testcases are complete outer loop will exit
				if (isTestCasesExecutionCompleted) {
					isContinueLoop = false;
				}
				Thread.sleep(E2EConstants.THREAD_SLEEP_TIME);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info("error occured =" + e.getMessage());

		}
	}
}