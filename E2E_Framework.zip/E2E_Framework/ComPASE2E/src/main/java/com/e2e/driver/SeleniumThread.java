package com.e2e.driver;

import java.io.DataOutputStream;
import java.util.Date;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.dao.MonitorExecutionStatusDAO;
import com.e2e.dao.RetrieveSeleniumReadyTestCaseDAO;
import com.e2e.dao.RetrieveTestCaseStatusDAO;
import com.e2e.dao.UpdateTestCaseStatusDAO;
import com.e2e.utilities.E2EUtility;
import com.e2e.vo.TestcaseVo;

/**
 * @author cpg7292
 * This class takes care of Selenium Testcase execution
 *
 */
public class SeleniumThread extends Thread {
	static Logger log = Logger.getLogger(SeleniumThread.class);
	private DataOutputStream outputStream;
	private int clientNumber;
	private String clientGivenToolName;

	public SeleniumThread(DataOutputStream outputStream, int clientNumber, String clientGivenToolName) {
		this.outputStream = outputStream;
		this.clientNumber = clientNumber;
		this.clientGivenToolName = clientGivenToolName;
	}

	@Override
	public void run() {
		try {
			long threadId = Thread.currentThread().getId();
			log.info("Starting execution of Thread =" + threadId);
			String e2eTestCaseId = null;
			String testCaseId = null;
			int seqNo = 0;
			boolean isContinueLoop = true;
			//String checkCount = E2EUtility.properties.getProperty("thread.status.check.count");
			//checkCount = (checkCount == null || checkCount.isEmpty())? "0": checkCount.trim();
			
			String sleepTime = E2EUtility.properties.getProperty("thread.sleep.time");
			sleepTime = (sleepTime == null || sleepTime.isEmpty())? "60000": sleepTime.trim();
			long configuredExecutionTime = Long.valueOf(E2EUtility.properties.getProperty("execution.cutoff.time.in.mins"));
			MonitorExecutionStatusDAO monitorExecutionStatusDAO = new MonitorExecutionStatusDAO();
			Date timeNow = null;
			Date startTime = null;
			long elapsedTime = 0;
			long elapsedTimeInMins = 0;
			long elapsedTimeInSeconds =0;
			
			while (isContinueLoop) {
				//Retrieves the Test case details for execution
				TestcaseVo testcaseVo = RetrieveSeleniumReadyTestCaseDAO.getInstance().getSeleniumTestcase(clientGivenToolName);
				log.info("id#"+threadId+": identified testcase details :"+ testcaseVo);
				if (testcaseVo != null) {
					startTime = new Date();
					log.info("Starting the test case with sequence ---->"+ seqNo + " and time: " + (new Date()));
					boolean isexecutionComplete = false;
					String executeStatusFromDB = null;
					e2eTestCaseId = testcaseVo.getE2eTestCaseId();
					testCaseId = testcaseVo.getCalledTestCaseId();
					String tool = testcaseVo.getToolNm();
					String testCaseInfo = testcaseVo.getCalledTestCaseId()
							+ "|" + testcaseVo.getE2eTestCaseId() + "|"
							+ testcaseVo.getSeqNum() + "|" + "GRID";
					log.info("thread Id #"+threadId+" End To End Test Case# " + e2eTestCaseId + " Executing tool =" + tool + " Sequence ID ="
							+ testcaseVo.getId() + "Called TestCaseID=" + testCaseId + " IP Address= GRID");
					//constructing testcase details string and sent to client.
					synchronized (outputStream) {
						log.info("Server sending testcase info ["+testCaseInfo+"] to socket client["+tool+","+threadId+"]");
						outputStream.writeUTF(testCaseInfo);
						outputStream.flush();
					}
					log.info("server sent information to clint and started status checkeing at "+new Date() +". test case info"+ testCaseInfo);
					// This while loop will continue till the execution of the test case is complete or it crossed the configured elapsed time.
					while(true){
						executeStatusFromDB = null;
						isexecutionComplete = false;
						Thread.sleep(Integer.parseInt(sleepTime));

						executeStatusFromDB = RetrieveTestCaseStatusDAO
								.getInstance().getTestCaseStatus(
										testcaseVo.getE2eTestCaseId(),
										testcaseVo.getCalledTestCaseId(),
										testcaseVo.getId());

						log.info("Execution status checking for selenium  "
								+ testcaseVo.getE2eTestCaseId() + "|"
								+ testcaseVo.getCalledTestCaseId()
								+ "******************" + executeStatusFromDB);
						//if the test case  is in Passed or Failed status, it will break the while loop and continue the execution
						if (!E2EConstants.QUEUED.equalsIgnoreCase(executeStatusFromDB) 
								&& !E2EConstants.IN_PROGRESS.equalsIgnoreCase(executeStatusFromDB)) {
							isexecutionComplete = true;
							break;
						}
						timeNow = new Date();
						elapsedTime = timeNow.getTime() - startTime.getTime();
						elapsedTimeInMins = elapsedTime / (60 * 1000) % 60;
						
						// if the elapsed time is greater than the configured time it will return the thread execution, no more test cases will execute.
						if(elapsedTimeInMins >= configuredExecutionTime){
							log.info("teminating the current thread{tool : "+clientGivenToolName+" with thread id: " + threadId +"} since it is taking more execution time than the configured execution time("
									+ "configured time:"+configuredExecutionTime+")");
							return;
						}
					}
					log.info("server finished status checking at "+new Date()+" for the test case info"+ testCaseInfo +" and the status of testcase is "+executeStatusFromDB);
               
					// in case of timed-out scenario's this block of code will not execute, as we are returning the thread
					/*	if (!isexecutionComplete
							&& (E2EConstants.QUEUED.equalsIgnoreCase(executeStatusFromDB)
									|| E2EConstants.IN_PROGRESS.equalsIgnoreCase(executeStatusFromDB))) {
						log.error("-------------Selenium E2ETestcase Failed ="
								+ testcaseVo.getE2eTestCaseId()
								+ " Selenium Testcase Name ="
								+ testcaseVo.getCalledTestCaseId()
								+ " -------------");
						UpdateTestCaseStatusDAO.getInstance().updateTestCaseStatus(
								E2EConstants.TIMED_OUT,
								testcaseVo.getId(),
								"GRID");
						log.error("client : "+tool+" is not compleated its execution within the E2E execution process wait time. the test case details are (E2E id : "+testcaseVo.getE2eTestCaseId()+","
								+ "called test case ID:"+testcaseVo.getCalledTestCaseId()+")");
						timeNow = new Date();
						elapsedTime = timeNow.getTime() - startTime.getTime();
						elapsedTimeInMins = elapsedTime / (60 * 1000) % 60;
						elapsedTimeInSeconds = elapsedTime / 1000 % 60;
						log.error("["+testcaseVo.getE2eTestCaseId()+","+testcaseVo.getCalledTestCaseId()+"] started at "+startTime + " and ended at "+ timeNow + "  &"
								+ " elapse time(in mins) is :"+elapsedTimeInMins
								+ "elapse time(in secs) is :"+elapsedTimeInSeconds);
					}*/

					// If the test case status is passed, updating dependent test cases pickup indicator to 'Yes'
					if (isexecutionComplete
							&& (E2EConstants.PASSED
									.equalsIgnoreCase(executeStatusFromDB))) {

						UpdateTestCaseStatusDAO.getInstance()
								.updateReadyToPickupStatus(e2eTestCaseId,
										testCaseId);
						log.info("status of the testcase ["+e2eTestCaseId+","+testCaseId+"] is passed and updated the ready to pick up indicator to \"YES\" for the dependent testcases.");
					}

					log.info("Execution Completed....status.. ="
							+ String.valueOf(isexecutionComplete));

				}
				
				
				boolean isTestCasesExecutionCompleted = monitorExecutionStatusDAO.retrieveOverAllStatus(clientGivenToolName);
				// if the over all execution is complete, breaking the  isContinue while loop
				if (isTestCasesExecutionCompleted) {
					isContinueLoop = false;
				}
				Thread.sleep(E2EConstants.THREAD_SLEEP_TIME); 
			}
			log.info("tool : "+clientGivenToolName+" with thread id: " + threadId +" is completed its execution.");
		} catch (Exception e) {
			e.printStackTrace();
			log.info("error occured =" + e.getMessage());
		}
	}
	
}