package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.utilities.DBConnectionManager;

/**
 * @author cpg7292
 * This class is to update the status of test cases.
 *
 */
public class UpdateTestCaseStatusDAO {

	private Connection ucaConn;
	private Statement st;
	private ResultSet rs;
	private static Logger log = Logger.getLogger(UpdateTestCaseStatusDAO.class);

	private static UpdateTestCaseStatusDAO updateStatusDAO = new UpdateTestCaseStatusDAO();

	public static UpdateTestCaseStatusDAO getInstance() {
		return updateStatusDAO;
	}

	private UpdateTestCaseStatusDAO() {
	}

	/**
	 * @param status
	 * @param id
	 * @param ipAddress
	 * Method to update the status, machine name of the testcase based on the id
	 */
	public void updateTestCaseStatus(String status, int id, String ipAddress) {
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			log.info("UpdateStatusDAO.updateStatus status = " + status + " ipAddress= " + ipAddress + " ID= "
					+ id);
			String query = "update E2E_TESTCASES set TEST_CASE_STAT_DESC = '" + status + "'";
			/*if (E2EConstants.TIMED_OUT.equals(status)) {
				query = query
						+ ",comments = 'updated status as Timed Out at '||TO_CHAR(sysdate, 'DD-MON-YYYY HH24:MI')||' and execution start time is ' ||TO_CHAR(EXEC_END_TIME, 'DD-MON-YYYY HH24:MI'), REINITIATE_IND='Y' ";
			}*/
			query = query + ", EXEC_MACH_NM='" + ipAddress + "' WHERE ID = " + id;
			st.executeUpdate(query);
		} catch (SQLException e) {
			log.error("Update TestCase Status Exception: " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}

	}

	/**
	 * Method to update the status  based on the tool name and run indicator
	 * 
	 * @param status
	 * @param toolName
	 */
	public int initializeTestCases(String status, String toolName) {
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			log.info("updating the test cases with tool name " + toolName + " status to " + status);

			int records = st.executeUpdate("update E2E_TESTCASES set TEST_CASE_STAT_DESC = '" + status
					+ "' WHERE RUN_IND = 'Y' and upper(TEST_CASE_STAT_DESC) = '"
					+ E2EConstants.NEW + "' AND UPPER(TOOL_NM)=upper ('" + toolName + "')");

			log.info(records + " records updated in E2E_TESTCASES for " + toolName + " tool name test cases");
			return records;
		} catch (SQLException e) {
			log.error("Exception occured while updating the status. Reason : " + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		return 0;
	}

	public void updateReinitiateStatus(int id, String e2eTestCaseId) {
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		Statement stmt = null;
		try {
			stmt = ucaConn.createStatement();
			String query = "update E2E_TESTCASES set REINITIATE_IND='N', comments=comments ||' reinitiated at '||sysdate WHERE RUN_IND = 'Y' AND  E2E_TEST_CASE_ID ='"
					+ e2eTestCaseId + "' and id='" + id + "'";
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
	}

	/**
	 * @param e2eTestCaseId
	 * @param testCaseId
	 * Method marks dependent testcases ready for execution
	 */
	public void updateReadyToPickupStatus(String e2eTestCaseId, String testCaseId) {

		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();
		try {
			st = ucaConn.createStatement();
			log.info("updateReadyToPickupYes---> e2eTestCaseId: " + e2eTestCaseId + " , testCaseId: " + testCaseId);
			if (testCaseId != null) {
				st.execute("update  E2E_TESTCASES set TC_PICKUP_READY_IND = 'Y' WHERE DEPEND_ON_TC_ID = '"
						+ testCaseId + "' AND E2E_TEST_CASE_ID ='" + e2eTestCaseId + "'");

			}
		} catch (SQLException e) {
			log.error(" UpdateReadyToPickupYes  exception :" + e.getMessage());
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}

	}

}
