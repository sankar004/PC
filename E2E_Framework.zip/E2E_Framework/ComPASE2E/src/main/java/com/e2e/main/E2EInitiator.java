package com.e2e.main;

import com.e2e.driver.E2EDriver;

public class E2EInitiator {

	/**
	 * @param args
	 * @throws Exception
	 * Main method kick start the E2E execution
	 */
	public static void main(String args[]) throws Exception {

		E2EDriver e2edriver = new E2EDriver();
		//e2edriver.loadConfig(args[0]);
		e2edriver.loadConfig();
	}
}
