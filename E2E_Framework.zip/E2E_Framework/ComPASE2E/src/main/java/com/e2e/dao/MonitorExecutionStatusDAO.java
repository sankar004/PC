package com.e2e.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import org.apache.log4j.Logger;

import org.apache.log4j.Logger;

import com.e2e.constants.E2EConstants;
import com.e2e.utilities.DBConnectionManager;

/**
 * @author cpg7292
 * This class is to monitor the execution status of Test cases.
 * 
 */
public class MonitorExecutionStatusDAO {

	private Connection ucaConn;
	private Statement st;
	private ResultSet rs;

	private static Logger log = Logger.getLogger(MonitorExecutionStatusDAO.class);

	public MonitorExecutionStatusDAO() {
	}

	/**
	 * Method to check is there any test cases with status as Initialized/In
	 * Progress/New. Returns true if none of the test cases with above statuses
	 * otherwise returns false
	 * 
	 * @return boolean
	 */
	public boolean retrieveOverAllStatus() {
		boolean isSystemShutdown = false;
		int inProgressTestCases = 0;
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();

		try {
			st = ucaConn.createStatement();
			rs = st.executeQuery("Select count(*) from E2E_TESTCASES WHERE RUN_IND = 'Y' AND TEST_CASE_STAT_DESC in  ('"
					+ E2EConstants.INITIALIZED + "','" + E2EConstants.IN_PROGRESS + "','" + E2EConstants.NEW + "')");
			if (rs.next()) {
				inProgressTestCases = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeResultSet(rs);
			DBConnectionManager.getInstance().closeStatement(st);
			DBConnectionManager.getInstance().returnConnectionToPool(ucaConn);
		}
		if (inProgressTestCases == 0) {
			isSystemShutdown = true;
		}
		return isSystemShutdown;
	}

	/**
	 * 
	 * Method to check is there any test cases with status as Initialized/In
	 * Progress/New for a given ToolName. Returns true if none of the test cases
	 * with above statuses otherwise returns false. This will help E2E to
	 * identify is there any pending test cases.
	 * 
	 * @param toolName
	 * @return boolean
	 * 
	 */
	public boolean retrieveOverAllStatus(String toolName) {
		boolean isSystemShutdown = false;
		int inProgressTestCases = 0;
		ucaConn = DBConnectionManager.getInstance().getConnectionFromPool();

		try {

			st = ucaConn.createStatement();
			rs = st.executeQuery("Select count(*) from E2E_TESTCASES WHERE RUN_IND = 'Y' AND UPPER(TOOL_NM)= UPPER('"
					+ toolName + "') AND TEST_CASE_STAT_DESC in ('" + E2EConstants.INITIALIZED + "','"
					+ E2EConstants.IN_PROGRESS + "','" + E2EConstants.NEW + "','" + E2EConstants.QUEUED + "')");
			if (rs.next()) {
				inProgressTestCases = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnectionManager.getInstance().closeAll(ucaConn, st, rs);
		}
		if (inProgressTestCases == 0) {
			isSystemShutdown = true;
		}
		return isSystemShutdown;
	}

}
