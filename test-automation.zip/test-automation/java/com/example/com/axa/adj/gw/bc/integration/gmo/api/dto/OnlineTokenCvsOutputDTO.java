
package com.example.com.axa.adj.gw.bc.integration.gmo.api.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.adj.axa.gw.bc.gmo.GmoError;
import com.guidewire.bc.typekey.ConvenienceStore_Adj;


/**
 * <p>OnlineTokenCvsOutputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="OnlineTokenCvsOutputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AccessID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AccessPass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CheckString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ConfNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Convenience" type="{http://guidewire.com/bc/typekey}ConvenienceStore_Adj" minOccurs="0"/&gt;
 *         &lt;element name="GmoErrors" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="TranDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnlineTokenCvsOutputDTO", propOrder = {
    "accessID",
    "accessPass",
    "checkString",
    "confNo",
    "convenience",
    "gmoErrors",
    "orderID",
    "paymentTerm",
    "receiptNo",
    "receiptUrl",
    "tranDate"
})
public class OnlineTokenCvsOutputDTO {

    @XmlElement(name = "AccessID")
    protected String accessID;
    @XmlElement(name = "AccessPass")
    protected String accessPass;
    @XmlElement(name = "CheckString")
    protected String checkString;
    @XmlElement(name = "ConfNo")
    protected String confNo;
    @XmlElement(name = "Convenience")
    @XmlSchemaType(name = "string")
    protected ConvenienceStore_Adj convenience;
    @XmlElement(name = "GmoErrors")
    protected OnlineTokenCvsOutputDTO.GmoErrors gmoErrors;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "PaymentTerm")
    protected String paymentTerm;
    @XmlElement(name = "ReceiptNo")
    protected String receiptNo;
    @XmlElement(name = "ReceiptUrl")
    protected String receiptUrl;
    @XmlElement(name = "TranDate")
    protected String tranDate;

    /**
     * accessIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessID() {
        return accessID;
    }

    /**
     * accessIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessID(String value) {
        this.accessID = value;
    }

    /**
     * accessPassプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessPass() {
        return accessPass;
    }

    /**
     * accessPassプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessPass(String value) {
        this.accessPass = value;
    }

    /**
     * checkStringプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckString() {
        return checkString;
    }

    /**
     * checkStringプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckString(String value) {
        this.checkString = value;
    }

    /**
     * confNoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfNo() {
        return confNo;
    }

    /**
     * confNoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfNo(String value) {
        this.confNo = value;
    }

    /**
     * convenienceプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ConvenienceStore_Adj }
     *     
     */
    public ConvenienceStore_Adj getConvenience() {
        return convenience;
    }

    /**
     * convenienceプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ConvenienceStore_Adj }
     *     
     */
    public void setConvenience(ConvenienceStore_Adj value) {
        this.convenience = value;
    }

    /**
     * gmoErrorsプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link OnlineTokenCvsOutputDTO.GmoErrors }
     *     
     */
    public OnlineTokenCvsOutputDTO.GmoErrors getGmoErrors() {
        return gmoErrors;
    }

    /**
     * gmoErrorsプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link OnlineTokenCvsOutputDTO.GmoErrors }
     *     
     */
    public void setGmoErrors(OnlineTokenCvsOutputDTO.GmoErrors value) {
        this.gmoErrors = value;
    }

    /**
     * orderIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * orderIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * paymentTermプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentTerm() {
        return paymentTerm;
    }

    /**
     * paymentTermプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentTerm(String value) {
        this.paymentTerm = value;
    }

    /**
     * receiptNoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptNo() {
        return receiptNo;
    }

    /**
     * receiptNoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptNo(String value) {
        this.receiptNo = value;
    }

    /**
     * receiptUrlプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptUrl() {
        return receiptUrl;
    }

    /**
     * receiptUrlプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptUrl(String value) {
        this.receiptUrl = value;
    }

    /**
     * tranDateプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranDate() {
        return tranDate;
    }

    /**
     * tranDateプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranDate(String value) {
        this.tranDate = value;
    }


    /**
     * <p>anonymous complex typeのJavaクラス。
     * 
     * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "entry"
    })
    public static class GmoErrors {

        @XmlElement(name = "Entry", nillable = true)
        protected List<GmoError> entry;

        /**
         * Gets the value of the entry property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the entry property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEntry().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GmoError }
         * 
         * 
         */
        public List<GmoError> getEntry() {
            if (entry == null) {
                entry = new ArrayList<GmoError>();
            }
            return this.entry;
        }

    }

}
