
package com.example.com.axa.adj.gw.pc.integration.gmo.api.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.pc.typekey.CardHolderType_Adj;


/**
 * <p>PayWithCreditCardForPolicyInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="PayWithCreditCardForPolicyInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="CardHolderType" type="{http://guidewire.com/pc/typekey}CardHolderType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="PaymentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentMethod" type="{http://guidewire.com/pc/typekey}GmoCreditCardPaymentM_Adj" minOccurs="0"/&gt;
 *         &lt;element name="PolicyNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PayWithCreditCardForPolicyInputDTO", propOrder = {
    "amount",
    "cardHolderType",
    "paymentIdentifier",
    "paymentMethod",
    "policyNumber",
    "token"
})
public class PayWithCreditCardForPolicyInputDTO {

    @XmlElement(name = "Amount")
    protected Integer amount;
    @XmlElement(name = "CardHolderType")
    @XmlSchemaType(name = "string")
    protected CardHolderType_Adj cardHolderType;
    @XmlElement(name = "PaymentIdentifier")
    protected String paymentIdentifier;
    @XmlElement(name = "PaymentMethod")
    protected String paymentMethod;
    @XmlElement(name = "PolicyNumber")
    protected String policyNumber;
    @XmlElement(name = "Token")
    protected String token;

    /**
     * amountプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * amountプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAmount(Integer value) {
        this.amount = value;
    }

    /**
     * cardHolderTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link CardHolderType_Adj }
     *     
     */
    public CardHolderType_Adj getCardHolderType() {
        return cardHolderType;
    }

    /**
     * cardHolderTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link CardHolderType_Adj }
     *     
     */
    public void setCardHolderType(CardHolderType_Adj value) {
        this.cardHolderType = value;
    }

    /**
     * paymentIdentifierプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentIdentifier() {
        return paymentIdentifier;
    }

    /**
     * paymentIdentifierプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentIdentifier(String value) {
        this.paymentIdentifier = value;
    }

    /**
     * paymentMethodプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * paymentMethodプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String value) {
        this.paymentMethod = value;
    }

    /**
     * policyNumberプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyNumber() {
        return policyNumber;
    }

    /**
     * policyNumberプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyNumber(String value) {
        this.policyNumber = value;
    }

    /**
     * tokenプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * tokenプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
