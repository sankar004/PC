
package com.example.com.axa.adj.gw.pc.integration.gmo.api.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.pc.typekey.CardHolderType_Adj;


/**
 * <p>PayWithCreditCardForSubmissionInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="PayWithCreditCardForSubmissionInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BranchNumber" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="CardHolderType" type="{http://guidewire.com/pc/typekey}CardHolderType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="PaymentIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentMethod" type="{http://guidewire.com/pc/typekey}GmoCreditCardPaymentM_Adj" minOccurs="0"/&gt;
 *         &lt;element name="SubmissionNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PayWithCreditCardForSubmissionInputDTO", propOrder = {
    "branchNumber",
    "cardHolderType",
    "paymentIdentifier",
    "paymentMethod",
    "submissionNumber",
    "token"
})
public class PayWithCreditCardForSubmissionInputDTO {

    @XmlElement(name = "BranchNumber")
    protected Integer branchNumber;
    @XmlElement(name = "CardHolderType")
    @XmlSchemaType(name = "string")
    protected CardHolderType_Adj cardHolderType;
    @XmlElement(name = "PaymentIdentifier")
    protected String paymentIdentifier;
    @XmlElement(name = "PaymentMethod")
    protected String paymentMethod;
    @XmlElement(name = "SubmissionNumber")
    protected String submissionNumber;
    @XmlElement(name = "Token")
    protected String token;

    /**
     * branchNumberプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBranchNumber() {
        return branchNumber;
    }

    /**
     * branchNumberプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBranchNumber(Integer value) {
        this.branchNumber = value;
    }

    /**
     * cardHolderTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link CardHolderType_Adj }
     *     
     */
    public CardHolderType_Adj getCardHolderType() {
        return cardHolderType;
    }

    /**
     * cardHolderTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link CardHolderType_Adj }
     *     
     */
    public void setCardHolderType(CardHolderType_Adj value) {
        this.cardHolderType = value;
    }

    /**
     * paymentIdentifierプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentIdentifier() {
        return paymentIdentifier;
    }

    /**
     * paymentIdentifierプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentIdentifier(String value) {
        this.paymentIdentifier = value;
    }

    /**
     * paymentMethodプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * paymentMethodプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentMethod(String value) {
        this.paymentMethod = value;
    }

    /**
     * submissionNumberプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubmissionNumber() {
        return submissionNumber;
    }

    /**
     * submissionNumberプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubmissionNumber(String value) {
        this.submissionNumber = value;
    }

    /**
     * tokenプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * tokenプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
