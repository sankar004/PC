@javax.xml.bind.annotation.XmlSchema(namespace = "http://example.com/com/axa/adj/gw/pc/integration/gmo/api/dto", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.example.com.axa.adj.gw.pc.integration.gmo.api.dto;
