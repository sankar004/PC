
package com.example.com.axa.adj.gw.bc.integration.gmo.api.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.bc.typekey.ConvenienceStore_Adj;
import com.guidewire.bc.typekey.ProductPaymentType_Adj;


/**
 * <p>OnlineTokenCvsInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="OnlineTokenCvsInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ADJContact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ADJContactBusinessHours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ADJContactPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ConvenienceStore" type="{http://guidewire.com/bc/typekey}ConvenienceStore_Adj" minOccurs="0"/&gt;
 *         &lt;element name="CustomerKana" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CustomerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="LinkID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MemberNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PaymentTermDay" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ProductType" type="{http://guidewire.com/bc/typekey}ProductPaymentType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReceiptDisp9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="RegisterDisp8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ReserveNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Tax" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="TelNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OnlineTokenCvsInputDTO", propOrder = {
    "adjContact",
    "adjContactBusinessHours",
    "adjContactPhoneNumber",
    "amount",
    "convenienceStore",
    "customerKana",
    "customerName",
    "linkID",
    "mailAddress",
    "memberNo",
    "paymentTermDay",
    "productType",
    "receiptDisp1",
    "receiptDisp10",
    "receiptDisp2",
    "receiptDisp3",
    "receiptDisp4",
    "receiptDisp5",
    "receiptDisp6",
    "receiptDisp7",
    "receiptDisp8",
    "receiptDisp9",
    "registerDisp1",
    "registerDisp2",
    "registerDisp3",
    "registerDisp4",
    "registerDisp5",
    "registerDisp6",
    "registerDisp7",
    "registerDisp8",
    "reserveNo",
    "tax",
    "telNo"
})
public class OnlineTokenCvsInputDTO {

    @XmlElement(name = "ADJContact")
    protected String adjContact;
    @XmlElement(name = "ADJContactBusinessHours")
    protected String adjContactBusinessHours;
    @XmlElement(name = "ADJContactPhoneNumber")
    protected String adjContactPhoneNumber;
    @XmlElement(name = "Amount")
    protected Integer amount;
    @XmlElement(name = "ConvenienceStore")
    @XmlSchemaType(name = "string")
    protected ConvenienceStore_Adj convenienceStore;
    @XmlElement(name = "CustomerKana")
    protected String customerKana;
    @XmlElement(name = "CustomerName")
    protected String customerName;
    @XmlElement(name = "LinkID")
    protected String linkID;
    @XmlElement(name = "MailAddress")
    protected String mailAddress;
    @XmlElement(name = "MemberNo")
    protected String memberNo;
    @XmlElement(name = "PaymentTermDay")
    protected Integer paymentTermDay;
    @XmlElement(name = "ProductType")
    @XmlSchemaType(name = "string")
    protected ProductPaymentType_Adj productType;
    @XmlElement(name = "ReceiptDisp1")
    protected String receiptDisp1;
    @XmlElement(name = "ReceiptDisp10")
    protected String receiptDisp10;
    @XmlElement(name = "ReceiptDisp2")
    protected String receiptDisp2;
    @XmlElement(name = "ReceiptDisp3")
    protected String receiptDisp3;
    @XmlElement(name = "ReceiptDisp4")
    protected String receiptDisp4;
    @XmlElement(name = "ReceiptDisp5")
    protected String receiptDisp5;
    @XmlElement(name = "ReceiptDisp6")
    protected String receiptDisp6;
    @XmlElement(name = "ReceiptDisp7")
    protected String receiptDisp7;
    @XmlElement(name = "ReceiptDisp8")
    protected String receiptDisp8;
    @XmlElement(name = "ReceiptDisp9")
    protected String receiptDisp9;
    @XmlElement(name = "RegisterDisp1")
    protected String registerDisp1;
    @XmlElement(name = "RegisterDisp2")
    protected String registerDisp2;
    @XmlElement(name = "RegisterDisp3")
    protected String registerDisp3;
    @XmlElement(name = "RegisterDisp4")
    protected String registerDisp4;
    @XmlElement(name = "RegisterDisp5")
    protected String registerDisp5;
    @XmlElement(name = "RegisterDisp6")
    protected String registerDisp6;
    @XmlElement(name = "RegisterDisp7")
    protected String registerDisp7;
    @XmlElement(name = "RegisterDisp8")
    protected String registerDisp8;
    @XmlElement(name = "ReserveNo")
    protected String reserveNo;
    @XmlElement(name = "Tax")
    protected Integer tax;
    @XmlElement(name = "TelNo")
    protected String telNo;

    /**
     * adjContactプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADJContact() {
        return adjContact;
    }

    /**
     * adjContactプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADJContact(String value) {
        this.adjContact = value;
    }

    /**
     * adjContactBusinessHoursプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADJContactBusinessHours() {
        return adjContactBusinessHours;
    }

    /**
     * adjContactBusinessHoursプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADJContactBusinessHours(String value) {
        this.adjContactBusinessHours = value;
    }

    /**
     * adjContactPhoneNumberプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADJContactPhoneNumber() {
        return adjContactPhoneNumber;
    }

    /**
     * adjContactPhoneNumberプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADJContactPhoneNumber(String value) {
        this.adjContactPhoneNumber = value;
    }

    /**
     * amountプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * amountプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAmount(Integer value) {
        this.amount = value;
    }

    /**
     * convenienceStoreプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ConvenienceStore_Adj }
     *     
     */
    public ConvenienceStore_Adj getConvenienceStore() {
        return convenienceStore;
    }

    /**
     * convenienceStoreプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ConvenienceStore_Adj }
     *     
     */
    public void setConvenienceStore(ConvenienceStore_Adj value) {
        this.convenienceStore = value;
    }

    /**
     * customerKanaプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerKana() {
        return customerKana;
    }

    /**
     * customerKanaプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerKana(String value) {
        this.customerKana = value;
    }

    /**
     * customerNameプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * customerNameプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerName(String value) {
        this.customerName = value;
    }

    /**
     * linkIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinkID() {
        return linkID;
    }

    /**
     * linkIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinkID(String value) {
        this.linkID = value;
    }

    /**
     * mailAddressプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * mailAddressプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailAddress(String value) {
        this.mailAddress = value;
    }

    /**
     * memberNoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberNo() {
        return memberNo;
    }

    /**
     * memberNoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberNo(String value) {
        this.memberNo = value;
    }

    /**
     * paymentTermDayプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPaymentTermDay() {
        return paymentTermDay;
    }

    /**
     * paymentTermDayプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaymentTermDay(Integer value) {
        this.paymentTermDay = value;
    }

    /**
     * productTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public ProductPaymentType_Adj getProductType() {
        return productType;
    }

    /**
     * productTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public void setProductType(ProductPaymentType_Adj value) {
        this.productType = value;
    }

    /**
     * receiptDisp1プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp1() {
        return receiptDisp1;
    }

    /**
     * receiptDisp1プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp1(String value) {
        this.receiptDisp1 = value;
    }

    /**
     * receiptDisp10プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp10() {
        return receiptDisp10;
    }

    /**
     * receiptDisp10プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp10(String value) {
        this.receiptDisp10 = value;
    }

    /**
     * receiptDisp2プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp2() {
        return receiptDisp2;
    }

    /**
     * receiptDisp2プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp2(String value) {
        this.receiptDisp2 = value;
    }

    /**
     * receiptDisp3プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp3() {
        return receiptDisp3;
    }

    /**
     * receiptDisp3プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp3(String value) {
        this.receiptDisp3 = value;
    }

    /**
     * receiptDisp4プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp4() {
        return receiptDisp4;
    }

    /**
     * receiptDisp4プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp4(String value) {
        this.receiptDisp4 = value;
    }

    /**
     * receiptDisp5プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp5() {
        return receiptDisp5;
    }

    /**
     * receiptDisp5プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp5(String value) {
        this.receiptDisp5 = value;
    }

    /**
     * receiptDisp6プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp6() {
        return receiptDisp6;
    }

    /**
     * receiptDisp6プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp6(String value) {
        this.receiptDisp6 = value;
    }

    /**
     * receiptDisp7プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp7() {
        return receiptDisp7;
    }

    /**
     * receiptDisp7プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp7(String value) {
        this.receiptDisp7 = value;
    }

    /**
     * receiptDisp8プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp8() {
        return receiptDisp8;
    }

    /**
     * receiptDisp8プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp8(String value) {
        this.receiptDisp8 = value;
    }

    /**
     * receiptDisp9プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDisp9() {
        return receiptDisp9;
    }

    /**
     * receiptDisp9プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDisp9(String value) {
        this.receiptDisp9 = value;
    }

    /**
     * registerDisp1プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp1() {
        return registerDisp1;
    }

    /**
     * registerDisp1プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp1(String value) {
        this.registerDisp1 = value;
    }

    /**
     * registerDisp2プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp2() {
        return registerDisp2;
    }

    /**
     * registerDisp2プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp2(String value) {
        this.registerDisp2 = value;
    }

    /**
     * registerDisp3プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp3() {
        return registerDisp3;
    }

    /**
     * registerDisp3プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp3(String value) {
        this.registerDisp3 = value;
    }

    /**
     * registerDisp4プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp4() {
        return registerDisp4;
    }

    /**
     * registerDisp4プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp4(String value) {
        this.registerDisp4 = value;
    }

    /**
     * registerDisp5プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp5() {
        return registerDisp5;
    }

    /**
     * registerDisp5プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp5(String value) {
        this.registerDisp5 = value;
    }

    /**
     * registerDisp6プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp6() {
        return registerDisp6;
    }

    /**
     * registerDisp6プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp6(String value) {
        this.registerDisp6 = value;
    }

    /**
     * registerDisp7プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp7() {
        return registerDisp7;
    }

    /**
     * registerDisp7プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp7(String value) {
        this.registerDisp7 = value;
    }

    /**
     * registerDisp8プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegisterDisp8() {
        return registerDisp8;
    }

    /**
     * registerDisp8プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegisterDisp8(String value) {
        this.registerDisp8 = value;
    }

    /**
     * reserveNoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReserveNo() {
        return reserveNo;
    }

    /**
     * reserveNoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReserveNo(String value) {
        this.reserveNo = value;
    }

    /**
     * taxプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTax() {
        return tax;
    }

    /**
     * taxプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTax(Integer value) {
        this.tax = value;
    }

    /**
     * telNoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * telNoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelNo(String value) {
        this.telNo = value;
    }

}
