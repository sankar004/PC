
package com.example.com.axa.adj.gw.bc.integration.gmo.api.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.adj.axa.gw.bc.gmo.GmoError;


/**
 * <p>CancelOnlineCvsTokenOutputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="CancelOnlineCvsTokenOutputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GmoErrors" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CancelOnlineCvsTokenOutputDTO", propOrder = {
    "gmoErrors",
    "orderID",
    "status"
})
public class CancelOnlineCvsTokenOutputDTO {

    @XmlElement(name = "GmoErrors")
    protected CancelOnlineCvsTokenOutputDTO.GmoErrors gmoErrors;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "Status")
    protected String status;

    /**
     * gmoErrorsプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link CancelOnlineCvsTokenOutputDTO.GmoErrors }
     *     
     */
    public CancelOnlineCvsTokenOutputDTO.GmoErrors getGmoErrors() {
        return gmoErrors;
    }

    /**
     * gmoErrorsプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link CancelOnlineCvsTokenOutputDTO.GmoErrors }
     *     
     */
    public void setGmoErrors(CancelOnlineCvsTokenOutputDTO.GmoErrors value) {
        this.gmoErrors = value;
    }

    /**
     * orderIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * orderIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * statusプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * statusプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }


    /**
     * <p>anonymous complex typeのJavaクラス。
     * 
     * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "entry"
    })
    public static class GmoErrors {

        @XmlElement(name = "Entry", nillable = true)
        protected List<GmoError> entry;

        /**
         * Gets the value of the entry property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the entry property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEntry().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GmoError }
         * 
         * 
         */
        public List<GmoError> getEntry() {
            if (entry == null) {
                entry = new ArrayList<GmoError>();
            }
            return this.entry;
        }

    }

}
