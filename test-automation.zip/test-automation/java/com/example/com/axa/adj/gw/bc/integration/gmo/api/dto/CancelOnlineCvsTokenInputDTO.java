
package com.example.com.axa.adj.gw.bc.integration.gmo.api.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.bc.typekey.ProductPaymentType_Adj;


/**
 * <p>CancelOnlineCvsTokenInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="CancelOnlineCvsTokenInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AccessID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AccessPass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductPaymentType" type="{http://guidewire.com/bc/typekey}ProductPaymentType_Adj" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CancelOnlineCvsTokenInputDTO", propOrder = {
    "accessID",
    "accessPass",
    "orderID",
    "productPaymentType"
})
public class CancelOnlineCvsTokenInputDTO {

    @XmlElement(name = "AccessID")
    protected String accessID;
    @XmlElement(name = "AccessPass")
    protected String accessPass;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "ProductPaymentType")
    @XmlSchemaType(name = "string")
    protected ProductPaymentType_Adj productPaymentType;

    /**
     * accessIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessID() {
        return accessID;
    }

    /**
     * accessIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessID(String value) {
        this.accessID = value;
    }

    /**
     * accessPassプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessPass() {
        return accessPass;
    }

    /**
     * accessPassプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessPass(String value) {
        this.accessPass = value;
    }

    /**
     * orderIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * orderIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * productPaymentTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public ProductPaymentType_Adj getProductPaymentType() {
        return productPaymentType;
    }

    /**
     * productPaymentTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public void setProductPaymentType(ProductPaymentType_Adj value) {
        this.productPaymentType = value;
    }

}
