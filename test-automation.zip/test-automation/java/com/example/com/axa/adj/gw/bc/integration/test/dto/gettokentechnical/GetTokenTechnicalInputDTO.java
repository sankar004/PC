
package com.example.com.axa.adj.gw.bc.integration.test.dto.gettokentechnical;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.bc.typekey.ProductPaymentType_Adj;


/**
 * <p>GetTokenTechnicalInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="GetTokenTechnicalInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Encrypted" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Key" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductPaymentType" type="{http://guidewire.com/bc/typekey}ProductPaymentType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="Seal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetTokenTechnicalInputDTO", propOrder = {
    "encrypted",
    "key",
    "productPaymentType",
    "seal"
})
public class GetTokenTechnicalInputDTO {

    @XmlElement(name = "Encrypted")
    protected String encrypted;
    @XmlElement(name = "Key")
    protected String key;
    @XmlElement(name = "ProductPaymentType")
    @XmlSchemaType(name = "string")
    protected ProductPaymentType_Adj productPaymentType;
    @XmlElement(name = "Seal")
    protected String seal;

    /**
     * encryptedプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncrypted() {
        return encrypted;
    }

    /**
     * encryptedプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncrypted(String value) {
        this.encrypted = value;
    }

    /**
     * keyプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * keyプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

    /**
     * productPaymentTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public ProductPaymentType_Adj getProductPaymentType() {
        return productPaymentType;
    }

    /**
     * productPaymentTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public void setProductPaymentType(ProductPaymentType_Adj value) {
        this.productPaymentType = value;
    }

    /**
     * sealプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeal() {
        return seal;
    }

    /**
     * sealプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeal(String value) {
        this.seal = value;
    }

}
