@javax.xml.bind.annotation.XmlSchema(namespace = "http://example.com/com/axa/adj/gw/bc/integration/test/dto/payWithRegisteredCreditCard", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.example.com.axa.adj.gw.bc.integration.test.dto.paywithregisteredcreditcard;
