
package com.example.com.axa.adj.gw.bc.integration.test.dto.paywithregisteredcreditcard;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.bc.typekey.ProductPaymentType_Adj;


/**
 * <p>PayWithRegisteredCreditCardInputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="PayWithRegisteredCreditCardInputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="CardSeq" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ClientField1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClientField2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ClientField3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="MemberID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Method" type="{http://guidewire.com/bc/typekey}CreditCardPaymentMethod_Adj" minOccurs="0"/&gt;
 *         &lt;element name="OrderID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="PayTimes" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="ProductPaymentType" type="{http://guidewire.com/bc/typekey}ProductPaymentType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="SecurityCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Tax" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PayWithRegisteredCreditCardInputDTO", propOrder = {
    "amount",
    "cardSeq",
    "clientField1",
    "clientField2",
    "clientField3",
    "memberID",
    "method",
    "orderID",
    "payTimes",
    "productPaymentType",
    "securityCode",
    "tax"
})
public class PayWithRegisteredCreditCardInputDTO {

    @XmlElement(name = "Amount")
    protected Integer amount;
    @XmlElement(name = "CardSeq")
    protected Integer cardSeq;
    @XmlElement(name = "ClientField1")
    protected String clientField1;
    @XmlElement(name = "ClientField2")
    protected String clientField2;
    @XmlElement(name = "ClientField3")
    protected String clientField3;
    @XmlElement(name = "MemberID")
    protected String memberID;
    @XmlElement(name = "Method")
    protected String method;
    @XmlElement(name = "OrderID")
    protected String orderID;
    @XmlElement(name = "PayTimes")
    protected Integer payTimes;
    @XmlElement(name = "ProductPaymentType")
    @XmlSchemaType(name = "string")
    protected ProductPaymentType_Adj productPaymentType;
    @XmlElement(name = "SecurityCode")
    protected String securityCode;
    @XmlElement(name = "Tax")
    protected Integer tax;

    /**
     * amountプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAmount() {
        return amount;
    }

    /**
     * amountプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAmount(Integer value) {
        this.amount = value;
    }

    /**
     * cardSeqプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCardSeq() {
        return cardSeq;
    }

    /**
     * cardSeqプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCardSeq(Integer value) {
        this.cardSeq = value;
    }

    /**
     * clientField1プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField1() {
        return clientField1;
    }

    /**
     * clientField1プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField1(String value) {
        this.clientField1 = value;
    }

    /**
     * clientField2プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField2() {
        return clientField2;
    }

    /**
     * clientField2プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField2(String value) {
        this.clientField2 = value;
    }

    /**
     * clientField3プロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientField3() {
        return clientField3;
    }

    /**
     * clientField3プロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientField3(String value) {
        this.clientField3 = value;
    }

    /**
     * memberIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberID() {
        return memberID;
    }

    /**
     * memberIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberID(String value) {
        this.memberID = value;
    }

    /**
     * methodプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMethod() {
        return method;
    }

    /**
     * methodプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMethod(String value) {
        this.method = value;
    }

    /**
     * orderIDプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderID() {
        return orderID;
    }

    /**
     * orderIDプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderID(String value) {
        this.orderID = value;
    }

    /**
     * payTimesプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPayTimes() {
        return payTimes;
    }

    /**
     * payTimesプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPayTimes(Integer value) {
        this.payTimes = value;
    }

    /**
     * productPaymentTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public ProductPaymentType_Adj getProductPaymentType() {
        return productPaymentType;
    }

    /**
     * productPaymentTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public void setProductPaymentType(ProductPaymentType_Adj value) {
        this.productPaymentType = value;
    }

    /**
     * securityCodeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecurityCode() {
        return securityCode;
    }

    /**
     * securityCodeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecurityCode(String value) {
        this.securityCode = value;
    }

    /**
     * taxプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTax() {
        return tax;
    }

    /**
     * taxプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTax(Integer value) {
        this.tax = value;
    }

}
