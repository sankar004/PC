
package com.example.com.axa.adj.gw.bc.integration.test.dto.gettoken;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.bc.typekey.ProductPaymentType_Adj;


/**
 * <p>GmoTokenOutputDTO complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="GmoTokenOutputDTO"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Brand" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ExpiryDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="HolderName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="IssuerCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProductPaymentType" type="{http://guidewire.com/bc/typekey}ProductPaymentType_Adj" minOccurs="0"/&gt;
 *         &lt;element name="Token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GmoTokenOutputDTO", propOrder = {
    "brand",
    "cardNumber",
    "expiryDate",
    "holderName",
    "issuerCode",
    "productPaymentType",
    "token"
})
public class GmoTokenOutputDTO {

    @XmlElement(name = "Brand")
    protected String brand;
    @XmlElement(name = "CardNumber")
    protected String cardNumber;
    @XmlElement(name = "ExpiryDate")
    protected String expiryDate;
    @XmlElement(name = "HolderName")
    protected String holderName;
    @XmlElement(name = "IssuerCode")
    protected String issuerCode;
    @XmlElement(name = "ProductPaymentType")
    @XmlSchemaType(name = "string")
    protected ProductPaymentType_Adj productPaymentType;
    @XmlElement(name = "Token")
    protected String token;

    /**
     * brandプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrand() {
        return brand;
    }

    /**
     * brandプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrand(String value) {
        this.brand = value;
    }

    /**
     * cardNumberプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * cardNumberプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * expiryDateプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * expiryDateプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDate(String value) {
        this.expiryDate = value;
    }

    /**
     * holderNameプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHolderName() {
        return holderName;
    }

    /**
     * holderNameプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHolderName(String value) {
        this.holderName = value;
    }

    /**
     * issuerCodeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerCode() {
        return issuerCode;
    }

    /**
     * issuerCodeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerCode(String value) {
        this.issuerCode = value;
    }

    /**
     * productPaymentTypeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public ProductPaymentType_Adj getProductPaymentType() {
        return productPaymentType;
    }

    /**
     * productPaymentTypeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ProductPaymentType_Adj }
     *     
     */
    public void setProductPaymentType(ProductPaymentType_Adj value) {
        this.productPaymentType = value;
    }

    /**
     * tokenプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * tokenプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
