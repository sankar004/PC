
package com.guidewire.bc.typekey;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ConvenienceStore_AdjのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * <p>
 * <pre>
 * &lt;simpleType name="ConvenienceStore_Adj"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="CircleK"/&gt;
 *     &lt;enumeration value="FamilyMart"/&gt;
 *     &lt;enumeration value="Lawson"/&gt;
 *     &lt;enumeration value="MiniStop"/&gt;
 *     &lt;enumeration value="SeikoMart"/&gt;
 *     &lt;enumeration value="SevenEleven"/&gt;
 *     &lt;enumeration value="Sunkus"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ConvenienceStore_Adj", namespace = "http://guidewire.com/bc/typekey")
@XmlEnum
public enum ConvenienceStore_Adj {

    @XmlEnumValue("CircleK")
    CIRCLE_K("CircleK"),
    @XmlEnumValue("FamilyMart")
    FAMILY_MART("FamilyMart"),
    @XmlEnumValue("Lawson")
    LAWSON("Lawson"),
    @XmlEnumValue("MiniStop")
    MINI_STOP("MiniStop"),
    @XmlEnumValue("SeikoMart")
    SEIKO_MART("SeikoMart"),
    @XmlEnumValue("SevenEleven")
    SEVEN_ELEVEN("SevenEleven"),
    @XmlEnumValue("Sunkus")
    SUNKUS("Sunkus");
    private final String value;

    ConvenienceStore_Adj(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ConvenienceStore_Adj fromValue(String v) {
        for (ConvenienceStore_Adj c: ConvenienceStore_Adj.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
