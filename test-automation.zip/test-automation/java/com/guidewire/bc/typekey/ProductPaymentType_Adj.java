
package com.guidewire.bc.typekey;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ProductPaymentType_AdjのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * <p>
 * <pre>
 * &lt;simpleType name="ProductPaymentType_Adj"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="AutoInstallmentPayment"/&gt;
 *     &lt;enumeration value="AutoLumpSumPayment"/&gt;
 *     &lt;enumeration value="DirectPersonalAccidentAndMedical"/&gt;
 *     &lt;enumeration value="GroupMedical"/&gt;
 *     &lt;enumeration value="GroupPersonalAccident"/&gt;
 *     &lt;enumeration value="PetInstallmentPayment"/&gt;
 *     &lt;enumeration value="PetLumpSumPayment"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ProductPaymentType_Adj", namespace = "http://guidewire.com/bc/typekey")
@XmlEnum
public enum ProductPaymentType_Adj {

    @XmlEnumValue("AutoInstallmentPayment")
    AUTO_INSTALLMENT_PAYMENT("AutoInstallmentPayment"),
    @XmlEnumValue("AutoLumpSumPayment")
    AUTO_LUMP_SUM_PAYMENT("AutoLumpSumPayment"),
    @XmlEnumValue("DirectPersonalAccidentAndMedical")
    DIRECT_PERSONAL_ACCIDENT_AND_MEDICAL("DirectPersonalAccidentAndMedical"),
    @XmlEnumValue("GroupMedical")
    GROUP_MEDICAL("GroupMedical"),
    @XmlEnumValue("GroupPersonalAccident")
    GROUP_PERSONAL_ACCIDENT("GroupPersonalAccident"),
    @XmlEnumValue("PetInstallmentPayment")
    PET_INSTALLMENT_PAYMENT("PetInstallmentPayment"),
    @XmlEnumValue("PetLumpSumPayment")
    PET_LUMP_SUM_PAYMENT("PetLumpSumPayment");
    private final String value;

    ProductPaymentType_Adj(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ProductPaymentType_Adj fromValue(String v) {
        for (ProductPaymentType_Adj c: ProductPaymentType_Adj.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
