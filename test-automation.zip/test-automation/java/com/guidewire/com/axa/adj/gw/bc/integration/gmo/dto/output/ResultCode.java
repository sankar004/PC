
package com.guidewire.com.axa.adj.gw.bc.integration.gmo.dto.output;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ResultCodeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * <p>
 * <pre>
 * &lt;simpleType name="ResultCode"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SUCCESS"/&gt;
 *     &lt;enumeration value="FAILURE"/&gt;
 *     &lt;enumeration value="PARTIAL_UNKNOWN"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ResultCode", namespace = "http://guidewire.com/com/axa/adj/gw/bc/integration/gmo/dto/output")
@XmlEnum
public enum ResultCode {

    SUCCESS("SUCCESS"),
    FAILURE("FAILURE"),
    @XmlEnumValue("PARTIAL_UNKNOWN")
    PARTIAL___UNKNOWN("PARTIAL_UNKNOWN");
    private final String value;

    ResultCode(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ResultCode fromValue(String v) {
        for (ResultCode c: ResultCode.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
