
package com.guidewire.pc.typekey;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>CardHolderType_AdjのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * <p>
 * <pre>
 * &lt;simpleType name="CardHolderType_Adj"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="family"/&gt;
 *     &lt;enumeration value="policyholder"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "CardHolderType_Adj", namespace = "http://guidewire.com/pc/typekey")
@XmlEnum
public enum CardHolderType_Adj {

    @XmlEnumValue("family")
    FAMILY("family"),
    @XmlEnumValue("policyholder")
    POLICYHOLDER("policyholder");
    private final String value;

    CardHolderType_Adj(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CardHolderType_Adj fromValue(String v) {
        for (CardHolderType_Adj c: CardHolderType_Adj.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
