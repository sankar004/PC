
package com.adj.axa.gw.ab;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.adj.axa.gw.ab.creditcard.CreditCardDTO;


/**
 * <p>anonymous complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="creditCardDto" type="{http://axa.adj.com/gw/ab/creditcard}CreditCardDTO" minOccurs="0"/&gt;
 *         &lt;element name="generateNewToken" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "creditCardDto",
    "generateNewToken"
})
@XmlRootElement(name = "updateCreditCard")
public class UpdateCreditCard {

    protected CreditCardDTO creditCardDto;
    protected boolean generateNewToken;

    /**
     * creditCardDtoプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link CreditCardDTO }
     *     
     */
    public CreditCardDTO getCreditCardDto() {
        return creditCardDto;
    }

    /**
     * creditCardDtoプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardDTO }
     *     
     */
    public void setCreditCardDto(CreditCardDTO value) {
        this.creditCardDto = value;
    }

    /**
     * generateNewTokenプロパティの値を取得します。
     * 
     */
    public boolean isGenerateNewToken() {
        return generateNewToken;
    }

    /**
     * generateNewTokenプロパティの値を設定します。
     * 
     */
    public void setGenerateNewToken(boolean value) {
        this.generateNewToken = value;
    }

}
