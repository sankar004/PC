@javax.xml.bind.annotation.XmlSchema(namespace = "http://axa.adj.com/gw/ab/creditcard", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.adj.axa.gw.ab.creditcard;
