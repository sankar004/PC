
package com.adj.axa.gw.ab;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.adj.axa.gw.ab.creditcard.CreditCardDTO;


/**
 * <p>anonymous complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="return" type="{http://axa.adj.com/gw/ab/creditcard}CreditCardDTO" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "_return"
})
@XmlRootElement(name = "updateCreditCardResponse")
public class UpdateCreditCardResponse {

    @XmlElement(name = "return")
    protected CreditCardDTO _return;

    /**
     * returnプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link CreditCardDTO }
     *     
     */
    public CreditCardDTO getReturn() {
        return _return;
    }

    /**
     * returnプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardDTO }
     *     
     */
    public void setReturn(CreditCardDTO value) {
        this._return = value;
    }

}
