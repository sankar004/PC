
package com.adj.axa.gw.ab;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.adj.axa.gw.ab package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.adj.axa.gw.ab
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetCreditCardsForTokens }
     * 
     */
    public GetCreditCardsForTokens createGetCreditCardsForTokens() {
        return new GetCreditCardsForTokens();
    }

    /**
     * Create an instance of {@link GetCreditCardsForTokensResponse }
     * 
     */
    public GetCreditCardsForTokensResponse createGetCreditCardsForTokensResponse() {
        return new GetCreditCardsForTokensResponse();
    }

    /**
     * Create an instance of {@link GetCreditCardsForContactResponse }
     * 
     */
    public GetCreditCardsForContactResponse createGetCreditCardsForContactResponse() {
        return new GetCreditCardsForContactResponse();
    }

    /**
     * Create an instance of {@link GetTokensForCreditCards }
     * 
     */
    public GetTokensForCreditCards createGetTokensForCreditCards() {
        return new GetTokensForCreditCards();
    }

    /**
     * Create an instance of {@link GetTokensForCreditCardsResponse }
     * 
     */
    public GetTokensForCreditCardsResponse createGetTokensForCreditCardsResponse() {
        return new GetTokensForCreditCardsResponse();
    }

    /**
     * Create an instance of {@link MakeCardInactive }
     * 
     */
    public MakeCardInactive createMakeCardInactive() {
        return new MakeCardInactive();
    }

    /**
     * Create an instance of {@link MakeCardInactiveResponse }
     * 
     */
    public MakeCardInactiveResponse createMakeCardInactiveResponse() {
        return new MakeCardInactiveResponse();
    }

    /**
     * Create an instance of {@link WsiAuthenticationException }
     * 
     */
    public WsiAuthenticationException createWsiAuthenticationException() {
        return new WsiAuthenticationException();
    }

    /**
     * Create an instance of {@link CreateCreditCard }
     * 
     */
    public CreateCreditCard createCreateCreditCard() {
        return new CreateCreditCard();
    }

    /**
     * Create an instance of {@link CreateCreditCardResponse }
     * 
     */
    public CreateCreditCardResponse createCreateCreditCardResponse() {
        return new CreateCreditCardResponse();
    }

    /**
     * Create an instance of {@link SetCreditCardActivity }
     * 
     */
    public SetCreditCardActivity createSetCreditCardActivity() {
        return new SetCreditCardActivity();
    }

    /**
     * Create an instance of {@link SetCreditCardActivityResponse }
     * 
     */
    public SetCreditCardActivityResponse createSetCreditCardActivityResponse() {
        return new SetCreditCardActivityResponse();
    }

    /**
     * Create an instance of {@link GetCreditCardForToken }
     * 
     */
    public GetCreditCardForToken createGetCreditCardForToken() {
        return new GetCreditCardForToken();
    }

    /**
     * Create an instance of {@link GetCreditCardForTokenResponse }
     * 
     */
    public GetCreditCardForTokenResponse createGetCreditCardForTokenResponse() {
        return new GetCreditCardForTokenResponse();
    }

    /**
     * Create an instance of {@link GetCreditCardsForTokens.Tokens }
     * 
     */
    public GetCreditCardsForTokens.Tokens createGetCreditCardsForTokensTokens() {
        return new GetCreditCardsForTokens.Tokens();
    }

    /**
     * Create an instance of {@link GetCreditCardsForTokensResponse.Return }
     * 
     */
    public GetCreditCardsForTokensResponse.Return createGetCreditCardsForTokensResponseReturn() {
        return new GetCreditCardsForTokensResponse.Return();
    }

    /**
     * Create an instance of {@link GetCreditCardsForContact }
     * 
     */
    public GetCreditCardsForContact createGetCreditCardsForContact() {
        return new GetCreditCardsForContact();
    }

    /**
     * Create an instance of {@link GetCreditCardsForContactResponse.Return }
     * 
     */
    public GetCreditCardsForContactResponse.Return createGetCreditCardsForContactResponseReturn() {
        return new GetCreditCardsForContactResponse.Return();
    }

    /**
     * Create an instance of {@link GetTokenForCreditCard }
     * 
     */
    public GetTokenForCreditCard createGetTokenForCreditCard() {
        return new GetTokenForCreditCard();
    }

    /**
     * Create an instance of {@link GetTokenForCreditCardResponse }
     * 
     */
    public GetTokenForCreditCardResponse createGetTokenForCreditCardResponse() {
        return new GetTokenForCreditCardResponse();
    }

    /**
     * Create an instance of {@link GetTokensForCreditCards.CreditCards }
     * 
     */
    public GetTokensForCreditCards.CreditCards createGetTokensForCreditCardsCreditCards() {
        return new GetTokensForCreditCards.CreditCards();
    }

    /**
     * Create an instance of {@link GetTokensForCreditCardsResponse.Return }
     * 
     */
    public GetTokensForCreditCardsResponse.Return createGetTokensForCreditCardsResponseReturn() {
        return new GetTokensForCreditCardsResponse.Return();
    }

    /**
     * Create an instance of {@link UpdateCreditCard }
     * 
     */
    public UpdateCreditCard createUpdateCreditCard() {
        return new UpdateCreditCard();
    }

    /**
     * Create an instance of {@link UpdateCreditCardResponse }
     * 
     */
    public UpdateCreditCardResponse createUpdateCreditCardResponse() {
        return new UpdateCreditCardResponse();
    }

}
