
package com.adj.axa.gw.bc.gmo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.guidewire.com.axa.adj.gw.bc.integration.gmo.dto.output.ResultCode;


/**
 * <p>GmoResult complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType name="GmoResult"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ErrList" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ResultCode" type="{http://guidewire.com/com/axa/adj/gw/bc/integration/gmo/dto/output}ResultCode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GmoResult", propOrder = {
    "errList",
    "resultCode"
})
public class GmoResult {

    @XmlElement(name = "ErrList")
    protected GmoResult.ErrList errList;
    @XmlElement(name = "ResultCode")
    @XmlSchemaType(name = "string")
    protected ResultCode resultCode;

    /**
     * errListプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link GmoResult.ErrList }
     *     
     */
    public GmoResult.ErrList getErrList() {
        return errList;
    }

    /**
     * errListプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link GmoResult.ErrList }
     *     
     */
    public void setErrList(GmoResult.ErrList value) {
        this.errList = value;
    }

    /**
     * resultCodeプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link ResultCode }
     *     
     */
    public ResultCode getResultCode() {
        return resultCode;
    }

    /**
     * resultCodeプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link ResultCode }
     *     
     */
    public void setResultCode(ResultCode value) {
        this.resultCode = value;
    }


    /**
     * <p>anonymous complex typeのJavaクラス。
     * 
     * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Entry" type="{http://axa.adj.com/gw/bc/gmo}GmoError" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "entry"
    })
    public static class ErrList {

        @XmlElement(name = "Entry", nillable = true)
        protected List<GmoError> entry;

        /**
         * Gets the value of the entry property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the entry property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getEntry().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link GmoError }
         * 
         * 
         */
        public List<GmoError> getEntry() {
            if (entry == null) {
                entry = new ArrayList<GmoError>();
            }
            return this.entry;
        }

    }

}
