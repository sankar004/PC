
package com.adj.axa.gw.bc;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.adj.axa.gw.bc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.adj.axa.gw.bc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PayWithNewCreditCard }
     * 
     */
    public PayWithNewCreditCard createPayWithNewCreditCard() {
        return new PayWithNewCreditCard();
    }

    /**
     * Create an instance of {@link PayWithNewCreditCardResponse }
     * 
     */
    public PayWithNewCreditCardResponse createPayWithNewCreditCardResponse() {
        return new PayWithNewCreditCardResponse();
    }

    /**
     * Create an instance of {@link ValidationException }
     * 
     */
    public ValidationException createValidationException() {
        return new ValidationException();
    }

    /**
     * Create an instance of {@link WsiAuthenticationException }
     * 
     */
    public WsiAuthenticationException createWsiAuthenticationException() {
        return new WsiAuthenticationException();
    }

    /**
     * Create an instance of {@link PayWithRegisteredCreditCard }
     * 
     */
    public PayWithRegisteredCreditCard createPayWithRegisteredCreditCard() {
        return new PayWithRegisteredCreditCard();
    }

    /**
     * Create an instance of {@link PayWithRegisteredCreditCardResponse }
     * 
     */
    public PayWithRegisteredCreditCardResponse createPayWithRegisteredCreditCardResponse() {
        return new PayWithRegisteredCreditCardResponse();
    }

    /**
     * Create an instance of {@link IllegalStateException }
     * 
     */
    public IllegalStateException createIllegalStateException() {
        return new IllegalStateException();
    }

    /**
     * Create an instance of {@link GenerateOnlineCvsToken }
     * 
     */
    public GenerateOnlineCvsToken createGenerateOnlineCvsToken() {
        return new GenerateOnlineCvsToken();
    }

    /**
     * Create an instance of {@link GenerateOnlineCvsTokenResponse }
     * 
     */
    public GenerateOnlineCvsTokenResponse createGenerateOnlineCvsTokenResponse() {
        return new GenerateOnlineCvsTokenResponse();
    }

    /**
     * Create an instance of {@link CancelOnlineCvsToken }
     * 
     */
    public CancelOnlineCvsToken createCancelOnlineCvsToken() {
        return new CancelOnlineCvsToken();
    }

    /**
     * Create an instance of {@link CancelOnlineCvsTokenResponse }
     * 
     */
    public CancelOnlineCvsTokenResponse createCancelOnlineCvsTokenResponse() {
        return new CancelOnlineCvsTokenResponse();
    }

}
