
package com.adj.axa.gw.bc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.example.com.axa.adj.gw.bc.integration.test.dto.gettokentechnical.GetTokenTechnicalInputDTO;


/**
 * <p>anonymous complex typeのJavaクラス。
 * 
 * <p>次のスキーマ・フラグメントは、このクラス内に含まれる予期されるコンテンツを指定します。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getTokenInput" type="{http://example.com/com/axa/adj/gw/bc/integration/test/dto/getTokenTechnical}GetTokenTechnicalInputDTO" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getTokenInput"
})
@XmlRootElement(name = "getTokenTechnical")
public class GetTokenTechnical {

    protected GetTokenTechnicalInputDTO getTokenInput;

    /**
     * getTokenInputプロパティの値を取得します。
     * 
     * @return
     *     possible object is
     *     {@link GetTokenTechnicalInputDTO }
     *     
     */
    public GetTokenTechnicalInputDTO getGetTokenInput() {
        return getTokenInput;
    }

    /**
     * getTokenInputプロパティの値を設定します。
     * 
     * @param value
     *     allowed object is
     *     {@link GetTokenTechnicalInputDTO }
     *     
     */
    public void setGetTokenInput(GetTokenTechnicalInputDTO value) {
        this.getTokenInput = value;
    }

}
