
package com.adj.axa.gw.pc;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.adj.axa.gw.pc package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.adj.axa.gw.pc
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PayWithCreditCardForSubmission }
     * 
     */
    public PayWithCreditCardForSubmission createPayWithCreditCardForSubmission() {
        return new PayWithCreditCardForSubmission();
    }

    /**
     * Create an instance of {@link PayWithCreditCardForSubmissionResponse }
     * 
     */
    public PayWithCreditCardForSubmissionResponse createPayWithCreditCardForSubmissionResponse() {
        return new PayWithCreditCardForSubmissionResponse();
    }

    /**
     * Create an instance of {@link ValidationException }
     * 
     */
    public ValidationException createValidationException() {
        return new ValidationException();
    }

    /**
     * Create an instance of {@link WsiAuthenticationException }
     * 
     */
    public WsiAuthenticationException createWsiAuthenticationException() {
        return new WsiAuthenticationException();
    }

    /**
     * Create an instance of {@link PayWithCreditCardForPolicy }
     * 
     */
    public PayWithCreditCardForPolicy createPayWithCreditCardForPolicy() {
        return new PayWithCreditCardForPolicy();
    }

    /**
     * Create an instance of {@link PayWithCreditCardForPolicyResponse }
     * 
     */
    public PayWithCreditCardForPolicyResponse createPayWithCreditCardForPolicyResponse() {
        return new PayWithCreditCardForPolicyResponse();
    }

}
