@javax.xml.bind.annotation.XmlSchema(namespace = "http://axa.adj.com/gw/pc", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.adj.axa.gw.pc;
