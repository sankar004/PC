package com.pc.screen;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class NewAccountHolder {
	public static String sheetname = "NewAccountHolder";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRNewAccountHolder() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;
	}
	
/*public Boolean selectAddress() throws Throwable{
		Boolean status = false;
		By locatorFirstSelectButton = By.xpath("//span[text()='Address' or text()= '住所']/following::tr[1]/td[1]/div/a");
		List<WebElement> SelectAddressTable = ManagerDriver.getInstance().getWebDriver().findElements(By.cssSelector("table[id='gridview-1798-record-74440']>tbody>tr>td"));
		// Select first row in Address options listed.
		if(SelectAddressTable.size()>0){
			SelectAddressTable.get(0).click();
			status = true;
		}	
		if(status){
			logger.info("Address selected successfully from Search result table");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Address should be selected from Search result table",
					"Address selected successfully from Search result table", "PASS");
		}else{
			logger.info("Address selection failed from Search result table");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Address should be selected from Search result table",
					"Address selection failed from Search result table", "FAIL");
		}
		return status;
	}*/
	
	public Boolean randomLastNamePhonetic() throws Throwable{
		Boolean status = enterRandomKanaName("edtNewAcLastNamePhonetic", "LastNamePhonetic");
		return status;
	}
	
	public Boolean randomFirstNamePhonetic() throws Throwable{
		Boolean status = enterRandomKanaName("edtNewAcFirstNamePhonetic", "First Name Phonetic");
		return status;
	}
	
	public Boolean randomLastName() throws Throwable{
		Boolean status = enterRandomKanaName("edtNewAcLastName", "Last Name");
		return status;
	}
	
	public Boolean randomFirstName() throws Throwable{
		Boolean status = enterRandomKanaName("edtNewAcFirstName", "First Name");
		return status;
	}
	
	public Boolean enterRandomKanaName(String elementlocatorName, String fieldName) throws Throwable{
		Boolean status = false;
		String kanaName = common.kanaRandomName();
		logger.info("kana Name used: " + kanaName);
		status = common.SafeAction(Common.o.getObject(elementlocatorName), kanaName, elementlocatorName);
		if(status){
			logger.info(fieldName +" entered successfully using Random function");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					fieldName +" should be entered Randomly",
					fieldName +" successfully entered Randomly", "PASS");
		}else{
			logger.info(fieldName +" failed to enter using Random function");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					fieldName +" should be entered Randomly",
					fieldName +" failed to enter Randomly", "FAIL");
		}
		return status;
	}
	
	 public static Boolean modifyPolicyHolder() throws Throwable{
         Boolean status = false;
         Common common = CommonManager.getInstance().getCommon();              
         status = common.SafeAction(Common.o.getObject("btnModify"), "Yes", "btnModify");
         status = common.SafeAction(Common.o.getObject("eleSelectModify"), "Yes", "eleSelectModify");
         if(status){
                logger.info("Vehicle & Driver & Policy Information - Policy Holder Modify option selected successfully");
                HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), 
                                 "Vehicle & Driver & Policy Information - Select Policy Holder Modify option",
                                "Vehicle & Driver & Policy Information - Policy Holder Modify option selected successfully", "PASS");
         }else{
                logger.info("In Outbound Documents screen verification Document: Not scheduled - failed");
                HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), 
                                 "Vehicle & Driver & Policy Information - Select Policy Holder Modify option",
                                "Vehicle & Driver & Policy Information - Policy Holder Modify option selection failed", "FAIL");
         }
         return status;
 }

	 public Boolean ValidateInfoMessage() throws Exception {
		 
		 String infomessage = common.ReadElement(common.o.getObject("valWarningMessage"), 30);
		 boolean status = false;
		 if(Pattern.matches("アノニマスアカウントは自動的に\\$A[0-9]{10}アカウントとマージされました", infomessage) || (Pattern.matches("The anonymous account has been automatically merged with the account A[0-9]{10}", infomessage))) 
			 {
					logger.info("System displayed information information message : " + infomessage);
					HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display information message : アノニマスアカウントは自動的に$A********アカウントとマージされました or The anonymous account has been automatically merged with the account A********","System displayed information information message : " + infomessage, "PASS");
					status = true;
				}
				else
				{
					logger.info("System not displayed information information message : " + infomessage);
					HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display information message : アノニマスアカウントは自動的に$A********アカウントとマージされました or The anonymous account has been automatically merged with the account A*********","System not displayed information message : アノニマスアカウントは自動的に$A********アカウントとマージされました  or The anonymous account has been automatically merged with the account A********* ", "FAIL");
					status = false;
				}
		 
		 
		 return true;
	 }
	 
		public Boolean EnterPhNames() throws Exception  {
			Boolean status = common.SafeAction(Common.o.getObject("edtLastNamePhonetic_PC"),  PCThreadCache.getInstance().getProperty(PCConstants.CACHE_Last_Name_Ph) , "edtLastNamePhonetic_PC");
			status = common.SafeAction(Common.o.getObject("edtFirstNamePhonetic_PC"),  PCThreadCache.getInstance().getProperty(PCConstants.CACHE_First_Name_Ph) , "edtFirstNamePhonetic_PC");
			return status;
		}
	 
	 
}
