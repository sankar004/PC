package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class SidebySideQuoting {
	
	public static String sheetname = "SidebySideQuoting";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRSidebySideQuoting() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
/*			if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("elePolicycontentsconfirmation"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Policy contents confirmation Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Policy contents confirmation Page","System displayed Policy contents confirmation Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Policy contents confirmation Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Policy contents confirmation Page","System not displayed Policy contents confirmation Page", "FAIL");
				status = false;
			}*/
			return status;
	}   
	
	public Boolean selectQuoteVersion(String quoteVersion) throws Throwable {
		Boolean status = false;
		switch (quoteVersion.trim()) {
		case "1":
			status = common.SafeAction(Common.o.getObject("btnselectQuote1"), "YES", "btnselectQuote1");
			break;
		case "2":
			status = common.SafeAction(Common.o.getObject("btnselectQuote2"), "YES", "btnselectQuote2");
			break;
		case "3":
			status = common.SafeAction(Common.o.getObject("btnselectQuote3"), "YES", "btnselectQuote3");
			break;
		default:
			status = false;
			break;

		}
		return status;
	}
	
	public Boolean changePaymentSchedule(String quoteversionAndPaymentSchedule) throws Throwable {
		Boolean status = false;
		String[] versionAndSchedule = quoteversionAndPaymentSchedule.split(":::");
		switch (versionAndSchedule[0].trim()) {
		case "1":
			status = common.SafeAction(Common.o.getObject("selPaymentScheduleV1"), versionAndSchedule[1], "selPaymentScheduleV1");
			break;
		case "2":
			status = common.SafeAction(Common.o.getObject("selPaymentScheduleV2"), versionAndSchedule[1], "selPaymentScheduleV2");
			break;
		case "3":
			status = common.SafeAction(Common.o.getObject("selPaymentScheduleV3"), versionAndSchedule[1], "selPaymentScheduleV3");
			break;
		default:
			status = false;
			break;

		}
		return status;
	}
}