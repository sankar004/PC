package com.pc.screen;

import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.pc.constants.PCConstants;
import com.pc.payment.PaymentUtil;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.FlatFile;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class Payment {
	
	public static String sheetname = "Payment";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	public String policyNumber;
	
	public Boolean SCRPayment() throws Exception
	{
		Boolean status = true;
		status = common.ClassComponent(sheetname,Common.o);
		if(!status)
		{
			return false;
		}
	/*	if(common.WaitUntilClickable(Common.o.getObject("eleForms"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System displayed Payment Page", "PASS");
			status = true;
		}
		else
		{
			logger.info("System not displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System not displayed Payment Page", "FAIL");
			status = false;
		} */
		return status;
	}   
	
	public Boolean ProcessPayment(String strFuncValue) throws Exception {
		boolean status = false;
		HashMap<String, Object> updateColumnNameValues = new HashMap<String, Object>();
		HashMap<String, Object> whereConstraint = new HashMap<String, Object>();
		HashMap<String, Object> whereConstraint_I = new HashMap<String, Object>();
		XlsxReader sXL = XlsxReader.getInstance();
		String BillingPremium = common.ReadElement(Common.o.getObject("elebillingpremiun"), 30);
		updateColumnNameValues.put(PCConstants.BILLINGPREMIUM, BillingPremium);

		String TCid = PCThreadCache.getInstance().getProperty("TCID");
		whereConstraint_I.put(PCConstants.ID, TCid);
		int indexOfIterationNo = TCid.indexOf("_I");
		Boolean itertaionTC = false;
		if (indexOfIterationNo != -1) {
			itertaionTC = true;
			TCid = TCid.substring(0, indexOfIterationNo);
		}
		logger.info("TC id to read Submission Number for Payment: " + TCid);
		whereConstraint.put(PCConstants.ID, TCid);
		// whereConstraint.put(PCConstants.ID,
		// PCThreadCache.getInstance().getProperty("TCID"));
		status = sXL.executeUpdateQuery(PCConstants.SHEET_PAYMENT, updateColumnNameValues, whereConstraint_I);
		status = sXL.executeUpdateQuery(PCConstants.SHEET_OUTPUT, updateColumnNameValues, whereConstraint);

		PaymentUtil pay = new PaymentUtil();
		/*
		 * String submissionNumber = common.Getcellvalue("Quote",
		 * "SubmissionNumber"); String totalPremium =
		 * common.Getcellvalue("Quote", "TotalPremium").replaceAll("[^0-9]",
		 * "");
		 */
		String submissionNumber = null;
		if (itertaionTC) {
			submissionNumber = common.getCellValueByTcId(PCConstants.SHEET_OUTPUT, PCConstants.SubmissionNumber);
		} else {
			submissionNumber = common.Getcellvalue(PCConstants.SHEET_OUTPUT, PCConstants.SubmissionNumber);
		}

		if (submissionNumber != null) {
			// String totalPremium =
			// common.Getcellvalue(PCConstants.SHEET_OUTPUT,
			// PCConstants.BILLINGPREMIUM).replaceAll("[^0-9]", "");
			BillingPremium = BillingPremium.replaceAll("[^0-9]", "");
			System.out.println("Submission Number ------->>>  " + submissionNumber
					+ "          <<==========>>            Premium  ------->>>  " + BillingPremium);

			switch (strFuncValue.toUpperCase()) {
			case "CC":
				common.SafeAction(Common.o.getObject("rdoCreditCard"), "Yes", "rdoCreditCard");
				// common.SafeAction(Common.o.getObject("btnMakePayment"), "Yes"
				// , "btnMakePayment");
				// common.SafeAction(Common.o.getObject("btnOkPayment"), "Yes" ,
				// "btnOkPayment");
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes", "btnSaveDraft");
				String version = common.GetcellvalueByIteration(sheetname, "Version");
				if(version.equals("")) {
					version = "01";
				}
				pay.payCreditCard(submissionNumber,version, "4111111111111111", "policyholder", BillingPremium);
				break;
			case "CVSON":
				common.SafeAction(Common.o.getObject("rdoOnlineCVS"), "Yes", "rdoOnlineCVS");
				common.SafeAction(Common.o.getObject("selCVS"), common.GetcellvalueByIteration(PCConstants.SHEET_PAYMENT, "CVS"),
						"selCVS");
				common.SafeAction(Common.o.getObject("eleGererateToken"), "Yes", "eleGererateToken");
				// if(common.WaitUntilClickable(Common.o.getObject("eleCVSToken"),
				// Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
				// {
				String CVSToken = common.ReadElement(Common.o.getObject("eleCVSToken"), 5);
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes", "btnSaveDraft");
				pay.payCvsOnline(submissionNumber, BillingPremium,
						common.ReadElement(Common.o.getObject("eleCVSToken"), 30));
				/*
				 * }
				 * ManagerDriver.getInstance().getWebDriver().findElement(Common
				 * .o.getObject("rdoOnlineCVS")).click();
				 * ManagerDriver.getInstance().getWebDriver().findElement(Common
				 * .o.getObject("rdoOnlineCVS")).click();
				 * pay.payCvsOnline(submissionNumber, totalPremium, "");
				 */
				break;
			case "CVSOFF":
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes", "btnSaveDraft");
				pay.payCvsOffline(submissionNumber, BillingPremium);
				break;
			}
			status = true;
			logger.info("Waiting for Payment to be updated in PC");
			Thread.sleep(15000);
		} else {
			status = false;
			logger.info("Submission number is empty. Unable to process payment");
		}
		return status;
	}
	
	
	public Boolean SelectPayment(String strFuncValue) throws Exception
	{	
		boolean status;
				
		Boolean blnStatus = false;
		blnStatus = true;
		switch(strFuncValue.toUpperCase())
		{
			case"CC":
				common.SafeAction(Common.o.getObject("rdoCreditCard"), "Yes" , "rdoCreditCard");
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes" , "btnSaveDraft");
				blnStatus = true;
				break;
			case"CVSON":
				common.SafeAction(Common.o.getObject("rdoOnlineCVS"), "Yes" , "rdoOnlineCVS");
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes" , "btnSaveDraft");
				blnStatus = true;
				break;
			case"CVSOFF":
				common.SafeAction(Common.o.getObject("rdoOfflineCVS"), "Yes" , "rdoOfflineCVS");
				common.SafeAction(Common.o.getObject("btnSaveDraft"), "Yes" , "btnSaveDraft");
				blnStatus = true;
				break;
		}
		return blnStatus;
	}
	
	public Boolean VerifyPayment() throws Exception
	{		
		Boolean blnStatus = false;
		int count = 0;
		while(!blnStatus && count <= 30){
			String paidamount;
			common.WaitUntilClickable(Common.o.getObject("elePaymentTab"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));	
			common.SafeAction(Common.o.getObject("elePaymentTab"), "YES", "elePaymentTab");
			paidamount = common.ReadElement(Common.o.getObject("elePremiumalreadyreceived"), 30);
			if((!paidamount.equals("-")) && ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("btnBindOptionsenabled")).isDisplayed()) {
				blnStatus = true; 
			}else {
				common.WaitUntilClickable(Common.o.getObject("eleQuotetab"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));	
				common.SafeAction(Common.o.getObject("eleQuotetab"), "YES", "eleQuotetab");
				Thread.sleep(1000);
				count++;
			}			
		}
		
		return blnStatus;
	}
	
	public Boolean verifyPaymentReceived() throws Exception
	{	
		// Confirm payment information updated in Payment screen. Refresh the payment page by switching to Quote tab.		
		Boolean isPaymentReceived = false;
		int count = 0;
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		while(!isPaymentReceived && count <= 30){
			String paidamount;
			common.WaitUntilClickable(Common.o.getObject("elePaymentTab"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));	
			common.SafeAction(Common.o.getObject("elePaymentTab"), "YES", "elePaymentTab");
			paidamount = common.ReadElement(Common.o.getObject("elePremiumalreadyreceived"), 30);
			if((!paidamount.equals("-"))) {
				isPaymentReceived = true; 
			}else {
				Thread.sleep(1000);
				common.WaitUntilClickable(Common.o.getObject("eleQuotetab"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")));	
				common.SafeAction(Common.o.getObject("eleQuotetab"), "YES", "eleQuotetab");
				count++;
			}			
		}
		
		return isPaymentReceived;
	}
	
	public Boolean GetPolicyNumber() throws Exception{
		HashMap<String,Object> updateColumnNameValues = new HashMap<String,Object>();
		HashMap<String,Object> whereConstraint = new HashMap<String,Object>();
		try{
			Boolean status = true;
			if(common.WaitUntilClickable(Common.o.getObject("elePolicyNumber"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				XlsxReader sXL = XlsxReader.getInstance();
				policyNumber = common.ReadElement(Common.o.getObject("elePolicyNumber"), 30);
				PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, policyNumber);
				updateColumnNameValues.put(PCConstants.PolicyNumber, policyNumber);
				whereConstraint.put(PCConstants.ID, PCThreadCache.getInstance().getProperty("TCID"));
				status = sXL.executeUpdateQuery(PCConstants.SHEET_PAYMENT, updateColumnNameValues, whereConstraint);
				status = sXL.executeUpdateQuery(PCConstants.SHEET_OUTPUT, updateColumnNameValues, whereConstraint);
				logger.info("System displayed Policy Summary Page with Policy Number: " + policyNumber);  
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Policy Summary Page with Policy Number","System displayed Policy Summary Page with Policy Number: '" + policyNumber + "'", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Policy Summary Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Policy Summary Page with Policy Number","System not displayed Policy Summary Page", "FAIL");
				status = false;
			}
			return status;
		}finally
		{
			updateColumnNameValues = null;
			whereConstraint = null;
		}
		
	}
	
	
}