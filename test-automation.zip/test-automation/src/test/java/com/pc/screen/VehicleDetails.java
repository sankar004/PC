package com.pc.screen;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class VehicleDetails {
	public static String sheetname = "VehicleDetails";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRVehicleDetails() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }

	public Boolean selectMileage(String mileage) throws Throwable {
		Boolean status = false;
		String elementName = "btnMileage";
		//status = selectImage(mileage, elementName);
		status = common.selectFromListByTextValue(common.o.getObject(elementName), mileage);
		if(status){
			logger.info("Mileage selected successfully for the value :" + mileage);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Mileage should be selected as " + mileage,
					"Mileage successfully selected as " + mileage, "PASS");
		}else {
			logger.info("Mileage selection failed for the value :" + mileage);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Mileage should be selected as " + mileage,
					"Mileage selection failed for the value " + mileage, "FAIL");
		}
		return status;
	}

	public Boolean selectUsage(String usage) throws Throwable {
		Boolean status = false;
		String elementName = "btnUsageOfCar";
		status = selectImage(usage, elementName);
		return status;
	}

	private Boolean selectImage(String value, String elementName) throws Throwable {
		By ImageElement = By.xpath("//img[contains(@alt,\'" + value + "\')]");
		return common.SafeAction(ImageElement, "YES", elementName);
	}
	
	
	public Boolean selectBikeEngineSize(String engineSize) throws Throwable{
		Boolean status = false;
		By engineSizeOption = By.xpath("//input[@name='displacement']/following-sibling::p[text()='" + engineSize +"']");
		status = common.SafeAction(engineSizeOption, "YES", "eleEngineSizeOption");		
		return status;
	}

	public Boolean clickNextToDriverInfo(String value) {
		// Dynamic to handle Language
		common.clickButtonByText(value);
		return true;
	}

}
