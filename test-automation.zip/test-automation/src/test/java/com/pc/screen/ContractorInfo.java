package com.pc.screen;

import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.ManagerDriver;

public class ContractorInfo {
	public static String sheetname =  "ContractorInfo";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRContractorInfo() throws Exception
	{
			Boolean status = false;
			status = common.ClassComponent(sheetname,Common.o);
			return status;
	} 
	
	
	public Boolean VerifyConfirmationMsg(String text) throws Exception{
/*		System.out.println(ManagerDriver.getInstance().getWebDriver().findElement(By.xpath("//div[@class='adjEstModalBox__box']/p[2]")).getText());
		System.out.println(ManagerDriver.getInstance().getWebDriver().findElement(By.xpath("//div[@class='adjEstModalBox__box']/p[3]")).getText());
		System.out.println(ManagerDriver.getInstance().getWebDriver().findElement(By.xpath("//div[@class='adjEstModalBox__box']/p[3]/following-sibling::button")).getText());*/
		Thread.sleep(4000);
		return true;
	}
	
	public Boolean enterPhoneticLastName() throws Throwable{
		Boolean status = false;
		String kanaName = common.kanaRandomName();
		logger.info("kana Name used: " + kanaName);
		status = common.SafeAction(Common.o.getObject("edtPhoneticLastName"), kanaName, "edtPhoneticLastName");
		if(!status){
			logger.info("Unable to enter Random Kana Name for PhoneticLastName");
		}
		return status;
	}
	
	public Boolean enterPhoneticFirstName() throws Throwable{
		Boolean status = false;
		String kanaName = common.kanaRandomName();
		logger.info("kana Name used: " + kanaName);
		status = common.SafeAction(Common.o.getObject("edtPhoneticFirstName"), kanaName, "edtPhoneticFirstName");
		if(!status){
			logger.info("Unable to enter Random Kana Name PhoneticFirstName");
		}
		return status;
	}
	
	public Boolean useRandomEmailForTest() throws Throwable{
		Boolean status = false;
		String email = "testAXAportalauto" + getRandomString() + "@hexaware.com";
		logger.info("email used: " + email);
		status = common.SafeAction(Common.o.getObject("edtEmail"), email, "edtEmail");
		if(!status){
			logger.info("Unable to enter Random Email");
		}
		return status;
	}
		
	private String getRandomString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 8) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }	
}
