package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class SearchPortalSubmission {
	
	public static String sheetname = "SearchPortalSubmission";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRSearchPortalSubmission() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			if(!status)
			{
				return false;
			}
			return status;
	}
	
	
	public Boolean SearchSubmission() throws Exception
	{		
		Boolean blnStatus = false;
		common.SafeAction(Common.o.getObject("melPolicy"), "Yes" , "melPolicy");
		common.SafeAction(Common.o.getObject("edtSerachsubNumber"),  common.Getcellvalue("PortalOutput", "SubmissionNumber"), "edtSerachsubNumber");
		common.SafeAction(Common.o.getObject("eleSearchPolicyicon"), "Yes" , "eleSearchPolicyicon");
		
		if(common.WaitUntilClickable(Common.o.getObject("elePaymenttitle"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System displayed Payment Page", "PASS");
			blnStatus = true;
		}
		else
		{
			logger.info("System not displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System not displayed Payment Page", "FAIL");
			blnStatus = false;
		}
		return blnStatus;
	}
	
}