/**
 * 
 */
package com.pc.screen;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

/**
 * @author X.Durairaj Portal Q & B - Screen to enter Information about insurance
 *         currently under contract when opting for Switch from other insurer /
 *         New purchase with having previous contract with in 13 month
 */
public class CurrentInsuranceInfo {
	public static String sheetname = "CurrentInsuranceInfo";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRCurrentInsuranceInfo() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }

	public Boolean selectInsuranceCompany(String companyName) throws Throwable {
		Boolean status = false;
		By locator = By.cssSelector("input[name='maker']+span");
		status = selectFromListByTextValue(locator, companyName );
		/*WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		List<WebElement> companyNameElements= driver.findElements(By.xpath("//input[@name='maker']/following-sibling::span"));
		for(WebElement element : companyNameElements){
			if(element.getText().equalsIgnoreCase(companyName)){
				element.click();
				status = true;
				logger.info("Insurance Company Name " + companyName + " selectecd succeffully");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Insurance Company Name " + companyName + " should be selectecd succeffully","Insurance Company Name " + companyName + " selectecd succeffully", "PASS");
				break;
			}
		}*/
		
		if(status){
			logger.info("Insurance Company Name " + companyName + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Insurance Company Name " + companyName + " should be selectecd succeffully","Insurance Company Name " + companyName + " selectecd succeffully", "PASS");
		}else{
			logger.info("Insurance Company Name " + companyName + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Insurance Company Name " + companyName + " should be selectecd succeffully","Insurance Company Name " + companyName + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}
	
	
	public Boolean selectNumberOfAccidents(String numOfAccident) throws Throwable{
		Boolean status = false;
		By locator = By.cssSelector("input[ng-model='vehicle.numberOfClaims_Adj.value'] + span");
		status = selectFromListByTextValue(locator, numOfAccident );
		if(status){
			logger.info("Number of Accidents " + numOfAccident + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Number of Accidents " + numOfAccident + " should be selectecd succeffully","Number of Accidents " + numOfAccident + " selectecd succeffully", "PASS");
		}else{
			logger.info("Number of Accidents " + numOfAccident + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Number of Accidents " + numOfAccident + " should be selectecd succeffully","Number of Accidents " + numOfAccident + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}

	
	public Boolean selectInsuranceAttached(String InsuranceAttached) throws Throwable{
		Boolean status = false;
		By locator = By.cssSelector("input[ng-model='vehicle.ownDamage_Adj.value'] + span");
		status = selectFromListByTextValue(locator, InsuranceAttached );
		if(status){
			logger.info("Vehichle Insurance Attached option " + InsuranceAttached + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Vehichle Insurance Attached option " + InsuranceAttached + " should be selectecd succeffully","Vehichle Insurance Attached option " + InsuranceAttached + " selectecd succeffully", "PASS");
		}else{
			logger.info("Vehichle Insurance Attached option " + InsuranceAttached + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Vehichle Insurance Attached option " + InsuranceAttached + " should be selectecd succeffully","Vehichle Insurance Attached option " + InsuranceAttached + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}
	// This function can be moved to common
	private Boolean selectFromListByTextValue(By locator, String textValue ){
		Boolean status = false;
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		List<WebElement> Elements= driver.findElements(locator);
		for(WebElement element : Elements){
			if(element.getText().equalsIgnoreCase(textValue)){
				element.click();
				status = true;
				break;
			}
		}
		return status;
	}
	

}
