package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class NewSubmission {
	
	public static String sheetname =  "NewSubmission";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRNewSubmission() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleQualificationquestions"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Qualification questions Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Qualification questions Page","System displayed Qualification questions Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Qualification questions Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Qualification questions Page","System not displayed Qualification questions Page", "FAIL");
				status = false;
			}
			return status;
	}   
	
	
	public Boolean OpenExistingAccount(String value) throws Exception
	{		
		Boolean blnStatus = false;
		common.SafeAction(Common.o.getObject("melACCOUNT"), "Yes" , "melACCOUNT");
		common.SafeAction(Common.o.getObject("edtSerachAccountNumber"),  value, "edtSerachAccountNumber");
		common.SafeAction(Common.o.getObject("eleSearchAccounticon"), "Yes" , "eleSearchAccounticon");
		
		if(common.WaitUntilClickable(Common.o.getObject("eleCreateNewAccountNumber"),  Integer.valueOf(HTML.properties.getProperty("NORMALWAIT"))) && value.equals(common.ReadElement(Common.o.getObject("eleCreateNewAccountNumber"), Integer.valueOf(HTML.properties.getProperty("NORMALWAIT")))))
		{
			logger.info("System displayed Account Summary Page with Account Number : " + value );
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Account Summary Page with the Account Number: '"+ value + "'","System displayed  Account Summary Page with the Account Number: '"+ value + "'", "PASS");
			blnStatus = true;
		}
		else
		{
			logger.info("Account Number : '" + value + "' is not avilable in the Policy Center");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"),  "System should display Account Summary Page with the Account Number: '"+ value + "'","Account Number : '" + value + "' is not avilable in the Policy Center", "FAIL");
			blnStatus = false;
		}
		return blnStatus;
	}
	public Boolean selectAccountByPhone(String phoneNumber) throws Throwable {
		Boolean status = false;
		//common.SafeAction(Common.o.getObject("melSearch"), "Yes", "melSearch");
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		//driver.findElement(Common.o.getObject("eleSearchMenu")).click();
		common.SafeAction(Common.o.getObject("eleSearchMenu"), "Yes", "eleSearchMenu");
		common.SafeAction(Common.o.getObject("eleAccounts"), "Yes", "eleAccounts");
		common.SafeAction(Common.o.getObject("edtPhone"), phoneNumber, "edtPhone");
		//driver.findElement(Common.o.getObject("edtPhone")).sendKeys("'09011112323");
		common.SafeAction(Common.o.getObject("btnAccountSearch"), "Yes", "btnAccountSearch");
		try {
			status = common.SafeAction(Common.o.getObject("eleFirstAccountNumber"), "Yes", "eleFirstAccountNumber");
		} catch (NoSuchElementException e) {
			logger.info("Phone Number : " + phoneNumber + " not accociated with any Account.");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Select Account associated with Phone Number : " + phoneNumber,
					"Phone Number : " + phoneNumber + " not accociated with any Account.", "FAIL");
			status = false;
		}
		if (status) {
			logger.info("Selected Account number mapped with Phone Number : " + phoneNumber);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Select Account associated with Phone Number : " + phoneNumber,
					"Selected Account number mapped with Phone Number : " + phoneNumber, "PASS");
			status = true;
		} else {
			logger.info("Phone Number : " + phoneNumber + " not accociated with any Account.");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Select Account associated with Phone Number : " + phoneNumber,
					"Phone Number : " + phoneNumber + " not accociated with any Account.", "FAIL");
			status = false;
		}
		return status;
	}
}