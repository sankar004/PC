/*package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class SearchAccountBC {
	
	public static String sheetname = "SearchAccountBC";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRSearchAccountBC() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			return status;
	}   
	
	public Boolean SearchAccount() throws Exception
	{		
		Boolean blnStatus = false;
		logger.info("Waiting for policy to reflect in BC");
		Thread.sleep(30000);
		String accountNumber = common.Getcellvalue("Ouput", "AccountNumber");	
		common.SafeAction(Common.o.getObject("eleAccountstabbc"), "Yes", "eleAccountstabbc");
		common.SafeAction(Common.o.getObject("edtAccountNumberbc"), accountNumber , "edtAccountNumberbc");
		common.SafeAction(Common.o.getObject("btnSearchbc"), "Yes", "btnSearchbc");
		if(common.WaitUntilClickable(Common.o.getObject("eleAccountNumberbc"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
		common.SafeAction(Common.o.getObject("eleAccountNumberbc"), "Yes", "eleAccountNumberbc");	
		}	
		return true;
	}
	
}*/

package com.pc.screen;

import java.sql.DriverManager;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class SearchAccountBC {
              
              public static String sheetname = "SearchAccountBC";
              static Logger logger =Logger.getLogger(sheetname);
              Common common = CommonManager.getInstance().getCommon();
              
              public Boolean SCRSearchAccountBC() throws Exception
              {
                                          Boolean status = true;
                                          status = common.ClassComponent(sheetname,Common.o);
                                          return status;
              }   
              
              public Boolean SearchAccount() throws Exception
              {                           
                            Boolean blnStatus = false;
                            logger.info("Waiting for policy to reflect in BC");
                            Thread.sleep(30000);
                            String accountNumber = common.Getcellvalue(PCConstants.SHEET_OUTPUT, "AccountNumber");
                            String accountName = common.Getcellvalue(PCConstants.SHEET_OUTPUT, "AccountName");
                            //String primaryContact = common.Getcellvalue("Ouput", "PrimaryContact");
                            //String address = common.Getcellvalue("Ouput", "Address");
                            //String phone = common.Getcellvalue("Ouput", "Phone");
                            //String delequencies = common.Getcellvalue("Ouput", "Delequencies");
                            //String lateFees = common.Getcellvalue("Ouput", "Latefees");
                            common.SafeAction(Common.o.getObject("eleAccountstabbc"), "Yes", "eleAccountstabbc"); //Clicking on the tab
                            common.SafeAction(Common.o.getObject("edtAccountNumberbc"), accountNumber , "edtAccountNumberbc"); //Entering account number
                            common.SafeAction(Common.o.getObject("btnSearchbc"), "Yes", "btnSearchbc"); //search button
                            if(common.WaitUntilClickable(Common.o.getObject("eleAccountNumberbc"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
                            {
                            common.SafeAction(Common.o.getObject("eleAccountNumberbc"), "Yes", "eleAccountNumberbc");//Account number link
                            blnStatus = true;
                            }             
                            common.SafeAction(Common.o.getObject("valAccountName"), accountName, "valAccountName"); //Account name verification
                            //common.SafeAction(Common.o.getObject("valPrimaryContact"), primaryContact, "valPrimaryContact"); //Primary Contact verification
                            //common.SafeAction(Common.o.getObject("valAddress"), address, "valAddress"); //Address verification
                            //common.SafeAction(Common.o.getObject("valPhone"), phone, "valPhone"); //Phone verification
                            //common.SafeAction(Common.o.getObject("valDelequencies"), delequencies, "valDelequencies"); //Delequencies verification
                            //common.SafeAction(Common.o.getObject("valLateFees"), lateFees, "valLateFees"); //LateFees verification
                            return blnStatus;
                                                        
              }
                            
                            public Boolean ValidateBillingPremium() throws Exception
                            {                           
                                          Boolean blnStatus = false;
                                          
                                          String BillingPremium = common.Getcellvalue(PCConstants.SHEET_OUTPUT, "BillingPremium");
                                          String BillingPremiumUpdate = common.ReadElement(Common.o.getObject("eleLastPayment"), 30);
                                          if(BillingPremium.replaceAll("[^0-9]", "").equals(BillingPremiumUpdate.replaceAll("[^0-9]", ""))) {
                                                        
                                                        logger.info("BillingPremium is updated  as : " + BillingPremium);
                                                        HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Last Payment Received should be updated  as : " + BillingPremium,"Last Payment Received is updated  as : " + BillingPremiumUpdate, "PASS");
                                                        blnStatus = true;
                                          }
                                          else
                                          {
                                                        logger.info("BillingPremium is not updated  as : " + BillingPremium);
                                                        HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Last Payment Received should be updated  as : " + BillingPremium,"Last Payment Received is updated  as : " + BillingPremiumUpdate, "PASS");
                                                        blnStatus = true;
                                          }
                            
                                          return blnStatus;
                            }
}
