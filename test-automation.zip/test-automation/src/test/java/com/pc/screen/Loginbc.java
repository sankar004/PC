/*package com.pc.screen;


import org.apache.log4j.Logger;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Loginbc{
	
	public static String sheetname = "Loginbc";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	String sURL = "";
	public Boolean SCRLoginbc() throws Exception
	{		
		sURL = HTML.properties.getProperty(HTML.properties.getProperty("Region") + "BC") + "/bc/BillingCenter.do";
		Boolean s = common.NavigateApp(sURL);
		if(!s)
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "PASS");
			return false;
		}
		Boolean status = true;
		if(HTML.properties.getProperty("EXECUTIONAPP").contains("ODS"))
		{
			status = common.CSVFile();
		}
		status = common.ClassComponent(sheetname,Common.o);
		if(!status)
		{
			return status;
		}
		if(common.WaitUntilClickable(Common.o.getObject("eleAccountstabbc"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("Application Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application loggedin successfully", "PASS");
			//status=SCRCommon.funGetUserLoggedName();
			status = true;
		}
		else
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "FAIL");
			status = false;
		}
		return status;
	}
	
	
}*/

package com.pc.screen;


import org.apache.log4j.Logger;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Loginbc{
              
              public static String sheetname = "Loginbc";
              static Logger logger =Logger.getLogger(sheetname);
              Common common = CommonManager.getInstance().getCommon();
              String sURL = "";
              Boolean status;
              public Boolean SCRLoginbc() throws Exception
              {                           
                            status = common.ClassComponent(sheetname,Common.o);
                            
                            if(common.WaitUntilClickable(Common.o.getObject("eleAccountstabbc"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
                            {
                                          logger.info("Application Loggedin Successfully");
                                          HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application loggedin successfully", "PASS");
                                          //status=SCRCommon.funGetUserLoggedName();
                                          status = true;
                            }
                            else
                            {
                                          logger.info("Application not Loggedin Successfully");
                                          HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "FAIL");
                                          status = false;
                            }
                            return status;
              }
              
              public boolean NavigateBC() throws Exception{                            

                            sURL = HTML.properties.getProperty(HTML.properties.getProperty("Region") + "BC") + "/bc/BillingCenter.do";
   
							 
   
                            Boolean status = common.NavigateApp(sURL);
                            if(!status)
   
				 
   
																																	  
                            {
                                          logger.info("Application not Loggedin Successfully");
                                          HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "PASS");
                                          return false;
                            }
                            return status;
              }
              
              public boolean OpenBC() throws Exception{                   

                            sURL = HTML.properties.getProperty(HTML.properties.getProperty("Region") + "BC") + "/bc/BillingCenter.do";
                            Boolean status = common.OpenApp(sURL);
                            if(!status)
	  
                            {
                                          logger.info("Application not Loggedin Successfully");
                                          HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "PASS");
                                          return false;
                            }

                            return status;
              }
              
 
}
