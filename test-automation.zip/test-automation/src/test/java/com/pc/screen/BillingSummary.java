package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class BillingSummary {
	
	public static String sheetname = "BillingSummary";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRBillingSummary() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			return status;
	}   
	
	public Boolean ValidateSummaryScreen() throws Exception
	{		
		Boolean blnStatus = false;
		 
		String Payment = common.Getcellvalue(PCConstants.SHEET_OUTPUT, PCConstants.BILLINGPREMIUM);	
		String LastPayment = common.ReadElement(Common.o.getObject("eleLastPayment"), 30);
		if(Payment.replaceAll("[^0-9]", "").equals(LastPayment.replaceAll("[^0-9]", ""))) {
			
			logger.info("Last Payment Received is updated  as : " + Payment);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Last Payment Received should be updated  as : " + Payment,"Last Payment Received is updated  as : " + LastPayment, "PASS");
			blnStatus = true;
		}
		else
		{
			logger.info("Last Payment Received is not updated  as : " + Payment);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Last Payment Received should be updated  as : " + Payment,"Last Payment Received is updated  as : " + LastPayment, "Fail");
			blnStatus = false;
		}
	
		return blnStatus;
	}
	
}