/**
 * 
 */
package com.pc.screen;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.PCThreadCache;

/**
 * @author X.Durairaj
 * Portal QB - Interruption Certificate Info screen
 *
 */
public class InterruptionCertificateInfo {
	public static String sheetname = "InterruptionCertificateInfo";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRInterruptionCertificateInfo() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

	 }
	
	public Boolean selectReason(String reason) throws Throwable{
		Boolean status = false;
		By reasonLocator = By.cssSelector("input[name='reason'] + p");
		status = common.selectFromListByTextValue(reasonLocator, reason);		
		if(status){
			logger.info("Reason for issuing Interruption Certificate " + reason + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Reason for issuing Interruption Certificate " + reason + " should be selectecd succeffully","Reason for issuing Interruption Certificate " + reason + " selectecd succeffully", "PASS");
		}else{
			logger.info("Reason for issuing Interruption Certificate " + reason + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Reason for issuing Interruption Certificate " + reason + " should be selectecd succeffully","Reason for issuing Interruption Certificate " + reason + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}
	
	public Boolean selectInsuranceCompany(String companyName) throws Throwable {
		Boolean status = false;
		By locator = By.cssSelector("input[name='maker']+span");
		status =  common.selectFromListByTextValue(locator, companyName );
		if(status){
			logger.info("Insurance Company Name " + companyName + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Insurance Company Name " + companyName + " should be selectecd succeffully","Insurance Company Name " + companyName + " selectecd succeffully", "PASS");
		}else{
			logger.info("Insurance Company Name " + companyName + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Insurance Company Name " + companyName + " should be selectecd succeffully","Insurance Company Name " + companyName + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}
	
	public Boolean selectNumberOfAccidents(String numOfAccidents) throws Throwable {
		Boolean status = false;
		By locator = By.cssSelector("input[ng-model='vehicle.numberOfClaims_Adj.value'] + span");
		status =  common.selectFromListByTextValue(locator, numOfAccidents );
		if(status){
			logger.info("Number of accidents " + numOfAccidents + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Number of accidents " + numOfAccidents + " should be selectecd succeffully","Insurance Company Name " + numOfAccidents + " selectecd succeffully", "PASS");
		}else{
			logger.info("Number of accidents " + numOfAccidents + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Number of accidents " + numOfAccidents + " should be selectecd succeffully","Insurance Company Name " + numOfAccidents + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}

	public Boolean selectInsuranceAttached(String InsuranceAttached) throws Throwable{
		Boolean status = false;
		By locator = By.cssSelector("input[ng-model='vehicle.ownDamage_Adj.value'] + span");
		status =  common.selectFromListByTextValue(locator, InsuranceAttached );
		if(status){
			logger.info("Vehichle Insurance Attached option " + InsuranceAttached + " selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Vehichle Insurance Attached option " + InsuranceAttached + " should be selectecd succeffully","Vehichle Insurance Attached option " + InsuranceAttached + " selectecd succeffully", "PASS");
		}else{
			logger.info("Vehichle Insurance Attached option " + InsuranceAttached + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Vehichle Insurance Attached option " + InsuranceAttached + " should be selectecd succeffully","Vehichle Insurance Attached option " + InsuranceAttached + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}

}
