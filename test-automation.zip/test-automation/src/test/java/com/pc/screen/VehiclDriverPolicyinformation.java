package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class VehiclDriverPolicyinformation {
	
	public static String sheetname = "VehiclDriverPolicyinformation";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRVehiclDriverPolicyinformation() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			/*if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleCoveragesectionquoteresult"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Coverage section & quote result Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Coverage section & quote result Page","System displayed Coverage section & quote result Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Coverage section & quote result Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Coverage section & quote result Page","System not displayed Coverage section & quote result Page", "FAIL");
				status = false;
			}*/
			return status;
	}   
	
	public Boolean EnterLicensePlateBike1(String value) throws Exception
	{		
		Boolean blnStatus = false;
		String[] sValue = value.split(":::");
		try {
			common.SafeAction(Common.o.getObject("selLicensePlate1"), sValue[0] , "selLicensePlate1");
		}catch(Exception e) {
			System.out.println(e);
			common.SafeAction(Common.o.getObject("selLicensePlate1"), sValue[0] , "selLicensePlate1");
		}
		
		Thread.sleep(1000);
		if(!ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleLicensePlate2")).isEnabled()) {
			ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("selLicensePlate1")).sendKeys(Keys.TAB);
		}
		if(common.WaitUntilClickable((By.xpath("//*[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body']//tr[1]//td[2]//div")),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		ManagerDriver.getInstance().getWebDriver().findElement(By.xpath("//*[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body']//tr[1]//td[2]//div")).click();
		ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleLicensePlate2")).click();
		common.SafeAction(Common.o.getObject("edtLicensePlate2"), sValue[1] , "edtLicensePlate2");
		common.SafeAction(Common.o.getObject("edtLicensePlatebike3"), sValue[2] , "edtLicensePlatebike3");	
		}
		//blnStatus = SCRCommon.ActionOnTableForICON(Common.o.getObject("eleAccountSummary_PolicyTermsTbl"), 1, 1, strFuncValue, "a");
		return true;
	}
	
	public Boolean EnterLicensePlate(String value) throws Exception
	{		
		
		Boolean blnStatus = false;
		String[] sValue = value.split(":::");
		JavascriptExecutor js = (JavascriptExecutor) ManagerDriver.getInstance().getWebDriver();
		String InsuranceType = common.ReadElement(common.o.getObject("lstInsuranceType"), 30);		
		if(InsuranceType.equals("")) {		
			InsuranceType = common.ReadElementFromListEditBox(common.o.getObject("lstInsuranceType"), 30);
		}
		
		
		//InsuranceType = common.ReadElementFromListEditBox(bylocator, iWaitTime)
		if(InsuranceType.equals("Auto") || InsuranceType.equals("自動車")) {	
		
		common.SafeAction(Common.o.getObject("selLicensePlate1"), sValue[0] , "selLicensePlate1");
		//Thread.sleep(1000);
		SCRCommon.JavaScript(js);
		common.SafeAction(Common.o.getObject("eleVehiclDriverPolicyinformation"), "YES" , "eleVehiclDriverPolicyinformation");
		//ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleVehiclDriverPolicyinformation")).click();
		SCRCommon.JavaScript(js);
		//ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleLicensePlate2")).click();
		common.SafeAction(Common.o.getObject("eleLicensePlate2"), "YES" , "eleLicensePlate2");
		SCRCommon.JavaScript(js);
		common.SafeAction(Common.o.getObject("edtLicensePlate2"), sValue[1] , "edg");
		common.SafeAction(Common.o.getObject("edtLicensePlate3"), sValue[2] , "edg");
		common.SafeAction(Common.o.getObject("edtLicensePlate4"), sValue[3] , "edg");
		blnStatus = true;
		}else if(InsuranceType.equals("Bike") || InsuranceType.equals("バイク")) {
			String VehicleType = common.ReadElement(common.o.getObject("eleVehicleType"), 30);
			if(VehicleType.equals("Moped") || VehicleType.equals("原付")){	
			ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleLicensePlateMoped1")).click();
			//common.SafeAction(Common.o.getObject("edtLicensePlateMoped1"), sValue[0] , "edtLicensePlateMoped1");
			common.SafeAction(Common.o.getObject("edtLicensePlateMoped1"), sValue[0] , "edg");
			//common.SafeAction(Common.o.getObject("edtLicensePlateMoped2"), sValue[1] , "edtLicensePlateMoped2");
			common.SafeAction(Common.o.getObject("edtLicensePlateMoped2"), sValue[1] , "edg");
			common.SafeAction(Common.o.getObject("edtLicensePlateMoped3"), sValue[2] , "edg");
			common.SafeAction(Common.o.getObject("edtLicensePlateMoped4"), sValue[3] , "edg");
			blnStatus = true;
			}else if (VehicleType.equals("Bike (A:~250cc)") || VehicleType.equals("軽二輪（バイクA）")){
				
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleBikeALicensePlate1")).click();
				common.SafeAction(Common.o.getObject("edtBikeALicensePlate1"), sValue[0] , "edg");
				common.SafeAction(Common.o.getObject("selBikeALicensePlate2"), sValue[1] , "selBikeALicensePlate2");
				Thread.sleep(1000);
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleVehiclDriverPolicyinformation")).click();
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleBikeALicensePlate3")).click();
				common.SafeAction(Common.o.getObject("edtBikeALicensePlate3"), sValue[2] , "edg");
				common.SafeAction(Common.o.getObject("edtBikeALicensePlate4"), sValue[3] , "edg");
                blnStatus = true;

			}else if (VehicleType.equals("Bike (B:251~cc)") || VehicleType.equals("小型二輪（バイクB）")){
				common.SafeAction(Common.o.getObject("selLicensePlate1"), sValue[0] , "selLicensePlate1");
				//Thread.sleep(1000);
				SCRCommon.JavaScript(js);
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleVehiclDriverPolicyinformation")).click();
				SCRCommon.JavaScript(js);
				ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleLicensePlate2")).click();
				common.SafeAction(Common.o.getObject("edtLicensePlate3"), sValue[1] , "edg");
				common.SafeAction(Common.o.getObject("edtLicensePlate4"), sValue[2] , "edg");	
				blnStatus = true;
			}
			
		}
		return blnStatus;
	}
	
	public Boolean ModelCode(String value) throws Exception{
		
		Boolean Status = false;		
		Status =common.SafeAction(Common.o.getObject("edtModelCode"), value , "edtModelCode");
		Status = common.SafeAction(Common.o.getObject("eleModleCodeSearch"), "Yes" , "eleModleCodeSearch");
		By btnSelectModel = By.xpath("//*[text()='" + value +"']/ancestor::td[1]/preceding-sibling::td/div/a");
		Status = common.SafeAction(btnSelectModel, "Yes" , "btnSelectModel");		
		return Status;		
	}
	
	public Boolean VehicleOwner(String value) throws Exception{
		
		Boolean Status = false;		
		Status =common.SafeAction(Common.o.getObject("selVehicleOwner"), value , "selVehicleOwner");
		if(value.equals("ディーラー/ローン業者/リース会社")) {
			Status =common.SafeAction(Common.o.getObject("selVehicleUser"), common.Getcellvalue(sheetname, "VehicleUser") , "selVehicleUser");				
		}
		if(value.equals("契約者またはその配偶者の親族") || value.equals("ディーラー/ローン業者/リース会社") || value.equals("契約者の配偶者") || value.equals("記名被保険者の配偶者")) {
			Status =common.SafeAction(Common.o.getObject("edtFamilyname(Character)"), common.kanaRandomName() , "edtFamilyname(Character)");
			Status =common.SafeAction(Common.o.getObject("edt1stName(Character)"), common.kanaRandomName() , "edt1stName(Character)");
			Status =common.SafeAction(Common.o.getObject("edtFamilynameinKanji"), common.kanaRandomName() , "edtFamilynameinKanji");
			Status =common.SafeAction(Common.o.getObject("edt1stnameinKanji"), common.kanaRandomName() , "edt1stnameinKanji");	
		}
		return Status;		
	}
	
	public Boolean SideCarattached() throws Exception{
		boolean status = common.SafeAction(Common.o.getObject("chkSideCarattached"), "YES" , "chkSideCarattached");
		JavascriptExecutor js = (JavascriptExecutor) ManagerDriver.getInstance().getWebDriver();
		String VehicleType = common.ReadElement(common.o.getObject("eleVehicleType"), 30);	
		System.out.println(VehicleType);
		while(!VehicleType.equals("軽二輪（バイクA）")){
			ManagerDriver.getInstance().getWebDriver().findElement(Common.o.getObject("eleVehiclDriverPolicyinformation")).click();
			boolean returnValue = SCRCommon.JavaScript(js);
			VehicleType = common.ReadElement(common.o.getObject("eleVehicleType"), 30);				
		}	
		return status;
		}	

}