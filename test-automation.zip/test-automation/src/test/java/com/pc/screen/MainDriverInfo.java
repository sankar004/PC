package com.pc.screen;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.ManagerDriver;

public class MainDriverInfo {

	public static String sheetname = "MainDriverInfo";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRMainDriverInfo() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;
 }

	public Boolean selectColorOfLicense(String color) throws Exception {
		selectImage(color);
		Thread.sleep(3000);
		return true;
	}

	private void selectImage(String value) {
		ManagerDriver.getInstance().getWebDriver().findElement(By.xpath("//img[contains(@alt,\'" + value + "\')]"))
				.click();

	}
	
/*	public Boolean clickLimitDriving(String option){
		// Dynamic to handle Language
		common.clickButtonByText(option);
		return true;
	}*/
	
	public Boolean clickNextToQuote(String option) throws Throwable{
		// Dynamic to handle Language
		common.clickButtonByText(option);
		By element = By.xpath("//*[text() = '" + option + "']");
		common.SafeAction(element, "NextToQuote", "ele");
		return true;
	}
}
