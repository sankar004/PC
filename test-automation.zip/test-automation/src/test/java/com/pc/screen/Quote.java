package com.pc.screen;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.FlatFile;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class Quote {
	
	public static String sheetname = "Quote";
	static Logger logger =Logger.getLogger(sheetname);
	public String SubmissionNumber;
	public String PolicyPeriod;
	public String TotalPremium;
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRQuote() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			/*if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleFormsTittle"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Forms Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Forms Page","System displayed Forms Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Forms Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Forms Page","System not displayed Forms Page", "FAIL");
				status = false;
			}*/
			return status;
	}   
	
	public Boolean getQuoteNumber() throws Exception{
		HashMap<String,Object> updateColumnNameValues = new HashMap<String,Object>();
		HashMap<String,Object> whereConstraint = new HashMap<String,Object>();
		try{
			Boolean status = true;
			if(common.WaitUntilClickable(Common.o.getObject("eleSubmissionNumber"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				XlsxReader sXL = XlsxReader.getInstance();
				SubmissionNumber = common.ReadElement(Common.o.getObject("eleSubmissionNumber"), 30);
				PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, SubmissionNumber);
				PolicyPeriod = common.ReadElement(Common.o.getObject("elePolicyPeriod"), 30);
				PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, PolicyPeriod);
				TotalPremium = common.ReadElement(Common.o.getObject("eleTotalPremium"), 30);
				PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, TotalPremium);
				updateColumnNameValues.put(PCConstants.SubmissionNumber, SubmissionNumber);
				updateColumnNameValues.put(PCConstants.PolicyPreiod, PolicyPeriod);
				updateColumnNameValues.put(PCConstants.TotalPremium, TotalPremium);
				whereConstraint.put(PCConstants.ID, PCThreadCache.getInstance().getProperty("TCID"));
				status = sXL.executeUpdateQuery(PCConstants.SHEET_QUOTE, updateColumnNameValues, whereConstraint);
				status = sXL.executeUpdateQuery(PCConstants.SHEET_OUTPUT, updateColumnNameValues, whereConstraint);
				logger.info("System displayed Quote Summary Page with Quote Number: " + SubmissionNumber);  
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Quote Summary Page with Quote Number","System displayed Quote Summary Page with Account Quote: '" + SubmissionNumber + "'", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Quote Summary Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Quote Summary Page with Quote Number","System not displayed Quote Summary Page", "FAIL");
				status = false;
			}
			return status;
		}finally
		{
			updateColumnNameValues = null;
			whereConstraint = null;
		}
		
	}
	
}