package com.pc.screen;


import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Loginpc{
	
	public static String sheetname = "Loginpc";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	String sURL = "";
	public Boolean SCRLoginpc() throws Exception
	{		
		sURL = HTML.properties.getProperty(HTML.properties.getProperty("Region") + "PC") + "/pc/PolicyCenter.do";
		Boolean s = common.OpenApp(sURL);
		if(!s)
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "PASS");
			return false;
		}
		Boolean status = true;
		if(HTML.properties.getProperty("EXECUTIONAPP").contains("ODS"))
		{
			status = common.CSVFile();
		}
		status = common.ClassComponent(sheetname,Common.o);
		if(!status)
		{
			return status;
		}
		if(common.WaitUntilClickable(Common.o.getObject("eleDeskTopAction"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("Application Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application loggedin successfully", "PASS");
			//status=SCRCommon.funGetUserLoggedName();
			status = true;
		}
		else
		{
			logger.info("Application not Loggedin Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Application should login successfully","Application not loggedin successfully", "FAIL");
			status = false;
		}
		return status;
	}
	
	
	public Boolean devtool() throws Exception
	{
		Boolean blnStatus = false;
		Actions a = new Actions(ManagerDriver.getInstance().getWebDriver());
		a.sendKeys(Keys.chord(Keys.ALT,Keys.SHIFT,"t")).perform();
		return true;
	}
	
	public boolean SwitchLanguage(String sFuncValue) throws Exception
	{
		boolean status = false;
		//String[] sValue = sFuncValue.split(":::");
		String actiontext;
		PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SYSTEMDATE_DATE,(common.ReadElement(Common.o.getObject("eleSystemDate"),30)));
		//common.SafeAction(Common.o.getObject("eleDeskTop"), "Yes", "eleDeskTop");
		actiontext = common.ReadElement(Common.o.getObject("eleDeskTopAction"), 30);	
		System.out.println(actiontext);
		if(actiontext.equals("Actions") && sFuncValue.equals("Japanese")) {
			common.SafeAction(Common.o.getObject("eleSettings"), "Yes", "eleSettings");
			common.SafeAction(Common.o.getObject("eleInternational"), "Yes", "eleInternational");
			common.SafeAction(Common.o.getObject("eleLanguage"), "Yes", "eleLanguage");
			common.SafeAction(Common.o.getObject("eleJapanese"), "Yes", "eleJapanese");			
			status = true;
			logger.info("Language Switched to " + sFuncValue + " Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Language should be Switched to " + sFuncValue ,"Language Switched to " + sFuncValue + " Successfully", "PASS");
		}else if(actiontext.equals("アクション") && sFuncValue.equals("English")) {			
			common.SafeAction(Common.o.getObject("eleSettings"), "Yes", "eleSettings");
			common.SafeAction(Common.o.getObject("eleInternational"), "Yes", "eleInternational");
			common.SafeAction(Common.o.getObject("eleLanguage"), "Yes", "eleLanguage");
			common.SafeAction(Common.o.getObject("eleEnglish"), "Yes", "eleEnglish");			
			status = true;
			logger.info("Language Switched to " + sFuncValue + " Successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Language should be Switched to " + sFuncValue ,"Language Switched to " + sFuncValue + " Successfully", "PASS");
		}else {
			logger.info( sFuncValue + " Verion of the Appplication opened already");	
			status = true;
		}  

		return status;
	}
}