package com.pc.screen;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.constants.PortalQB;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class PortalPayment {

	public static String sheetname = "PortalPayment";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRPortalPayment() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }
	
	public Boolean PaymentOption(String payOption) throws Throwable{
		Boolean status = false;
		if(payOption.equalsIgnoreCase("lumpSum")){			
			status = common.SafeAction(Common.o.getObject("eleLumpSum"), "YES" , "eleLumpSum");	
			
		}else if(payOption.equalsIgnoreCase("Installment")){
			status = common.SafeAction(Common.o.getObject("eleInstallment"), "YES" , "eleInstallment");	
		}
		return status;
	}
	
	public Boolean PaymentMethod(String payMethod) throws Throwable{
		Boolean status = false;
		if(payMethod.equalsIgnoreCase("CreditCard")){			
			status = common.SafeAction(Common.o.getObject("eleCreditCard"), "YES" , "eleCreditCard");			
		}else if(payMethod.equalsIgnoreCase("ConvenientStore")){
			status = common.SafeAction(Common.o.getObject("eleConvenientStore"), "YES" , "eleConvenientStore");	
		}
		return status;
	}
	
	public Boolean getSubmissionNumber() throws Throwable{
		Boolean status = false;
		
		HashMap<String,Object> updateColumnNameValues = new HashMap<String,Object>();
		HashMap<String,Object> whereConstraint = new HashMap<String,Object>();

			if(common.presenceOfElementLocated(Common.o.getObject("outputSubmissionNo"),  Integer.valueOf(HTML.properties.getProperty("LONGWAIT"))))
			{
				String temp = "abs";
				XlsxReader sXL = XlsxReader.getInstance();
				String submissionNumber = common.ReadElement(Common.o.getObject("outputSubmissionNo"), 30);
			//	PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, policyNumber);
				updateColumnNameValues.put(PortalQB.SUBMISSION_NO_COL, submissionNumber);
				whereConstraint.put(PortalQB.TESTCASE_ID_COL, PCThreadCache.getInstance().getProperty("TCID"));
				status = sXL.executeUpdateQuery(PortalQB.OUTPUT_WORKSHEET, updateColumnNameValues, whereConstraint);
				logger.info("Portal QB process completed sucessfully for submission Number: " + submissionNumber);  
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Portal QB process should display confirmation page with submission Number","Portal QB process completed sucessfully for submission Number: '" + submissionNumber + "'", "PASS");
				status = true;
				System.out.println(temp);
				
			}
			else
			{
				logger.info("Portal QB process final page is not displaying submission Number");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Portal QB process should display confirmation page with submission Number","Portal QB process final page is not displaying submission Number", "FAIL");
				status = false;
			}		
	
		return status;
	}
	
	public Boolean selectCVS(String store) throws Throwable{
		Boolean status = false;
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		List<WebElement> cvsElements= driver.findElements(By.cssSelector("div.adjPayment-lump-sum-store.ng-scope >div > ul > li> label > p"));
		for(WebElement element : cvsElements){
			if(element.getText().equalsIgnoreCase(store)){
				element.click();
				status = true;
				logger.info("Convenient Store radio option " + store + " selectecd succeffully");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Convenient Store radio option " + store + " should be selectecd succeffully","Convenient Store radio option " + store + " selectecd succeffully", "PASS");
				break;
			}
		}
		if(!status){
			logger.info("Convenient Store radio option " + store + " NOT selectecd succeffully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Convenient Store radio option " + store + " should be selectecd succeffully","Convenient Store radio option " + store + " NOT selectecd succeffully", "FAIL");
		}
		return status;
	}
	
}
