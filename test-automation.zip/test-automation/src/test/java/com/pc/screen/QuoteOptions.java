package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class QuoteOptions {
	public static String sheetname = "QuoteOptions";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRQuoteOptions() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }

	public Boolean selectQuote(String plan) throws Exception {

		Boolean status = false;
		String objectName = "buttonsBuyNow";
		By buyNowOptions = Common.o.getObject(objectName);	
		List<WebElement> buyNowButtons = ManagerDriver.getInstance().getWebDriver().findElements(buyNowOptions);
		WebElement element = null;
try{
		if (plan.equals("A") || plan.equals("Aプラン")) {
			System.out.println("Plan A matched");
			element = buyNowButtons.get(0);
			Thread.sleep(2000);
			element.click();
			status = true;

		} else if (plan.equals("B") || plan.equals("Bプラン")) {
			element = buyNowButtons.get(1);
			element.click();
			status = true;
		} else if (plan.equals("C") || plan.equals("Cプラン")) {
			element = buyNowButtons.get(2);
			element.click();
			status = true;
		}
}
catch(Exception e){
	System.out.println(e.getMessage());
}
		Thread.sleep(3000);

		if (status) {
			logger.info("Thread ID = " + Thread.currentThread().getId() + "  Clicked on '" + objectName
					+ "' element or button or link and element '" + element + "'");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"System should click on '" + objectName + "' element or button or link",
					"Clicked on '" + objectName + "' element or button or link", "PASS");
		}

		
		// log, report - what if false ?
		return status;
	}

}
