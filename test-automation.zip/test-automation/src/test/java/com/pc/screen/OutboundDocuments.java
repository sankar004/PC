package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class OutboundDocuments {
	
	public static String sheetname = "OutboundDocuments";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCROutboundDocuments() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			if(!status)
			{
				return false;
			}
			return status;
	}   
	
	public Boolean VerifyPackage(String value) throws Exception
	{		
		Boolean blnStatus = false;
		if (tableDisplayedwithpackage(value)) {
		blnStatus = SCRCommon.verifyTextFromTable("tablepackage", 0, value, "Package table");
		}
		return blnStatus;
		
	}
	
	public Boolean VerifyPackageNotDisplayed(String value) throws Exception
	{		
		Boolean blnStatus = false;
		if (tableDisplayedwithpackage(value)) {
			blnStatus = false;
			logger.info("Package "+ value  +" is displayed in the Outbound documents screen");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Package " + value  + " should not be displayed in the Outbound documents screen","Package "+ value  +" is displayed in the Outbound documents screen", "FAIL");
		}else{
			blnStatus = true;
			logger.info("Package "+ value  +" is not displayed in the Outbound documents screen");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "Package " + value  + " should not be displayed in the Outbound documents screen","Package "+ value  +" is not displayed in the Outbound documents screen", "PASS");
		}

		return blnStatus;
		
	}
	
	public Boolean VerifySendChannel(String value) throws Exception
	{		
		Boolean blnStatus = false;
		String[] sValue = value.split(":::");
		if (tableDisplayedwithpackage(sValue[0])) {		
		blnStatus = SCRCommon.verifyTextFromTable("tablepackage", 0, sValue[0], 3, sValue[1],"Package table");
		}
		return blnStatus;
	}

	
	public Boolean VerifyDocuments(String value) throws Exception
	{		
		Boolean blnStatus = false;
		String[] sValue = value.split(":::");
		blnStatus = SCRCommon.ActionOnTable(common.o.getObject("tablepackage"), 0, 0, sValue[0] , "div");
		for(int i = 1; i < sValue.length; i++) {
			blnStatus = SCRCommon.verifyTextFromTable("tableListofDocuments", 3, sValue[i], "List of Documents of :" + sValue[0] );	
		}
		return blnStatus;
	}
	

	//move to SCRCommon
	private Boolean tableDisplayed() throws Exception {		
		Boolean tableDisplayed = false;
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		int retryTimes= 0;
		while (!tableDisplayed  && retryTimes <= 5) {
		try {
			
				if (driver.findElement(Common.o.getObject("tablepackage")).isDisplayed()) {
					logger.info("Package table displayed");
					tableDisplayed = true;
					//driver.findElement(Common.o.getObject("btnDocumentSearch")).click();
					common.SafeAction(Common.o.getObject("btnDocumentSearch"), "Yes", "btnDocumentSearch");
				}
			
		} catch (NoSuchElementException e) {
				//driver.findElement(Common.o.getObject("btnDocumentSearch")).click();
				common.SafeAction(Common.o.getObject("btnDocumentSearch"), "Yes", "btnDocumentSearch");
				retryTimes++;
				logger.info("Waiting for table to be displayed...");
		} catch(Exception e){				
				common.SafeAction(Common.o.getObject("btnDocumentSearch"), "Yes", "btnDocumentSearch");
				retryTimes++;
				logger.info("Waiting for table to be displayed...");
				e.printStackTrace();
		}
		}
		return tableDisplayed;
	}
	
	
	private Boolean tableDisplayedwithpackage(String strPackage) throws Exception {		
		Boolean tableDisplayed = false;
		WebDriver driver = ManagerDriver.getInstance().getWebDriver();
		int retryTimes= 0;		
		List<WebElement> elePackage = driver.findElements(By.xpath("//div[contains(@id,'Documents_AdjScreen:Package_AdjLV-body')]/div/div/table//td/div[text()='" + strPackage + "']")); 
		while (elePackage.size() == 0  && retryTimes <= 3) {
			common.SafeAction(Common.o.getObject("btnDocumentSearch"), "Yes", "btnDocumentSearch");
			elePackage = driver.findElements(By.xpath("//div[contains(@id,'Documents_AdjScreen:Package_AdjLV-body')]/div/div/table//td/div[text()='" + strPackage + "']"));			
			retryTimes++;	
		}
		if(elePackage.size() > 0) {
			tableDisplayed = true;
		}
		else {
			tableDisplayed = false;
		}
		return tableDisplayed;
	}
}