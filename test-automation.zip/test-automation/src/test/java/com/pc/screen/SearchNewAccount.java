package com.pc.screen;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class SearchNewAccount {
	
	public static String sheetname = "SearchNewAccount";
	Common common = CommonManager.getInstance().getCommon();
	static Logger logger =Logger.getLogger(sheetname);
	
	public Boolean SCRSearchNewAccount() throws Exception{
		
		Boolean status = true;
		status = common.ClassComponent(sheetname, Common.o);
		/*if(!status)
		{
			return false;
		}
		if(common.WaitUntilClickable(Common.o.getObject("edtAddressSearch"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed Create New Account Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Create New Account Page","System displayed Create New Account Page", "PASS");
			status = true;
		}
		else
		{
			logger.info("System not displayed Create New Account Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Create New Account Page","System not displayed Create New Account Page", "FAIL");
			status = false;
		}*/
			return status;
	}
	
	
	// function to generate a random string of length n 
    public static String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
  
    public static String getKanjiRandomName(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "荳�蜿ｳ髮ｨ蜀�邇矩浹荳狗↓闃ｱ雋晏ｭｦ豌嶺ｹ昜ｼ醍脂驥醍ｩｺ譛育堪隕倶ｺ泌哨譬｡蟾ｦ荳牙ｱｱ蟄仙屁邉ｸ蟄苓�ｳ荳�霆頑焔蜊∝�ｺ螂ｳ蟆丈ｸ頑｣ｮ莠ｺ豌ｴ豁｣逕滄搨螟慕浹襍､蜊�蟾晏�域掠闕芽ｶｳ譚大､ｧ逕ｷ遶ｹ荳ｭ陌ｫ逕ｺ螟ｩ逕ｰ蝨滉ｺ梧律蜈･蟷ｴ逋ｽ蜈ｫ逋ｾ譁�譛ｨ譛ｬ蜷咲岼遶句鴨譫怜�ｭ"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
    
    public static String getKanaRandomName(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ァアィイゥウェエォオカガキギクグケゲコゴサザシジスズセゼソゾタダチヂッツヅテデトドナニヌネノハバパヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロワ"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 
  
	
	public Boolean randomname() throws Exception
	{
		Boolean blnStatus = false;
		String rndomfnameph = getKanaRandomName(8);
		String rndomlnameph = getKanaRandomName(8);
		PCThreadCache.getInstance().setProperty(PCConstants.CACHE_Last_Name_Ph,rndomlnameph);
		PCThreadCache.getInstance().setProperty(PCConstants.CACHE_First_Name_Ph,rndomfnameph);

		//System.out.println(rndomname);
		common.SafeAction(Common.o.getObject("edtLastNamePhoneticSA"),  rndomlnameph , "edtLastNamePhoneticSA");
		common.SafeAction(Common.o.getObject("edtFirstNamePhoneticSA"),  rndomfnameph , "edtFirstNamePhoneticSA");
		common.SafeAction(Common.o.getObject("edtLastNameSA"),  getKanaRandomName(8) , "edtLastNameSA");
		common.SafeAction(Common.o.getObject("edtFirstNameSA"),  getKanaRandomName(8) , "edtFirstNameSA");
		//blnStatus = SCRCommon.ActionOnTableForICON(Common.o.getObject("eleAccountSummary_PolicyTermsTbl"), 1, 1, strFuncValue, "a");
		return true;
	}
	
}
