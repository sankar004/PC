package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Forms {
	
	public static String sheetname = "Forms";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRForms() throws Exception
	{
		Boolean status = true;
		common.WaitForPageToBeReady1();
		status = common.ClassComponent(sheetname,Common.o);
		/*if(!status)
		{
			return false;
		}
		if(common.WaitUntilClickable(Common.o.getObject("elePaymenttitle"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
		{
			logger.info("System displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System displayed Payment Page", "PASS");
			status = true;
		}
		else
		{
			logger.info("System not displayed Payment Page");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Payment Page","System not displayed Payment Page", "FAIL");
			status = false;
		}*/
		return status;
	}   
	
	public Boolean UpdateDocumentStatus() throws Exception
	{	
		Boolean blnStatus = false;
		int docCount;
		docCount = ManagerDriver.getInstance().getWebDriver().findElements(Common.o.getObject("selDocStatus")).size();
		for(int i = 1; i<= docCount; i++ ) {
			blnStatus =	common.SafeAction(Common.o.getObject("selDocStatus" + i), "OK" , "selDocStatus"+i);	
			Thread.sleep(1000);	
		} 				
		return blnStatus;
	}
	
	public Boolean UpdateDocumentStatus(String value) throws Exception
	{		
		String[] sValue = value.split(":::");
		Boolean blnStatus = false;
		for(int i = 0; i< sValue.length; i++ ) {
			String[] docs = sValue[i].split(":");
			By selDocStatus = By.xpath("//div[text()='"+ docs[0] +"']//following::td[1]");
			blnStatus =	common.SafeAction(selDocStatus, docs[1] , "selDocStatus " + docs[0]);	
			Thread.sleep(1000);	
		} 				
		return blnStatus;
	}
	
}