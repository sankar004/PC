package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;

public class ContractConfirmation {
	
	public static String sheetname =  "ContractConfirmation";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRContractConfirmation() throws Exception
	{		
			Boolean status = false;
			status = common.ClassComponent(sheetname,Common.o);
			return status;
			
		/*	if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleQualificationquestions"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Qualification questions Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Qualification questions Page","System displayed Qualification questions Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Qualification questions Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Qualification questions Page","System not displayed Qualification questions Page", "FAIL");
				status = false;
			}
			//return status;
*/	} 
}
