package com.pc.screen;
// Portal QB - Bike Information

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;

public class BikeInfo {
	public static String sheetname = "BikeInfo";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRBikeInfo() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }

	
	
	public Boolean selectBikeEngineSize(String engineSize) throws Throwable{
		Boolean status = false;
		By engineSizeLocator = By.xpath("//input[@name='displacement']/following-sibling::p[text()='" + engineSize +"']");
		status = common.SafeAction(engineSizeLocator, "YES", "eleEngineSizeOption");		
		return status;
	}
	
	public Boolean selectBikeSideCar(String sideCar) throws Throwable{
		Boolean status = false;
		By sideCarLocator = By.xpath("//input[@name='sidecar']/following-sibling::span[text()='" + sideCar +"']");
		status = common.SafeAction(sideCarLocator, "YES", "eleBikeSideCar");		
		return status;
	}
	
	//input[@name='sidecar']/following-sibling::span[text()='Yes']
	
	public Boolean selectMileage(String mileage) throws Throwable {
		Boolean status = false;
		String elementName = "btnMileage";
		By MileageIdentifier = By.xpath("//p[text()='" + mileage + "']/parent::div/preceding-sibling::p/img");
	    status = common.SafeAction(MileageIdentifier, "YES", elementName);			
		return status;
	}

	public Boolean selectUsage(String usage) throws Throwable {
		Boolean status = false;
		String elementName = "btnUsageOfBike";
		By UsageIdentifier = By.xpath("//p[text()='" + usage + "']/parent::div/preceding-sibling::p/img");
	    status = common.SafeAction(UsageIdentifier, "YES", elementName);	
		return status;
	}

	public Boolean clickNextToDriverInfo(String value) {
		// Dynamic to handle Language
		common.clickButtonByText(value);
		return true;
	}

}
