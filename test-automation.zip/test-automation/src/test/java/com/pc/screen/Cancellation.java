package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Cancellation {
	
	public static String sheetname = "Cancellation";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRCancellation() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			if(!status)
			{
				return false;
			}
			return status;
	}   
	
	
	public Boolean CancellationEffectiveDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edgCancellationEffectiveDate"), SCRCommon.calcDate(expectedDate),
				"edgCancellationEffectiveDate");
		return status;
	}
	
	
}