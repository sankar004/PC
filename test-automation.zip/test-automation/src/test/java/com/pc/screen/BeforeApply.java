package com.pc.screen;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

/*Portal　QB - Before Applying screen
 * */
public class BeforeApply {

	public static String sheetname = "BeforeApply";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRBeforeApply() throws Exception {
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;
 }

	public Boolean selectGender(String gender) throws Throwable {
		Boolean status = false;
	    Thread.sleep(3000);	
		By genderElement = By.xpath("//*[text()='" + gender + "']");
		logger.info("selectGender function execute for :" + gender);
		status = common.SafeAction(genderElement, "Yes", "lnkGender");
		if(status){
			logger.info("Gender selected as :" + gender);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Gender should be selected as " + gender,
					"Gender successfully selected as " + gender, "PASS");
		}else{
			logger.info("Gender selection failed for the value :" + gender);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Gender should be selected as " + gender,
					"Gender selection failed for the value " + gender, "FAIL");
		}
		return status;
	}

	public Boolean selectMainDriver(String mainDriver) throws Throwable {
		Boolean status = false;
		String formatMainDriver = mainDriver.replace("'", "\'");
		String elementName = "eleMainDriver";
		//By MainDriver = By.xpath("//p[text()=\"" + formatMainDriver + "\"]/parent::div/preceding-sibling::p/img");		
		By MainDriver = By.xpath("//p[text()=\"" + formatMainDriver + "\"]/parent::div/parent::div/parent::label/input[@ng-model='vehicle.ownerRelation.value']/following-sibling::div/p/img");
		status = common.SafeAction(MainDriver, "YES", elementName);
		return status;	
	}
	
	
	public Boolean selectContractorOwner(String contractorOwner) throws Throwable{
		boolean status = false;
		By locator = By.cssSelector("input[ng-model='vehicle.isPolicyHolderOwnerOfVehicle_Adj.value']+p");
		status = common.selectFromListByTextValue(locator, contractorOwner.trim());
		if(status){
			logger.info("Is Contractor Owner selected successfully for the value :" + contractorOwner);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Is Contractor Owner should be selected as " + contractorOwner,
					"Is Contractor Owner successfully selected as " + contractorOwner, "PASS");
		}else {
			logger.info("Is Contractor Owner selection failed for the value :" + contractorOwner);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Is Contractor Owner should be selected as " + contractorOwner,
					"Is Contractor Owner selection failed for the value " + contractorOwner, "FAIL");
		}
		return status;
	}
	
	public Boolean enterPhoneticLastName() throws Throwable{
		Boolean status = false;
		String kanaName = common.kanaRandomName();
		logger.info("kana Name used: " + kanaName);
		status = common.SafeAction(Common.o.getObject("edtLastNamePhonetic"), kanaName, "edtLastNamePhonetic");
		if(!status){
			logger.info("Unable to enter Random Kana Name for PhoneticLastName");
		}
		return status;
	}
	
	public Boolean enterPhoneticFirstName() throws Throwable{
		Boolean status = false;
		String kanaName = common.kanaRandomName();
		logger.info("kana Name used: " + kanaName);
		status = common.SafeAction(Common.o.getObject("edtFirstNamePhonetic"), kanaName, "edtFirstNamePhonetic");
		if(!status){
			logger.info("Unable to enter Random Kana Name PhoneticFirstName");
		}
		return status;
	}

	
	

}
