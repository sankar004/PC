package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class BeforeQuote {

	public static String sheetname = "BeforeQuote";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();

	public Boolean SCRBeforeQuote() throws Exception {

		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		return status;

		/*
		 * if(!status) { return false; }
		 * if(common.WaitUntilClickable(Common.o.getObject(
		 * "eleQualificationquestions"),
		 * Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT")))) {
		 * logger.info("System displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System displayed Qualification questions Page", "PASS"); status =
		 * true; } else {
		 * logger.info("System not displayed Qualification questions Page");
		 * HTML.fnInsertResult(PCThreadCache.getInstance().getProperty(
		 * "testcasename"),
		 * PCThreadCache.getInstance().getProperty("methodName"),
		 * "System should display Qualification questions Page"
		 * ,"System not displayed Qualification questions Page", "FAIL"); status
		 * = false; } //return status;
		 */ }

	public Boolean selectLanguage(String language) throws Exception {
		Boolean status = false;
		if (language.trim().equalsIgnoreCase("English")) {
			status = common.SafeAction(Common.o.getObject("languageMenu"), "YES", "btnLanguageMenu");
			// driver.findElement(Common.o.getObject("languageMenu")).click();
			Thread.sleep(2000);
			status = common.SafeAction(Common.o.getObject("languageChange"), "YES", "btnLanguageChange");
			// driver.findElement(Common.o.getObject("languageChange")).click();
			Thread.sleep(2000);
		} else {
			status = true;
			logger.info("No language change done as expected");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Language option should be selected " + language,
					"Language option successfully selected " + language, "PASS");
		}
		logger.info("Thread ID = " + Thread.currentThread().getId() + "  Function selectLanguage executed successfully "
				+ "for the value " + language);
		if(!status){
			logger.info("Language selection failed for : " + language);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Language option should be selected " + language,
					"Language option failed for the value " + language, "FAIL");
		}
		return status;
	}

	public Boolean selectTypeOfContract(String value) throws Throwable {
		logger.info("selectTypeOfContract execution started");
		Boolean status = false;
		String radioValue = value;
		By radioOptions = Common.o.getObject("radioTypeOfContract");
		List<WebElement> elements = ManagerDriver.getInstance().getWebDriver().findElements(radioOptions);
		for (WebElement ele : elements) {
			if (ele.getText().matches(radioValue)) {
				ele.click();
				status = true;
				logger.info("Type of contract selected as :" + value);
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
						PCThreadCache.getInstance().getProperty("methodName"),
						"Type of contract should be selected as " + value,
						"Type of contract successfully selected as " + value, "PASS");
				break;
			}
		}
		if (!status) {
			logger.info("Type of contract selection failed for the value :" + value);
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"),
					"Type of contract should be selected as " + value,
					"Type of contract selection failed for the value " + value, "FAIL");
		}
		return status;
	}

}
