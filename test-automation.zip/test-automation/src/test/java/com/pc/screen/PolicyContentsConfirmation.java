package com.pc.screen;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.FlatFile;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class PolicyContentsConfirmation {
	
	public static String sheetname = "PolicyContentsConfirmation";
	static Logger logger =Logger.getLogger(sheetname);
	public String SubmissionNumber;
	public String PolicyPeriod;
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRPolicyContentsConfirmation() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			/*if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleSidebySideQuoting"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Side-by-Side Quoting Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Side-by-Side Quoting Page","System displayed Side-by-Side Quoting Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Side-by-Side Quoting Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Side-by-Side Quoting Page","System not displayed Side-by-Side Quoting Page", "FAIL");
				status = false;
			}*/
			return status;
	}   
	
	public Boolean GetQuoteNumber() throws Exception{
		HashMap<String,Object> updateColumnNameValues = new HashMap<String,Object>();
		HashMap<String,Object> whereConstraint = new HashMap<String,Object>();
		try{
			Boolean status = true;
			if(common.WaitUntilClickable(Common.o.getObject("eleSubmissionNumber"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				XlsxReader sXL = XlsxReader.getInstance();
				SubmissionNumber = common.ReadElement(Common.o.getObject("eleSubmissionNumber"), 30);
				PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SUBMISSION_NUMBER, SubmissionNumber);
				updateColumnNameValues.put(PCConstants.SubmissionNumber, SubmissionNumber);
				whereConstraint.put(PCConstants.ID, PCThreadCache.getInstance().getProperty("TCID"));
				status = sXL.executeUpdateQuery(PCConstants.SHEET_POLICYCONTENTSCONFERMATION, updateColumnNameValues, whereConstraint);
				logger.info("System displayed Quote Summary Page with Quote Number: " + SubmissionNumber);  
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Quote Summary Page with Quote Number","System displayed Quote Summary Page with Account Quote: '" + SubmissionNumber + "'", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Quote Summary Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Quote Summary Page with Quote Number","System not displayed Quote Summary Page", "FAIL");
				status = false;
			}
			return status;
		}finally
		{
			updateColumnNameValues = null;
			whereConstraint = null;
		}
		
	}
	
	
}