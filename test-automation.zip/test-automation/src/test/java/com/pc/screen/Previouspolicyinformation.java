package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class Previouspolicyinformation {
	
	public static String sheetname = "Previouspolicyinformation";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRPreviouspolicyinformation() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
/*			if(!status)
			{
				return false;
			}
			if(common.WaitUntilClickable(Common.o.getObject("eleVehiclDriverPolicyinformation"),  Integer.valueOf(HTML.properties.getProperty("VERYLONGWAIT"))))
			{
				logger.info("System displayed Vehicle & Driver & Policy information Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Vehicle & Driver & Policy information Page","System displayed Vehicle & Driver & Policy information Page", "PASS");
				status = true;
			}
			else
			{
				logger.info("System not displayed Vehicle & Driver & Policy information Page");
				HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"), PCThreadCache.getInstance().getProperty("methodName"), "System should display Vehicle & Driver & Policy information Page","System not displayed Vehicle & Driver & Policy information Page", "FAIL");
				status = false;
			}*/
			return status;
	}   
	
/*	public boolean EnterPPDates(String strFuncValue) throws Exception
	{
		boolean status = false;
		String[] strSplitValue = strFuncValue.split(":::");
		String strDate = null;
		String SwithPurchase = common.Getcellvalue(PCConstants.SHEET_PPINFO, PCConstants.SwitchPurchase);
		String Interruptioncertification = common.Getcellvalue(PCConstants.SHEET_PPINFO, PCConstants.SwitchPurchase);
		switch(strSplitValue[0].toUpperCase())
		{
			case"CURRENTDATE":			
				strDate = common.ReadElement(Common.o.getObject("eleSystemDate"), 30);
				break;
			case"INCREASEDECREASEDATE":
				strDate = SCRCommon.returnDate(common.ReadElement(Common.o.getObject("eleSystemDate"), 30), Integer.parseInt(strSplitValue[1]));
				break;
		}
		
		status = common.SafeAction(Common.o.getObject("edtPPEndDate"), strDate, "edtPPEndDate");
		status = common.SafeAction(Common.o.getObject("edtPPExpirationDate"), strDate, "edtPPExpirationDate");
		status = common.SafeAction(Common.o.getObject("edtPPExpirationDate"), strDate, "edtPPExpirationDate");
		
		return status;
	}*/
	
	public boolean DefaultEffectiveDate(String strFuncValue) throws Exception
	{
		boolean status = false;
		String[] strSplitValue = strFuncValue.split(":::");
		String strDate = null;
		//String SwithPurchase = common.Getcellvalue(PCConstants.SHEET_PPINFO, PCConstants.SwitchPurchase);
		//String Interruptioncertification = common.Getcellvalue(PCConstants.SHEET_PPINFO, PCConstants.Interruptioncertification);
		String SwithPurchase = common.GetcellvalueByIteration(PCConstants.SHEET_PPINFO, PCConstants.SwitchPurchase);
		String Interruptioncertification = common.GetcellvalueByIteration(PCConstants.SHEET_PPINFO, PCConstants.Interruptioncertification);
		//PCThreadCache.getInstance().setProperty(PCConstants.CACHE_SYSTEMDATE_DATE,(common.ReadElement(Common.o.getObject("eleSystemDate"),30)));
		switch(strSplitValue[0].toUpperCase())
		{
			case"CURRENTDATE":
				//strDate = SCRCommon.ReturnCurrentDate();
				//status = common.SafeAction(Common.o.getObject("edgEffectiveDate"), strDate, "edgEffectiveDate");
				//strDate = common.ReadElement(Common.o.getObject("eleSystemDate"), 30);
				strDate = PCThreadCache.getInstance().getProperty(PCConstants.CACHE_SYSTEMDATE_DATE);
				break;
			case"INCREASEDECREASEDATE":
				//strDate = SCRCommon.returnDate(Integer.parseInt(strSplitValue[1]));
				//status = common.SafeAction(Common.o.getObject("edgEffectiveDate"), strDate, "edgEffectiveDate");
				strDate = SCRCommon.returnDate(PCThreadCache.getInstance().getProperty(PCConstants.CACHE_SYSTEMDATE_DATE), Integer.parseInt(strSplitValue[1]));
				break;
		}		
		PCThreadCache.getInstance().setProperty(PCConstants.CACHE_EFFECTIVE_DATE, strDate );
		if(SwithPurchase.equalsIgnoreCase("Yes")){
			status = common.SafeAction(Common.o.getObject("edtPPEffectiveDate"), SCRCommon.returnDate(strDate,-365), "edtPPEffectiveDate");
			status = common.SafeAction(Common.o.getObject("edtPPExpirationDate"), strDate, "edtPPExpirationDate");
			status = common.SafeAction(Common.o.getObject("edtPPEndDate"), strDate, "edtPPEndDate");
			
			
		}/*else if(Interruptioncertification.equalsIgnoreCase("Yes")){
			
			status = common.SafeAction(Common.o.getObject("edtVehicleacquisitiondate"), SCRCommon.returnDate(strDate,-200), "edtVehicleacquisitiondate");
			status = common.SafeAction(Common.o.getObject("edtPPEffectiveDate"), SCRCommon.returnDate(strDate,-460), "edtPPEffectiveDate");
			status = common.SafeAction(Common.o.getObject("edtInterruptiondateofpreviouspolicy"), SCRCommon.returnDate(strDate,-260), "edtInterruptiondateofpreviouspolicy");
			status = common.SafeAction(Common.o.getObject("edgEffectiveDate"), strDate, "edgEffectiveDate");	
		}*/
		
		
		else {
			status = common.SafeAction(Common.o.getObject("edgEffectiveDate"), strDate, "edgEffectiveDate");			
		}		
		
		return status;
	}
	
	public boolean VerfiyinfoMessage() throws Exception{
		
		String message = ManagerDriver.getInstance().getWebDriver().findElement(By.className("message")).getText();
		
		System.out.println(message);
		
		return true;
		
	}
	
	public Boolean PPEffectiveDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edtPPEffectiveDate"), SCRCommon.calcDate(expectedDate),
				"edtPPEffectiveDate");
		return status;
	}
	
	public Boolean PPExpirationDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edtPPExpirationDate"), SCRCommon.calcDate(expectedDate),
				"edtPPExpirationDate");
		return status;
	}

	public Boolean PPEndDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edtPPEndDate"), SCRCommon.calcDate(expectedDate),
				"edtPPEndDate");
		return status;
	}

	public Boolean EffectiveDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edgEffectiveDate"), SCRCommon.calcDate(expectedDate),
				"edgEffectiveDate");
		return status;
	}
	
	public Boolean StartDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edtStartDate"), SCRCommon.calcDate(expectedDate),
				"edtStartDate");
		return status;
	}
	
	public Boolean EndDate(String expectedDate) throws Throwable {
		Boolean status = false;
		status = common.SafeAction(Common.o.getObject("edtEndDate"), SCRCommon.calcDate(expectedDate),
				"edtEndDate");
		return status;
	}
	
}