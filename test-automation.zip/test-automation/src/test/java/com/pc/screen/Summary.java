package com.pc.screen;

import org.apache.log4j.Logger;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;

public class Summary {
	
	public static String sheetname =  "Summary";
	static Logger logger =Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRSummary() throws Exception
	{		
			Boolean status = false;
			status = common.ClassComponent(sheetname,Common.o);
			return status;			
	} 
}
