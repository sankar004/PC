package com.pc.screen;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.pc.constants.PCConstants;
import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.FlatFile;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;
import com.pc.utilities.XlsxReader;

public class GWProfiler {
	
	public static String sheetname = "GWProfiler";
	static Logger logger =Logger.getLogger(sheetname);
	public String SubmissionNumber;
	public String PolicyPeriod;
	public String TotalPremium;
	Common common = CommonManager.getInstance().getCommon();
	
	public Boolean SCRGWProfiler() throws Exception
	{
			Boolean status = true;
			status = common.ClassComponent(sheetname,Common.o);
			return status;
	}   
	
	public Boolean GuidewireProfiler() throws Exception
	{
		Boolean blnStatus = false;
		Actions a = new Actions(ManagerDriver.getInstance().getWebDriver());
		a.sendKeys(Keys.chord(Keys.ALT,Keys.SHIFT,"p")).perform();
		return true;
	}
}