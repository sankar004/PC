package com.pc.screen;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.pc.utilities.Common;
import com.pc.utilities.CommonManager;
import com.pc.utilities.HTML;
import com.pc.utilities.ManagerDriver;
import com.pc.utilities.PCThreadCache;

public class PortalQBHome {

	public static String sheetname = "PortalQBHome";
	static Logger logger = Logger.getLogger(sheetname);
	Common common = CommonManager.getInstance().getCommon();
	String sURL = "";

	public Boolean SCRPortalQBHome() throws Exception {
		sURL = HTML.properties.getProperty(HTML.properties.getProperty("Region") + "QB");
		Boolean s = common.OpenApp(sURL);	
		
		// Verify Browser opened successfully
		if (!s) {			
			logger.info("Browser failed to open");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"), "Browser should open successfully",
					"Browser failed to open", "FAIL");
			return false;
		}
		
		Boolean status = false;
		status = common.ClassComponent(sheetname, Common.o);
		
		
		// Verify Page Loaded Successfully	

		
/*		if (common.presenceOfElementLocated(Common.o.getObject("coverageOptionAuto"),
				Integer.valueOf(HTML.properties.getProperty("LONGWAIT")))) {		
			
			logger.info("Customer Engage Quote and Buy Portal opened successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"), "Customer Engage Quote and Buy Portal should open successfully",
					"Customer Engage Quote and Buy Portal opened successfully", "PASS");
			// status=SCRCommon.funGetUserLoggedName();
			status = true;
		} else {		
			logger.info("Customer Engage Quote and Buy Portal failed to open successfully");
			HTML.fnInsertResult(PCThreadCache.getInstance().getProperty("testcasename"),
					PCThreadCache.getInstance().getProperty("methodName"), "Customer Engage Quote and Buy Portal should open successfully",
					"Customer Engage Quote and Buy Portal failed to open successfully", "FAIL");
			status = false;
		}*/
	
		return status;
		
	}
	
	
	public Boolean selectProduct(String Product) throws Exception
	{	
		// Function to select Car, Bike in Portal Home Page.
		boolean status = false;	
		By btnSelectProduct = By.linkText(Product);
		status = common.SafeAction(btnSelectProduct, "YES", "btnSelectProduct");
		return status;
	}

	public boolean SelectActivity(String sFuncValue) throws Exception {
		boolean status = false;
		String[] sValue = sFuncValue.split(":::");
		status = common.ActionOnTable(Common.o.getObject("eleActivityTable"), 2, 2, sValue[1], sValue[1], "a");
		return status;
	}

}
