package com.pc.payment;

import javax.xml.ws.soap.SOAPBinding;

import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;

public class PortGenerator {

    public static <T> T generatePort(Class<T> clazz, String url) {
        return generatePortWithBasicAuth(clazz, url, null, null);
    }

    @SuppressWarnings("unchecked")
    public static <T> T generatePortWithBasicAuth(Class<T> clazz, String url, String user, String password) {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();

        factory.getInInterceptors().add(new LoggingInInterceptor());
        factory.getOutInterceptors().add(new LoggingOutInterceptor());
        factory.setServiceClass(clazz);
        factory.setAddress(url);
        factory.setBindingId(SOAPBinding.SOAP12HTTP_BINDING);

        Object api = factory.create();

        if (user != null && !user.isEmpty() && password != null) {
            Client client = ClientProxy.getClient(api);
            HTTPConduit http = (HTTPConduit) client.getConduit();
            AuthorizationPolicy authPolicy = new AuthorizationPolicy();
            authPolicy.setAuthorizationType("Basic");
            authPolicy.setUserName(user);
            authPolicy.setPassword(password);
            http.setAuthorization(authPolicy);
        }
        return (T) api;
    }
}
