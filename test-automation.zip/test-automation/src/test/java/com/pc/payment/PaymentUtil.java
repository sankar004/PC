package com.pc.payment;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.adj.axa.gw.bc.BCSoapTestsPortType;
import com.adj.axa.gw.pc.GmoAPIPortType;
import com.adj.axa.gw.pc.ValidationException_Exception;
import com.adj.axa.gw.pc.WsiAuthenticationException_Exception;
//import com.axa.adj.fw.common.ws.PortGenerator;
//import com.axa.adj.fw.uitest.UIConfiguration;
//import com.axa.adj.fw.uitest.UITestContext;
//import com.axa.adj.fw.uitest.gw.definition.ActionDefinition;
import com.example.com.axa.adj.gw.bc.integration.test.dto.gettoken.GetTokenInputDTO;
import com.example.com.axa.adj.gw.bc.integration.test.dto.gettoken.GmoTokenOutputDTO;
import com.example.com.axa.adj.gw.pc.integration.gmo.api.dto.PayWithCreditCardForSubmissionInputDTO;
import com.guidewire.pc.typekey.CardHolderType_Adj;
import com.pc.utilities.HTML;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PaymentUtil {
    
    public void payCvsOnline(String submissionNumber, String amount, String cvsToken) throws IOException {

        String url = HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "BC") + "/bc/service/cvs/notification";
    	//String url="https://bc.apps.pre-prod.on-prem.axa-direct-jp.intraxa/bc/service/cvs/notification";
    	 
        String now = DateTimeFormatter.ofPattern("yyyyMMddhhmmss").format(LocalDateTime.now());
        Map<String, String> formParamMap = new HashMap<>();
        formParamMap.put("ShopID", "tshop00019316");
        formParamMap.put("ShopPass", "h4hxqqfn");
        formParamMap.put("AccessID", "96f417b732b19e29787f350744aaf1ff");
        formParamMap.put("AccessPass", "fd358fd7204c826df5ee6c2617514a0b");
        formParamMap.put("OrderID", String.format("abcdefdhijkl0000%s01", submissionNumber));
        formParamMap.put("Status", "PAYSUCCESS");
        formParamMap.put("Amount", amount);
        formParamMap.put("Tax", "0");
        formParamMap.put("Currency", "JPY");
        formParamMap.put("TranID", "123456-asabckjfdsdfsewfjhdsf");
        formParamMap.put("TranDate", now);
        formParamMap.put("CvsCode", "00007");
        formParamMap.put("CvsConfNo", "999999999999999999");
        formParamMap.put("CvsReceiptNo", cvsToken);
        formParamMap.put("PaymentTerm", now);
        formParamMap.put("FinishDate", now);
        formParamMap.put("ReceiptDate", now);
        formParamMap.put("PayType", "3");

        // Names and values will be url encoded
        final FormBody.Builder formBuilder = new FormBody.Builder();
        formParamMap.forEach(formBuilder::add);
        RequestBody requestBody = formBuilder.build();

        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .build();

        try (Response response = okHttpClient.newCall(request).execute()) {
            int responseCode = response.code();
            System.out.println("responseCode: " + responseCode);

            if (!response.isSuccessful()) {
                System.out.println("error!!");
            }
            if (response.body() != null) {
                System.out.println("body: " + response.body().string());
            }
        }catch(Exception e) {
        	  
        	  e.printStackTrace();
          }

        System.out.println(String.format("payCvsOnline: %s\t%s\t%s", submissionNumber, amount, cvsToken));
    }

   
    public void payCvsOffline(String submissionNumber, String amount) throws IOException {

        String url = HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "BC") + "/bc/service/cvs/notification";
        String now = DateTimeFormatter.ofPattern("yyyyMMddhhmmss").format(LocalDateTime.now());
        Map<String, String> formParamMap = new HashMap<>();
        formParamMap.put("ShopID", "tshop00019316");
        formParamMap.put("ShopPass", "h4hxqqfn");
        formParamMap.put("AccessID", "96f417b732b19e29787f350744aaf1ff");
        formParamMap.put("AccessPass", "fd358fd7204c826df5ee6c2617514a0d");
        formParamMap.put("OrderID", "abcdefghijkl00" + submissionNumber + "010e");
        formParamMap.put("Status", "PAYSUCCESS");
        formParamMap.put("TranDate", now);
        formParamMap.put("PvFrontBillKey", "23400" + submissionNumber + "010");
        formParamMap.put("PvResultCode", "0");
        formParamMap.put("PvReceiptDatetime", now);
        formParamMap.put("PvReceiptAgencyCode", "01");
        formParamMap.put("PvCvsCode", "00007");
        formParamMap.put("PvCvsBranchCode", "01234567");
        formParamMap.put("PvBarcode", "919876547890123400" + submissionNumber + "01018073000305105");
        formParamMap.put("PvPaymentAmount", amount);
        formParamMap.put("PayType", "32");

        // Names and values will be url encoded
        final FormBody.Builder formBuilder = new FormBody.Builder();
        formParamMap.forEach(formBuilder::add);
        RequestBody requestBody = formBuilder.build();

        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .build();

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .build();

        try (Response response = okHttpClient.newCall(request).execute()) {
            int responseCode = response.code();
            System.out.println("responseCode: " + responseCode);

            if (!response.isSuccessful()) {
                System.out.println("error!!");
            }
            if (response.body() != null) {
                System.out.println("body: " + response.body().string());
            }
        }catch(Exception e) {
      	  
      	  e.printStackTrace();
        }

        System.out.println(String.format("payCvsOffline: %s\t%s", submissionNumber, amount));
    }
/*
    public void payCreditCard(String submissionNumber, String creditCardNumber, String cardHolderType, String amount)
        throws WsiAuthenticationException_Exception,
        ValidationException_Exception,
        com.adj.axa.gw.bc.WsiAuthenticationException_Exception {
    	
        BCSoapTestsPortType bcTestPort = PortGenerator.generatePortWithBasicAuth(
            BCSoapTestsPortType.class,                       
            HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "BC") + "/bc/ws/com/axa/adj/gw/bc/integration/test/BCSoapTests?WSDL",
            "sfujita",
            "gw");
        GetTokenInputDTO getTokenInput = new GetTokenInputDTO();
        getTokenInput.setCardNo(creditCardNumber);

        GmoTokenOutputDTO out = bcTestPort.getToken(getTokenInput);
        String token = out.getToken();
        System.out.println(token);

        GmoAPIPortType port = PortGenerator.generatePortWithBasicAuth(
            GmoAPIPortType.class,
            HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "PC") + "/pc/ws/com/axa/adj/gw/pc/integration/gmo/api/GmoAPI?WSDL",
            "su",
            "0gw1");
        PayWithCreditCardForSubmissionInputDTO dto = new PayWithCreditCardForSubmissionInputDTO();
        dto.setBranchNumber(1);
        dto.setPaymentIdentifier(submissionNumber + "01");
        dto.setPaymentMethod("1_LUMPSUM");
        dto.setSubmissionNumber(submissionNumber);
        dto.setToken(token);
        dto.setCardHolderType(CardHolderType_Adj.fromValue(cardHolderType));
        port.payWithCreditCardForSubmission(dto);

        System.out.println(String.format("payCreditCard: %s\t%s", submissionNumber, amount));
    }
*/
    
    private static final String PG_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlhKDXlWw4tu2JrbFITYUDT82BH2W8rLZ9OMFifrYIjO8fz12EsP+Xo+I/xUeh1ctTjGOIQYzZHYacWQ+xjNE5NSF5Beilcn2It0ST8EuQEb0NpRcm7BnYgVP7vYROXUFHiyrOUlPopSW4o+31IKwmO7VtTmq4iHZspMF/25YahIbOJfFF0uMAdIJYRxpYwIS5LWQB0zMT1G70tIGU6yIe3ciN7Le7phljZFidnM+EVSaauela9U8uL00WxTFudpybEwpDTX4zYoE5Cd1DWhZt4pSeKpqEiBMzK/siF1tkPBFifU+VH0e8L8+3n6/v52NwMnhPkoeHdDyLgl1tJnWJwIDAQAB";
    
    public String getGmoToken(CardInfo cardInfo) {
        ObjectMapper mapper = new ObjectMapper();
        try {

            //MockConfiguration config = MockConfiguration.getInstance(cardInfo.getEnvironment());

            Map<String, String> map = new HashMap<>();
            map.put("cardNo", cardInfo.getCardNo());
            map.put("expire", cardInfo.getExpire());
            String cardInfoJson = mapper.writeValueAsString(map);
            System.out.println(cardInfoJson);

            byte[] buffer = Base64.getDecoder().decode(PG_PUBLIC_KEY.getBytes());
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(buffer);
            KeyFactory keyFactory;
            keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = keyFactory.generatePublic(keySpec);
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encryptedByte = cipher.doFinal(cardInfoJson.getBytes());
            String encryptedCardInfo = Base64.getEncoder().encodeToString(encryptedByte);

            Map<String, String> formParamMap = new HashMap<>();
            formParamMap.put("Encrypted", encryptedCardInfo);
            formParamMap.put("ShopID", "tshop00019316");
            formParamMap.put("KeyHash", "59e3e2708cdd699bfc9d3e8029350b4704c43591b52992f428190ee069cebcc1");

            final FormBody.Builder formBuilder = new FormBody.Builder();
            formParamMap.forEach(formBuilder::add);
            okhttp3.RequestBody requestBody = formBuilder.build();

            Request request = new Request.Builder()
            	//.url("https://esb.apps.pre-prod.on-prem.axa-direct-jp.intraxa/esb/gmopg/ext/api/credit/getToken")
               .url(HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "ESB") + "/esb/gmopg/ext/api/credit/getToken")
//            		.url("https://esb-iat.apps.dev.aws.axa-direct-jp.intraxa/esb/gmopg/ext/api/credit/getToken")
                // .url("https://pt01.mul-pay.jp/ext/api/credit/getToken")
                .post(requestBody)
                .build();

            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .build();

            try (Response response = okHttpClient.newCall(request).execute()) {
                int responseCode = response.code();
                System.out.println("responseCode: " + responseCode);

                if (!response.isSuccessful()) {
                    System.out.println("error!!");
                }
                if (response.body() != null) {
                    String token = response.body().string();
                    System.out.println("body: " + token);

                    try {
                        Map ret = mapper.readValue(token, HashMap.class);
                        return (String) ((List) ((Map) ret.get("tokenObject")).get("token")).get(0);

                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            return null;
        } catch (JsonProcessingException | NoSuchAlgorithmException | InvalidKeySpecException | NoSuchPaddingException | InvalidKeyException
                | IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException();
        }
    }


    public void payCreditCard(String submissionNumber, String version, String creditCardNumber, String cardHolderType, String amount)
        throws WsiAuthenticationException_Exception,
        ValidationException_Exception,
        com.adj.axa.gw.bc.WsiAuthenticationException_Exception {

       // MockConfiguration config = MockConfiguration.getInstance(req.getEnvironment());

        CardInfo cardInfo = new CardInfo();
        cardInfo.setCardNo(creditCardNumber);
        cardInfo.setExpire("201501");
        //cardInfo.setEnvironment(req.getEnvironment());
        String token = getGmoToken(cardInfo);
        System.out.println(token);

        GmoAPIPortType port = PortGenerator.generatePortWithBasicAuth(
            GmoAPIPortType.class,
            //config.getPcUrl() +
            HTML.properties.getProperty(HTML.properties.getProperty("Region")+ "PC") +
                    "/pc/ws/com/axa/adj/gw/pc/integration/gmo/api/GmoAPI?WSDL",
           // config.getPcUserId(),
                    "su",
           // config.getPcPassword());
                    "0gw1");

        PayWithCreditCardForSubmissionInputDTO dto = new PayWithCreditCardForSubmissionInputDTO();
        dto.setBranchNumber(1);
        dto.setPaymentIdentifier(submissionNumber + "01");
        dto.setPaymentMethod("1_LUMPSUM");
        dto.setSubmissionNumber(submissionNumber);
        //dto.setBranchNumber(Integer.parseInt("01"));
        dto.setBranchNumber(Integer.parseInt(version));
        dto.setToken(token);
        dto.setCardHolderType(CardHolderType_Adj.fromValue(cardHolderType));
        port.payWithCreditCardForSubmission(dto);

        System.out.println(String.format("payCreditCard: %s\t%s", submissionNumber, amount));
        //System.out.println(String.format("payCreditCard: %s", req.toString()));
    }

    
    
    public static class CardInfo {
        private String cardNo;
        private String expire;
        private String environment;

        public String getCardNo() {
            return cardNo;
        }

        public void setCardNo(String cardNo) {
            this.cardNo = cardNo;
        }

        public String getExpire() {
            return expire;
        }

        public void setExpire(String expire) {
            this.expire = expire;
        }

        public String getEnvironment() {
            return environment;
        }

        public void setEnvironment(String environment) {
            this.environment = environment;
        }

    }

    
  public static void main(String[] args) {
        try {
        
          //new PaymentUtil().payCvsOffline("000224841", "251340");
         // new PaymentUtil().payCreditCard("000000891", "4111111111111111", "policyholder", "57790");
        	//new PaymentUtil().payCvsOffline("000004051", "243470");
          new PaymentUtil().payCvsOnline("000012861", "194140", "FM2458665508");
          Thread.sleep(10000);  
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
  
  
}
