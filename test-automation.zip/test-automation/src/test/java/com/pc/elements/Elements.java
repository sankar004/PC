/**
 * @ClassPurpose Object repository
 * @Scriptor All
 * @ReviewedBy
 * @ModifiedBy All
 * @LastDateModified 02/20/2019
 */
package com.pc.elements;

import java.util.HashMap;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
public class Elements
{
		public static String sheetname = "Elements";
		private  HashMap<String,By> hm = new HashMap<String,By>();  
		static Logger logger =Logger.getLogger(sheetname);
		public Elements()
		{	
			
			//GW Profiler
			hm.put("eleGWProfilertab", By.xpath("//*[text()= 'Guidewire Profiler']"));
			hm.put("chkStackTraceTracking", By.xpath("//*[text()= 'Stack Trace Tracking']/ancestor::td[1]/preceding-sibling::td//div/img"));
			hm.put("btnEnableGWProfiler", By.id("ProfilerPopup:ProfilerConfigurationScreen:EnableWebProfilerPanelSet:TurnProfilingOn-btnInnerEl"));
			hm.put("btnDisableGWProfiler", By.id("ProfilerPopup:ProfilerConfigurationScreen:EnableWebProfilerPanelSet:TurnProfilingOff-btnInnerEl"));
			hm.put("btnDownload", By.id("ProfilerAnalysisPopup:ProfilerAnalysisScreen:ProfilerAnalysisPanelSet:ProfilerResultsCV_tb:DownloadButton-btnInnerEl"));
			//hm.put("eleActionServertools", By.id("ServerTools:InternalToolsMenuActions-btnEl"));
			//hm.put("eleReturntoPC", By.id("ServerTools:InternalToolsMenuActions:ReturnToApp-textEl"));
			
			
			
			//Common Objects Across all the Screens
			hm.put("btnOK_PC", By.xpath("//span[text()='OK']"));		
			hm.put("edtLastNamePhonetic_PC", By.xpath("//input[contains(@id,'GlobalPersonNameInputSet:LastName-inputEl')]"));
			hm.put("edtFirstNamePhonetic_PC", By.xpath("//input[contains(@id,'GlobalPersonNameInputSet:FirstName-inputEl')]"));
			hm.put("edtLastName_PC", By.xpath("//input[contains(@id,'GlobalPersonNameInputSet:LastNameKanji-inputEl')]"));
			hm.put("edtFirstName_PC", By.xpath("//input[contains(@id,'GlobalPersonNameInputSet:FirstNameKanji-inputEl"));
			hm.put("edtDateOfBirth_PC", By.xpath("//input[contains(@id,'DateOfBirth-inputEl')]"));			
			hm.put("selMaritalStatus_PC", By.xpath("//input[contains(@id,'MaritalStatus-inputEl')]"));			
			hm.put("selPrimaryPhone_PC", By.xpath("//input[contains(@id,'PrimaryPhone-inputEl')]"));			
			hm.put("edtHomePhone_PC", By.xpath("//input[contains(@id,'HomePhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));			
			hm.put("edtWorkPhone_PC", By.xpath("//input[contains(@id,'WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));			
			hm.put("edtMobilePhone_PC", By.xpath("//input[contains(@id,'CellPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));			
			hm.put("edtFaxPhone_PC", By.xpath("//input[contains(@id,'FaxPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));
			hm.put("edtPrimaryEmail_PC", By.xpath("//input[contains(@id,'EmailAddress1-inputEl')]"));
			hm.put("edtAddressSearchPostalOrText_PC", By.xpath("//input[contains(@id,'AgrexSearch-inputEl')]"));
			//hm.put("eleAutoFillAddress_PC", By.xpath("//span[contains(@id,'AddressCodeSearch-btnInnerEl')]"));
			hm.put("btnAutoFillAddressIcon_PC", By.xpath("//a[contains(@id,'AutoFillIcon')]"));
			hm.put("btnSelectFirstMatchAddress_PC", By.xpath("//span[text()='Address' or text()= '住所']/following::tr[1]/td[1]/div/a"));
			hm.put("btnAddressCodeSearch_PC", By.xpath("//span[contains(@id,'AddressCodeSearch-btnInnerEl')]"));
			hm.put("edtAddress2Phonetic_PC", By.xpath("//input[contains(@id,'AddressLine2-inputEl')]"));			
			
			//Pc Menu
			hm.put("melPolicy", By.id("TabBar:PolicyTab-btnInnerEl"));
			hm.put("melACCOUNT", By.id("TabBar:AccountTab-btnInnerEl"));
			//hm.put("elepolicymenu", By.id("TabBar:PolicyTab-btnInnerEl"));
			hm.put("edtSerachsubNumber", By.xpath("//input[@id='TabBar:PolicyTab:PolicyTab_SubmissionNumberSearchItem-inputEl']"));
			hm.put("edtSerachAccountNumber", By.xpath("//input[@id='TabBar:AccountTab:AccountTab_AccountNumberSearchItem-inputEl']"));
			hm.put("eleSearchPolicyicon", By.id("TabBar:PolicyTab:PolicyTab_SubmissionNumberSearchItem_Button"));
			hm.put("eleSearchAccounticon", By.id("TabBar:AccountTab:AccountTab_AccountNumberSearchItem_Button"));
			hm.put("eleSearchMenu", By.id("TabBar:SearchTab-btnInnerEl"));
			hm.put("eleAccounts", By.cssSelector("td[id='Search:MenuLinks:Search_AccountSearch']>div>span"));
			
			//login Screen Objects
			hm.put("edtUserName", By.id("Login:LoginScreen:LoginDV:username-inputEl"));
			hm.put("edtPassword", By.id("Login:LoginScreen:LoginDV:password-inputEl"));
			hm.put("eleLogin", By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
			
			//Action Menu
			hm.put("eleDeskTop", By.id("TabBar:DesktopTab-btnInnerEl"));			
			hm.put("eleDeskTopAction", By.id("Desktop:DesktopMenuActions-btnInnerEl"));
			hm.put("elePolicyAction", By.id("PolicyFile:PolicyFileMenuActions-btnEl"));
			hm.put("eleDeskTopNewAccount", By.id("Desktop:DesktopMenuActions:DesktopMenuActions_CreateAnonymous:DesktopMenuActions_NewAccount-textEl"));
			hm.put("eleDeskTopNewAccount", By.id("Desktop:DesktopMenuActions:DesktopMenuActions_CreateAnonymous:DesktopMenuActions_NewAccount-textEl"));
			hm.put("eleCancelation", By.id("PolicyFile:PolicyFileMenuActions:PolicyFileMenuActions_NewWorkOrder:PolicyFileMenuActions_CancelPolicy-itemEl"));
			hm.put("eleChangePolicy", By.id("PolicyFile:PolicyFileMenuActions:PolicyFileMenuActions_NewWorkOrder:PolicyFileMenuActions_ChangePolicy-itemEl"));
			
			//Search Account - PC			
			hm.put("edtLastNamePhoneticSA", By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:LastName-inputEl"));
			hm.put("edtFirstNamePhoneticSA", By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:FirstName-inputEl"));
			hm.put("edtLastNameSA", By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:LastNameKanji-inputEl"));
			hm.put("edtFirstNameSA", By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:FirstNameKanji-inputEl"));
			hm.put("btnSearch", By.id("NewAccount:NewAccountScreen:NewAccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"));
			hm.put("btnCreateNewAccount", By.id("NewAccount:NewAccountScreen:NewAccountButton-btnInnerEl"));
			hm.put("eleCreateNewAccountPerson", By.id("NewAccount:NewAccountScreen:NewAccountButton:NewAccount_Person-itemEl"));
			hm.put("edtPhone", By.cssSelector("input[id='AccountSearch:AccountSearchScreen:AccountSearchDV:Phone-inputEl']"));
			hm.put("btnAccountSearch", By.id("AccountSearch:AccountSearchScreen:AccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"));
			hm.put("eleFirstAccountNumber", By.id("AccountSearch:AccountSearchScreen:AccountSearchResultsLV:0:AccountNumber"));
			
			//language switch
			hm.put("eleSettings", By.id(":TabLinkMenuButton-btnIconEl"));
			hm.put("eleInternational", By.id("TabBar:LanguageTabBarLink-textEl"));
			hm.put("eleLanguage", By.id("TabBar:LanguageTabBarLink:languageSwitcher-itemEl"));
			hm.put("eleEnglish", By.id("TabBar:LanguageTabBarLink:languageSwitcher:2:langs-itemEl"));
			hm.put("eleJapanese", By.id("TabBar:LanguageTabBarLink:languageSwitcher:3:langs-textEl"));
			
			//logout
			hm.put("eleLogout", By.id("TabBar:LogoutTabBarLink-itemEl"));
			
			//Search Policy Screen
			hm.put("selSearchFor", By.xpath("//input[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:SearchFor-inputEl']"));
			hm.put("edtSubmissionNumber", By.xpath("//input[@id='PolicySearch:PolicySearchScreen:DatabasePolicySearchPanelSet:PolicySearchDV:SubmissionNumber-inputEl']"));
			
			
			//New Account Screen - PC			
			hm.put("edtLastNamePhoneticNA", By.id("CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:LastName-inputEl"));
			hm.put("edtFirstNamePhoneticNA", By.id("CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:FirstName-inputEl"));
			hm.put("edtLastNameNA", By.id("CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:LastNameKanji-inputEl"));
			hm.put("edtFirstNameNA", By.id("CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:FirstNameKanji-inputEl"));
			hm.put("edtHomePhone", By.id("CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:HomePhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl"));
			hm.put("edtWorkPhone", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:Phone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
			hm.put("edtMobilePhone", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:CellPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
			hm.put("edtDateofBirth", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:DateOfBirth-inputEl']"));
			hm.put("edtPrimaryEmail", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:EmailAddress1-inputEl']"));
			hm.put("edtDateofbirth", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:DateOfBirth-inputEl']"));
			hm.put("lstPrimayPhone", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:PrimaryPhone-inputEl']"));
			hm.put("edtAddressSearch", By.xpath("//*[contains(@id , 'AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AgrexSearch-inputEl')]"));
			hm.put("eleAddressSearch", By.xpath("//*[contains(@id , 'AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AgrexSearch-inputEl')]//following::div[1]"));
			hm.put("btnSelectAddress", By.id("AgrexAddressSelectPopup:0:_Select"));
			hm.put("lstAddressType", By.xpath("//input[contains(@id , ':AddressType-inputEl')]"));
			hm.put("btnUpdate", By.xpath("//*[text()='pdate' or text() = '更新']"));
			hm.put("eleDeskTopActionsNewSubmission", By.id("Desktop:DesktopMenuActions:DesktopMenuActions_CreateAnonymous:DesktopMenuActions_NewSubmissionAnonymous-textEl")); 
			hm.put("edtAddress2(phonetic)", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine2-inputEl']"));
			hm.put("edtAddress3", By.xpath("//input[@id='CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine3-inputEl']"));
			
			
			
			//Account File Summary
			hm.put("eleCreateNewAccountNumber", By.xpath("//div[@id='AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_BasicInfoDV:AccountNumber-inputEl']"));
			hm.put("eleAccountAction", By.id("AccountFile:AccountFileMenuActions-btnEl"));
			hm.put("eleNewSubmission", By.id("AccountFile:AccountFileMenuActions:AccountFileMenuActions_Create:AccountFileMenuActions_NewSubmission-itemEl"));
			hm.put("edgCampaignCode", By.xpath("//input[@id='NewSubmission:NewSubmissionScreen:campaignCode-inputEl']"));
			hm.put("lsgCampaignCode", By.id("NewSubmission:NewSubmissionScreen:campaignCode-trigger-picker"));
			hm.put("lstProducerCode", By.xpath("//input[@id='NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:ProducerSelectionInputSet:ProducerCode-inputEl']"));
			hm.put("btnSelectlob", By.id("NewSubmission:NewSubmissionScreen:ProductOffersDV:ProductSelectionLV:0:addSubmission"));
			hm.put("edtShopCode", By.xpath("//input[@id='NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:AdditionalInformationInputSet:Shopcode-inputEl']"));
			hm.put("edtCustomerID", By.xpath("//input[@id='NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:AdditionalInformationInputSet:CustomerID-inputEl']"));
			hm.put("eleAccountName", By.id("AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_BasicInfoDV:Name-inputEl")); 
			hm.put("edtEmployeenumber", By.xpath("//input[@id='NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:AdditionalInformationInputSet:EmployeeNumber-inputEl']"));
			hm.put("eleContactstab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Contacts' or text() = '連絡先']"));
			hm.put("eleEditContacts", By.id("AccountFile_Contacts:AccountFile_ContactsScreen:AccountContactsLV:0:EditButton"));
			hm.put("eleAddressTab", By.id("EditAccountContactPopup:ContactDetailScreen:AccountContactCV:AddressesCardTab-btnInnerEl"));
			hm.put("btnAdd", By.id("EditAccountContactPopup:ContactDetailScreen:AccountContactCV:AddressesPanelSet:AddressesLV_tb:Add-btnInnerEl"));
			
			
			
			//Qualification questions
			hm.put("eleQualificationquestions", By.id("SubmissionWizard:SubmissionWizard_PreQualificationScreen:ttlBar"));
			
			//hm.put("btnNextSubmission", By.id("SubmissionWizard:Next-btnInnerEl"));
			hm.put("btnNextSubmission", By.xpath("//*[text()='次へ >' or text() = 'Next >']"));
			hm.put("btnNext", By.xpath("//*[text()='次へ >' or text() = 'Next >']"));
			
			//Previous Policy Information
			hm.put("btnPPEditPolicyTransaction",By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JobWizardToolbarButtonSet:EditPolicy-btnInnerEl"));
			hm.put("btnEditPopUpOK", By.xpath("//span[text()='OK']/parent::span"));
			hm.put("elePreviousPolicyInformation", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:ttlBar"));
			hm.put("edgEffectiveDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:PolicyInfoInputSet:EffectiveDate-inputEl']"));
			hm.put("rdo1stpurchase", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:ContractType_option1-inputEl"));
			hm.put("rdoSwithPurchase", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:ContractType_option2-inputEl"));
			hm.put("rdoInterruptioncertification", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:ContractType_option3-inputEl"));
			hm.put("lstSuspendCategory", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:SuspendCovCategory-inputEl']"));
			hm.put("selReasonofinterruption", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:ReasonOfInterruption-inputEl']"));
			hm.put("edtVehicleacquisitiondate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:VehicleAcquisitionDate-inputEl']"));
			hm.put("chksucceednonfleetgrade", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:NonFleetGradeSuccessionSpecialRule:NonFleetGradeApplicable-inputEl']"));
			hm.put("selReasonforNonFleetGradeSuccession", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:NonFleetGradeSuccessionSpecialRule:NonFleetSuccessionReason-inputEl']"));
			hm.put("selPreviousPolicyCarrier", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousCoverageCarrier-inputEl']"));
			hm.put("selDriverRelationship", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:DriversRelationship-inputEl']"));
			hm.put("selNonFleetgrade", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PrevNonFleetGrade-inputEl')]"));
			hm.put("lstAccidentIndex", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousAccidentIndex-inputEl']"));
			//hm.put("edgPPEffectiveDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:OtherPolicyEffectiveDate-inputEl']"));
			hm.put("edtPPEffectiveDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:OtherPolicyEffectiveDate-inputEl']"));
			hm.put("edtInterruptiondateofpreviouspolicy", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:SuspendedDate-inputEl']"));
			//hm.put("edgPPExpirationDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:OtherPolicyExpirationDate-inputEl']"));
			hm.put("edtPPExpirationDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:OtherPolicyExpirationDate-inputEl']"));
			//hm.put("edgPPEndDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousPolicyEndDate-inputEl']"));
			hm.put("edtPPEndDate", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousPolicyEndDate-inputEl']"));
			hm.put("edtGrade3Accident", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousGrade3DownAccident-inputEl')]"));
			hm.put("edgGrade3Accident", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousGrade3DownAccident-inputEl']"));
			hm.put("edtGrade1Accident", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousGrade1DownAccident-inputEl']"));
			hm.put("edtNoofClaims", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:NumberOfClaimsOf0BMDown-inputEl']"));
			hm.put("edtPPNumber", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousPolicyNumber-inputEl']"));
			hm.put("edtPPBranchNumber", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousPolicyBranchNumber-inputEl']"));
			hm.put("selPPOwnDamage", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousOwnDamage-inputEl']"));
			hm.put("lstPPOwnDamage", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousOwnDamage-inputEl']"));
			hm.put("eleSystemDate", By.xpath("//*[text()='現在の日付：' or text()='Current Date:']/following-sibling::span"));
			hm.put("rdoDocumentCommunication", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:PolicyInfoInputSet:documentCommunicationForbidden_true-inputEl']"));
			hm.put("rdoMultiplevehiclediscount", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:OtherPolicyQuestion_true-inputEl']"));
			//hm.put("lstAccidentIndex", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:PreviousAccidentIndex-inputEl']"));
			hm.put("eleSideMenuPreviousPolicyInfo", By.cssSelector("td[id='SubmissionWizard:LOBWizardStepGroup:JPPAPreviousPolicy']>div>span"));
			hm.put("valWarningMessage", By.className("message"));
			hm.put("valInfoMessage", By.className("message"));
			hm.put("selInsuredRelation", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyInsuredRelation-inputEl']"));
            hm.put("selOwnerRelation", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyOwnerRelation-inputEl']"));
            hm.put("selVehicleUseType", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyVehicleUseType-inputEl']"));
            hm.put("selInsurer", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyExistingCoverageCarrier-inputEl']"));
            hm.put("edtPolicyNumber", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyNumber-inputEl']"));
            hm.put("edtPolicySubNumber", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyNumberSubNumber-inputEl']"));
            hm.put("selNonFleetGrade", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:otherPolicyNonFleetGrade-inputEl']"));
            hm.put("edtStartDate", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:EffectiveDate-inputEl']"));
            hm.put("edtEndDate", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:JPPAPreviousPolicyDetails_AdjInputSet:ExpirationDate-inputEl']"));
            hm.put("valAccidentIndex", By.cssSelector("div[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:AccidentIndex-inputEl']"));
            hm.put("valNonFleetGrade", By.cssSelector("div[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:NonFleetGrade-inputEl']"));
            hm.put("valBonusGradeMessage", By.cssSelector("div[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAPreviousPolicy_AdjScreen:JPPAPreviousPolicy_AdjDV:JPPAPreviousPolicyInputSet:realContractType-inputEl']"));
            hm.put("btnClearValidationMessage", By.id("WebMessageWorksheet:WebMessageWorksheetScreen:WebMessageWorksheet_ClearButton-btnInnerEl")); 
            hm.put("eleTransactionNo", By.cssSelector("span[id='SubmissionWizard:JobWizard_AdjInfoBar:JobNumber-btnInnerEl']>span:nth-child(2)"));
            
            
			//Vehicle & Driver & Policy information
			//hm.put("eleVehiclDriverPolicyinformation", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:ttlBar"));
			hm.put("eleVehiclDriverPolicyinformation", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:ttlBar')]"));
			hm.put("lstInsuranceType", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:ProductSubtype-inputEl')]"));
			hm.put("edtModelCode", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:ModeCodelID-inputEl')]"));
			hm.put("eleModleCodeSearch", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:ModeCodelID:SelectModeCodelID')]"));
			hm.put("btnSelectModel", By.id("JPPAVehicleSearchPopup:VehicleSearchPopupScreen:JPPAVehicleSearchResult:JPPAMakerModelLV:0:_Select"));	
			//hm.put("sel1stregdate1", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPAVehicleDates_AdjInputSet:RegAndManufacturedDate:VehicleDeliveryDate:JICYearMonthInputSet:yearDropdown:yearDropdown_Arg-inputEl']"));
			//hm.put("sel1stregdate2", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPAVehicleDates_AdjInputSet:RegAndManufacturedDate:VehicleDeliveryDate:JICYearMonthInputSet:monthDropdown:monthDropdown_Arg-inputEl']"));
			hm.put("chkSideCarattached", By.xpath("//*[text() = 'Side car' or text() = '側車はついていますか?']"));
			hm.put("sel1stregdate1", By.xpath("//input[contains(@id,':yearDropdown:yearDropdown_Arg-inputEl')]"));
			hm.put("sel1stregdate2", By.xpath("//input[contains(@id,':monthDropdown:monthDropdown_Arg-inputEl')]"));
			hm.put("edtVIN", By.xpath("//input[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:Vin-inputEl')]"));	
			hm.put("zedVIN", By.xpath("//input[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:Vin-inputEl')]"));
			hm.put("selVehicleOwnerafterchange", By.xpath("//input[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnersRelationAfterPolicyChangeID-inputEl')]"));
			hm.put("selVehicleOwner", By.xpath("//input[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:HolderOwnerRelationship-inputEl')]"));
			hm.put("selVehicleUser", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:HolderUserRelationship-inputEl']"));
			hm.put("eleVehicleType", By.xpath("//div[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:VehicleClassification-inputEl')]"));
			hm.put("selLicensePlate1", By.xpath("//*[text() = 'License Plate' or text() = '登録番号']//following::div[1]//tr//td[1]//div"));
			//hm.put("selLicensePlate1", By.xpath("//*[@data-qtip='Vehicle registration office' or @data-qtip='陸運支局']"));
			
			hm.put("edtLicensePlate1", By.xpath("//*[text() = 'License Plate' or text() = '登録番号']//following::div[1]//tr//td[1]//div"));
			hm.put("eleLicensePlate2", By.xpath("//*[text() = 'License Plate'  or text() = '登録番号']//following::div[1]//tr//td[2]"));
			//hm.put("edtLicensePlate2", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[3]//input"));
			hm.put("edtLicensePlate2", By.xpath("//*[@data-qtip='Vehicle classification code' or @data-qtip='分類番号']"));
			hm.put("edtLicensePlatebike3", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[4]//input"));
			//hm.put("edtLicensePlate3", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV')]//div[1]//input[1]"));
			hm.put("edtLicensePlate3", By.xpath("//*[@data-qtip='Vehicle use type (Hiragana)' or @data-qtip='ひらがな']"));
			//hm.put("edtLicensePlate4", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV')]//div[1]//input[1]"));
			hm.put("edtLicensePlate4", By.xpath("//*[@data-qtip='Vehicle registration number' or @data-qtip='番号']"));
			
			hm.put("eleLicensePlateMoped1", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[1]//tr//td[1]"));
			hm.put("edtLicensePlateMoped1", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[1]//input"));
			hm.put("edtLicensePlateMoped2", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[3]//input"));
			hm.put("edtLicensePlateMoped3", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[4]//input"));
			hm.put("edtLicensePlateMoped4", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[5]//input"));
			
			hm.put("eleBikeALicensePlate1", By.xpath("//*[text() = 'License Plate'  or text() = '登録番号']//following::div[1]//tr//td[1]"));
			hm.put("edtBikeALicensePlate1", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[1]//input"));
			//hm.put("selBikeALicensePlate2", By.xpath("//*[text() = 'License Plate'  or text() = '登録番号']//following::div[1]//tr//td[2]")); 
			hm.put("selBikeALicensePlate2", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[3]//input"));
			hm.put("eleBikeALicensePlate3", By.xpath("//*[text() = 'License Plate'  or text() = '登録番号']//following::div[1]//tr//td[3]"));
			hm.put("edtBikeALicensePlate3", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[4]//input"));
			hm.put("edtBikeALicensePlate4", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:JPPALicensePlate_AdjLV-body')]//div[5]//input"));
			
			hm.put("btnJikenkyoCheck", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:jikenkyocheck-btnInnerEl')]"));
			hm.put("valJikenkyoMessage", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:RegistrationCertificateAcknowlegement')]"));
			hm.put("selUsage", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:MainPerpousOFUSageID-inputEl')]"));	
			hm.put("lstUsage", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:MainPerpousOFUSageID-inputEl')]"));
			hm.put("edtMileageofvehicle", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:annualmiles-inputEl')]"));
			hm.put("selMileage", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:MileageTypeID-inputEl')]"));	
			hm.put("edtDateofbirthdriver", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:DriverDOB-inputEl')]"));	
			//hm.put("edgDateofbirthdriver", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:DriverDOB-inputEl']"));
			hm.put("selColoroflicense", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:DriversLicenseColor-inputEl')]"));	
			hm.put("selPrefecture", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:State-inputEl']"));
			hm.put("edtActualenginesize", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:Displacement-inputEl']"));	
			hm.put("selCategorofenginesize", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:DisplacementClassification-inputEl']"));
			hm.put("selMake", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:bikeMake-inputEl']"));
			hm.put("edtVehiclename", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:ModelID-inputEl']"));
			hm.put("selTypeofvehicle", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:TypeOfVehicleID-inputEl')]"));
			hm.put("selUsageType", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:UsageTypeID-inputEl')]"));
			hm.put("edtDateofconfirmation", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:DateOfConfirmationID-inputEl')]"));
			hm.put("selInsuredRelationDriver", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:InsuredRelation-inputEl']"));
			hm.put("selGender", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:DriversGender-inputEl']"));
			//hm.put("selMultiplevehiclediscount", By.xpath("//input[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:HolderOwnerRelationship-inputEl']"));
			hm.put("eleVehInfoTab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Vehicle & Driver & Policy information' or text() = '契・記被・車両情報']"));
			hm.put("eleEditPolicyTransaction", By.xpath("//span[contains(@id,':EditPolicy-btnInnerEl')]"));
			hm.put("btnEditPolicyTransaction_PC", By.xpath("//span[contains(@id,':EditPolicy-btnInnerEl')]"));
			hm.put("btnVDSubmission", By.xpath("//span[@id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl']")); 
			//hm.put("btnModify", By.cssSelector("a[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:PolicyHolderInfo_AdjInputSet:ModifyPolicyHolderForAnonymous:ModifyPolicyHolderForAnonymousMenuIcon']>img"));
			hm.put("btnModify", By.xpath("//div[text()='Modify' or text()='修正']/parent::div/following-sibling::div/a"));
			//hm.put("eleSelectModify", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:PolicyHolderInfo_AdjInputSet:ModifyPolicyHolderForAnonymous:Modify-textEl"));
			hm.put("eleSelectModify", By.xpath("//span[text()='Modify' or text()='修正']/parent::a"));
			hm.put("selAEBequipment", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:AEBCustomerDeclaration-inputEl')]"));
			hm.put("btnASVOnlineConfirmation", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:JikenkyoASVCheck-btnInnerEl')]"));
			hm.put("valASVOnlineConfirmation", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:ASVJikenkyoResponse-inputEl')]"));
			hm.put("btnSelectMatching", By.id("DuplicateContactsPopup:DuplicateContactsScreen:ResultsLV:0:Select"));
			hm.put("btnCreateCustomVehicle", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:VehicleInformation_AdjInputSet:customvehicle"));
            hm.put("edtCustomVehicleModelCode", By.cssSelector("input[id='CustomVehicleCreation_AdjPopup:ModelCode-inputEl']"));
            hm.put("selCustomVehicleMake", By.cssSelector("input[id='CustomVehicleCreation_AdjPopup:Maker-inputEl']"));
            hm.put("edtCustomVehicleName", By.cssSelector("input[id='CustomVehicleCreation_AdjPopup:ModelID-inputEl']"));
            hm.put("selCustomVehicleType", By.cssSelector("input[id='CustomVehicleCreation_AdjPopup:VehicleClassification-inputEl']"));
            hm.put("selCustomVehicleTypeOfVehicle", By.cssSelector("input[id='CustomVehicleCreation_AdjPopup:TypeOfVehicleID-inputEl']"));
            hm.put("btnNameInsuredChange", By.cssSelector("a[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:ChangeJPPADriverInsuredButton:ChangeJPPADriverInsuredButtonMenuIcon']>img"));
            hm.put("eleNewPerson", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:JPPAPolicyDriverInfo_AdjInputSet:ChangeJPPADriverInsuredButton:JPPADriverPersonAdder-textEl"));
            hm.put("edtLastNamePhoneticND", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:LastName-inputEl"));
            hm.put("edtFirstNamePhoneticND", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl"));
            hm.put("edtLastNameND", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:LastNameKanji-inputEl"));
            hm.put("edtFirstNameND", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:FirstNameKanji-inputEl"));
            hm.put("edtDateOfBirthND", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:DateOfBirth-inputEl"));                
            hm.put("btnOkNewDriver", By.id("NewJPPAPolicyDriverPopup:ContactDetailScreen:ForceDupCheckUpdate-btnInnerEl"));
            /*hm.put("edtFamilyname(Character)", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerLastNameKana-inputEl']"));
            hm.put("edt1stName(Character)", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerFirstNameKana-inputEl']"));
            hm.put("edtFamilynameinKanji", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerLastNameKanji-inputEl']"));
            hm.put("edt1stnameinKanji", By.cssSelector("input[id='SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerFirstNameKanji-inputEl']"));
            */
            hm.put("edtFamilyname(Character)", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerLastNameKana-inputEl')]"));
            hm.put("edt1stName(Character)", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerFirstNameKana-inputEl')]"));
            hm.put("edtFamilynameinKanji", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerLastNameKanji-inputEl')]"));
            hm.put("edt1stnameinKanji", By.xpath("//*[contains(@id , 'LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JPPAVehiclePanelSet:CoverableListDetailPanel:JPPAVehicleCV:JPPAVehicleDetails_AdjDV:VehicleInformation:OwnerFirstNameKanji-inputEl')]"));
            

            
            
            
			// Common Global Input Set
            hm.put("edtGlobalLastNamePhonetic", By.xpath("//input[contains(@id,'ContactNameInputSet:GlobalPersonNameInputSet:LastName-inputEl')]"));
            hm.put("edtGlobalFirstNamePhonetic", By.xpath("//input[contains(@id,'ContactNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl')]"));
            hm.put("edtGlobalLastName", By.xpath("//input[contains(@id,'ContactNameInputSet:GlobalPersonNameInputSet:LastNameKanji-inputEl')]"));
            hm.put("edtGlobalFirstName", By.xpath("//input[contains(@id,'ContactNameInputSet:GlobalPersonNameInputSet:FirstNameKanji-inputEl')]"));
            hm.put("edtGlobalDateOfBirth", By.xpath("//input[contains(@id,'ContactNameInputSet:DateOfBirth-inputEl')]"));
            hm.put("selGlobalMaritalStatus", By.xpath("//input[contains(@id,'ContactNameInputSet:MaritalStatus-inputEl')]"));
            hm.put("selGlobalPrimaryPhone", By.xpath("//input[contains(@id,'ContactNameInputSet:PrimaryPhone-inputEl')]"));
            hm.put("edtGlobalHomePhone", By.xpath("//input[contains(@id,'ContactNameInputSet:HomePhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));
            hm.put("edtGlobalWorkPhone", By.xpath("//input[contains(@id,'ContactNameInputSet:WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));
            hm.put("edtGlobalMobilePhone", By.xpath("//input[contains(@id,'ContactNameInputSet:CellPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));
            hm.put("edtGlobalFaxPhone", By.xpath("//input[contains(@id,'ContactNameInputSet:FaxPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl')]"));
           
            
            
            
            //hm.put("eleTransactionNumber", By.id("AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_WorkOrdersLV:0:WorkOrderNumber"));
            
          //New Account Holder
            hm.put("edtNewAcLastNamePhonetic", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:LastName-inputEl']"));
            hm.put("edtNewAcFirstNamePhonetic", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl']"));
            hm.put("edtNewAcLastName", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:LastNameKanji-inputEl']"));
            hm.put("edtNewAcFirstName", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:FirstNameKanji-inputEl']"));
            hm.put("edtNewAcDateOfBirth", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:DateOfBirth-inputEl']"));
            hm.put("selNewAcMaritalStatus", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:MaritalStatus-inputEl']"));
            hm.put("selNewAcPrimaryPhone", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:PrimaryPhone-inputEl']"));
            hm.put("edtNewAcHomePhone", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:HomePhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
            hm.put("edtNewAcWorkPhone", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:WorkPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
            hm.put("edtNewAcMobilePhone", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:CellPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
            hm.put("edtNewAcFaxPhone", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:FaxPhone:GlobalPhoneInputSet:NationalSubscriberNumber-inputEl']"));
            hm.put("edtNewAcPrimaryEmail", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:EmailAddress1-inputEl']"));                        
            hm.put("edtNewAcAddressSearch", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AgrexSearch-inputEl']"));
            hm.put("eleAutoFillAddress", By.cssSelector("a[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AgrexSearch:AutoFillIcon']>img"));
            hm.put("btnSelectFirstMatchAddress", By.xpath("//span[text()='Address' or text()= '住所']/following::tr[1]/td[1]/div/a"));
            hm.put("btnAddressCodeSearch", By.id("ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressCodeSearch-btnInnerEl"));
            hm.put("edtAddress2Phonetic", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine2-inputEl']"));
            hm.put("selAddressType", By.cssSelector("input[id='ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressType-inputEl']"));
            hm.put("btnCheckForDuplicates", By.id("ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:CheckForDuplicates-btnInnerEl"));
            hm.put("btnNewAccountHolderOK", By.id("ChangeAnonymousAccountHolderToNewContact_AdjPopup:ContactDetailScreen:ForceDupCheckUpdate-btnInnerEl"));
            

            
			//Coverage section & quote result [side-by-side]
			
            hm.put("eleCoveragetab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Coverage section & quote result [side-by-side]' or text() = '補償内容']"));
            hm.put("eleCoveragesectionquoteresult", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:ttlBar')]"));	
			hm.put("selPhysicalDamageLimit", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:1:CoverageInputSet:CovPatternInputGroup:1:CovTermInputSet:OptionTermInput-inputEl')]"));
			hm.put("selDriverAgeConditioTerm", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPAVehicleConditions:JPPAVehicleConditions_ADJDV:0:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:TypekeyTermInput-inputEl')]"));
			hm.put("selDriverLimitationConditionTerm", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPAVehicleConditions:JPPAVehicleConditions_ADJDV:1:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:TypekeyTermInput-inputEl')]"));
			hm.put("chkselfIncurredPersonalAccident", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:2:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));	
			hm.put("chkPersonalInjury", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:4:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("selPersonalInjuryLimit", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:4:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:OptionTermInput-inputEl')]"));
			hm.put("rdoPIonlyDriverandpassenger", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:4:CoverageInputSet:CovPatternInputGroup:1:CovTermInputSet:BooleanTermInput_true-inputEl')]"));
			hm.put("chkDriverPassengersPersonalAccident", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:5:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("selDeathObstableDisabilitylimitLawyersExpenseSpecialClause", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:5:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:OptionTermInput-inputEl')]"));
			hm.put("chkOwnDamage", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:6:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("selCoveragetype", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:6:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:TypekeyTermInput-inputEl')]"));
            hm.put("selDeductible", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:6:CoverageInputSet:CovPatternInputGroup:1:CovTermInputSet:PackageTermInput-inputEl')]"));
            hm.put("selCarValue", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoverageMainGroupPanelRefID:JPPAVehicleCoverages_ADJDV:6:CoverageInputSet:CovPatternInputGroup:carValue-inputEl')]"));

			
			hm.put("chkEarthquakespecialclause", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPAPackegPlusCoveragGroupPanelRefID:JPPAVehicleLayerFamilyEarthquakeCoverages_ADJDV:0:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("chkFamilybikespecialclause", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPAPackegPlusCoveragGroupPanelRefID:JPPAVehicleLayerFamilyEarthquakeCoverages_ADJDV:1:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("chkLawyersExpenseSpecialClause", By.xpath("//*[text()='Lawyers Expense Special Clause' or text()= '弁護士費用等補償特約']/preceding-sibling::div//input"));
			hm.put("chkPDLTotalLossSpecialClause", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPAPackegPlusCoveragGroupPanelRefID:JPPAVehicleLayerFamilyEarthquakeCoverages_ADJDV:2:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("chkFamilyPlus", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoveragePanelPlusPackegesRefID:JPPAVehiclePlusPackagesCoveragesSets_ADJDV:0:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("chkLadiesPlus", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoveragePanelPlusPackegesRefID:JPPAVehiclePlusPackagesCoveragesSets_ADJDV:1:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
			hm.put("chkPetPlus", By.xpath("//*[contains(@id, 'LOBWizardStepGroup:LineWizardStepSet:JPPACoveragesScreen:JPPACoveragePanelPlusPackegesRefID:JPPAVehiclePlusPackagesCoveragesSets_ADJDV:2:CoverageInputSet:CovPatternInputGroup:_checkbox')]"));
						
			hm.put("lstPaymentScheduleV1", By.xpath("//input[contains(@id,'paymentScheduleIterator:0:PaymentScheduleName-inputEl')]"));
			hm.put("selPaymentScheduleV1", By.xpath("//input[contains(@id,'paymentScheduleIterator:0:PaymentScheduleName-inputEl')]"));
            hm.put("lstPaymentScheduleV2", By.xpath("//input[contains(@id,'paymentScheduleIterator:1:PaymentScheduleName-inputEl')]"));
            hm.put("selPaymentScheduleV2", By.xpath("//input[contains(@id,'paymentScheduleIterator:1:PaymentScheduleName-inputEl')]"));
            hm.put("lstPaymentScheduleV3", By.xpath("//input[contains(@id,'paymentScheduleIterator:2:PaymentScheduleName-inputEl')]"));
            hm.put("selPaymentScheduleV3", By.xpath("//input[contains(@id,'paymentScheduleIterator:2:PaymentScheduleName-inputEl')]"));
            hm.put("btnselectQuote1", By.xpath("//*[contains(@id, 'ActionButtonSetsId:0:SelectButtonId')]"));    
            hm.put("btnselectQuote2", By.xpath("//*[contains(@id, 'ActionButtonSetsId:1:SelectButtonId')]"));    
            hm.put("btnselectQuote3", By.xpath("//*[contains(@id, 'ActionButtonSetsId:2:SelectButtonId')]"));  

			//Risk Analysis	
			hm.put("eleRiskAnalysis", By.xpath("//*[contains(@id, ':Job_RiskAnalysisScreen:0')]"));	
			hm.put("eleClaimstab", By.id("PolicyChangeWizard:Job_RiskAnalysisScreen:RiskAnalysisCV:ClaimsCardTab-btnInnerEl"));
			
			
			//Policy contents confirmation
			//hm.put("elePolicycontentsconfirmation", By.id("SubmissionWizard:SubmissionWizard_PolicyReviewScreen:ttlBar"));
			hm.put("elePolicycontentsconfirmation", By.xpath("//*[contains(@id, 'Screen:ttlBar') and (text() = 'Policy Review' or text()='契約内容の確認')]"));	
			hm.put("btnQuote", By.xpath("//*[contains(@id, ':JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl')]"));	
			
			//Side-by-Side Quoting
			hm.put("eleSidebySideQuoting", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:ttlBar"));	
			hm.put("eleSidebySideQuotingTab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Side-by-Side Quoting' or text() = '並列見積']"));	
			hm.put("btnSave", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:SideBySideToolbarButtonSet:SaveAll-btnInnerEl"));	
			hm.put("lstPaymentSchedule", By.xpath("//input[@id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:JPPASideBySideTableLayoutDV:paymentScheduleIterator:0:PaymentScheduleName-inputEl']"));
			hm.put("selPaymentSchedule", By.xpath("//input[@id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:JPPASideBySideTableLayoutDV:paymentScheduleIterator:0:PaymentScheduleName-inputEl']"));
			hm.put("btnReCalculation", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:SideBySideToolbarButtonSet:QuoteAll-btnInnerEl"));
			hm.put("btnSelectQuote", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:JPPASideBySideTableLayoutDV:ActionButtonSetsId:0:SelectButtonId"));
			//hm.put("elePCCEditPolicyTransaction", By.id()); 
			hm.put("btnSendAllOfferings", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:SideBySideToolbarButtonSet:SendDocuments-btnInnerEl"));
			hm.put("btnSSQSendSelectedOffer", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:SideBySideToolbarButtonSet:SendDocuments:SendSelectedOfferNow-textEl"));
			//hm.put("valStatus", By.cssSelector("span[id='SubmissionWizard:JobWizardInfoBar:JobLabel-btnInnerEl']>span"));
			hm.put("valSendOfferErrMsg", By.cssSelector("div[class='message']"));
			hm.put("valASVDiscount", By.xpath("//div[@id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:discountsDV:2:discount_Adj-inputEl']"));
			hm.put("eleOwnDamage", By.cssSelector("input[id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:JPPASideBySideTableLayoutDV:vehicleSetsForConditions:0:vehLevelCoverages:6:vehCovRow:0:targetedCovTermId:SideBySideCovTermInputSet:covTermEnabledId-inputEl']"));
			hm.put("chkInternetDiscount", By.cssSelector("input[id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:discountsDV:0:discount_Adj-inputEl']"));	
			hm.put("chkMGMDiscount", By.cssSelector("input[id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:discountsDV:1:discount_Adj-inputEl']"));
			hm.put("chkASVDiscount", By.cssSelector("input[id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:JPPASideBySideScreen:discountsDV:2:discount_Adj-inputEl']"));
			
			//Quote Screen
			hm.put("eleQuotetab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Quote' or text() = '見積']"));	
			hm.put("eleSubmissionNumber", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:JobNumber-inputEl']"));
			hm.put("elePolicyPeriod", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:PolicyPeriod-inputEl']"));
			hm.put("eleTotalPremium", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_QuoteScreen:Quote_SummaryDV:TotalCost-inputEl']"));
			//Forms
			hm.put("eleFormsTittle", By.id("SubmissionWizard:FormsScreen:ttlBar"));			
			hm.put("eleInboundDocuments", By.id("EditForms_AdjPopup:ttlBar"));
			hm.put("btnEditForms", By.xpath("//*[contains(@id, 'FormsScreen:Forms_AdjDV_tb:edit-btnInnerEl')]"));	
			hm.put("chkDisclosurestatement", By.xpath("//input[@id='EditForms_AdjPopup:Forms_AdjDV:DisclosureStatement-inputEl']"));
			hm.put("chkContractintentionconfirmation", By.xpath("//input[@id='EditForms_AdjPopup:Forms_AdjDV:ContractIntentionConfirmation-inputEl']"));
			hm.put("selInterruptionCertification", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[1]//td[2]"));	
			hm.put("selApplicationForm", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[2]//td[2]"));	
			hm.put("selCarRegistration", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[3]//td[2]"));	
			hm.put("selDocStatus", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス' or text() = 'ステータス']//following::tr//td[2]"));	
			hm.put("selDocStatus1", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[1]//td[2]"));	
			hm.put("selDocStatus2", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[2]//td[2]"));	
			hm.put("selDocStatus3", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[3]//td[2]"));	
			hm.put("selDocStatus4", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[4]//td[2]"));	
			hm.put("selDocStatus5", By.xpath("//*[text() = 'Document Status' or text() = 'ステータス']//following::tr[5]//td[2]"));	
			hm.put("btnOkeditForms", By.id("EditForms_AdjPopup:Update-btnInnerEl"));	
			hm.put("eleForms", By.xpath("//*[contains(@id, 'FormsScreen:ttlBar')]"));	
			hm.put("eleFormstab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Forms' or text() = '契約手続／受領書類']"));
			hm.put("btnSendSelectedOfferOption", By.xpath("//*[contains(@id,'SendDocumentForVersion-btnInnerEl')]"));
			hm.put("eleSendSelectedOffer", By.xpath("//*[contains(@id,'SendDocumentForVersion:SendSelectedOfferNow-textEl')]/.."));
			//hm.put("btnSendSelectedOfferOption", By.id("SubmissionWizard:FormsScreen:JobWizardToolbarButtonSet:SendDocumentForVersion-btnInnerEl"));
			//hm.put("eleSendSelectedOffer", By.id("SubmissionWizard:FormsScreen:JobWizardToolbarButtonSet:SendDocumentForVersion:SendSelectedOfferNow-textEl"));
			//hm.put("btnSendSelectedOffer", By.id("SubmissionWizard:FormsScreen:JobWizardToolbarButtonSet:SendDocumentForVersion-btnInnerEl"));
			//hm.put("btnSendSelectedOfferOption", By.xpath("//*[contains(@id,'SendDocumentForVersion-btnInnerEl')]"));
			//hm.put("btnCreateandSend", By.id("NewDocumentFromTemplatePopup:NewDocumentFromTemplateScreen:CreateAndSend_Adj-btnInnerEl"));	
			hm.put("btnCreateandSend", By.id("NewDocumentFromTemplatePopup:NewDocumentFromTemplateScreen:Update-btnInnerEl"));
			hm.put("btnProcedureDocumentShipment", By.id("SubmissionWizard:FormsScreen:Forms_AdjDV_tb:SendDocument-btnInnerEl"));
			//hm.put("eleSendDocument", By.id("//*[contains(@id,'FormsScreen:Forms_AdjDV_tb:SendDocument:SendSelectedOfferNow-textEl')]"));
			hm.put("btnSendDocument", By.xpath("//*[contains(@id,'SendSelectedOfferNow-textEl')]"));
			hm.put("btnFormsBindOptions", By.id("SubmissionWizard:FormsScreen:JobWizardToolbarButtonSet:BindOptions-btnInnerEl"));	
			//hm.put("btnBindOptionsenabled", By.xpath("//*[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions-btnWrap' and @class ='x-btn-wrap x-btn-wrap-default-toolbar-small x-btn-arrow x-btn-arrow-right']"));
			hm.put("eleFormsIssuePolicy", By.id("SubmissionWizard:FormsScreen:JobWizardToolbarButtonSet:BindOptions:BindAndIssue-textEl"));
			hm.put("btnFormsPopUpIssuePolicyOK", By.xpath("//span[text()='OK']"));	
			hm.put("validationResults", By.xpath("//*[text()='Validation Results']"));
			
			//Payment
			hm.put("elePaymenttitle", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:ttlBar"));	
			hm.put("elePaymentTab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Payment' or text() = '支払']"));	
			hm.put("btnBindOptions", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions-btnInnerEl"));	
			hm.put("btnBindOptionsenabled", By.xpath("//*[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions-btnWrap' and @class ='x-btn-wrap x-btn-wrap-default-toolbar-small x-btn-arrow x-btn-arrow-right']"));
			hm.put("eleIssuePolicy", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions:BindAndIssue-textEl"));
			hm.put("btnIssueOK", By.xpath("//*[text()='OK']"));	
			hm.put("btnOK", By.xpath("//*[text()='OK']"));	
			hm.put("eleAccountnumber", By.xpath("//span[text() = 'Account #' or text() = 'アカウント番号']"));	
			hm.put("elepolicylink", By.xpath("//span[text() = 'Transaction #' or text() = 'トランザクション番号']//following::tr[1]//td[2]//div//a"));			
			hm.put("elePremiumalreadyreceived", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:BindSummaryDV:AmountPaid-inputEl']"));	
			hm.put("eleViewPolicy", By.xpath("//div[@id = 'JobComplete:JobCompleteScreen:JobCompleteDV:ViewPolicy-inputEl']"));
			hm.put("elePolicyNumber", By.xpath("//div[@id = 'PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_DatesDV:PolicyNumber-inputEl']"));	
			hm.put("elebillingpremiun", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:BindSummaryDV:Premium_AdjInputSet:BillingPremium-inputEl']"));
			hm.put("valBillingpremium", By.xpath("//*[contains(@id, 'BindSummaryDV:Premium_AdjInputSet:BillingPremium-inputEl')]"));
			hm.put("rdoOnlineCVS", By.xpath("//*[text()='Online convenience store payment' or text() = 'オンラインコンビニエンスストア払い']//preceding-sibling::input"));	
			hm.put("rdoCreditCard", By.xpath("//*[text()='Credit Card online ' or text() = 'クレジットカード払い']//preceding-sibling::input"));
			hm.put("rdoOfflineCVS", By.xpath("//*[text()='Convenience store payment' or text() = '払込票方式コンビニエンスストア払い']//preceding-sibling::input"));
			hm.put("selCVS", By.xpath("//input[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:ConvenienceStore-inputEl']"));
			hm.put("eleGererateToken", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:GenerateToken"));			
			hm.put("eleCVSToken", By.xpath("//div[@id='SubmissionWizard:SubmissionWizard_PaymentScreen:ReceiptNo-inputEl']"));	
			hm.put("btnMakePayment", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:BindSummaryDV:MakePaymentTotal"));
			hm.put("btnOkPayment", By.id("MakePayment_AdjPopup:Update-btnInnerEl"));
			//hm.put("btnSaveDraft", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:Draft-btnInnerEl"));
			hm.put("btnSaveDraft", By.xpath("//*[contains(@id,'Draft-btnInnerEl')]"));
			hm.put("btnSelectPaymentInstrument", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:PolicyPaymentInstruments_AdjDV:PaymentInstrumentsDDLV_tb:selectPaymentInstrument-btnInnerEl"));
			//hm.put("eleDisbursementtab", By.id("PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:policypaymentInstrumentInfoCV:disbursementCardTab-btnInnerEl"));
			hm.put("eleDisbursementtab", By.xpath("//*[contains(@id,'disbursementCardTab-btnInnerEl')]"));
			//hm.put("btnSelectDisbursementBankAcc", By.id("PolicyChangeWizard:PolicyChangeWizard_PaymentScreen:policypaymentInstrumentInfoCV:DisbursementPaymentInstrument_AdjDV:DisbursementInstrumentsDDLV_tb:selectDisbursementInstrument-btnInnerEl"));
			hm.put("btnSelectDisbursementBankAcc", By.xpath("//*[contains(@id,'selectDisbursementInstrument-btnInnerEl')]"));
			hm.put("btnNewPaymentInstrument", By.id("PaymentInstrumentSelection_AdjPopup:ContactPaymentInstruments_AdjDV:ContactBankAccounts_AdjLV_tb:newPaymentInstrument-btnInnerEl"));
			hm.put("rdoRegisterasDirectdebit_No", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:soth_false-inputEl']"));
			hm.put("lstBankAccountType", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:BankAccountType-inputEl']"));
			hm.put("edtBankAccountNumber", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:BankAccountNumber-inputEl']"));
			hm.put("edtBranchCode", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:BranchCode-inputEl']"));
			hm.put("selDepositType", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:DepositType-inputEl']"));
			hm.put("eleSelectBankAccount", By.id("PaymentInstrumentSelection_AdjPopup:ContactPaymentInstruments_AdjDV:ContactBankAccounts_AdjLV:0:_Select"));
			hm.put("selDDStatus", By.xpath("//input[@id='RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:usageType-inputEl']"));
			//hm.put("edtBankCode", By.id("BankBranchSearch_AdjPopup:BankBranchSearchScreen:bankCode-inputEl"));
			hm.put("eleBankBranchSearch", By.id("RegisterPaymentInstrument_AdjPopup:PaymentInstrumentInformation_AdjDV:BankBranchSearch"));
			hm.put("edtBankCode", By.xpath("//input[@id='BankBranchSearch_AdjPopup:BankBranchSearchScreen:bankCode-inputEl']"));
			hm.put("edtBranchCodebanksearch", By.xpath("//input[@id='BankBranchSearch_AdjPopup:BankBranchSearchScreen:branchCode-inputEl']"));
			hm.put("eleSelectBank", By.id("BankBranchSearch_AdjPopup:BankBranchSearchScreen:0:_Select"));
			hm.put("valBankAccount", By.xpath("//*[text()='Bank Account Number' or text()= '口座番号']//following::tr[1]//td[4]//div"));
			hm.put("eleReturnToPayment", By.id("PaymentInstrumentSelection_AdjPopup:__crumb__"));
			hm.put("eleSearchBank", By.id("BankBranchSearch_AdjPopup:BankBranchSearchScreen:SearchForBankBranches"));
			hm.put("btnSelectExistingCC", By.id("SubmissionWizard:SubmissionWizard_PaymentScreen:PolicyPaymentInstruments_AdjDV:toolbarCC:selectPaymentInstrument-btnInnerEl"));
            hm.put("btnSelectFirstCC", By.cssSelector("div[id='PaymentInstrumentSelection_AdjPopup:ContactPaymentInstruments_AdjDV:ContactBankAccounts_AdjLV-body'] > div > div > table:nth-child(1)>tbody>tr>td>div:nth-child(1)>a"));

            //Summary Screen
            hm.put("btnReverse", By.xpath("//*[contains(@id, 'ReverseChangeLink')]"));
            hm.put("eleSummarytab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Summary' or text() = '契約概要']"));
            
          //Account File Summary
			// eleTransactionNumber1 written for the scenario where the Pending Policy Transactions table has only one transaction. 
			hm.put("eleTransactionNumber", By.id("AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_WorkOrdersLV:0:WorkOrderNumber"));
			
			//decline quote
			hm.put("btnCloseOptions", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JobWizardToolbarButtonSet:CloseOptions-btnInnerEl"));
			hm.put("eleNotTaken", By.id("SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:JPPAVehicleScreen:JobWizardToolbarButtonSet:CloseOptions:NotTakenJob-textEl"));
			hm.put("selNotTakenReasonCode", By.cssSelector("input[id='NotTakenReasonPopup:RejectScreen:RejectReasonDV:RejectReason-inputEl']"));
			hm.put("btnNotTaken", By.id("NotTakenReasonPopup:RejectScreen:Update-btnInnerEl"));
			hm.put("eleViewSubmission", By.cssSelector("div[id='JobComplete:JobCompleteScreen:JobCompleteDV:ViewJob-inputEl']"));
			
			
			//Policy Documents
			hm.put("eleOutboundDocumentstab", By.xpath("//*[@class='x-grid-tree-node-leaf  x-grid-row']//span[text()='Outbound Documents' or text() = 'アウトバウンドドキュメント']"));	
			hm.put("valPackageType", By.xpath("//*[text() = 'Package Type']//following::tr[1]/td[1]/div"));
			//hm.put("tablepackage", By.xpath("//*[@id='SubmissionWizard:JobWizardToolsMenuWizardStepSet:Documents_AdjScreen:Package_AdjLV-body']//table//tbody"));
			hm.put("tablepackage", By.xpath("//div[contains(@id,'Documents_AdjScreen:Package_AdjLV-body')]/div/div/table/tbody"));
			//hm.put("tableListofDocuments", By.id("SubmissionWizard:JobWizardToolsMenuWizardStepSet:Documents_AdjScreen:documentsListPanelTab:panelId-table"));
			hm.put("tableListofDocuments", By.xpath("//*[contains(@id, 'Documents_AdjScreen:documentsListPanelTab:panelId-table')]"));
			//hm.put("btnDocumentSearch", By.id("PolicyFile_Documents:Documents_AdjScreen:DocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"));
			hm.put("btnDocumentSearch", By.xpath("//*[contains(@id,'DocumentSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search')]"));
			hm.put("eleForms", By.xpath("//*[contains(@id, 'FormsScreen:ttlBar')]"));
			
			//Start cancelation:
			hm.put("selSource", By.xpath("//input[@id='StartCancellation:StartCancellationScreen:CancelPolicyDV:Source-inputEl']"));
			hm.put("selReasonForCancellation", By.xpath("//input[@id='StartCancellation:StartCancellationScreen:CancelPolicyDV:Reason-inputEl']"));
			hm.put("edtSupplementaryNotes", By.xpath("//*[@id='StartCancellation:StartCancellationScreen:CancelPolicyDV:ReasonDescription-inputEl']"));
			hm.put("edgCancellationEffectiveDate", By.xpath("//input[@id='StartCancellation:StartCancellationScreen:CancelPolicyDV:CancelDate_date-inputEl']"));
			hm.put("btnStartCancellation", By.id("StartCancellation:StartCancellationScreen:NewCancellation-btnInnerEl"));			
			hm.put("eleCancelNow", By.id("CancellationWizard:CancellationWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions:CancelNow-textEl"));	
			hm.put("btnBindOptionsCancel", By.id("CancellationWizard:CancellationWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions-btnInnerEl"));
			hm.put("btnNextCancellation", By.id("CancellationWizard:Next-btnInnerEl"));	
			
			//ReWrite
			hm.put("eleRewriteFullTerm", By.id("PolicyFile:PolicyFileMenuActions:PolicyFileMenuActions_NewWorkOrder:StartRewriteMenuItemSet:RewriteFullTerm-textEl"));
			hm.put("eleIssueRewrite", By.id("RewriteWizard:RewriteWizard_QuoteScreen:JobWizardToolbarButtonSet:BindRewrite-btnInnerEl"));
			
			//Policy Change
			hm.put("selChangeType", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:ChangeType-inputEl']"));
			hm.put("edtChangeEffDate", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:StartPolicyChangeInputSet:EffectiveDate_date-inputEl']"));
			hm.put("edgChangeEffDate", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:StartPolicyChangeInputSet:EffectiveDate_date-inputEl']"));
			hm.put("btnNextChange", By.id("StartPolicyChange:StartPolicyChangeScreen:NewPolicyChange-btnInnerEl"));
			//hm.put("eleIssueChange", By.id("PolicyChangeWizard:PolicyChangeWizard_QuoteScreen:JobWizardToolbarButtonSet:BindPolicyChange-btnInnerEl"));
			hm.put("eleIssueChange", By.xpath("//*[contains(@id,'BindPolicyChange-btnInnerEl')]"));
			hm.put("rdochangethevehicle", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:StartPolicyChangeInputSet:ChangeOfVehicleID_true-inputEl']"));
			hm.put("selTypeofChange", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:StartPolicyChangeInputSet:TypeOFCarAfterChangeID-inputEl']"));
			hm.put("edtDateofvehicledelivery", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:StartPolicyChangeInputSet:DateOfVehicleDeliveredID-inputEl']"));
			hm.put("edtSupplementaryinformation", By.xpath("//input[@id='StartPolicyChange:StartPolicyChangeScreen:StartPolicyChange_AdjDV:Description-inputEl']"));
			
			 //E2E Validations
            //hm.put("submissionStatus", By.cssSelector("span[id='SubmissionWizard:JobWizardInfoBar:JobLabel-btnInnerEl']>span"));
            hm.put("submissionStatus", By.xpath("//*[@id='TabBar:DesktopTab-btnInnerEl']//following::span[@class='x-btn-inner x-btn-inner-default-toolbar-small'][2]//span"));
			
/**
*************************************************************************************************************************************			
******************************************** BillingCenter *************************************************************************
***********************************************************************************************************************************
***/
			
			
			
            //Account Page BC
            hm.put("eleAccountstabbc", By.id("TabBar:AccountsTab-btnInnerEl"));         
            hm.put("edtAccountNumberbc", By.xpath("//input[@id='Accounts:AccountSearchScreen:AccountSearchDV:AccountNumberCriterion-inputEl']"));
            hm.put("btnSearchbc", By.id("Accounts:AccountSearchScreen:AccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"));
            hm.put("eleAccountNumberbc", By.xpath("//*[text()='Segment' or text() = '区分']/following::tr[1]/td[3]/div/a"));              //Link
            
            //Account Page Verification BC
            hm.put("valAccountName", By.id("AccountSummary:AccountSummaryScreen:Name-inputEl"));
            hm.put("valAccountSince", By.id("AccountSummary:AccountSummaryScreen:AccountSinceValue"));                   
            hm.put("valPrimaryContact", By.id("AccountSummary:AccountSummaryScreen:PrimaryContact-inputEl"));
            hm.put("valAddress", By.id("AccountSummary:AccountSummaryScreen:Address-inputEl"));
            hm.put("valPhone", By.id("AccountSummary:AccountSummaryScreen:Phone-inputEl"));
            hm.put("valDelequencies", By.id("//*[contains(@id, 'AccountSummary:AccountSummaryScreen:description')]"));
            hm.put("valLateFees", By.id("AccountSummary:AccountSummaryScreen:LateFees-inputEl"));
            hm.put("eleLastPayment", By.xpath("//div[@id='AccountSummary:AccountSummaryScreen:LastPaymentReceived-inputEl']"));
            
            //Policy Number Verification BC
            hm.put("elePolicyNumberbc", By.xpath("//*[text()='Policy #']/following::tr[1]/td[4]/div/a")); //Policy Number link
            hm.put("valPolicyInsuredbc", By.id("PolicySummary:PolicySummaryScreen:Insured-inputEl")); //Insured
            hm.put("valPolicyLifetimebc", By.id("PolicySummary:PolicySummaryScreen:PolicySinceValue")); // Policy Lifetime
            hm.put("valPolicyEffectiveDatesbc", By.id("PolicySummary:PolicySummaryScreen:EffectiveDate-inputEl")); //Need to write function if required
            hm.put("valPolicyCancellationStatusbc", By.id("PolicySummary:PolicySummaryScreen:EffectiveDate-inputEl"));
            hm.put("valPolicyDelequenciesbc", By.id("PolicySummary:PolicySummaryScreen:DelinquencyDescription"));
            hm.put("valPolicyLastUpdate", By.xpath("//div[@id='PolicySummary:PolicySummaryScreen:PolicySummaryFinancialsDV:LastPayment-inputEl']"));
            
            //Producer Page BC
            hm.put("eleProducertabbc", By.id("TabBar:ProducersTab-btnInnerEl"));
            hm.put("edtProducercodesearchbc", By.id("Producers:ProducerSearchScreen:ProducerSearchDV:ProducerCodeCriterion-inputEl"));
            hm.put("eleSearchbuttonbc", By.id("Producers:ProducerSearchScreen:ProducerSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"));
            hm.put("eleProducerlinksearchbc", By.xpath("//*[text()='Address']/following::tr[1]/td[3]/div"));
            
            //Producer Summary Verification BC
            hm.put("valProducercodeverifybc", By.xpath("//*[text()='Producer Code']/following::tr[1]/td[2]/div"));
            hm.put("valProducernameverifybc", By.id("ProducerDetail:ProducerDetailScreen:ProducerDetailDV:Name-inputEl"));
            hm.put("valCommissionPlanbc", By.xpath("//*[text()='Commission Plan']/following::tr[1]/td[3]/div/a"));
            hm.put("eleActiveverifybc", By.xpath("//*[text()='Active?']/following::tr[1]/td[4]/div"));
            hm.put("elePlanRateverifybc", By.xpath("//*[text()='Plan Rate']/following::tr[1]/td[5]/div"));
  
        
            
            
/**
*************************************************************************************************************************************			
******************************************** Portal Q and B screens *************************************************************************
***********************************************************************************************************************************
***/
            
            
        //Portal Q and B
        hm.put("eleCarInsurance", By.linkText("自動車保険"));
        
        //BeforeQuote
        hm.put("dropdownDateStartCompensation", By.name("dateFieldsYear"));
        hm.put("dropdownDateStartCompensation", By.name("dateFieldsMonth"));
        hm.put("dropdownDateStartCompensation", By.name("dateFieldsDay"));

  		// Screen PortalHome
		hm.put("coverageOptionAuto", By.xpath("////*[contains(text(),'自動車保険') or contains(text(),'Auto Quote')]"));
																														 

		// Portal QB -  BeforeQuote
		hm.put("radioTypeOfContract", By.xpath("//div/ng-transclude/ul/li/label/span"));		
		//hm.put("languageMenu", By.xpath("//span[@class='gw-pl-dropdown-toggle ng-binding']"));
		hm.put("languageMenu", By.xpath("//span[contains(text(),'日本語')]"));		
		//hm.put("languageChange", By.xpath("//span[@class='gw-dropdown-menu-item ng-binding']"));
		hm.put("languageMenu", By.xpath("//span[contains(text(),'English')]"));
		
		hm.put("drpYearInceptionDate", By.name("dateFieldsYear"));
		hm.put("drpMonthInceptionDate", By.name("dateFieldsMonth"));
		hm.put("drpDayInceptionDate", By.name("dateFieldsDay"));

		hm.put("btnNextToVehicleDetails", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		// Portal QB - BeforeQuote - Interruption Certificate
		hm.put("btnInterruptionCertificateApplicable", By.cssSelector("button[class='adjEntrance-modal-footer-close-button']"));

		//Portal QB - Vehicle Details
		hm.put("drpFirstRegYear", By.xpath("//div[@id='firstRegistrationDate']/div/child::select[@name='dateFieldsYear']"));		
		hm.put("drpFirstRegMonth", By.xpath("//div[@id='firstRegistrationDate']/div/child::select[@name='dateFieldsMonth']"));
		hm.put("edtCarModelCode", By.id("input-Model-No"));		
		hm.put("btnMileage", By.cssSelector("input[name=distance]+p"));			
		hm.put("btnDiscountOptionYes",By.xpath("li[@class='adjInputted-item-column']/label/span[text()='Yes' or text()='はい']"));
		hm.put("btnDiscountOptionNo",By.xpath("li[@class='adjInputted-item-column']/label/span[text()='No' or text()='いいえ']"));
		//hm.put("btnNextVehicleDetails", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		hm.put("btnNextVehicleDetails", By.xpath("//span[text()='Next' or text() = '次へ']"));
		
		
		//Portal QB - Bike Info
		hm.put("drpBikeMake", By.id("maker"));
		hm.put("edtBikeModelName", By.id("input-suggestion"));
		hm.put("btnNextBikeInfo", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		//Portal QB - Current Insurance Info
		hm.put("drpPolicyTerm", By.id("previousPolicyTerm_Adj"));
		hm.put("drpMaturityYear", By.name("dateFieldsYear"));
		hm.put("drpMaturityMonth", By.name("dateFieldsMonth"));
		hm.put("drpMaturityDay", By.name("dateFieldsDay"));
		hm.put("drpChooseGrade", By.cssSelector("select[gw-pl-select='vehicle.previousNonFleetGrade.value']"));
		hm.put("drpAccidentPeriod", By.cssSelector("select[gw-pl-select='vehicle.previousAccidentIndex.value']"));
		hm.put("btnNextCurrentInsurance", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		// Portal QB - Main Driver Info screen		
		//hm.put("drpSelectPrefecture", By.xpath("//select[@id='prefecture_Adj']"));		
		hm.put("drpSelectPrefecture", By.id("prefecture_Adj"));		
		//hm.put("drpSelectBirthYear", By.xpath("//select[@name='dateFieldsYear']"));
		hm.put("drpSelectBirthYear", By.name("dateFieldsYear"));
		hm.put("drpSelectBirthMonth", By.name("dateFieldsMonth"));
		hm.put("drpSelectBirthDay", By.name("dateFieldsDay"));
		//hm.put("btnLimitDrivingYes", By.xpath("//span[@class='adjInputted-item-radio-button adjInputted-item-radio-button-toggle ng-binding ng-scope'][text() = 'はい' or text() = 'Yes']]"));
		hm.put("btnLimitDrivingYes", By.xpath("//*[text() = 'はい' or text() = 'Yes']"));
		//hm.put("btnLimitDrivingNo", By.xpath("//span[@class='adjInputted-item-radio-button adjInputted-item-radio-button-toggle ng-binding ng-scope'][text() = 'いいえ' or text() = 'No']"));
		hm.put("btnLimitDrivingNo", By.xpath("//*[text() = 'いいえ' or text() = 'No']"));
		hm.put("drpSelectYoungDriver", By.id("ageRangeValues"));
		hm.put("btnNextMainDriver", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		// Portal QB - Interruption Certificate Info
		hm.put("drpInsuranceStartDateYear", By.cssSelector("div[ng-model='vehicle.previousEffectiveDate.value']>div>select[name='dateFieldsYear']"));
		hm.put("drpInsuranceStartDateMonth", By.cssSelector("div[ng-model='vehicle.previousEffectiveDate.value']>div>div>select[name='dateFieldsMonth']"));
		hm.put("drpInsuranceStartDateDay", By.cssSelector("div[ng-model='vehicle.previousEffectiveDate.value']>div>select[name='dateFieldsDay']"));
		hm.put("drpCancelledDateYear", By.cssSelector("div[ng-model='vehicle.previousSuspendedDate_Adj.value']>div>select[name='dateFieldsYear']"));
		hm.put("drpCancelledDateMonth", By.cssSelector("div[ng-model='vehicle.previousSuspendedDate_Adj.value']>div>div>select[name='dateFieldsMonth']"));
		hm.put("drpCancelledDateDay", By.cssSelector("div[ng-model='vehicle.previousSuspendedDate_Adj.value']>div>select[name='dateFieldsDay']"));
		hm.put("drpSelectGrade", By.cssSelector("select[gw-pl-select='vehicle.previousNonFleetGrade.value']"));
		hm.put("drpAccidentPeriod", By.cssSelector("select[gw-pl-select='vehicle.previousAccidentIndex.value']"));
		hm.put("drpNoOfAccidents", By.cssSelector("select[gw-pl-select='vehicle.previousAccidentIndex.value']"));
		hm.put("drpRegistrationDateYear", By.cssSelector("div[ng-model='vehicle.vehicleAcquisitionDate_Adj.value']>div>select[name='dateFieldsYear']"));
		hm.put("drpRegistrationDateMonth", By.cssSelector("div[ng-model='vehicle.vehicleAcquisitionDate_Adj.value']>div>div>select[name='dateFieldsMonth']"));
		hm.put("drpRegistrationDateDay", By.cssSelector("div[ng-model='vehicle.vehicleAcquisitionDate_Adj.value']>div>select[name='dateFieldsDay']"));
		hm.put("btnNextInterruptionCertificate", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		
		//Portal QB - Quote Options page
		hm.put("buttonsBuyNow", By.xpath("//button[@class='adjTariffPcPlan__summary-apply-button']//*[text()='Buy Now' or text()='申し込み']"));
		hm.put("btnPopUpSelect", By.xpath("//button[text()='全てに該当しません']"));

		//Portal QB - Before Apply page	
		
		hm.put("edtVINPortal",By.xpath("//input[@ng-model='vehicle.vin.value']"));
		/*hm.put("btnContractorOwnerNo", By.xpath("//input[@name='yourself']/following-sibling::p//*[text()='No' or text()='いいえ']"));
		hm.put("btnContractorOwnerYes", By.xpath("//input[@name='yourself']/following-sibling::p//*[text()='Yes' or text()='はい']"));*/
		
		hm.put("edtLastNameKanji",By.cssSelector("#driverName02 > div > div > div:nth-child(1) > div > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > ng-transclude > input"));
		hm.put("edtFirstNameKanji",By.cssSelector("#driverName02 > div > div > div:nth-child(1) > div > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > ng-transclude > input"));
		hm.put("edtLastNamePhonetic",By.cssSelector("#driverName02 > div > div > div:nth-child(2) > div > div:nth-child(1) > div.has-error > div:nth-child(2) > ng-transclude > input"));
		hm.put("edtFirstNamePhonetic",By.cssSelector("#driverName02 > div > div > div:nth-child(2) > div > div:nth-child(2) > div.has-error > div:nth-child(2) > ng-transclude > input"));
		
		
		//hm.put("drpTransportOffice", By.xpath("//select[@id='licenseArea']"));
		hm.put("drpTransportOffice", By.id("licenseArea"));
		//hm.put("edtVehicleClassificationNo", By.xpath("//input[@id='licensPlate3number']"));
		hm.put("edtVehicleClassificationNo", By.id("licensPlate3number"));
		//hm.put("edtVehicleUseType", By.xpath("//input[@id='licensePlateKana']"));
		hm.put("edtVehicleUseType", By.id("licensePlateKana"));
		//hm.put("edtVehicleRegNo", By.xpath("//input[@id='licensePlate4number']"));
		hm.put("edtVehicleRegNo", By.id("licensePlate4number"));
		hm.put("edtMileagePortal", By.xpath("//*[@class='adjInput__unit'][text()='km']/preceding-sibling::input"));
		/*hm.put("drpConfirmationYear", By.xpath("//select[@name='dateFieldsYear']"));
		hm.put("drpConfirmationMonth", By.xpath("//select[@name='dateFieldsMonth']"));
		hm.put("drpConfirmationDay", By.xpath("//select[@name='dateFieldsDay']"));*/
		hm.put("drpConfirmationYear", By.name("dateFieldsYear"));
		hm.put("drpConfirmationMonth", By.name("dateFieldsMonth"));
		hm.put("drpConfirmationDay", By.name("dateFieldsDay"));
		hm.put("btnNextToContractorInfo", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		hm.put("edtSecuritiesNumber", By.cssSelector("input[ng-model='vehicle.previousPolicyNumber.value']"));
		
// Portal QB - Contractor Info
		
		hm.put("edtLastName", By.xpath("//input[@ng-model='contact.lastNameKanji.value']"));
		hm.put("edtFirstName", By.xpath("//input[@ng-model='contact.firstNameKanji.value']"));
		hm.put("edtPhoneticLastName", By.xpath("//input[@ng-model='contact.lastName.value']"));
		hm.put("edtPhoneticFirstName", By.xpath("//input[@ng-model='contact.firstName.value']"));
		hm.put("edtZipcode", By.xpath("//input[@ng-model='address.postalCode.value']"));
		hm.put("edtAddressBuildingNumber", By.xpath("//input[@ng-model='address.addressLine2.value']"));
		hm.put("edtAddressBuildingName", By.xpath("//input[@ng-model='address.addressLine3.value']"));
		hm.put("edtMobilePhoneNo", By.name("mobile-phone"));
		hm.put("edtEmail", By.xpath("//input[@ng-model='submissionVm.baseData.accountHolder.emailAddress1.value']"));
	    hm.put("btnGetAddress", By.xpath("//div[@address='policyAddress']/div/ng-form/div[2]/button"));
		hm.put("btnNextToLast", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		//Portal QB - Choose Address
		hm.put("eleAddressValue", By.xpath("//input[@name='address']/following-sibling::span[1]"));
		hm.put("btnClickOk",By.xpath("//button[text()='Ok' or text()='決定']"));
		
		// Portal QB - Pop up confirmation to send email
		hm.put("btnProceed", By.xpath("//button[(contains(text(), '次へ')) or (contains(text(), 'Proceed'))]"));
		
		// Portl QB - Terms and Conditions
		hm.put("eleAcceptCondition", By.xpath("//p[text()='重要事項説明書の記載内容を確認しました']"));
		hm.put("btnTermsConditionNext", By.xpath("//button/span[text() = 'Next' or text() = '次へ']"));
		
		// Portal QB - Contract Confirmation
		hm.put("eleIAgree", By.xpath("//*[text()= '同意する']"));
		hm.put("btnTermsConditionNext", By.xpath("//*[text() = 'Next' or text() = '次へ']"));

		// Portal QB - Payment
		hm.put("eleLumpSum", By.xpath("//input[@value='lumpSum']/following-sibling::p"));
		hm.put("eleInstallment", By.xpath("//input[@value='installment']/following-sibling::p"));
		hm.put("eleCreditCard", By.xpath("//input[@name='payment-lump-sum-type'][@value='creditCard']/following-sibling::p"));
		hm.put("eleConvenientStore", By.xpath("//input[@name='payment-lump-sum-type'][@value='ocvs']/following-sibling::p"));
		hm.put("btnDecision", By.xpath("//button[(contains(text(),'Decision')) or (contains(text(),'決定'))]"));
		hm.put("edtCardNumber", By.id("cardNumber"));
		hm.put("drpExpirationDateMonth", By.xpath("//select[@ng-model='mm']"));
		hm.put("drpExpirationDateYear", By.xpath("//select[@ng-model='yyyy']"));
		hm.put("edtSecurityCode", By.id("securityCode"));
		//hm.put("selectCVS", By.cssSelector("div.adjPayment-lump-sum-store.ng-scope >div > ul > li> label > p"));
		hm.put("btnConfirmPayment", By.xpath("//button/span[(contains(text(),'Confirm with this content')) or  (contains(text(),'この内容で確認'))]"));
		//hm.put("btnBuyNow", By.xpath("//button/span[(contains(text(),'Buy Now')) or (contains(text(),'申し込み'))]"));
		hm.put("btnBuyNow", By.xpath("//button/span[(contains(text(),'Buy Now')) or (contains(text(),'支払い'))]"));
		
		
		// Portal QB - Confirmation Payment Pop-Up
		hm.put("btnBuy", By.xpath("//button[text()='Buy' or text()='確定​']"));
		
		// Portal QB - Application process completed 
		hm.put("outputSubmissionNo", By.xpath("//p[@class='adjHeader-common-estimate-label']/following-sibling::p"));
		hm.put("btnContinue", By.xpath("//button/span[text()='Continue']"));
   
	}

	public By getObject(String ff) {
		By retuValue = null;
		if (hm.containsKey(ff)) {
			retuValue = hm.get(ff);
		} else // if(retuValue == null)
		{
			logger.info("oops " + ff + " element is not available in the repository");			
		}
		return retuValue;
	}
	
	
}