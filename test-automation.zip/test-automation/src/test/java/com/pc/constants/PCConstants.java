package com.pc.constants;
/**
 * Constants for PC and BC application Automation
 * @author Muthusankar
 *
 */
public class PCConstants 
{
	public static final String   executionModeLocal = "Local";
	public static final String   executionModeRemote = "Remote";
	public static final String   componentSheet = "componentSheet";
	public static final String 	 YES = "YES";
	public static final String 	 FailureSSPath = "FailureSSPath";
	public static final String 	 ALMScreenshotPath = "ALMScreenshotPath";
	public static final String 	 SSFolderPath = "SSFolderPath";
	public static final String 	 FlatFile = "FlatFile";
	public static final String 	 FormsFolderPath = "FormsFolderPath";
	
	//Sheet Column Names
	public static final String   AccountNumber = "AccountNumber";
	public static final String   AccountName = "AccountName"; 
	public static final String   LastNamePh = "LastNamePh";
	public static final String   FirstNamePh = "FirstNamePh";
	public static final String   edtaccountNumber = "edtaccountNumber";
	public static final String 	 ID ="ID";
	public static final String 	 PolicyNumber ="PolicyNumber";
	public static final String   SubmissionNumber = "SubmissionNumber";
	public static final String   PolicyPreiod = "PolicyPreiod";
	public static final String   TotalPremium = "TotalPremium";
	public static final String   BILLINGPREMIUM= "BillingPremium";
	public static final String   UserName = "UserName";
    public static final String   Sheets = "Sheets";
    public static final String   PC = "PC";
    public static final String   E2E_Fields = "E2E_Fields";
    public static final String   E2E_Scenario_Name = "E2E_Scenario_Name";
    public static final String   FieldName = "FieldName";
    public static final String   FieldValues = "FieldValues";
    public static final String 	 PCElementName = "PCElementName";
    public static final String 	 PCValue = "PCValue";
    public static final String 	 PCFieldNames = "PCFieldName";
//  public static final String 	 DBAliasNames = "DBAliasName";
    public static final String 	 FlatFileName = "FlatFileName";
    public static final String   DBAliasName = "DBAliasName";
    public static final String   Iteration = "Iteration";
    public static final String   TableHeader = "TableHeader";
	public static final String   TableBody = "TableBody";
	public static final String   RenewalWait = "5000";
	public static final String   CoverageName = "CoverageName";
	public static final String   CoverageButtonID = "CoverageButtonID";
	public static final String   CoverageID = "CoverageID";
	public static final String   E2E_TestCaseID = "E2E_TestCaseID";
	public static final String   Execution = "Execution";
	public static final String 	 TestCaseGroup = "TestCaseGroup";
	public static final String   TestCaseType = "TestCaseType";
	public static final String 	 SwitchPurchase = "rdoSwithPurchase";
	public static final String   Interruptioncertification = "rdoInterruptioncertification";
	public static final String   TRANSACTION_NO = "TransactionNumber";
	
	
	//Sheet Name
	public static final String SHEET_CREATEACCOUNT = "CreateAccount";
	public static final String SHEET_ACCOUNTCONTACT = "AccountContact";
	public static final String SHEET_SEARCHACCOUNT = "SearchAccount";
	public static final String SHEET_SEARCHACCOUNTBC = "SearchAccountBC";
	public static final String SHEET_PAYMENT = "Payment";	
	public static final String SHEET_SEARCHPOLICY = "SearchPolicy";
	public static final String SHEET_VALIDATION = "Validation";
	public static final String SHEET_TESTCASE = "TestCase";
	public static final String SHEET_Read = "Read";
    public static final String SHEET_Name_Mapping = "Name_Mapping";
    public static final String SHEET_E2E_Testdata = "E2E_Testdata";
    public static final String SHEET_FLATFILE = "FlatFile";
	public static final String SHEET_Queries = "Queries";
	public static final String SHEET_Trans = "Trans";
	public static final String SHEET_POLICYCONTENTSCONFERMATION = "PolicyContentsConfirmation";
	public static final String SHEET_QUOTE = "Quote";
	public static final String SHEET_OUTPUT = "PC_Output";
	public static final String SHEET_PPINFO = "Previouspolicyinformation";

	
	
	//PCThreadCache Constants
	public static final String   CACHE_ACCOUNT_NUMBER = "CacheAccountNumber";
	public static final String   CACHE_POLICY_NUMBER = "CachepolicyNumber";
	public static final String   CACHE_Last_Name_Ph = "LastNamePh";
	public static final String   CACHE_First_Name_Ph = "FirstNamePh";
	public static final String   CACHE_POLICY_PERIOD = "PolicyPeriod";
	public static final String   CACHE_SUBMISSION_NUMBER = "CacheSubmissionNumber";
	public static final String   CACHE_EFFECTIVE_DATE = "Effectivedate";
	public static final String   CACHE_SYSTEMDATE_DATE = "SystemDate";
	public static final String   CACHE_POLICY_NUMBER_SEARCH = "CachepolicyNumberSearch";
	public static final String   CACHE_TEST_CASE_STATUS = "CacheTestCaseStatus";
	public static final String   TARGETDAYSNDHRS = "TargetDaysAndHrs";
	public static final String   ESCLATIONDAYSNDHRS = "EsclationDaysAndHrs";

	
	//Coverages Constants
	public static final String PCConstants 	 								= "PCConstants";
	
	public static final String LOGGED_USERNAME = "LOGGED_USERNAME";
	public static final String ORGRECEIVED_DATE = "ORGRECEIVED_DATE";

	
}