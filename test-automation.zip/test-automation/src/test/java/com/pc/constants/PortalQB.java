package com.pc.constants;
/**
 * Constants for Portal QB application Automation
 * @author X.Durairaj
 *
 */
public class PortalQB {
	
	public static final String OUTPUT_WORKSHEET = "PortalOutput";
	public static final String TESTCASE_ID_COL = "ID";
	public static final String SUBMISSION_NO_COL = "SubmissionNumber";
	

}
