import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;



public class PdfReader_new{
	 	static PDDocument actualDocument =null;
		static PDDocument mockDocument =null;
		static String Filename; 
		static HashMap filecontent;
		static String Folderpath="C:\\Users\\COG12768\\Desktop\\Bi_qd\\";
		static String filepath=Folderpath+"PDF\\";
		static String txtfilepath=Folderpath+"txt\\";
		static String resultfilepath=Folderpath+"result\\";
    public static void main(String args[]) {
        PDFTextStripper pdfStripper = null;
        PDDocument pdDoc = null;
        COSDocument cosDoc = null;
        

		 File [] filenew= (new File(filepath)).listFiles();
		 LinkedHashMap<String,String> map = new LinkedHashMap<>();	 
	
		 for(int k=0;k<filenew.length;k++)
		 {
			
			 String outPutForm = filenew[k].getPath();
			 if (outPutForm.contains(".pdf"))
			 {
			 System.out.println(outPutForm);
			 File actpath= new File(outPutForm); 
        
        try {
            PDFParser parser = new PDFParser(new FileInputStream(actpath));
            parser.parse();
            cosDoc = parser.getDocument();
            pdfStripper = new PDFTextStripper();
            pdDoc = new PDDocument(cosDoc);            
            String parsedText = pdfStripper.getText(pdDoc);
            //System.out.println(parsedText);
            FileOutputStream outputFile = new FileOutputStream(txtfilepath+actpath.getName().replace(".pdf", ".txt"));
            outputFile.write(parsedText.getBytes());
            outputFile.close();
           map= validatepattern(outPutForm);
           HSSFWorkbook workbook = null;
  		 HSSFSheet sheet = null;
  		FileOutputStream out= new FileOutputStream(new File(resultfilepath+actpath.getName().replace(".pdf", ".xls")));
  		workbook = new HSSFWorkbook();
		 sheet =workbook.createSheet("Result");
		 sheet.createRow(0).createCell(0).setCellValue("Form Numbers from PDF");
		 sheet.getRow(0).createCell(1).setCellValue("PdF Page No");
		 sheet.getRow(0).createCell(2).setCellValue("conversion of PDF to TXT file");
		/* for(int i=0;i<list.size();i++){
			String [] s = list.get(i).split(",");
			System.out.println(list.get(i)+"aaaaa"+s[0]);
			sheet.createRow(i+1).createCell(0).setCellValue(s[0]);
			if(s[1].equals(s[2])){
				sheet.getRow(i+1).createCell(1).setCellValue(s[1]);
			}
			else{
				sheet.getRow(i+1).createCell(1).setCellValue(s[1]+" to "+s[2]);
			}
		 }*/
		 Set<String> set = map.keySet();
		 int i=1;
		 for (String key: set)
		 {
			 map.get(key);
			 if (key.contains("No Form Number"))
			 {
				 sheet.createRow(i).createCell(0).setCellValue("No Form Number");
			 }
			 else
			 {
				 sheet.createRow(i).createCell(0).setCellValue(key);
			 }
			 if (map.get(key).contains(","))
			 {
				 sheet.getRow(i).createCell(1).setCellValue(map.get(key).substring(0, map.get(key).indexOf(","))+ " TO "+map.get(key).substring( map.get(key).lastIndexOf(",")+1));
			 }
			 else
			 {
				 sheet.getRow(i).createCell(1).setCellValue(map.get(key));
			 }
			 
			i++;
		 }
		 
		 sheet.getRow(1).createCell(2).setCellValue(txtfilepath+actpath.getName().replace(".pdf", ".txt"));
		 HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
			sheet_link.setAddress(txtfilepath+actpath.getName().replace(".pdf", ".txt"));	
			sheet.getRow(1).getCell(2).setHyperlink(sheet_link);
			workbook.write(out);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 
    }
}
    }

	private static LinkedHashMap validatepattern(String outPutForm) {
		// TODO Auto-generated method stub
		
		actualDocument = new PDDocument();
		  mockDocument= new PDDocument();
		  LinkedList<String> list = new LinkedList<>();
		  LinkedHashMap<String, String> map = new LinkedHashMap<>();
			try {
				
				actualDocument = PDDocument.load(outPutForm);
			
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			List allPages = actualDocument.getDocumentCatalog().getAllPages();
			System.out.println(allPages.size()+"$$$$$$$$$$$$$$$$$$");
			String Prevfootertext="";
			
			for(int i=0;i<allPages.size();i++)
			{
				String text = "No Form Number";
				PDPage firstPage = (PDPage)allPages.get( i );				
				stripper.extractRegions( firstPage );
				//Add Regions and Extract the contents from the Region/*
				PDRectangle pageSize = firstPage.findMediaBox();
				float ht=pageSize.getHeight();
				float wd=pageSize.getWidth();
				//System.out.println( "Page Width:" + wd );
				//System.out.println( "Page Height:" + ht );
				int x1,y1,x2,y2;
				x1=1;
				y1=(int) ht-60;
				x2=(int) (wd);
				y2=60;
				Rectangle footer = new Rectangle(x1, y1,(int) (x2), y2);
				stripper.addRegion( "footer", footer);
				stripper.extractRegions( firstPage );	
				String footer_text=stripper.getTextForRegion( "footer" );
				System.out.println(footer_text+"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				
				
				
				File f=new File(Folderpath+"Patterns.csv");
				Filename=f.getName();
				BufferedReader br = new BufferedReader(new FileReader(Folderpath+"Patterns.csv"));
			    StringBuilder sb = new StringBuilder();
			    String line = br.readLine();
			    
			    while (line != null) 
			    {
			    	String arr[]=line.split(",");
			    	//System.out.println(arr[4]);
			    	 
			    	  Pattern p= Pattern.compile(arr[5]);			    	  
			    	  Matcher m =p.matcher(footer_text);
			    	  if (m.find( )) {
			    		  text= m.group(0);
			    	         System.out.println("*******************Found value: " + m.group(0)+"*************************" );
			    	         break;
			    	  }
			    	  /*else{
			    		  System.out.println("NOTYN Found value" );
			    	  }*/
			        line = br.readLine();
			    }
			    if (text=="No Form Number")
			    {
			    	text=text+(i+1);
			    }
			    if (map.get(text)==null)
			    {
			    	
			    map.put(text,i+1+"");
			    }
			    else
			    {
			    	map.put(text,map.get(text)+","+(i+1));
			    }
			    
	}
			System.out.println(map);
			String prvtext = "";
			int start = 1;
			int end = 0;
			Set<String> set = map.keySet();
			
		    /*for(String key: set){
		    	map.get(key);
		    	
		    	if (( prvtext!="" && !map.get(key).equals(prvtext))||(prvtext!="" && map.get(key).equals("No Form Number"))){
		    		end = key-1;
		    		System.out.println(prvtext+"++"+start+"++"+end);
		    		list.add(prvtext+","+start+","+end);
		    		start =key;
		    	}
		    	prvtext = map.get(key);
		    }*/
		    list.add(prvtext+","+start+","+map.size());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return map;
	}
	}
