
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
 
public class TestJFilePicker extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frmBulkUpload;
	JButton btnDownloadTemplate = new JButton("Download Template");
    JButton btnUpload = new JButton("Upload");

    public TestJFilePicker() {
        //super("Test using JFilePicker");
         
        setLayout(new FlowLayout());
        frmBulkUpload = new JFrame();
		frmBulkUpload.setTitle("Bulk Upload");
		frmBulkUpload.setBounds(100, 100, 450, 300);
		frmBulkUpload.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmBulkUpload.getContentPane().setLayout(null);
		
        // set up a file picker component
        JFilePicker filePicker = new JFilePicker("Pick a file", "Browse...",frmBulkUpload);
        filePicker.setMode(JFilePicker.MODE_SAVE);
        filePicker.addFileTypeFilter(".jpg", "JPEG Images");
        filePicker.addFileTypeFilter(".mp4", "MPEG-4 Videos");
        filePicker.setBounds(10, 101, 271, 20);
        frmBulkUpload.getContentPane().add(filePicker);
        // access JFileChooser class directly
        JFileChooser fileChooser = filePicker.getFileChooser();
        fileChooser.setCurrentDirectory(new File("D:/"));
		btnUpload.setBounds(309, 137, 91, 23);
		frmBulkUpload.getContentPane().add(btnUpload);		
		
		btnDownloadTemplate.setBounds(10, 23, 173, 23);
		frmBulkUpload.getContentPane().add(btnDownloadTemplate);
		
		//upload Template
		btnUpload.addActionListener(new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent evt) {
	            buttonActionPerformed(evt);            
	        }
			});

		
		//open template
		
		btnDownloadTemplate.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent evt) {
            buttonActionPerformed(evt);            
        }
		});

    	
		
        // add the component to the frame
		
         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 100);
        setLocationRelativeTo(null);    // center on screen
    }
     
    
    private void buttonActionPerformed(ActionEvent evt) {
    	if (evt.getSource()==btnDownloadTemplate)
    			{
    		System.out.println("Down Load button clicke");
    		try {
				Desktop.getDesktop().open(new File("H:\\Template.xlsx"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    			}
    	else if (evt.getSource()==btnUpload)
    	{
    		/*for (Component C : frmBulkUpload.getComponents())
    		{    
    		    if (C instanceof JTextField || C instanceof JTextArea){

    		        ((JTextComponent) C).setText(""); //abstract superclass
    		    }
    		} */
    		JFilePicker.textField.setText("");
    		System.out.println(frmBulkUpload.getContentPane().getComponents());
    		System.out.println("Up Load button clicke");
    		JOptionPane.showMessageDialog(null, "Uploaded Successfully","Message Box",JOptionPane.INFORMATION_MESSAGE);
    	}
    	
    	
    }
 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TestJFilePicker().frmBulkUpload.setVisible(true);
            }
        });
    }
    public static class JFilePicker extends JPanel {
        /**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String textFieldLabel;
        private String buttonLabel;
         
        private JLabel label;
          static  JTextField textField;
        private JButton button;
         
        private JFileChooser fileChooser;
         
        private int mode;
        public static final int MODE_OPEN = 1;
        public static final int MODE_SAVE = 2;
         
        public JFilePicker(String textFieldLabel, String buttonLabel, JFrame frmBulkUpload) {
            this.textFieldLabel = textFieldLabel;
            this.buttonLabel = buttonLabel;
             
            fileChooser = new JFileChooser();
    		

        //    frmBulkUpload.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
     
            // creates the GUI
            label = new JLabel(textFieldLabel);
             
            textField = new JTextField(30);
            button = new JButton(buttonLabel);
            button.setBounds(309, 100, 91, 23);
            textField.setBounds(10, 101, 271, 20);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent evt) {
                    buttonActionPerformed(evt);            
                }
            });
             
            frmBulkUpload.getContentPane().add(label);
            frmBulkUpload.getContentPane().add(textField);
            frmBulkUpload.getContentPane().add(button);
             
        }
         
        private void buttonActionPerformed(ActionEvent evt) {
            if (mode == MODE_OPEN) {
                if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                    textField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                }
            } else if (mode == MODE_SAVE) {
                if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    textField.setText(fileChooser.getSelectedFile().getAbsolutePath());
                }
            }
        }
     
        public void addFileTypeFilter(String extension, String description) {
            FileTypeFilter filter = new FileTypeFilter(extension, description);
            fileChooser.addChoosableFileFilter(filter);
        }
         
        public void setMode(int mode) {
            this.mode = mode;
        }
         
        public String getSelectedFilePath() {
            return textField.getText();
        }
         
        public JFileChooser getFileChooser() {
            return this.fileChooser;
        }
    }
}