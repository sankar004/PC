import java.awt.List;
import java.awt.geom.Rectangle2D;
import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

public class Sequence extends DynamicContent
{
	public static void Sequence(LinkedList<String> Actual,LinkedList<String> Mock,String formNumber_Sequence_OSP_CPT)
	{
	Actual=Form_Seq_Act;
	Mock=Form_Seq_Mck;
	

	//public static void main(String[] args)
	//{
		System.out.println(Form_Seq_Act);
		String[] dynamicCompareResult = new String[2];
		String regex="[A-Z]{1,3}[-]{1}[0-9]{2,4}[-]{1}[0-9]{1}";
		String regex1="[A-Z]{1,3}[-]{1}[0-9]{2,4}[-]{1}[0-9]{1}";//A-9800-0,PLA-9800-0,PLA-394-0
	
		String regex2="[A-Z]{1,3}[-]{1}[0-9]{2,4}[-]{1}[0-9]{2}";//DRA-927-10
		String regex3="[A-Z]{2}[-]{1}[A-Z]{2}[-]{1}[A-Z]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{2}";//PA-AR-SR-11-11-08
		String regex4="[0-9]{4}";//8511
		String regex5="[A-Z]{2}[-]{1}[A-Z]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{2}";//CA-AP-11-06-07
		String regex6="[A-Z]{1}[-]{1}[0-9]{4}[-]{1}[0-9]{1}[A-Z]{1}";//U-1000-0A
		String regex7="[A-Z]{4}[-]{1}[A-Z]{3}[0-9]{1}";		
		String s2=null;
		int count=0,k=0,i=0,j=0,m=0;
		LinkedList<String> L1=new LinkedList<String>();
		LinkedList<String> L2=new LinkedList<String>();
		String s3=null,s4=null; 
		int r=0,c=0;
		ArrayList<String> Lsheets=new ArrayList<String>();
		ArrayList<String> Form_Exc=new ArrayList<String>();
		String[] Arr_forms_p=new String[10000];
	try
	{
		
	String fname="Form_Sequencing";
		PDDocument doc=PDDocument.load("C:\\PDFValidationDocuments\\CPT Samples\\A-9800-OSP-New.pdf");
		count=doc.getNumberOfPages();
		System.out.println("Total Number of pages in pdf is: "+count);
		for(k=0;k<=count-1;k++)
		{
			
		
						PDPage page=(PDPage)doc.getDocumentCatalog().getAllPages().get(k);
			
	
		
		Rectangle2D region=new Rectangle2D.Float(10f, 60f,150f, 900f);
		String regionName="region";
		PDFTextStripperByArea stripper=new PDFTextStripperByArea();
		stripper.addRegion(regionName, region);
		stripper.extractRegions(page);
		
		System.out.println("Region is"+stripper.getTextForRegion("region"));
		//String regex="[A-Z]{1,3}[-]{1}[0-9]{2,4}[-]{1}[0-9]{1}";
		String s1=stripper.getTextForRegion("region");
		
				//System.out.println(s1);
		String[] A1=new String[s1.length()];
		String[] A2=new String[A1.length];
		A1=s1.split("\r\n");
		//System.out.println(A1.length);
	//System.out.println("First Element in array is "+A1[15]);
		
		for( i=0;i<=A1.length-1;i++)
		{
			//System.out.println("Element at position "+i+" is: "+A1[i]);
			 A2=A1[i].toString().split(" ");
			//s2=A1[i].replaceAll("\r\n","");
			for(j=0;j<=A2.length-1;j++)
			{
				s2=A2[j];
			
			if(s2.matches(regex)||s2.matches(regex2)||s2.matches(regex3)||s2.matches("8511")||s2.matches("8513")||s2.matches(regex5)||s2.matches(regex6)||s2.matches(regex7))
			{
				System.out.println(s2);//+"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
				
			L1.add(s2);
				
			}
			}
			
		}
		//System.out.println(L1+"%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		}
	
		System.out.println("Elements in list with duplicates is: "+L1);
		/*for(int h=0;h<=Form_Seq_Mck.size()-1;h++)
		{
			L1.remove(index)
		}*/
		System.out.println("L1 after removal of Mock form n end:\n"+L1);
		if(formNumber_Sequence_OSP_CPT.equals("OSP"))
		{
		for(i=0;i<=Form_Seq_Mck.size()-1;i++)
		{
		L1.remove(Form_Seq_Mck.get(i));
		}
		}
		if(formNumber_Sequence_OSP_CPT.equals("CPT"))
		{
		for(i=0;i<=Form_Seq_Act.size()-1;i++)
		{
		L1.remove(Form_Seq_Act.get(i));
		}
		}
		System.out.println(L1);
		//LinkedList<String> newList=new LinkedList<String>(L1);
LinkedList<String> newList=new LinkedList<>(new LinkedHashSet<>(L1));
Iterator it=newList.iterator();

while(it.hasNext())
{
s3=it.next().toString();
L2.add(s3);
}
System.out.println("Elements without duplicates are: "+L2);

FileInputStream fis=new FileInputStream("C:\\PDFValidationDocuments\\Master_form_list.xls");
HSSFWorkbook wb=new HSSFWorkbook(fis);
Lsheets.add("Form Sequencing");
HSSFSheet worksheet=wb.getSheet(Lsheets.get(0));

if(worksheet!=null)
{
		int rc=worksheet.getLastRowNum()+1;
System.out.println(rc);
int cc=worksheet.getRow(0).getLastCellNum();
System.out.println(cc);
for(r=0;r<=102;r++)
		{
	for(c=0;c<4;c++)
	{
	
		HSSFCell row=worksheet.getRow(r).getCell(c);
		
	int type=row.getCellType();
	//System.out.println("Type is: "+type);
	switch(type)
	{
	case 0:
		String r1=Double.toString(row.getNumericCellValue());
		//System.out.println(r1);
		
		
		break;
	case 1:
			String s1=row.getStringCellValue();
			
			s1=s1.replace("(Ed. 10/15)", "").replaceAll(" ", "");
			//System.out.println("String Values are:"+s1);
			
			
			if(c==3)
			{
				//System.out.println("String Values are:"+s1);
			if(s1.matches(regex1))
			{
				//System.out.println("PLA-9010-0");
				Form_Exc.add(s1);
				//System.out.println("Matched 1");
			}
						
			else if(s1.matches(regex2))
			{
				Form_Exc.add(s1);
				//System.out.println("Matched 2");
			}
			else if(s1.matches(regex3))
			{
				Form_Exc.add(s1);
				//System.out.println("Matched 3");
			}	
			else if(s1.matches(regex4))
			{

				Form_Exc.add(s1);
				//System.out.println("Matched 4");
			}
			else if(s1.matches(regex5))
			{

				Form_Exc.add(s1);
				//System.out.println("Matched 5");
			}
			else if(s1.matches(regex6))
			{

				Form_Exc.add(s1);
				//System.out.println("Matched 6");
			}
			else if(s1.matches(regex7))
			{

				Form_Exc.add(s1);
				//System.out.println("Matched 7");
			}
			
			else
			{
				//System.out.println("Does not match any");
			}
			}
			//System.out.println(Form_Exc);
			break;
	case 3:
		System.out.println("It is blank");
		break;
		default:
			System.out.println("IN default");
			break;
	}
		}
	
		}

}
System.out.println(Form_Exc);
System.out.println("After adding form numbers in list, the size of the list is: "+Form_Exc.size());

//L2 contains the forms that are present in the PDF
//Form_Exc contains the form numbers that are present in the master excel sheet
String p_pdf=null,p_excel=null;

//This will store the form bnumber which is not available in master form sheet.
ArrayList<String> dummy_Form_Pdf=new ArrayList<String>(L2);
ArrayList<String> dummy_Form_Exc=new ArrayList<String>(Form_Exc);
//To store the order
ArrayList<Integer> order_pdf=new ArrayList<Integer>();
ArrayList<Integer> order_Excel=new ArrayList<Integer>();
ArrayList<Integer> Matched=new ArrayList<Integer>();
ArrayList<Integer> Not_Matched=new ArrayList<Integer>();

//To store the not matched form number
ArrayList<String> Not_Matched_Form=new ArrayList<String>();

//To display the result in excel
StringBuffer sb_mstr=new StringBuffer();
StringBuffer sb_pdf=new StringBuffer();
StringBuffer sb_notMatched=new StringBuffer();
StringBuffer sb_missing=new StringBuffer();

//To display the result in excel
ArrayList<String> resultList1=new ArrayList<String>();
ArrayList<String> resultList_Missing=new ArrayList<String>();
ArrayList<String> resultList_Missing_order_form=new ArrayList<String>();

dummy_Form_Exc.retainAll(L2);
for(int r1=0;r1<=dummy_Form_Exc.size()-1;r1++)
{
	sb_mstr.append(dummy_Form_Exc.get(r1));
	sb_mstr.append("\n");
}
resultList1.add("Master form Matched forms: \n"+sb_mstr.toString());


for(int r1=0;r1<=L2.size()-1;r1++)
{
	sb_pdf.append(L2.get(r1));
	sb_pdf.append("\n");
}
resultList1.add("Form numbers from Excel: \n"+sb_pdf.toString());

System.out.println(resultList1);

int n2=0;
dummy_Form_Pdf.removeAll(Form_Exc);
if(dummy_Form_Pdf.size()>0)
{
	
	System.out.println("Form numbers that are not present in master list is:\n");

	for(int n=0;n<=dummy_Form_Pdf.size()-1;n++)
	{
		sb_missing.append(dummy_Form_Pdf.get(n));
		sb_missing.append("\n");
		System.out.println(dummy_Form_Pdf.get(n));
		//resultList_Missing.add(dummy_Form_Pdf.get(n));
}
	
}
if(dummy_Form_Pdf.size()>0){
	
	resultList_Missing.add("Form that is not at all present in master sheet: \n"+sb_missing.toString());	
}
else
{
	resultList_Missing.add("No data is missing");
}

for(int n1=0;n1<=L2.size()-1;n1++)
{

		p_pdf=L2.get(n1);
		
		order_pdf.add(n1);
		//Extracting values from Excel
		for(n2=0;n2<=Form_Exc.size()-1;n2++)
		{
			String exce=Form_Exc.get(n2);
			//System.out.println(exce);
		if(Form_Exc.get(n2).equals(p_pdf))
		{
			System.out.println("Present in Master form List");
			System.out.println("Value from Excel is:"+Form_Exc.get(n2));
			System.out.println("Value from PDF is:"+L2.get(n1));
			int n3=n2;
			
			order_Excel.add(n3);
		    break;
	     }
		/*else
		{
			Not_Matched.add(p_pdf);
		}*/
	
	}
		n2=0;

}

ArrayList<Integer> order_Excel_sort=new ArrayList<Integer>(order_Excel);


System.out.println("Odrer values from pdf is:"+order_pdf);
System.out.println("Odrer values from excel before sort is:"+order_Excel);
Collections.sort(order_Excel_sort);
System.out.println("After sort list items are: "+order_Excel_sort);
if(order_Excel.size()==order_Excel_sort.size())
{
	int size=order_Excel.size();
	System.out.println("Size is: "+size);
	for(int n=0;n<=size-1;n++)
	{
	if(n!=size-1)
	{
		
		if(order_Excel.get(n+1)>order_Excel.get(n))
		{
			Matched.add(order_Excel.get(n));
		}
		else
		{
			Not_Matched.add(order_Excel.get(n));
		}
	}
	else if(n==size-1)
	{
		if(order_Excel.get(n)>order_Excel.get(n-1))
		{
			Matched.add(order_Excel.get(n));
		}
		else
		{
			Not_Matched.add(order_Excel.get(n));
	    }
	
	}
	
	}
}
System.out.println("Matched data is: "+Matched);
System.out.println("Non-Matched data is: "+Not_Matched);
for(int a=0;a<=Not_Matched.size()-1;a++)
{
			int position=Not_Matched.get(a);
		String form=Form_Exc.get(position);
		Not_Matched_Form.add(form);
		sb_notMatched.append(form);
		sb_notMatched.append("\n");
}
resultList_Missing_order_form.add("Form which is not in order is : \n"+sb_notMatched.toString());
System.out.println(resultList_Missing_order_form);
System.out.println("List of non matched forms are: \n"+Not_Matched_Form);
if(Not_Matched_Form.size()>0)

{
	dynamicCompareResult[0]="Fail";
}

else
{
	dynamicCompareResult[0]="pass";
}
String ExcelResultFile = "Z:\\CPT Automation tracker\\1103\\Results\\Form_Sequencing\\"+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
DynamicExcelCreation.createExcelwithFinalValue_FormSequencing(resultList1, 1, ExcelResultFile, resultList_Missing, resultList_Missing_order_form, dynamicCompareResult[0]);
resultList1.clear();
resultList_Missing_order_form.clear();
resultList_Missing.clear();
}

	catch(IOException e)
	{
		System.out.println("Message is"+e);
	}
	}
}
	
