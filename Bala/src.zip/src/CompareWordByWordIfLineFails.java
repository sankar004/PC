import java.util.Arrays;


public class CompareWordByWordIfLineFails {

	public static String[] compareWordByWord(String mockPages, String outputPages) {
		String[] mocklWordSplit = null;
		String[] outputlWordSplit = null ;
		String[] Result = new String[5];
		
		mockPages = mockPages.replace("\r\n", " ");
		outputPages = outputPages.replace("\r\n", " ");
		mocklWordSplit = mockPages.split(" ");
		outputlWordSplit = outputPages.split(" ");
		Result = CompareMockAndOutPut(mocklWordSplit,outputlWordSplit);
		return Result;
		
	}

	private static String[] CompareMockAndOutPut(String[] mocklWordSplit,
			String[] outputlWordSplit) {
		int wordlowest;
		String[] Result = new String[5];
		String[] s1 = null;
		String[] s2 = null;
		
		boolean mockword = mocklWordSplit.length > outputlWordSplit.length;
		if(mockword)
			wordlowest = outputlWordSplit.length;
		else 
			wordlowest = mocklWordSplit.length;
		int l;	
		for(l=0;l<wordlowest;l++){					
			if(mocklWordSplit[l].equals(outputlWordSplit[l]))
			{
				Result[0] = "pass";
				Result[1] = "outPutForm";
				Result[2] = "mockUpForm";
				Result[3] = "No Error";
				//Result[4] = "No Error";
			}
			else{
				Result[0] = "Fail";	
				Result[1] = "";
				Result[2] = "";
				Result[3] = "Error Found";
				//Result[4] = "";
				 
				if(outputlWordSplit[l].equals("")){
					outputlWordSplit[l] = "<space>";
				}
				
				if(l>0 & l!=(wordlowest-1)){
					s1 = Arrays.copyOfRange(outputlWordSplit, l, l+10);
					s2 = Arrays.copyOfRange(mocklWordSplit, l, l+10);
					for(int m = 0;m<s1.length;m++) {
						Result[1]= Result[1] + s1[m] + " ";
						Result[2]= Result[2] + s2[m] + " ";
				   	}
				} 
				else if(l>0 & l==(wordlowest-1)){
					s1 = Arrays.copyOfRange(outputlWordSplit, l, wordlowest);
					s2 = Arrays.copyOfRange(mocklWordSplit, l, wordlowest);
				for(int m = 0;m<s1.length;m++) {
					Result[1]= Result[1] + s1[m] + " ";	
					Result[2]= Result[2] + s2[m] + " ";
			   		}
				} 
				else if(l==0 & (wordlowest > 10)){					
					s1 = Arrays.copyOfRange(outputlWordSplit, 0, 11);
					s2 = Arrays.copyOfRange(mocklWordSplit, 0, 11);
					for(int m = 0;m<s1.length;m++) {
						Result[1]= Result[1] + s1[m] + " ";	
						Result[2]= Result[2] + s2[m] + " ";
					   	}
					} 
				else if(l>=0 & (wordlowest < 10)){					
					s1 = Arrays.copyOfRange(outputlWordSplit, 0, wordlowest);
					s2 = Arrays.copyOfRange(mocklWordSplit, 0, wordlowest);
					for(int m = 0;m<s1.length;m++) {
						Result[1]= Result[1] + s1[m] + " ";	
						Result[2]= Result[2] + s2[m] + " ";
					   	}
					} 
				else if(l==0 & l!=(wordlowest-1)){
					Result[1] = outputlWordSplit[l];
				Result[2] = mocklWordSplit[l];}
				else{
					Result[1] = outputlWordSplit[l];
				Result[2] = mocklWordSplit[l];}				
					
				break;
					}
				
				if(l==wordlowest){
					Result[0] = "Fail";
					Result[1] = "";
					Result[2] = "";
					
					if(mockword){
						Result[1]= mocklWordSplit[l].substring(outputlWordSplit.length, mocklWordSplit.length);
					Result[2] = "";}
					else{
						Result[1]= outputlWordSplit[l].substring(mocklWordSplit.length, outputlWordSplit.length);
					Result[2] = "";}
				}	
			
			
		}
		return Result;
		
	}

}
