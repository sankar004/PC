import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;


public class ExcelResult {
	
	static HSSFWorkbook workbook = null;
    static HSSFSheet worksheet = null;
    static FileOutputStream fileOut = null;
    static FileInputStream fileIn = null;
	
	public ExcelResult() {
		
	}
	
public static void createExcel(String[] result, int i, String formNumber, String excelResultFile) throws IOException{
	File file = new File(excelResultFile);    
	if (!file.exists()) {
		createDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}	
	else{
		openDocument(formNumber,excelResultFile,"Static");
		updateDocument(result,i);
	}
	//if(h==2)	
		flushall();
		
	}

static void openDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	
	fileIn = new FileInputStream(excelResultFile);
	fileOut = new FileOutputStream(excelResultFile);
	if(type == "Narrative"){
		worksheet = workbook.createSheet(formNumber+" NarrationCheck");
		updateSheetHeader(type);
	}
	else{
	if(workbook.getSheet(formNumber)!=null){
		worksheet = workbook.getSheet(formNumber);
	}
	else{
		worksheet = workbook.createSheet(formNumber);
		updateSheetHeader(type);
	}
	}
}

private static void updateDocument(String[] result, int i) throws IOException {
	HSSFRow row1 = worksheet.createRow(i+1);
	
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No/Section No   "+i);
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue(result[1]);
	
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue(result[2]);
	
	Cell cellA3 = row1.createCell(3);		
	cellA3.setCellValue(result[0]);
	setFontColourForPassFail(cellA3,result[0]);
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue(result[3]);
	//Added by Saravanan to have hyperlink for compared file
	if(PDFContent.type.contentEquals("NonStacked_Columnar"))
	{
	HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_FILE);
	sheet_link.setAddress(result[3]);	
	cellA4.setHyperlink(sheet_link);
	}
	workbook.write(fileOut);
}

static void flushall() throws IOException {
	
	
	fileOut.flush();
	fileOut.close();
	if(fileIn!=null)
	fileIn.close();
	
}

static void createDocument(String formNumber, String excelResultFile, String type) throws FileNotFoundException {
	
	fileOut = new FileOutputStream(excelResultFile);
	workbook = new HSSFWorkbook();
	worksheet = workbook.createSheet(formNumber);
	updateSheetHeader(type);
	//workbook.getSheet("");
	
}

private static void updateSheetHeader(String type) {
	
	   
HSSFRow row1 = worksheet.createRow(0);
	
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Line No/Section No");
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue("Mock");
	if(type=="Static"){
	Cell cellA2 = row1.createCell(2);
	cellA2.setCellValue("Actual");
	
	Cell cellA3 = row1.createCell(3);
	cellA3.setCellValue("Pass/Fail");
	
	Cell cellA4 = row1.createCell(4);
	cellA4.setCellValue("Error Description");}
	else if(type=="Dynamic"){
		
		
		cellA1.setCellValue("Actual Line");
		
		Cell cellA2 = row1.createCell(6);
		cellA2.setCellValue("Mock Line/TestData Value");
		
		Cell cellA3 = row1.createCell(7);
		cellA3.setCellValue("Pass/Fail");
		
	}
	else if(type=="Narrative"){
		
		Cell cellA6 = row1.createCell(0);
		cellA6.setCellValue("FormNumber");
		
		Cell cellA2 = row1.createCell(1);
		cellA2.setCellValue("page Number in the document");		
			
		Cell cellA3 = row1.createCell(2);
		cellA3.setCellValue("Narration");
		
		Cell cellA4 = row1.createCell(3);
		cellA4.setCellValue("Pass/Fail");
		
	}
	//if(type!="Dynamic")
	makeRowBold(row1);
	for(int size = 0 ;size<7;size++)
	worksheet.autoSizeColumn(size);	
	worksheet.setColumnWidth(1,20*600);	
	worksheet.setColumnWidth(2,20*600);
	//worksheet.setColumnWidth(3,20*256);
	
}
public static void makeRowBold(Row row){
    CellStyle style = workbook.createCellStyle();//Create style
    Font font = workbook.createFont();//Create font
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
    style.setFont(font);//set it to bold
    style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
    //style.setFillPattern(CellStyle.BORDER_THICK);
    style.setAlignment(CellStyle.ALIGN_CENTER);

    for(int i = 0; i < row.getLastCellNum(); i++){
    	try{//For each cell in the row 
        row.getCell(i).setCellStyle(style);//Set the style
        	}
    	catch(NullPointerException e){
    		row.createCell(i).setCellStyle(style);
    	}
    }
}

static void updateDynamicDocument(ArrayList<String> resultList, int i, String mockOrTestdataValue, String passOrFail) throws IOException {
	HSSFRow row1 = null;
	//int rowNumber = 0;
//	
		for (int n = 0; n < resultList.size(); n++) {

			if (n == 0) {
				row1 = worksheet.createRow(i + 1);
			}
			//rowNumber = row1.getRowNum();
			Cell cellA5 = row1.createCell(0);
			cellA5.setCellValue("Line No   " + (i + 1));

			Cell cellA1 = row1.createCell(n + 1);
			cellA1.setCellValue(resultList.get(n));
			
		
		//row1 = worksheet.getRow(rowNumber);
		Cell cellB1 = row1.createCell(6);
		cellB1.setCellValue(mockOrTestdataValue);
		
		Cell cellB2 = row1.createCell(7);
		cellB2.setCellValue(passOrFail);
		setFontColourForPassFail(cellB2,passOrFail);
		workbook.write(fileOut);
}
	}

public static void updateNarrativeDocument(String formNumber, String[] result) throws IOException {
	
HSSFRow row1 = worksheet.createRow(1);
	
		
	Cell cellA1 = row1.createCell(0);
	cellA1.setCellValue(formNumber);
	
	Cell cellA2 = row1.createCell(1);
	cellA2.setCellValue(result[2]);
	
	Cell cellA3 = row1.createCell(2);		
	cellA3.setCellValue(result[1]);
	
	Cell cellA4 = row1.createCell(3);		
	cellA4.setCellValue(result[3]);
	setFontColourForPassFail(cellA4,result[3]);	
	
	workbook.write(fileOut);
}

private static void setFontColourForPassFail(Cell cellA4, String result) {
	HSSFFont font = workbook.createFont();
	HSSFCellStyle cellStyle= workbook.createCellStyle();
	if(result.equals("Fail")){
		font.setColor(HSSFFont.COLOR_RED);
		cellStyle.setFont(font);
		cellA4.setCellStyle(cellStyle);}
	else{
		//font.setColor(HSSFColor.DARK_GREEN.index);
		font.setColor(HSSFFont.COLOR_NORMAL);
		cellStyle.setFont(font);
		cellA4.setCellStyle(cellStyle);
	}
	
}

public static void SummaryReport(String excelResultFile) {
	try {
		File f=new File(excelResultFile);
		if(f.exists()==true)
		{
		fileIn = new FileInputStream(excelResultFile);
		fileOut = new FileOutputStream(excelResultFile);
		
		//workbook = new HSSFWorkbook(fileIn);
		worksheet = workbook.createSheet("Summary Report");
		workbook.setSheetOrder("Summary Report",0);
		updateHeadersInSummerySheet();
		flushall();
		updateSummeryResult(excelResultFile);
		}
		//flushall();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
}

private static void updateSummeryResult(String excelResultFile) {
	try {
		
	for (int i = 1; i < workbook.getNumberOfSheets(); i++) {
		fileIn = new FileInputStream(excelResultFile);
		fileOut = new FileOutputStream(excelResultFile);
        HSSFSheet sheet = workbook.getSheetAt(i);
        worksheet = workbook.getSheetAt(0); 
       int cellNumber=0;
       String[] summeryResult = new String[2];
        HSSFRow row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		while(cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			if(cell.getStringCellValue()=="Pass/Fail"){
				cellNumber=cell.getColumnIndex();
				break;
			}
			
		}
		Iterator<Row> rowIterator = sheet.iterator();
		while(rowIterator.hasNext()) {
	        Row row1 = rowIterator.next();
	        Cell cell1 = row1.getCell(cellNumber);
	        if(cell1.getStringCellValue().equals("Fail")){
	        	summeryResult[1] = "Fail";
	        	summeryResult[0] = sheet.getSheetName();
	        }
		}
		if(summeryResult[1]==null){
			summeryResult[1] = "Pass";
        	summeryResult[0] = sheet.getSheetName();
		} 
		//HSSFFont font = workbook.createFont();
		//HSSFCellStyle cellStyle= workbook.createCellStyle();		   
		int lastRow= worksheet.getLastRowNum();
		HSSFRow row1 = worksheet.createRow(lastRow+1);
		HSSFHyperlink sheet_link=new HSSFHyperlink(HSSFHyperlink.LINK_DOCUMENT);
		sheet_link.setAddress("'"+summeryResult[0]+"'!A1");
		Cell cellA5 = row1.createCell(0);
		cellA5.setCellValue(summeryResult[0]);
		cellA5.setHyperlink(sheet_link);
		
		Cell cellA1 = row1.createCell(1);
		cellA1.setCellValue(summeryResult[1]);
		setFontColourForPassFail(cellA1,summeryResult[1]);
		/*if(summeryResult[1].equals("Fail")){
			font.setColor(HSSFFont.COLOR_RED);
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);}
		else{
			font.setColor(HSSFColor.DARK_GREEN.index);			
			cellStyle.setFont(font);
			cellA1.setCellStyle(cellStyle);
		}*/
		workbook.write(fileOut);
		flushall();
    }
		//workbook.write(fileOut);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
}

private static void updateHeadersInSummerySheet() {
	try {	
		CellStyle style = workbook.createCellStyle();//Create style
	    Font font = workbook.createFont();//Create font
	    font.setBoldweight(Font.BOLDWEIGHT_BOLD);//Make font bold
	    font.setColor(HSSFColor.DARK_BLUE.index);
	    style.setFont(font);//set it to bold
	    //style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
	    //style.setFillPattern(CellStyle.BORDER_THICK);
	    style.setAlignment(CellStyle.ALIGN_CENTER);
		
	HSSFRow row1 = worksheet.createRow(0);
	Cell cellA5 = row1.createCell(0);
	cellA5.setCellValue("Form Number");
	cellA5.setCellStyle(style);
	worksheet.autoSizeColumn(0);
	
	Cell cellA1 = row1.createCell(1);
	cellA1.setCellValue("Pass/Fail");
	cellA1.setCellStyle(style);
	worksheet.autoSizeColumn(1);
	
		workbook.write(fileOut);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	}


