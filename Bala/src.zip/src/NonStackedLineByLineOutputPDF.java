import java.io.IOException;
import java.util.List;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;


public class NonStackedLineByLineOutputPDF {

	public NonStackedLineByLineOutputPDF() {
		// TODO Auto-generated constructor stub
	}
	public static String getStartEndPageandCreateNewOutPutPDFNonStacked(PDDocument actualDocument, String outPutForm, List<PDPage> list, String formNumber) throws IOException, COSVisitorException {
		outPutForm = "c:\\PDFValidationDocuments\\OutPutPDF\\";
		 PDDocument newdocument = new PDDocument();
		 PDFTextStripper textStripper=new PDFTextStripper(); 
	        
	        String pages= null; 
	        boolean found = false;   
	        PDPage page = new PDPage();
	        String outputFormPDF = outPutForm+formNumber+" OutPut "+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
       	 outPutForm = outputFormPDF;
       	 if(formNumber.equals("Welcome Letter")){       		
       		
            	 System.out.println("found");
            	 page = list.get(1);
            	 COSDictionary pageDict = page.getCOSDictionary();
            	 COSDictionary newPageDict = pageDict; new COSDictionary(pageDict);
            	 newPageDict.removeItem(COSName.ANNOTS);
            	 PDPage newPage = new PDPage(newPageDict);            	
            	 newdocument.addPage(newPage);            	
            	 newdocument.save(outPutForm);           	 
           
       	 }
       	 else{       		 
       	 
	        for(int i = 5; i <= list.size(); i++) {
	           
	            textStripper.setStartPage(i); 
	            textStripper.setEndPage(i);             
	                        
	            pages = textStripper.getText(actualDocument); 
	            String[] lines = pages.split("\\n");
	            String line2 = lines[1];
	            
	            found = line2.contains(formNumber);
	            //found = true;
	            if (found == true) {
	            	 System.out.println("found");
	            	 page = list.get(i-1);
	            	 COSDictionary pageDict = page.getCOSDictionary();
	            	 COSDictionary newPageDict = pageDict; new COSDictionary(pageDict);
	            	 newPageDict.removeItem(COSName.ANNOTS);
	            	 PDPage newPage = new PDPage(newPageDict);
	            	
	            	 newdocument.addPage(newPage);
	            	
	            	 newdocument.save(outPutForm);
	            	 
	            }
	                        
	              if (found == false) {                       
	                   // System.out.println("page returned is: " + pages);
	                       
	                    }                
	        }    
       	 }
	    	newdocument.close();
	    	actualDocument.close();
			return outPutForm;
	    	
	    	//outPutForm= "D:\\PDFValidationDocuments\\OutPutPDF\\3.pdf";
	    	//Excelresult(formNumber,formTitle,outPutForm,mockUpForm);
		}

}
