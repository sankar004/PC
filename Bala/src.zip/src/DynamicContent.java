import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;


public class DynamicContent {
	
	static String ExcelResultFile= null;
	static String FormNumber = null;
	static int actual_document_no_of_pages,mock_document_no_of_pages;
	static PDDocument actdocument = null,mckdocument = null;
	static int actFormPages[],mockFormPages[];
	static int startPage=-1,endPage=-1;
	public DynamicContent() {
		// TODO Auto-generated constructor stub
	}	
	public static void DynamicContentPDF(PDDocument actualDocument, List<PDPage> list, String formNumber, String formTitle, String actualForm, String mockUpForm, String excelResultFile, String testcaseName) throws IOException, COSVisitorException{
		
		actual_document_no_of_pages=NonStackedColumnar.Get_noofpages(actualDocument);
		ExcelResultFile= excelResultFile;
		FormNumber = formNumber;
		
		//Get the page numbers that have the respective Form number from the Actual document
		actFormPages=NonStackedColumnar.GetFormpages(actualDocument,formNumber);		
		startPage=actFormPages[0];
		endPage=actFormPages[1];
		actualDocument.close();
		getresult(formNumber, formTitle, actualForm, mockUpForm, startPage,
				endPage,testcaseName);
	}

	private static void getresult(String formNumber, String formTitle,
			String actualForm, String mockUpForm, int startPage, int endPage, String testcaseName)
					throws COSVisitorException {

		String[] mocklLineSplit = null;
		String[] actualLineSplit = null;

		try {
			System.out.println(actualForm);
			PDDocument outputdocument = PDDocument.load(actualForm);
			PDFTextStripper outputtextStripper = new PDFTextStripper();
			String actualPages = null;
			//System.out.println(startPage);
			//System.out.println(endPage);
			outputtextStripper.setStartPage(startPage+1);
			outputtextStripper.setEndPage(endPage+1);
			actualPages = outputtextStripper.getText(outputdocument);
			System.out.println(mockUpForm);
			PDDocument mockdocument =PDDocument.load(mockUpForm);
			PDFTextStripper mocktextStripper=new PDFTextStripper();
			String mockPages = null;
			
			mocktextStripper.setStartPage(startPage+1); 
			mocktextStripper.setEndPage(endPage+1);
			mockPages = mocktextStripper.getText(mockdocument);	

			//System.out.println(actualPages);
			//System.out.println(mockPages);
			actualLineSplit = actualPages.split("\r\n");
			mocklLineSplit = mockPages.split("\r\n");
			getValuesforExcel(actualLineSplit,mocklLineSplit,testcaseName);
			//CompareDynamicData.compareDynamicValues(ExcelResultFile,FormNumber);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void getValuesforExcel(String[] actualLineSplit, String[] mocklLineSplit, String testcaseName)
			throws IOException {
		//HashMap<String,String> dynamicValues = null;
		CompareDynamicData compareDynamicData = new CompareDynamicData(testcaseName);
		String[] dynamicCompareResult = new String[2];
		int i = 0;
		int h = 1;
		System.out.println(actualLineSplit.length);
		int cnter=0;
		while (i < actualLineSplit.length) {
			ArrayList<String> resultList = new ArrayList<String>();
			//System.out.println(actualLineSplit[i]);
			/*if (actualLineSplit[i].contains("The premium for this policy")) {
				resultList.add(actualLineSplit[i]);				
				int count = 0;
				for (int j = i; j < actualLineSplit.length; j++) {
					dynamicCompareResult = compareStaticDatainDynamicPage(actualLineSplit[i],mocklLineSplit[i]);
					DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber,"","");
				}
			}*/
			if (actualLineSplit[i].contains("Policy Number")) {				
				resultList.add(actualLineSplit[i]);
				//dynamicCompareResult = compareStaticDatainDynamicPage(actualLineSplit[i],mocklLineSplit[i]);
				DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber,"","");
				int j=i;
					String[] splitValues = actualLineSplit[j].split(":");
					String pol_number=splitValues[1].replaceAll("Endorsement Number","").trim();					
					String end_number=splitValues[2].trim();					
					resultList.add(pol_number);				
					dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Policy Number");
					//System.out.println(pol_number);
					//System.out.println(dynamicCompareResult[0]);
					if(pol_number.equals(dynamicCompareResult[0])){
						dynamicCompareResult[1] = "Pass";
						System.out.println("pass for policy");
					}
					else{
						dynamicCompareResult[1] = "Fail";}
					
					DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
					cnter=cnter+1;
					resultList.clear();
					resultList.add(actualLineSplit[i]);
					resultList.add(end_number);
					dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Endorsement Number");					
					if(end_number.equals(dynamicCompareResult[0])){
						dynamicCompareResult[1] = "Pass";
						System.out.println("pass for policy");
					}
					else{
						dynamicCompareResult[1] = "Fail";}
					DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);					
					i++;
					cnter++;
					resultList.clear();

			} else if (actualLineSplit[i].contains("Effective Date")) {
				resultList.add(actualLineSplit[i]);
				//DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
				int j=i;
				String[] splitValues = actualLineSplit[j].trim().split(":");							
				String eff_date[]=splitValues[1].split(" ");				
				resultList.add(eff_date[1]);
				//System.out.println(eff_date[1]);
				dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Effective Date").toString();
				//System.out.println(eff_date[1]);
				//System.out.println(dynamicCompareResult[0]);
				if(eff_date[1].equals(dynamicCompareResult[0])){
					dynamicCompareResult[1] = "Pass";
					System.out.println("pass for policy");
				}
				else{
					dynamicCompareResult[1] = "Fail";}
				DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
					i++;
					cnter++;
					resultList.clear();
							} 
			else if (actualLineSplit[i].contains("Named Insured and Address:")) {
				//resultList = new ArrayList<String>();
				String[] splitValues = actualLineSplit[i].split(":");
				String insured=splitValues[1].trim();
				resultList.add(actualLineSplit[i]);
				resultList.add(insured);
				dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Insured");
				if(insured.equals(dynamicCompareResult[0])){
					dynamicCompareResult[1] = "Pass";
					System.out.println("pass for policy");
				}
				else{
					dynamicCompareResult[1] = "Fail";}
				DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
				i++;
				cnter++;
				resultList.clear();
				String Add1=actualLineSplit[i].trim();
				resultList.add(actualLineSplit[i]);
				resultList.add(Add1);
				dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Address1");
				if(Add1.equals(dynamicCompareResult[0])){
					dynamicCompareResult[1] = "Pass";
					System.out.println("pass for policy");
				}
				else{
					dynamicCompareResult[1] = "Fail";}
				DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
				i++;				
				cnter++;
				resultList.clear();
				String Add2=actualLineSplit[i].trim();
				resultList.add(actualLineSplit[i]);
				resultList.add(Add2);
				dynamicCompareResult[0] = compareDynamicData.dynamicValues.get("Address2");
				if(Add2.equals(dynamicCompareResult[0])){
					dynamicCompareResult[1] = "Pass";
					System.out.println("pass for policy");
				}
				else{
					dynamicCompareResult[1] = "Fail";}
				DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
				i++;
				cnter++;
				
			}  else {
				
				/*resultList.add(actualLineSplit[i]);
				dynamicCompareResult = compareStaticDatainDynamicPage(actualLineSplit[i],mocklLineSplit[i]);
				DynamicExcelCreation.createExcelwithFinalValue(resultList, cnter,ExcelResultFile,FormNumber,dynamicCompareResult[0],dynamicCompareResult[1]);
				*/
				i++;
				//cnter++;
				
			}
/*
			if (i == actualLineSplit.length) {
				h = 2;
			DynamicExcelCreation.createExcelwithFinalValue(resultList, i,ExcelResultFile,FormNumber," "," ");
			}*/
		}

	}

	private static String[] compareStaticDatainDynamicPage(String actual,String mock) {
		String compareResult[] = null;
		if(actual.equals(mock)){
			compareResult =new String[]{mock,"Pass"};
		}else{
			compareResult =new String[]{mock,"Fail"};
		}		
		return compareResult;
	}

	private static String convertarrayListToString(ArrayList<String> resultList) {
		
		String listString = "";
		for (String s : resultList)
		{
		    listString += s + ";";
		}
		System.out.println("a  "+listString.substring(0,listString.length()-1));
		return listString.substring(0,listString.length()-1);
	}	
		
	}


