import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.util.PDFTextStripper;


public class StackedLineByLineOutputPDF {

	public StackedLineByLineOutputPDF() {
		// TODO Auto-generated constructor stub
	}
	
	public static String getStartEndPageandCreateNewOutPutPDFStacked(PDDocument actualDocument, String outPutForm, List<PDPage> list, String formNumber, String formTitle) throws IOException, COSVisitorException{
		outPutForm = "c:\\PDFValidationDocuments\\OutPutPDF\\";
		 int EOL = 0;
	        int SOL = 0;
	        int lineNumber = 0;
	        int lineListSize = 0;
	        int count = 1;
	        String[] lineSplit = null;
	        String[] finalArray = null;
	        String[] finalArray1 = null;
	        int line = 0; 
	        String pages= null; 
	        boolean foundTitle = false;
	        PDDocument newdocument = new PDDocument();
			 PDFTextStripper textStripper=new PDFTextStripper();
			 PDPage page = new PDPage();
			 PDPageContentStream contentStream = null;
	               		
	            for(int i = 10; i <= list.size(); i++) {   
	            textStripper.setStartPage(i); 
	            textStripper.setEndPage(i);             
	                        
	            pages = textStripper.getText(actualDocument);                        
	            foundTitle = pages.contains(formTitle);
	                        
	            if (foundTitle == true) {
	            	lineSplit=pages.split("\r\n");
	        		lineListSize = lineSplit.length;
	            	for (lineNumber = 0;lineNumber <= lineListSize ; lineNumber++) {            			
	        			if(lineSplit[lineNumber].contains(formTitle)){            				
	        				SOL= lineNumber;
	        				break;
	        			}  
	            	}
	            	
	            	for(int r = i ; r<=list.size(); r++ )
	            	{
	            		textStripper.setStartPage(r); 
	                    textStripper.setEndPage(r);
	                    pages = textStripper.getText(actualDocument);
	                    lineSplit=pages.split("\r\n");
	            		lineListSize = lineSplit.length;
	            	    if(pages.contains(formNumber)){            	
	            		  count++;        		
	            		//List<String> lineSplit= Arrays.asList(pages.split("\r\n"));
	            		
	            		for (lineNumber = 0;lineNumber <= lineListSize ; lineNumber++) {            			
	            			if(lineSplit[lineNumber].contains(formNumber)){            				
	            				EOL= lineNumber;           				
	            				
	            				break;
	            			}  
	            		}
	            		if(count <= 3)
	            		 finalArray= Arrays.copyOfRange(lineSplit, SOL, EOL+1);
	            		else{
	            			finalArray = Arrays.copyOfRange(lineSplit, SOL-1, EOL+1);
	            			List<String> both = new ArrayList<String>(finalArray.length + finalArray1.length);
	            			Collections.addAll(both, finalArray1);
	            		    Collections.addAll(both, finalArray);            		    
	            		    finalArray = both.toArray(new String[both.size()]);
	            		}
	            		
	            		 PDFont font = PDType1Font.HELVETICA_BOLD;
	                     Color color = Color.black; 
	                     PDRectangle rect = page.getMediaBox();                                 
	                     newdocument.addPage( page );
	                     if(contentStream==null)
	                     contentStream = new PDPageContentStream(newdocument, page);
	                     
	                     for (int j = 0, il = finalArray.length; j < il; j++){
	                     contentStream.beginText();
	                     contentStream.setFont( font, 8 );
	                     contentStream.setNonStrokingColor(color);
	                     contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++line));
	                     contentStream.drawString(finalArray[j]);
	                     contentStream.endText();
	                     }
	                     
	                     contentStream.close(); 
	                     String outputFormPDF = outPutForm+formNumber+" OutPut "+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
		            	 outPutForm = outputFormPDF;
	                     newdocument.save(outPutForm);
	                  }                             		
	            	
	            	else{            		
	            		//System.out.println("searchInNextPage");
	            		if(count==1){
	            		EOL= lineListSize;
	            		count = 5;
	            		finalArray1= Arrays.copyOfRange(lineSplit, SOL, EOL);
	            		SOL = 1;            		
	            		}
	            	}
	            }
	            	break;
	            }
	       else{
	    	   //System.out.println("Title not present");	
	        	}
	        } 
	    	newdocument.close();
	    	contentStream.close(); 
	    	actualDocument.close();
	    	//outPutForm= "D:\\PDFValidationDocuments\\OutPutPDF\\3.pdf";
	    	return outPutForm;
	}

}
