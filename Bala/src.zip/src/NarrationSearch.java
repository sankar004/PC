import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;



public class NarrationSearch {
	static String[] result = new String[4];
	
	public static String[] searchForForm(PDDocument actualDocument, String formNumber, String narration) {
		 try {
		 List<PDPage> list = actualDocument.getDocumentCatalog().getAllPages();
	     PDFTextStripper textStripper=new PDFTextStripper(); 
	     String pages= null; 
	     for(int i = 1; i <= list.size(); i++) {
	           
	            textStripper.setStartPage(i); 
	            textStripper.setEndPage(i);
	            pages = textStripper.getText(actualDocument);				
	            String[] lines = pages.split("\\n");
	            String line1 = lines[0];
	            String line2 = lines[1];
	            
	           if(line2.contains(formNumber)||line1.contains(formNumber)){
	        	   pages = pages.replace("\r\n", " ");
	        	  if(pages.contains(narration)){
	        		  System.out.println("Narration found");
	        		  result[3] = "pass";
	        		  result[2] = Integer.toString(i);
	        	  }
	           }
	           else{
	        	   //System.out.println("Form Number not found");
	           }           
	            
	     	}
	     if(result[3]==null){
	    	 result[3] ="Narration not found in form number";
	     }
	     result[0]= formNumber;
	     result[1] = narration;
	    // NarrationExcelCreation();
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		 	}
		return result; 
	}

}
