import java.awt.Rectangle;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.LinkedList;
import java.util.List;

import org.apache.pdfbox.ExtractText;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;


public class NonStackedSequence {	
	
	static int actual_document_no_of_pages,mock_document_no_of_pages;
	static PDDocument actdocument = null,mckdocument = null;
	static String section1="",section2="";		
	static int act_from_page,act_to_page,mck_from_page,mck_to_page;
	static String act_content="",mck_content="",temp_act_content="",temp_mck_content="";	
	static int count = 0;
	static int compare_dot_line=0;
	static int result_counter=0;
	public NonStackedSequence() {
		// TODO Auto-generated constructor stub
	}
	
	
	public static void GetSequence(String actualDocument, String mockDocument,String formNumber,String section[],String compare_type) throws IOException, COSVisitorException {
		
		try
		{
			
			
		actdocument = PDDocument.load( actualDocument );
		actual_document_no_of_pages=NonStackedColumnar.Get_noofpages(actdocument);
		String section_names="";
		int cnter=0;
		int temp_actFormPages[];
		//Based on the number of Forms in the document the from and to page needs to  be extracted
		if(section.length>0)		
		{
			System.out.println(section.length);
			int []actFormPages=new int[section.length*2];;
			for(int i=0;i<section.length;i++)
			{
				System.out.println(i);
				//Get the page numbers that have the respective Form number from the Actual document
				temp_actFormPages=NonStackedColumnar.GetFormpages(actdocument,section[i]);			
				
				actFormPages[cnter]=temp_actFormPages[0];
				cnter++;
				actFormPages[cnter]=temp_actFormPages[1];
				cnter++;
				section_names=section_names+section[i]+"\n";
			}
			
			String Result[] = new String[4];
			String Result_Content="";
			int fail_count=0;
			int frm=2;
			int too=3;
			//System.out.println("LENGTH"+section.length);
			for(int i=0;i<section.length-1;i++)
			{														
						if(actFormPages[frm]>actFormPages[frm-2] && actFormPages[too]>actFormPages[too-2] )
						{							
							Result[0] = "Pass";								
						}
						else
						{
							Result[0] = "Fail";	
							fail_count=fail_count+1;
						}							
						Result_Content=Result_Content+section[i]+" Page:"+(actFormPages[frm-2]+(int)1);
						Result_Content=Result_Content+" To "+(actFormPages[too-2]+(int)1)+ " \n ";						
						if(i==section.length-2){
							Result_Content=Result_Content+section[i+1]+" Page:"+(actFormPages[frm]+(int)1);
							Result_Content=Result_Content+" To "+(actFormPages[too]+(int)1)+ " \n ";	
						}
						frm=frm+2;
						too=too+2;	
				}
			if(fail_count>0)
			{
				Result[0] = "Fail";
				Result[3]="Sequence not matching with the expectation";	
			}
			else
			{
				Result[0] = "Pass";
				Result[3]="Sequence matching with the expectation";	
			}
			Result[1]=section_names;
			Result[2] =Result_Content;
								
			ExcelResult.createExcel(Result,result_counter,"Sequence_Check",PDFContent.ExcelResultFile);						
			result_counter++;
		}
		}
	
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
	}	
}

