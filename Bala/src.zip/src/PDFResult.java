import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

public class PDFResult {
	static PDDocument resultDocument = null;
	static PDPage resultPage = null;
	static PDPageContentStream contentStream = null;
	static int nextline=1;
	static Boolean firstin= true;
	
	public static void createUpdatePDF(String[] result, int i, String formNumber,
			String pdfResultFile) throws IOException, COSVisitorException {
		if (!(new File(pdfResultFile)).exists()) {
		createPDF(pdfResultFile);
		updatePDF(result,formNumber,i,pdfResultFile);
		}
		else{
			openPDF(pdfResultFile);
			updatePDF(result,formNumber,i,pdfResultFile);
		}
		flushall(pdfResultFile);
	}

	private static void flushall(String pdfResultFile) throws IOException, COSVisitorException {
		resultDocument.save(pdfResultFile);
		resultDocument.close();
		
	}

	private static void openPDF(String pdfResultFile) throws IOException {
		resultDocument = PDDocument.load(new File(pdfResultFile));
		List<PDPage> listOfPages = resultDocument.getDocumentCatalog().getAllPages();
		resultPage = (PDPage) resultDocument.getDocumentCatalog().getAllPages().get(listOfPages.size()-1);
		 //PDFont font = PDType1Font.HELVETICA_BOLD;
	        //PDPageContentStream contentStream = new PDPageContentStream(
	        		//resultDocument, resultPage,true,true);
	       // resultPage.getContents().getStream();
		
	}

	private static void updatePDF(String[] result, String formNumber, int i, String pdfResultFile) {
		try {
			
			PDFont font = PDType1Font.HELVETICA_BOLD;
			PDRectangle rect = resultPage.getMediaBox();
			//checkContentStream(1,pdfResultFile);
			//float newY = checkYCoord(1, 3, 10);
			if (nextline > 70)
			{
				PDPage page = new PDPage(PDPage.PAGE_SIZE_LETTER);
		        resultDocument.addPage(page);
		        resultPage= page;
		        nextline =1;
			}
			PDPageContentStream contentStream = new PDPageContentStream(resultDocument, resultPage,true,true);
			if(i==0){			
			contentStream.beginText();
			contentStream.setFont( font, 12 );
			contentStream.setNonStrokingColor(Color.BLUE);
			contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++nextline));
			contentStream.drawString(formNumber);
			contentStream.endText();
			++nextline;
			//firstin = false;
			}
			
			contentStream.beginText();
			contentStream.setFont( font, 7 );
			
			if(result[0].equals("Fail"))
				contentStream.setNonStrokingColor(Color.RED);
			else
			contentStream.setNonStrokingColor(Color.black);
			contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++nextline));
			contentStream.drawString("Result : "+result[0]);
			contentStream.endText();
			
			contentStream.beginText();
			contentStream.setFont( font, 7 );
			contentStream.setNonStrokingColor(Color.black);
			contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++nextline));
			contentStream.drawString("Mock File Line "+(i+1)+" content   : "+result[1]);
			contentStream.endText();
			
			contentStream.beginText();
			contentStream.setFont( font, 7 );
			contentStream.setNonStrokingColor(Color.black);
			contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++nextline));
			contentStream.drawString("Actual File Line "+(i+1)+" content : "+result[2]);
			contentStream.endText();
			
			contentStream.beginText();
			contentStream.setFont( font, 7 );
			contentStream.setNonStrokingColor(Color.red);
			contentStream.moveTextPositionByAmount( 70, rect.getHeight() - 10*(++nextline));
			if(!result[3].equals("No Error"))
				contentStream.drawString("Error in word : "+result[3] );
			contentStream.endText();
			

	        // Make sure that the content stream is closed:
	        contentStream.close();
	        
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

//	private static float checkContentStream(float y, String pdfResultFile) throws IOException {
//		float newY = checkYCoord(y, 3, 10);
//	    if (newY == 700) {
//	        if (contentStream != null) {
//	        	contentStream.close();
//	        }
//
//	        File file = new File(pdfResultFile);
//	        PDPage page = new PDPage(PDPage.PAGE_SIZE_LETTER);
//	        resultDocument.addPage(page);
//	        contentStream = new PDPageContentStream(resultDocument, page);
//	       
//	    }
//	    return newY;
//	    }
//	
//
//	private static float checkYCoord(float y, int lines, int space) {
//	    float newY = y;
//	    for (int i = 0; i < lines; i++) {
//	        if ((newY - space) <= 60) {
//	        newY = 700f;
//	        return newY;
//	        } else {
//	        newY = newY - space;
//	        }
//	    }
//	    return y;
//	    }

	private static void createPDF(String pdfResultFile) throws IOException {
		
		
		resultDocument = new PDDocument();		
		resultPage = new PDPage();
		resultDocument.addPage(resultPage);

}
}
