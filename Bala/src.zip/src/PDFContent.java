import org.apache.pdfbox.exceptions.InvalidPasswordException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.awt.Rectangle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.List;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


/*
* This is an example on how to extract text from a specific area on the PDF document.
*
* Usage: java org.apache.pdfbox.examples.util.ExtractTextByArea &lt;input-pdf&gt;
*
* @author <a href="mailto:ben@benlitchfield.com">Ben Litchfield</a>
* @version $Revision: 1.2 $
*/
public class PDFContent
{
	static String ExcelResultFile = "c:\\PDFValidationDocuments\\Result\\ExcelResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".xls";
	static String pdfResultFile = "c:\\PDFValidationDocuments\\Result\\PDFResult\\FinalResult "+LoadPDFAndCompare.GenratrateCurrentDate()+".pdf";
	static String actualForm;
	static String mockUpForm;
	static String formNumber;
	static String formTitle;
	static String type;
	static String narration;
	static String testcaseName;	
	static String inputFile= "C:\\PDFValidationDocuments\\FormDetails_Compass.xls";
	static HSSFWorkbook inputworkbook = null;
    static HSSFSheet inputworksheet = null;    
    static FileInputStream inputfileIn = null;    
    static String compare_type="";
    
private PDFContent()
{
//utility class and should not be constructed.
}

/*
* This will print the documents text in a certain area.
*
* @param args The command line arguments.
*
* @throws Exception If there is an error parsing the document.
*/
public static void main( String[] args ) throws Exception
{
	
try{
	
testcaseName= //args[1];
		 "TC1";
getInputData();	
}
catch(Exception e){
	e.printStackTrace();
}
}

public static void getInputData() {
	try {
		File inputfiles = new File(inputFile); 		
		inputfileIn = new FileInputStream(inputfiles);
		inputworkbook = new HSSFWorkbook(inputfileIn);
		inputworksheet = inputworkbook.getSheetAt(0);
		Iterator<Row> rowIterator = inputworksheet.iterator();
		boolean firstTime = true; 
		while(rowIterator.hasNext()) {
	        Row row1 = rowIterator.next();
	        Cell cell1 = row1.getCell(0);
	        formNumber = cell1.getStringCellValue();
	        
	        Cell cell2 = row1.getCell(1);
	        if(!(cell2.getStringCellValue().equals("NotRequired")))
	        mockUpForm = cell2.getStringCellValue();
	        else
	        	mockUpForm ="";
	        
	        Cell cell3 = row1.getCell(2);
	        if(!(cell3.getStringCellValue().equals("NotRequired")))
	        formTitle = cell3.toString();
	        else
	        	formTitle="";
	        
	        Cell cell4 = row1.getCell(3);
	        type = cell4.getStringCellValue();
	        
	        
	        Cell cell5 = row1.getCell(4);
	        if(!(cell5.getStringCellValue().equals("NotRequired")))
	        narration = cell5.getStringCellValue(); 
	        else
	        	narration= "";
	        
	        Cell cell6 = row1.getCell(5);
	        if(!(cell6.getStringCellValue().equals("NotRequired")))
	        	actualForm = cell6.getStringCellValue(); 
	        else
	        	actualForm= "";
	        
	        Cell cell7 = row1.getCell(6);
	        String section[]=null;
	        if(!(cell7.getStringCellValue().equals("NotRequired"))){
	        	section= new String [cell7.getStringCellValue().split(";").length];	 
	        	section=cell7.getStringCellValue().split(";");
	        	System.out.println(section.length);
	        }	        

	        Cell cell8 = row1.getCell(7);
	        if(!(cell8.getStringCellValue().equals("NotRequired"))){	        	
	        	compare_type= cell8.getStringCellValue();
	        }
	        
	        if(!firstTime){
	        LoadPDFAndCompare.LoadPDFAndComparePDF(actualForm,mockUpForm,formNumber,formTitle,type,narration,ExcelResultFile,pdfResultFile,testcaseName,section,compare_type);
			//
	        }
	        firstTime= false;
	        
		}
		ExcelResult.SummaryReport(ExcelResultFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (NullPointerException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		finally{
			flushall();
		}

}
private static void flushall() {
	
	if(inputfileIn!=null)
		try {
			inputfileIn.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}
//Extract the fields in Dynamic Form
//PDDocument document1 = null;
//document1 = PDDocument.load( "C:\\PDFValidationDocuments\\ActualPDF\\TRAI2WC000412.pdf" );
//ExtractFields(document1);
public static void ExtractFields(PDDocument document){

	//Try extracting the fields
	try{
	PDAcroForm acro=document.getDocumentCatalog().getAcroForm();
	Object[] a=acro.getFields().toArray();
	for(int i=0;i<a.length;i++){
		System.out.println(a[i].toString());
	}
	}
	catch(Exception e){
		e.printStackTrace();
	}
}
/*
 * *
* This will print the usage for this document.
*/
private static void usage()
{
System.err.println( "Usage: java org.apache.pdfbox.examples.util.ExtractTextByArea <input-pdf>" );
}

}
/*PDRectangle Prec=new PDRectangle();
Prec.setLowerLeftX(1);
Prec.setLowerLeftY(491);
Prec.setUpperRightX(300);
Prec.setUpperRightY(181);
*/

//Rectangle rect = new Rectangle(1, 180, 300, 300);
//stripper.addRegion( "class1", rect );
//List allPages = document.getDocumentCatalog().getAllPages();
//PDPage firstPage = (PDPage)allPages.get( 0 );
//stripper.extractRegions( firstPage );
//System.out.println( "Text in the area:" + rect );
//System.out.println( stripper.getTextForRegion( "class1" ) );


//Try extracting the Regions
//List reg=stripper.getRegions();
//Object[] a=reg.toArray();
/*Object[] a=stripper.getRegions().toArray();
for(int i=0;i<stripper.getRegions().size();i++)
{	
	System.out.println("**************************************************");
	System.out.println("Region "+ (i+1));
	System.out.println("**************************************************");
	
	System.out.println(stripper.getTextForRegion(a[i].toString()));
	System.out.println("**************************************************");
}*/

//Try extracting the Regions
/*
stripper.extractRegions(firstPage);
List re=stripper.getRegions();
for(int i=0;i<re.size();i++)
System.out.println(re.get(i).toString());
*/
//Try extracting the Annotations
/*List annotations = firstPage.getAnnotations();
for( int j=0; j<annotations.size(); j++ )                   
{                        
	PDAnnotation annot = (PDAnnotation)annotations.get( j );  
	System.out.println(annot.getContents());
	//if( annot instanceof PDAnnotationLink )                        
	//{                            
		//PDAnnotationLink link = (PDAnnotationLink)annot;                            
		//PDAction action = link.getAction();                            
		//String urlText = stripper.getTextForRegion( "" + j );                            
//	}	
}
*/

/*
if(start_point>0 && end_point==0 && (sec_name.trim().contains("GENERAL SECTION")==false)){
 */
/*Rectangle rec_left_text = new Rectangle(x1, y1,310, y2);
stripper.addRegion( "left_text"+counter, rec_left_text );
stripper.extractRegions( firstPage );
text_content=stripper.getTextForRegion( "left_text"+counter ) ;
System.out.println( "Text:" + text_content );		
left_text=left_text+text_content;*/

//System.out.println( "Text:" + left_text );
/* Rectangle rec_right_text = new Rectangle((int) (x2/2)+1, y1, x2, y2);
stripper.addRegion( "right_text"+counter, rec_right_text );
stripper.extractRegions( firstPage );
text_content=stripper.getTextForRegion( "right_text"+counter ) ;
right_text=right_text+text_content; 
}*/

//String section_text=left_text+right_text;
//System.out.println( "Text:" + section_text );
/*x1=1;
y1=start_point+10;
x2=(int) (wd/2);
y2=end_point-start_point;
counter=1;

Rectangle r1 = new Rectangle(x1,y1,x2,y2);
stripper.addRegion( "GenSect_Left", r1 );
stripper.extractRegions( firstPage );
System.out.println( stripper.getTextForRegion( "GenSect_Left" ) );*/


//Extract "GENERAL SECTION" Right side content
/*x1=x2;
y1=start_point+10;
String GenSect_Right="";
counter=counter+1;
while(y1<=ht){
Rectangle r2 = new Rectangle(x1, y1, x2, y2);
stripper.addRegion( "GenSect_Right"+counter, r2 );
stripper.extractRegions( firstPage );
String sec_name1=stripper.getTextForRegion( "GenSect_Right"+counter ) ;
counter=counter+1;
System.out.println( sec_name1 );
//GenSect_Right=GenSect_Right+sec_name;
y1=y1+10;
}*/


/*
x1=1;
y1=1;
x2=(int) (wd/2);
y2=10;
counter=1;
while(y1<=ht){
Rectangle r1 = new Rectangle(x1, y1, x2, y2);
stripper.addRegion( "R"+counter, r1 );
stripper.extractRegions( firstPage );
System.out.println( "Text in the area:" + r1 );
System.out.println( stripper.getTextForRegion( "R"+counter ) );
counter=counter+1;
y1=y1+10;

}
*/
