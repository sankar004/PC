import java.awt.Rectangle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.pdfbox.ExtractText;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class NonStackedColumnar {	
	
	static int actual_document_no_of_pages,mock_document_no_of_pages;
	static PDDocument actdocument = null,mckdocument = null;
	static String section1="",section2="";
	static int actFormPages[],mockFormPages[];
	static int act_from_page,act_to_page,mck_from_page,mck_to_page;
	static String act_content="",mck_content="",temp_act_content="",temp_mck_content="";	
	static int count = 0;
	static int compare_dot_line=0,first_time=0;
	static FileOutputStream fout;
	static String global_compare_type="";
	static String spell_check_text="";
	public NonStackedColumnar() {
		// TODO Auto-generated constructor stub
		
		
	}
	public static int Get_noofpages(PDDocument document)
	{
		List allPages = document.getDocumentCatalog().getAllPages();
		return allPages.size();
	}
	public static int[] GetFormpages(PDDocument document, String form_number)
	{
		int from_page=-1, to_page=-1,first_time=0;
		int[] page_return=new int[2];
		try
		{
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition( true );
			List allPages = document.getDocumentCatalog().getAllPages();			
			for(int i=0;i<allPages.size();i++)
			{
				PDPage firstPage = (PDPage)allPages.get( i );				
				stripper.extractRegions( firstPage );
				//Add Regions and Extract the contents from the Region/*
				PDRectangle pageSize = firstPage.findMediaBox();
				float ht=pageSize.getHeight();
				float wd=pageSize.getWidth();
				//System.out.println( "Page Width:" + wd );
				//System.out.println( "Page Height:" + ht );
				int x1,y1,x2,y2;
				x1=1;
				y1=(int) ht-60;
				x2=(int) (wd);
				y2=60;
				Rectangle footer = new Rectangle(x1, y1,(int) (x2/2), y2);
				stripper.addRegion( "footer", footer);
				stripper.extractRegions( firstPage );	
				String footer_text=stripper.getTextForRegion( "footer" );
				if(footer_text.contains(form_number))
				{
					if(first_time==0)
					{
						from_page=i;
						first_time=1;
					}
					else
					{
						to_page=i;
					}
				}				
			}
			if(from_page>-1 && to_page==-1)
			{
				to_page=from_page;				
			}
			page_return[0]=from_page;
			page_return[1]=to_page;
			return page_return;
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			
		}
		return page_return;
	}
	//Get the section contents
	public static String GetSectionContent(String act_mock,PDDocument document)
	{	
		String section_content="";
		int from_page,to_page;
		int start_page_no;
		if(act_mock=="actual")
		{
			from_page=act_from_page;
			to_page=act_to_page;			
		}
		else
		{
			from_page=mck_from_page;
			to_page=mck_to_page;
		}
		try
		{			
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition( true );
			List allPages = document.getDocumentCatalog().getAllPages();
			int start_point=0;			
			int end_point=0;
			start_page_no=-1;
				for(int i=from_page;i<=to_page;i++)
				{
					PDPage firstPage = (PDPage)allPages.get( i );
					stripper.extractRegions( firstPage );
					//Add Regions and Extract the contents from the Region/*
					PDRectangle pageSize = firstPage.findMediaBox();
					float ht=pageSize.getHeight();
					float wd=pageSize.getWidth();
					System.out.println( "Page Width:" + wd );
					System.out.println( "Page Height:" + ht );
					int x1,y1,x2,y2;
					//Find the starting point and ending point of the section
					x1=1;
					y1=1;
					x2=(int) (wd);
					y2=10;
					int counter=1;					
					int no_of_lines=0;
					String left_text="",right_text="";
					//String General_section="";					
					while(y1<=(int)ht-30)
					{
						Rectangle r1 = new Rectangle(x1, y1, x2, y2);
						stripper.addRegion( "R"+counter, r1 );
						stripper.extractRegions( firstPage );
						String sec_name=stripper.getTextForRegion( "R"+counter ) ;
						//System.out.println( stripper.getTextForRegion( "R"+counter ) );
						if(sec_name.trim().contentEquals(section1)){
							start_point=y1+10;
							start_page_no=i;
							System.out.println( "Starting Point:" + r1 );
						}
						if(sec_name.trim().contentEquals(section2)){
							end_point=y1-10;
							no_of_lines=end_point-start_point;
							System.out.println( "End Point:" + r1 );
							break;
						}	
						counter=counter+1;	
						y1=y1+10;
					}
					//if the section does not end in the same page
					if(start_point>0 && end_point==0 && start_page_no==i)
					{						
						no_of_lines=(int)ht-start_point-30;						
					}	
					//if the section does not end in the same page and the start point is in a different page
					if(start_point>0 && end_point==0 && start_page_no!=i)
					{						
						start_point=1;
						no_of_lines=(int)ht-start_point-30;						
					}	
					//Last section
					if(start_point>0 && section2=="" && i==to_page && end_point==0)
					{	
						if(start_page_no==i)
						no_of_lines=(int)ht-start_point-30;		
						else if(start_page_no<i)
						{
							start_point=1;
							no_of_lines=(int)ht-start_point-30;
						}
					}
						y2=no_of_lines;
						System.out.println(no_of_lines);
						PDFTextStripperByArea stripper1 = new PDFTextStripperByArea();
						stripper1.setSortByPosition( true );	
						Rectangle rec_left_text = new Rectangle(1, start_point,(int) (x2/2), y2);
						stripper1.addRegion( "left", rec_left_text);
						stripper1.extractRegions( firstPage );	
						left_text=stripper1.getTextForRegion( "left" );
						
						PDFTextStripperByArea stripper2 = new PDFTextStripperByArea();
						stripper2.setSortByPosition( true );	
						Rectangle rec_right_text = new Rectangle((int) (x2/2), start_point,x2, y2);
						stripper2.addRegion( "right", rec_right_text);
						stripper2.extractRegions( firstPage );	
						right_text=stripper2.getTextForRegion( "right" );
						
						section_content=section_content+left_text+right_text;
						//if both the start section and end section are found then break from for loop
						if(start_point>0 && end_point>0)
						{	
							break;
						}
						//if the section does not end in the same page
						if(start_point>0 && end_point==0)
						{						
							start_point=1;
						}	
				}
					
		
		}
		catch(Exception e)
		{
			
		}
		return section_content;
	}
	//Compares the content sectionwise 
	public static void CompareSectionContent(String section_name, int j,String compare_type)
	{	
		try
		{
		act_from_page=actFormPages[0];
		act_to_page=actFormPages[1];
		mck_from_page=mockFormPages[0];
		mck_to_page=mockFormPages[1];		
		String section=section_name;
		int compare=0;
		if(compare_type.matches("Word"))
		{
			compare=1;
			global_compare_type="Word";
		}
		else if(compare_type.matches("Character"))
		{
			compare=2;
		}
		else if(compare_type.matches("By_line_dot"))
		{
			compare=3;
		}
		switch(compare)
		{
		case 1:
			act_content=GetSectionContent("actual",actdocument);
			mck_content=GetSectionContent("mock",mckdocument);
			SpellCheck(act_content,mck_content);
			break;
		case 2:
			act_content=GetSectionContent("actual",actdocument).replaceAll("\r\n","").replaceAll(" ","");
			mck_content=GetSectionContent("mock",mckdocument).replaceAll("\r\n","").replaceAll(" ","");
			break;
		case 3:
			//act_content=GetSectionContent("actual",actdocument).replaceAll("\r\n"," << new line >> ");
			//mck_content=GetSectionContent("mock",mckdocument).replaceAll("\r\n"," << new line >>");
			act_content=GetSectionContent("actual",actdocument).replaceAll("\r\n"," ");
			mck_content=GetSectionContent("mock",mckdocument).replaceAll("\r\n"," ");
			CompareLineByDot(mck_content,act_content,PDFContent.formNumber,PDFContent.ExcelResultFile,PDFContent.pdfResultFile);
			break;
		}
			//act_content=GetSectionContent("actual",actdocument);
			//mck_content=GetSectionContent("mock",mckdocument);
		
			//Comparing at character level
			//act_content=GetSectionContent("actual",actdocument).replaceAll("\r\n","").replaceAll(" ","");
			//mck_content=GetSectionContent("mock",mckdocument).replaceAll("\r\n","").replaceAll(" ","");
			
			//temp_act_content=GetSectionContent("actual",actdocument).replaceAll("\r\n"," ");
			//temp_mck_content=GetSectionContent("mock",mckdocument).replaceAll("\r\n"," ");;
		if(compare!=3)
		{
			System.out.println("Actual Content:"+ act_content);
			System.out.println("Mock Content:"+ mck_content);
			diff_match_patch d=new diff_match_patch();
			LinkedList diff=d.diff_main(mck_content, act_content);
			String ss=d.diff_prettyHtml(diff);
			int rr=d.diff_levenshtein(diff);
			String Result[] = new String[4];
			if(rr==0){				
				System.out.println("No Error Found:" + ss);				
				Result[0] = "Pass";	
				}
			else{
				System.out.println("Error Found:" + ss); 				
				Result[0] = "Fail";	
			}		
			Result[1] =mck_content;
			Result[2] =act_content;
			Result[3]= "C:\\PDFValidationDocuments\\Result\\HtmlResult\\"+section+"_"+LoadPDFAndCompare.GenratrateCurrentDate()+".html";
			CreateHtml(ss,Result[3]);
			
			//ExcelResult.createExcel(Result,j,PDFContent.formNumber+"_"+PDFContent.compare_type,PDFContent.ExcelResultFile);
			
			//PDFResult.createUpdatePDF(Result,j,PDFContent.formNumber,PDFContent.pdfResultFile);
			//CompareWordByWordIfLineFails.compareWordByWord(mck_content,act_content);
		}
		}
		catch(Exception e)
		{
			
		}
		
	}
	public static void SpellCheck(String act, String mck)
	{
		try
		{
		//Create the Actual content Word document
			//POIFSFileSystem fs=new POIFSFileSystem();	
			File file,file1;
			/*if(first_time==0){
			 file = new File("C:\\PDF\\empty.doc");
			}*/
				file = new File("C:\\PDF\\empty.doc");		
				fout=new FileOutputStream("C:\\PDF\\empty.doc");			
				fout.write(section1.getBytes());
				fout.write("\n".getBytes());
				fout.write(act.getBytes());
				fout.write("\n".getBytes());
				first_time++;
				fout.close();
				file1 = new File("C:\\PDF\\testfile.txt");
		    	Runtime.getRuntime().exec("wscript C:\\PDF\\spellcheck.vbs");		
		    	TimeUnit.SECONDS.sleep(10);
		    	FileInputStream fin=new FileInputStream("C:\\PDF\\testfile.txt");
		    	//byte[] everything = IOUtils.toByteArray(fin);
		    	int content;
		    	String es="";
				while ((content = fin.read()) != -1) {
					// convert to char and display it
					System.out.print((char) content);
					es=es+(char) content;
				}
				System.out.println(es);
		    	
		    	if(es!=null && es!=""){
		    		spell_check_text="<tr><td colspan='4'>"+ es +"</td></tr>";		    		
		    	}
		    	else
		    	{
		    		spell_check_text=null;
		    	}
		    	fin.close();		    	
		    	file1.delete();
		    	file1=null;	
		    	file.delete();
				file=null;
			//act=act.replace("\r\n"," ");
			//String actlines[] = act.split("\\.");
			//fs.createDocument(f,"this is test");			
			
			//Runtime.getRuntime().exec("wscript C:\\PDF\\spellcheck.vbs");
			
		//Create the Mock content Word document
		
		//Do a spell check
		}
		catch(Exception e)
		{
		System.out.println(e.getMessage());
		}
	}
	public static void CompareLineByDot(String mockPages,
			String outputPages, String formNumber, String excelResultFile,String pdfResultFile) throws IOException, COSVisitorException {
		String[] mocklLineSplit = null;
		String[] outputlLineSplit = null ;
		
		mocklLineSplit = mockPages.split("\\.");
		outputlLineSplit = outputPages.split("\\.");
		
		boolean mockLinehighest = mocklLineSplit.length > outputlLineSplit.length;
		int linelowest;
		int wordlowest;
		String Result[] = new String[4];
		
		
		if(mockLinehighest)
			linelowest = outputlLineSplit.length;
		else 
			
			linelowest = mocklLineSplit.length;
		System.out.println(linelowest);
		for(int i=0,j=0; i< linelowest || j< linelowest ;i++,j++){
			
			String mck=mocklLineSplit[i].trim().replaceAll(" ","");
			String ot=outputlLineSplit[j].trim().replaceAll(" ","");
			if(mck.equals(ot))
			{
				Result[0] = "Pass";
				Result[1] = mocklLineSplit[i];
				Result[2] = outputlLineSplit[j];
				Result[3]= "No Error";
			}
			else{
				
				String[] mockWordsinLine = mocklLineSplit[i].split(" ");
				System.out.println("---------------------------------------");
				System.out.println("Line "+ i+ " "+mocklLineSplit[i]);
				String[] outPutWordinLine = outputlLineSplit[i].split(" ");
				System.out.println(outputlLineSplit[i]);
				boolean mockword = mockWordsinLine.length > outPutWordinLine.length;
				if(mockword)
					wordlowest = outPutWordinLine.length;
				else 
					wordlowest = mockWordsinLine.length;
				int l;	
				for(l=0;l<wordlowest;l++){
					
					if(mockWordsinLine[l].equals(outPutWordinLine[l]))
					{
						Result[0] = "Pass";
					}
					else{
						Result[0] = "Fail";
						Result[1] = mocklLineSplit[i];
						Result[2] = outputlLineSplit[j];
						if(outPutWordinLine[l].equals("")){
							outPutWordinLine[l] = "<space>";
						}
						if(l>0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l] +" " + outPutWordinLine[l+1];
						else if(l>0 & l==(wordlowest-1))
							Result[3] = outPutWordinLine[l-1] + " " + outPutWordinLine[l];
						else if(l==0 & (outPutWordinLine[l].length()==1))
							Result[3] = outPutWordinLine[l];
						else if(l==0 & l!=(wordlowest-1))
							Result[3] = outPutWordinLine[l];
						else
							Result[3] = outPutWordinLine[l];
						
						break;
					}
				}
				if(l==wordlowest){
					Result[0] = "Fail";
					Result[1] = mocklLineSplit[i];
					Result[2] = outputlLineSplit[j];
					if(mockword)
						Result[3]= mocklLineSplit[i].substring(outPutWordinLine.length, mockWordsinLine.length);
					else
						Result[3]= outputlLineSplit[i].substring(mockWordsinLine.length, outPutWordinLine.length);
				}
				
			}

			if(Result[0]=="Fail"){				
				count++;
			}
			else{
				count=0;
			}	
			
			PDFResult.createUpdatePDF(Result,compare_dot_line,formNumber+"_"+PDFContent.compare_type,pdfResultFile);
			ExcelResult.createExcel(Result,compare_dot_line,formNumber+"_"+PDFContent.compare_type,excelResultFile);
			compare_dot_line=compare_dot_line+1;
		}		
		count =0;
	}
	
	public static void CreateHtml(String s,String section){
		

	    try {
	    	PrintStream out = new PrintStream(new FileOutputStream(section));
	    	byte[] bb=s.getBytes();
	    	
	    	out.write(bb);
	    	
	    	
	    		
	    } 
	catch (IOException x) {
	      System.out.println("Exception thrown: " + x);
	    }

	}
	
	public static void ExtractContents(String actualDocument, String mockDocument,String formNumber,String section[],String compare_type) throws IOException, COSVisitorException {
		actdocument = PDDocument.load( actualDocument );
		actual_document_no_of_pages=Get_noofpages(actdocument);
		
		mckdocument = PDDocument.load( mockDocument );
		mock_document_no_of_pages=Get_noofpages(mckdocument);	
		
		//Get the page numbers that have the respective Form number from the Actual document
		actFormPages=GetFormpages(actdocument,formNumber);
		
		//Get the page numbers that have the respective Form number from the Mock document
		mockFormPages=GetFormpages(mckdocument,formNumber);
		
		//Based on the number of sections in the document the contents needs to extracted
		if(section.length>0)		
		{
			//System.out.println(section.length);
			
			for(int i=0;i<section.length;i++)
			{
				System.out.println(i);
				if(i<section.length-1)
				{
					section1=section[i];
					section2=section[i+1];
					CompareSectionContent(section1,i,compare_type);
				}
				else if(i==section.length-1)
				{
					section1=section[i];
					section2="Last_$$Section$$";
					//System.out.println(section1);
					CompareSectionContent(section1,i,compare_type);
				}
			}
		}
		
		
		
		}
	
}
