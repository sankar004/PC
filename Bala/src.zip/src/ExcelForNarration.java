import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;


public class ExcelForNarration {

	public ExcelForNarration() {
		// TODO Auto-generated constructor stub
	}

	public static void createOpenExcelForNarrative(String actualForm,
			String formNumber, String[] result, String excelResultFile) throws IOException {
		
		File file = new File(excelResultFile);    
		if (!file.exists()) {
			ExcelResult.createDocument(formNumber,excelResultFile,"Narrative");
			ExcelResult.updateNarrativeDocument(formNumber,result);
		}	
		else{
			ExcelResult.openDocument(formNumber,excelResultFile,"Narrative");
			ExcelResult.updateNarrativeDocument(formNumber,result);
		}
			
		ExcelResult.flushall();
		
	}

}
